#!/bin/bash

usage() {
echo "Usage: for $0 :
-H        host address of SOLR server
-p        port of SOLR server
-v        version difference of replication between master and slave
-t        last successfully sync time
-c        core name"
exit
}

HOST="";

while getopts "hp:vtH:c:" opt; do
  case $opt in
    H)
      HOST=$OPTARG;
      ;;
    p)
      PORT=$OPTARG;
      ;;
    v)
      CHECK_METHOD="version";
      ;;
    t)
      CHECK_METHOD="time";
      ;;
    h)
      usage ;
      ;;
    c)
      CORE_NAME=$OPTARG;
      ;;
  esac
done

if [ -z "$HOST" ];then
HOST=localhost
fi

if [ -z "$PORT" ];then
PORT=14083
fi

if [ -z "$CHECK_METHOD" ];then
echo -e "\dde[33mError: method definition is missing! \e[0m"
usage
exit
fi

if [ -z "$CORE_NAME" ];then
CORE_NAME=jobcore
fi


# Check if host is a master or a slave solr server
CHECK_MASTER=`curl --max-time 10 --silent http://${HOST}:${PORT}/solr/${CORE_NAME}/replication?command=details | xmllint --format - | grep -c 'masterUrl'  `
        if [ $CHECK_MASTER -eq "0" ];then
                echo "The seleted server is a master server. Exiting..."
                exit
        fi
                                             
