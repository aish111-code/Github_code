#!/bin/bash
#
# Read /prod/particitions to discover linux disk devices
#
# usage:   $0 discovery
#

if [[ -z $1 ]]; then
  exit
fi

function findLogicalDevices () {
  devices=$(cat /proc/partitions | grep -v name |awk '{ print $NF }' | sed "s/ //g"| grep "^dm")
  for dev in $(echo $devices)
  do
    if [[ -z ${devList[@]} ]]; then
      devList=($dev);
    else
      devList=("${devList[@]}" ${dev})
    fi
  done
}

case $1 in
	"discovery")
	  findLogicalDevices
	  if [[ ! -z ${devList[@]} ]]; then
	    count=0
	    echo "{"
	    echo -e "\"data\":["
	    for device in "${devList[@]}"
	      do
	        count=$(($count+1))
	        if [[ $count -lt ${#devList[@]} ]]; then
	          echo -e "{\"{#DEVICE}\":\"$device\"},"
	        else
	          echo -e "{\"{#DEVICE}\":\"$device\"}"
	        fi
	      done
	    echo -e "]"
	    echo "}"
	  fi
	;;
*)
	echo "unknown param"
	;;
esac