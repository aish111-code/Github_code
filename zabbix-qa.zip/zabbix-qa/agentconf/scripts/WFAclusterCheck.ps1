Param(
	[string]$check= "sc2wfadbiis02"
	
)

Try{
$count = 0
Import-Module FailoverClusters
$clusG = Get-ClusterGroup
ForEach ($_.name in $clusG) {
	$gName = $_.name.ToLower()
	$val = $gName.Contains($check.ToLower())
	if($val -eq "True") 
		{
			$count = 10
			$resourceState = $_.State 
			$clusOwn = $_.ownernode.ToString()
			$clusNode = $clusOwn.Substring($clusOwn.length -2, 2)
				if($resourceState -eq "Online" -and ($clusNode -eq '01' -or $clusNode -eq '03' -or $clusNode -eq '05' -or $clusNode -eq '07')){
				$res = 1}
				elseif($resourceState -eq "Online" -and ($clusNode -eq '02' -or $clusNode -eq '04' -or $clusNode -eq '06' -or $clusNode -eq '08')){
				$res = 2}
	Else {
		$res = 99}
		$res
}}
if($count -eq 0){
$res = -10
$res}
		
		}

Catch
{
$res = -1
$res
}
