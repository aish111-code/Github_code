cd /local/customers/plateau/plateau-talent-management/logs
LogName="$(ls -ltrh TMS-*.log | grep -v perflog | awk -F" " '{print $9}')"
du -s $LogName |awk -F" " '{printf$1}'
