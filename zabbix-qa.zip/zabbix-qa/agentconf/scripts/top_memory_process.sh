#!/bin/bash
#####################################################
# top_memory_process
# returns names of most memory consuming processes

ps axwwo %mem,pid,user,cmd | sort -k 1 -r -n|sed -e '/^%/d'|head -1|awk '{print "MEM:"$1 "% PID:" $2 " CMD: " $4,$5}'

