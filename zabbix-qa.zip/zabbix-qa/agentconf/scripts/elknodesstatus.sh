#!/bin/bash
nodes_stat=`curl -k -u "zabbix_user:Zabb1x@123" "https://$1:9200/_cat/nodes" 2> /dev/null | grep $1 | wc -l`
if [ $nodes_stat == "1" ]; then
        echo "OK"
else
        echo "NOT OK"
fi
