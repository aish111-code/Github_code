#!/bin/bash

curl -k http://$1:1090/status/format/json 2> /dev/null| awk -F "$2" '{print $2}' | awk -F ':' '{print $2}' | awk -F ',' '{print $1}'
