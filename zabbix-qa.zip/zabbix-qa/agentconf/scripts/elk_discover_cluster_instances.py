#!/usr/bin/python -W ignore
import requests
import json
import re
from pprint import pprint
import sys
import os
import socket
import urllib3
import warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

urls = []
cluster_Region=sys.argv[1]
if cluster_Region == "EUROPE":
   clusters={'Analytics':'d985e2b66da74bd1860a09a9347c3506','Bizx Operations':'90d1db8601c543058dde31f381000113','Database Operations':'6ab46e5afaec454092a9b0d564275fd5','Platform Operations':'53aad80ec9c741469f3300e6403dc12b','Bizx Engineering':'b848ac0c9a8b48e8b99db3a4f96218d4'}

   sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   primary = sock.connect_ex(('10.117.214.158',12443))

   secondary = sock.connect_ex(('10.117.210.75',12443))

   tertiary = sock.connect_ex(('10.117.213.10',12443))

   if primary == 0:
       eu_mgt_ip = "10.117.214.158"
   elif secondary == 0:
       eu_mgt_ip = "10.117.210.75"
   else:
       eu_mgt_ip = "10.117.213.10"

   #print eu_mgt_ip
   data = []
   for name,id in clusters.iteritems(): 
       headers = {
    'Content-Type': 'application/json',
}     
       url = "https://{0}:12443/api/v1/clusters/elasticsearch/{1}".format(eu_mgt_ip,id)
       #url = "https://10.117.214.158:12443/api/v1/clusters/elasticsearch/d985e2b66da74bd1860a09a9347c3506"
        
       urls.append(url) 
       #print urls
       response = requests.get(url, headers=headers, verify=False, auth=('readonly', '6R2hOT6llteJ2Ns7E8xBqf2C097Xwjvp55P2ezeHKbV'))
       masters = response.json().get('elasticsearch', {}).get('master_info', {}).get('masters', [])    
       for master in masters:
           instance_names = master.get('instances', [])
      
       for i in instance_names:
            data.append({'{#NAME}': name, '{#ID}': id, '{#MGT_IP}': eu_mgt_ip, '{#INSTANCE}': i, '{#REGION}': cluster_Region})
   zabbix_template_data = {'data': data}
   print(json.dumps(zabbix_template_data, indent=4))

 
elif cluster_Region == "US":
     clusters={'Analytics':'18e5c7e47f52440faae74078e6404f0d','Bizx Operations':'07ece18c8a2e418b8e62ee16291d400f','Database Operations':'2bbc31a73f0b42678e6580aba8fb0f8f','Platform Operations':'528e55b3f7cf403ca4f1ab002c1977fd','Bizx Engineering':'fc62b1fbe7d144178ccadc719f63833c'}

     sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
     primary = sock.connect_ex(('10.8.200.140',12443))

     secondary = sock.connect_ex(('10.8.200.143',12443))

     tertiary = sock.connect_ex(('10.8.200.144',12443))

     if primary == 0:
        us_mgt_ip = "10.8.200.140"
     elif secondary == 0:
        us_mgt_ip = "10.8.200.143"
     else:
        us_mgt_ip = "10.8.200.144"

     #print us_mgt_ip
     data = []
     for name,id in clusters.iteritems():
         headers = {
    'Content-Type': 'application/json',
}
         url = "https://{0}:12443/api/v1/clusters/elasticsearch/{1}".format(us_mgt_ip,id)
         #url = "https://10.117.214.158:12443/api/v1/clusters/elasticsearch/d985e2b66da74bd1860a09a9347c3506"

         urls.append(url)
         #print urls
         response = requests.get(url, headers=headers, verify=False, auth=('readonly', 'yBbdPpIwryDri1b5dh1IbKiEe0t1IeH1duCyVNmOwUW'))
         masters = response.json().get('elasticsearch', {}).get('master_info', {}).get('masters', [])
         for master in masters:
             instance_names = master.get('instances', [])

         for i in instance_names:
            #print i, name, id, us_mgt_ip
            data.append({'{#NAME}': name, '{#ID}': id, '{#MGT_IP}': us_mgt_ip, '{#INSTANCE}': i, '{#REGION}': cluster_Region})
     zabbix_template_data = {'data': data}
     print(json.dumps(zabbix_template_data, indent=4))


