#!/bin/bash

output=$(docker exec agent-server pgrep -fc 'agent-server' || echo 0)
echo "$output"

exit 0
