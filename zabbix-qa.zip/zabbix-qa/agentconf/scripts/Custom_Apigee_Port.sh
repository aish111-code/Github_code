import subprocess
import json
import re
#from subprocess import PIPE, run
#result = run(['hostname'], stdout=PIPE, stderr=PIPE, universal_newlines=True)
#hostname = result.stdout.split('\n')[0]
result =  subprocess.check_output("hostname",shell=True)
hostname = str(result.decode().strip())
def getData(sample):
    output = subprocess.check_output("cat "+sample+"| grep -v '127.0.0.1' | grep 'listen' | sort | uniq -c | awk '{print $3}' | sed 's/.*://' | tr '\n' ','", shell=True)
    output = output.decode().strip()

    list2 = output.split(',')

    server_data = []
    val="{#APIGEEPORT3}"
    for element in list2[0:-1]:
        server_data.append({val:str(element)})
    json_data = json.dumps(server_data)
    return json_data

# Prod Data
if re.match("^pc.*apgmtmp",hostname):
    print(getData("/etc/zabbix/apigee/hcmprod_*.conf"))
elif re.match("^pc.*apgcf",hostname):
    print(getData("/etc/zabbix/apigee/hcmprodcf*.conf"))
elif re.match("^pc.*apglms",hostname):
    print(getData("/etc/zabbix/apigee/hcmprodlms*.conf"))
#Preview Data
elif re.match("^sc.*apgmtmp",hostname):
    print(getData("/etc/zabbix/apigee/hcmpreview_*.conf"))
elif re.match("^sc.*apgcf",hostname):
    print(getData("/etc/zabbix/apigee/hcmpreviewcf*.conf"))
elif re.match("^sc.*apglms",hostname):
    print(getData("/etc/zabbix/apigee/hcmprevlms*.conf"))
# Sales Data
elif re.match("^ss.*apgmtmp",hostname):
    print(getData("/etc/zabbix/apigee/hcmsales_*.conf "))
elif re.match("^ss.*apgcf",hostname):
    print(getData("/etc/zabbix/apigee/hcmsalescf*.conf"))
elif re.match("^ss.*apglms",hostname):
    print(getData("/etc/zabbix/apigee/hcmsaleslms*.conf"))
elif re.match("^pd.*apglms",hostname):
    print(getData("/etc/zabbix/apigee/hcmdrlms*.conf"))
elif re.match("^pd.*apgcf",hostname):
    print(getData("/etc/zabbix/apigee/hcmdrcf*.conf"))
elif re.match("^pd.*apgmtmp",hostname):
    print(getData("/etc/zabbix/apigee/hcmdr_*.conf"))
elif re.match("^dd.*apglms",hostname):
    print(getData("/etc/zabbix/apigee/hcmdevdemolms*.conf"))
elif re.match("^dd.*apgcf",hostname):
    print(getData("/etc/zabbix/apigee/hcmdevdemocf*.conf"))
elif re.match("^dd.*apgmtmp",hostname):
    print(getData("/etc/zabbix/apigee/hcmdevdemo_*.conf"))
elif re.match("^ds.*apglms",hostname):
    print(getData("/etc/zabbix/apigee/hcmdevshowlms*.conf"))
elif re.match("^ds.*apgcf",hostname):
    print(getData("/etc/zabbix/apigee/hcmdevshowcf*.conf"))
elif re.match("^ds.*apgmtmp",hostname):
    print(getData("/etc/zabbix/apigee/hcmdevshow_*.conf"))
else:
    print("Necessary files not found")

