##############################################
# Script to detect individual heap memory for
# Kibana logstash Elastic serach
#############################################
#!/bin/bash
#!/bin/bash
i=`echo "$1"|awk -F '_' '{print $1}'`
j=`echo "$1"|awk -F '_' '{print $2}'`
if [[ "$j" == "heap" ]];then
curl -s -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_nodes/$i/stats?pretty"|grep -i "heap_max_in_bytes"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g'
exit
fi
curl -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cat/nodes" 2> /dev/null | grep $i | awk '{print $2}'
