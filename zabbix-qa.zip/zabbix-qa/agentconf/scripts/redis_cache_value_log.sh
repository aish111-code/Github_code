#!/bin/bash

LOGFILEDATEPATTERN=$(date +"%Y-%m-%d")
LOGFILENAME="redis_cache_value_$LOGFILEDATEPATTERN.log"
LOGFILENAMEPATTERN="redis_cache_value_*.log"
LOGFILEFOLDER="/var/log/zabbix/custom_redis_logs"
LOGPATH="$LOGFILEFOLDER/$LOGFILENAME"
TEMPDATA="/var/log/zabbix/redis_cache_value_out"
REDISHOST=$(hostname)

wget -O $TEMPDATA  http://$REDISHOST:8080/cache  > /dev/null 2>&1
mkdir -p $LOGFILEFOLDER

PARAMETERS=("LocalCacheCapacity" "LocalCacheMemory" "LocalCacheSize" "LocalCacheHit" "LocalCacheMiss" "RemoteCacheL1Hit" "RemoteCacheL1Miss" "RemoteCacheL2Hit"
  "RemoteCacheL2Miss" "LocalCacheEvictionPolicy" "GetAverageTime" "GetAverageFromRemoteTime" "putAverageTime" "GetCacheCounter" "PutCacheCounter")

REDIS=`cat $TEMPDATA | grep -i -e MIXEDSFEDIS -e SUPERSFEDIS | cut -d">" -f3|cut -d"<" -f1`
if [ "$REDIS" == "" ]
then
REDIS="NO_MIXEDSFEDIS_CACHE_FOUND"
fi
for n in $(echo $REDIS)
do
  if [[ -z ${List[@]} ]]; then
    List=($n);
  else
    List=("${List[@]}" ${n})
  fi
done

FINALLOGSTRING=""
DATESTRING=$(date +"%a %b %d %H:%M:%S %Y")
if [[ ! -z ${List[@]} ]]; then
for cache in "${List[@]}"
do
  LOGSTRING="$DATESTRING CacheName=$cache"
  for param in "${PARAMETERS[@]}"
  do
    VALUE=`grep "Name>$cache</Name" $TEMPDATA | grep -i -e MIXEDSFEDIS -e SUPERSFEDIS | awk -F"$param" '{print $2}' | sed 's/>//g' | cut -d"<" -f1`
    if [ "$VALUE" != "" ]; then
      VALUE_STRING="$param=$VALUE"
      LOGSTRING="$LOGSTRING, $VALUE_STRING"
    fi
  done

  if [ "$FINALLOGSTRING" == "" ]; then
    FINALLOGSTRING="$LOGSTRING"
  else
    FINALLOGSTRING="$FINALLOGSTRING\n$LOGSTRING"
  fi
done
fi

find $LOGFILEFOLDER -name "$LOGFILENAMEPATTERN" -type f -mtime +0 -delete
echo -e "${FINALLOGSTRING}" >> $LOGPATH
