#Redis Cache script
#Author: Sreekanth K P
#Version: 1.0, 12/04/2016

#!/bin/bash

VALUE=`grep "Name>$1</Name" /tmp/cache_output |grep -i -e MIXEDSFEDIS -e SUPERSFEDIS|awk -F"$2" '{print $2}'|sed 's/>//g'|cut -d"<" -f1`
if [ "$VALUE" == "" ]
then
echo "9999999"
else
echo $VALUE
fi

