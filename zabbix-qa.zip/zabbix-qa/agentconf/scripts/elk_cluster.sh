#!/bin/bash

#if [[ "$1" == "dc10" ]];then
#       ip_string="10.10.199.27_10.10.199.23_10.10.199.22_10.10.199.21"
        ip_string="$1"
#fi
IFS=$'_'

for i in `echo "$ip_string"`
do

        nodes_stat=`curl -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cat/nodes" 2> /dev/null | grep $i | wc -l`
        if [ $nodes_stat == "1" ]; then
                if [[ "$2" == "health" ]];then
                        curl -s -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cluster/health?pretty"|grep -w "$3"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g'
                elif [[ "$2" == "stats" ]];then
                        curl -s -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cluster/stats?pretty"|grep -w "$3"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g'
                elif [[ "$2" == "disk" ]];then
                        total=`curl -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cluster/stats?human&pretty" 2> /dev/null | grep "total_in_bytes" | awk 'FNR==2 {print}' | awk -F ':' '{print $2}' | cut -d ',' -f1`

                        available=`curl -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cluster/stats?human&pretty" 2> /dev/null | grep "available_in_bytes" | awk -F ':' '{print $2}'`

                        used=$((total - $available))

                        used_percent=$(echo "scale=3; 100*$used/$total" |bc)
                        echo $used_percent
                elif [[ "$2" == "heap" ]];then
                        total=`curl -s -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cluster/stats?pretty"|grep -w heap_max_in_bytes|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g'`
                        used=`curl -s -k -u "zabbix_user:Zabb1x@123" "https://$i:9200/_cluster/stats?pretty"|grep -w heap_used_in_bytes|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g'`
                        used_percent=$(echo "scale=0; 100*$used/$total" |bc)
                        echo -n "$used_percent"
                fi
                break
        fi
done

