###############################################
#Author: Sreekanth KP
#DISK discovery
#version 2.0, 03/01/2017
################################################

#!/bin/bash


devices=`cat /proc/partitions |awk '{print $4}'|grep -v "^name$"|grep -v "^$"|sed '/sd..[0-9]/d'|sed '/sd../d'`
  for dev in $(echo $devices)
  do
    if [[ "$dev" =~ ^"dm-" ]]
    then
        devname=`cat /sys/block/$dev/dm/name|sed '/part/d'`
        if [[ -z ${devList[@]} ]]; then
        devList=($devname);
        else
        devList=("${devList[@]}" ${devname})
        fi
     else
        if [[ -z ${devList[@]} ]]; then
        devList=($dev);
        else
        devList=("${devList[@]}" ${dev})
        fi
fi

  done
if [[ ! -z ${devList[@]} ]]; then
  count=0
  echo "{"
  echo -e "\"data\":["
  for device in "${devList[@]}"
    do
      count=$(($count+1))
      if [[ $count -lt ${#devList[@]} ]]; then
        echo -e "{\"{#DEVICE}\":\"$device\"},"
      else
        echo -e "{\"{#DEVICE}\":\"$device\"}"
      fi
    done
  echo -e "]"
  echo "}"
fi

