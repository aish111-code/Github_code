#!/bin/bash

queue_path=`cat /opt/logstash/config/pipelines.yml |grep -i "path.queue"|awk -F ": " '{print $2}'`

if [[ "$1" == "beat" ]];then
du -csh --block-size=1M $queue_path/beats|grep -i beats |awk '{print $1}'
fi

if [[ "$1" == "metric" ]];then
du -csh --block-size=1M $queue_path/metric|grep -i beats |awk '{print $1}'
fi
