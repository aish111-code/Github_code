BASE_DIR=/app
## . ${BASE_DIR}/.lookup_file.env
#CMDB_DIR=${BASE_DIR}/cmdb
CMDB_SCRPTS_DIR=${CMDB_DIR}/scripts
#source ${CMDB_SCRPTS_DIR}/.lookup_file.env
CMDB_LOG_DIR=/tmp
MYSQL_USER=$1
MYSQL_PASS=$2

hst=`hostname`
if [ `echo "$hst"|grep -Ei "sc22jsdb|pc22jsdb|pc23jsdb|sc23jsdb"|wc -l` -eq 1 ];then
ip=`hostname -i`
else
ip=`/sbin/ifconfig | grep -e "inet:" -e "addr:" | grep -v "inet6" | grep -v "127.0.0.1" | head -n 1 | awk '{print $2}' | cut -c6-`
fi

mysql -u${MYSQL_USER} -p${MYSQL_PASS} -h${ip} -e "show variables like 'max_connection%'\g" 2> /dev/null > ${CMDB_LOG_DIR}/max_connections.log

#mysql --skip-secure-auth -u${MYSQL_USER} -p${MYSQL_PASS} -e "SHOW SLAVE STATUS \G" > ${CMDB_LOG_DIR}/slave_status.log

MAX_CONNECTION=`cat ${CMDB_LOG_DIR}/max_connections.log| grep "max_connections" | awk '{ print $2 }'`
mysql -u${MYSQL_USER} -p${MYSQL_PASS} -h${ip} -e "select count(*) from information_schema.processlist \G" 2> /dev/null > ${CMDB_LOG_DIR}/current_count.log
current_count=`cat ${CMDB_LOG_DIR}/current_count.log| grep "count" | awk '{ print $2 }'`
percent=$((100*$current_count/$MAX_CONNECTION))
echo $percent
