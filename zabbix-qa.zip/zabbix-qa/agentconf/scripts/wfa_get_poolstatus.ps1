Param(
	[string]$appPoolName = "DefaultAppPool"
)
Import-Module WebAdministration;
$appPoolStatus = 0

Try
{
	$state = (Get-WebAppPoolState $appPoolName).Value
	if ($state.Contains("Started"))
	{
		$appPoolStatus = 1
	}
}
Catch
{
	$appPoolStatus = -1
}
#Write-Host $state
Write-Host $appPoolStatus


