mkdir -p /var/log/zabbix/redis/
rm /var/log/zabbix/redis/redis_stats-$1.log
/usr/local/bin/redis-cli -p $1 -a "BjXqQQ@0%*-s#p*XTL2s" info 2>/dev/null| grep -i "^[a-z]" > /var/log/zabbix/redis/redis_stats-$1.log
echo $?
