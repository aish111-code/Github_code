#!/usr/bin/perl
use strict;
use Data::Dumper;

use JSON;

my $inp_dc = $ARGV[0];
my $inp_prd = $ARGV[1];
if( ! $inp_dc || ! $inp_prd ) {
    die " usage: $0 inp_dc inp_prd \n";
}

my $json_text;
{
  local $/; #Enable 'slurp' mode
  open my $fh, "<", "/tmp/splunkUsageGrps.json";
  $json_text = <$fh>;
  close $fh;
}


my $json = decode_json($json_text);
my $first = 1;
print "{\n";
print "\t\"data\":[\n\n";
foreach my $data ( @{$json->{data}} ) {
    my $grpName = $data->{GRPNAME};
    my $value = $data->{VALUE};
    $value =~ s/"//g;
    chomp($value);
    my $product = $data->{PRODUCT};
    chomp($product);
    my $dc= $data->{DC};
    chomp($dc);
    if( $inp_dc eq $dc && $inp_prd eq $product ) {
        print ",\n" if not $first;
        $first = 0;

        print "\t{\n";
        print "\t\t\"{#GRPNAME}\":\"$grpName\",\n";
        print "\t\t\"{#PRODUCT}\":\"$product\",\n";
        print "\t\t\"{#VALUE}\":\"$value\",\n";
        print "\t\t\"{#DC}\":\"$dc\"\n";
        print "\t}";
    }
}
print "\n\t]\n";
print "}\n";
#print Dumper \@res;

