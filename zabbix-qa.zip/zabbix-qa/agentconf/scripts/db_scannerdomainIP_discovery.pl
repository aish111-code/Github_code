##################################################################
# Author        : Sreekanth K P
# Purpose       : Scanner domain/IP discovery script
# Version       : 20/12/2016 - Initial code
#
####################################################################


#!/usr/bin/perl -w
use strict;
my $SCANNER_STR;
my $HOST;
my %SCANNER_STRING;
my @SCANNER;
my $size;
my @LOOKUP;
my $DOMAIN;
my $SCANNERIP;
my $DC2_PROD;
my $DC4_PROD;
my $DC8_PROD;
my $DC10_PROD;
my $DC12_PROD;
my $DC15_PROD;
my $DC17_PROD;
my $DC18_PROD;
my $DC19_PROD;
my $DC2_PREV;
my $DC4_PREV;
my $DC8_PREV;
my $DC10_PREV;
my $DC12_PREV;
my $DC17_PREV;
my $DC18_PREV;
my $DC19_PREV;
my $DC2_SALES;
my $DC4_SALES;
my $DC8_SALES;

#use strict;
#our  %SCANNER_STRING=("DC4_PROD" => "dc4crspc4.phx.sf.priv dc4crspc1.phx.sf.priv dc4crspc5.phx.sf.priv");
#%SCANNER_STRING=("DC2_PROD" => "dc2prdcrs1.successfactors.eu dc2orapc4.ams2.sf.priv dc2orastgc1.ams2.sf.priv dc2orapc3.ams2.sf.priv", "DC4_PROD" => "dc4crspc4.phx.sf.priv dc4crspc1.phx.sf.priv    dc4crspc5.phx.sf.priv", "DC8_PROD" => "dc8prdcrs1.ash.sf.priv dc8prdcrs4.ash.sf.priv dc8prdcrs5.ash.sf.priv dc8prdcrs6.ash.sf.priv dc8orapc2.ash.sf.priv dc8orapc4.ash.sf.priv", "DC10_PROD" => "dc10prdcrs1.syd.sf.priv", "DC12_PROD" => "DC12BIZXPRDCRS03.rot.od.sap.biz", "DC12_PROD" => "dc12orapc1.rot.od.sap.biz", "DC12_PROD" => "dc12orapc2.rot.od.sap.biz", "DC15_PROD" => "dc15prdcrs1.sha.sf.priv", "DC17_PROD" => "dc17prdcrs1.dc17.saas.sap.corp", "DC18_PROD" => "dc18prdcrs1.dc18.saas.sap.corp", "DC19_PROD" => "dc19prdcrs1.dc19.saas.sap.corp");
%SCANNER_STRING=("DC2_PROD" => "dc2prdcrs1.successfactors.eu dc2orapc4.ams2.sf.priv dc2orastgc1.ams2.sf.priv dc2orapc3.ams2.sf.priv", "DC4_PROD" => "dc4crspc4.phx.sf.priv dc4crspc1.phx.sf.priv dc4crspc5.phx.sf.priv", "DC8_PROD" => "dc8prdcrs1.ash.sf.priv dc8prdcrs4.ash.sf.priv dc8prdcrs5.ash.sf.priv dc8prdcrs6.ash.sf.priv dc8orapc2.ash.sf.priv dc8orapc4.ash.sf.priv", "DC10_PROD" => "dc10prdcrs1.syd.sf.priv", "DC12_PROD" => "DC12BIZXPRDCRS03.rot.od.sap.biz dc12orapc1.rot.od.sap.biz dc12orapc2.rot.od.sap.biz", "DC15_PROD" => "dc15prdcrs1.sha.sf.priv", "DC17_PROD" => "dc17prdcrs3.dc17.saas.sap.corp", "DC18_PROD" => "dc18prdcrs1.dc18.saas.sap.corp", "DC19_PROD" => "dc19prdcrs1.dc19.saas.sap.corp", "DC2_PREV" => "dc2orastgc1.ams2.sf.priv dc2orastgc1n1.ams2.sf.priv dc2prdcrs1.ams2.sf.priv", "DC4_PREV" => "dc4crspc1.phx.sf.priv dc4orastgc1.phx.sf.priv", "DC8_PREV" => "dc8orapc2.ash.sf.priv dc8orapc4.ash.sf.priv", "DC10_PREV" => "dc10prdcrs1.syd.sf.priv", "DC12_PREV" => "dc12orapc1.rot.od.sap.biz dc12stgcrs1.rot.od.sap.biz", "DC17_PREV" => "dc17stgcrs2.dc17.saas.sap.corp", "DC18_PREV" => "dc18stgcrs1.dc18.saas.sap.corp", "DC19_PREV" => "dc19stgcrs1.dc19.saas.sap.corp", "DC2_SALES" => "dc2prdcrs2.ams2.sf.priv", "DC4_SALES" => "dc4crspc4.phx.sf.priv dc4crspc5.phx.sf.priv", "DC8_SALES" => "dc8prdcrs1.ash.sf.priv dc8orasales1.ash.sf.priv");
$HOST=`hostname`;
if ( -e "/etc/mcollective/monsoonfacts.yaml" ) {
$HOST=`grep -w name /etc/mcollective/monsoonfacts.yaml| cut -d':' -f2 | sed 's/ //g'`;
}
$DC4_PROD=($HOST =~ "pc4|PC4")? 1 : 0 ;
$DC2_PROD=($HOST =~ "pc2|PC2")? 1 : 0 ;
$DC8_PROD=($HOST =~ "pc8|PC8")? 1 : 0 ;
$DC10_PROD=($HOST =~ "pc10|PC10")? 1 : 0 ;
$DC12_PROD=($HOST =~ "pc12|PC12")? 1 : 0 ;
$DC15_PROD=($HOST =~ "pc15|PC15")? 1 : 0 ;
$DC17_PROD=($HOST =~ "pc17|PC17")? 1 : 0 ;
$DC18_PROD=($HOST =~ "pc18|PC18")? 1 : 0 ;
$DC19_PROD=($HOST =~ "pc19|PC19")? 1 : 0 ;
$DC2_PREV=($HOST =~ "sc2|SC2")? 1 : 0 ;
$DC4_PREV=($HOST =~ "sc4|SC4")? 1 : 0 ;
$DC8_PREV=($HOST =~ "sc8|SC8")? 1 : 0 ;
$DC10_PREV=($HOST =~ "sc10|SC10")? 1 : 0 ;
$DC12_PREV=($HOST =~ "sc12|SC12")? 1 : 0 ;
$DC17_PREV=($HOST =~ "sc17|SC17")? 1 : 0 ;
$DC18_PREV=($HOST =~ "sc18|SC18")? 1 : 0 ;
$DC19_PREV=($HOST =~ "sc19|SC19")? 1 : 0 ;
$DC2_SALES=($HOST =~ "ps2|PS2|DC2|dc2")? 1 : 0 ;
$DC4_SALES=($HOST =~ "ps4|dc4|PS4|DC4")? 1 : 0 ;
$DC8_SALES=($HOST =~ "ps8|dc8|PS8|DC8")? 1 : 0 ;

if ($DC2_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC2_PROD};
}
if ($DC4_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC4_PROD};
}
if ($DC8_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC8_PROD};
}
if ($DC10_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC10_PROD};
}
if ($DC12_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC12_PROD};
}
if ($DC15_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC15_PROD};
}
if ($DC17_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC17_PROD};
}
if ($DC18_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC18_PROD};
}
if ($DC19_PROD == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC19_PROD};
}
if ($DC2_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC2_PREV};
}
if ($DC4_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC4_PREV};
}
if ($DC8_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC8_PREV};
}
if ($DC10_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC10_PREV};
}
if ($DC12_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC12_PREV};
}
if ($DC17_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC17_PREV};
}
if ($DC18_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC18_PREV};
}
if ($DC19_PREV == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC19_PREV};
}
if ($DC2_SALES == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC2_SALES};
}
if ($DC4_SALES == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC4_SALES};
}
if ($DC8_SALES == 1) {
    $SCANNER_STR=$SCANNER_STRING{DC8_SALES};
}
#@SCANNER = print $_, "," for split ' ', "$SCANNER_STR" ;

@SCANNER=split(/\s+/, $SCANNER_STR);
foreach $DOMAIN (@SCANNER) {
$size = @LOOKUP;
if ($size == 0 ) {
        @LOOKUP="$DOMAIN\n";
#       @LOOKUP=(@LOOKUP, `nslookup $DOMAIN|grep -v '#53'|grep "Address:"|awk '{print \$2}'|tr -s "\n" ,|sed 's/,\$//'`);
        @LOOKUP=(@LOOKUP, `nslookup $DOMAIN|grep -v '#53'|grep "Address:"|awk '{print \$2}'`);
        }
else {
        @LOOKUP=(@LOOKUP, "$DOMAIN\n");
        @LOOKUP=(@LOOKUP, `nslookup $DOMAIN|grep -v '#53'|grep "Address:"|awk '{print \$2}'`);
        }
#foreach $i (@LOOKUP) {
#print "$i";
#}
}
chomp(@LOOKUP);
#foreach my $SCAN in "$SCANNER" {
#`nslookup $SCAN`;
#}
$size=@LOOKUP;
#print "SiZE=$size \n";
if ($size ne 0) {
        our $count=0;
        my $size=@LOOKUP;
        print "{\n";
        print "\"data\":[\n";
        foreach $SCANNERIP (@LOOKUP) {
                $count=$count + 1;
#               print "COUNT = $count \n";
#               print "Size = $size \n ";
                if ($count < $size) {

                        print "{\"{#SCANNERIP}\":\"$SCANNERIP\"}, \n";
                } else {
                        print "{\"{#SCANNERIP}\":\"$SCANNERIP\"}\n";
                        }
                }
        print "]\n";
        print "}";
}

