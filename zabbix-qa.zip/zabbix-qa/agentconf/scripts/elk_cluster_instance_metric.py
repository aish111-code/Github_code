#!/usr/bin/python -W ignore
import requests
import json
import re
from pprint import pprint
import sys
import os
import socket
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

cluster_Region=sys.argv[1]
cluster_id=sys.argv[2]
cluster_mgt_ip=sys.argv[3]
cluster_instance=sys.argv[4]
instance_metric=sys.argv[5]
instance_metric_field=sys.argv[6]

if cluster_Region == "EUROPE":
   headers = {
    'Content-Type': 'application/json',
}
   url = "https://{0}:12443/api/v1/clusters/elasticsearch/{1}".format(cluster_mgt_ip,cluster_id)
   response = requests.get(url, headers=headers, verify=False, auth=('readonly', '6R2hOT6llteJ2Ns7E8xBqf2C097Xwjvp55P2ezeHKbV'))
   #print response.text
   data = response.json().get('topology', {}).get('instances', [])
   #print(json.dumps(data, indent=4))
   for i in data:
       if (i['instance_name']) == cluster_instance:
           print(i[instance_metric][instance_metric_field])


elif cluster_Region == "US":
   headers = {
    'Content-Type': 'application/json',
}
   url = "https://{0}:12443/api/v1/clusters/elasticsearch/{1}".format(cluster_mgt_ip,cluster_id)
   response = requests.get(url, headers=headers, verify=False, auth=('readonly', 'yBbdPpIwryDri1b5dh1IbKiEe0t1IeH1duCyVNmOwUW'))
   #print masters
   data = response.json().get('topology', {}).get('instances', [])
   #print(json.dumps(data, indent=4))
   for i in data:
       if (i['instance_name']) == cluster_instance:
           print(i[instance_metric][instance_metric_field])
