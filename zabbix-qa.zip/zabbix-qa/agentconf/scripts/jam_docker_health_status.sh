#!/bin/bash

if [[ -z "$1" ]]; then
    echo "Please state which app you want to check."
    exit 1
fi

output=$(docker inspect --format='{{.State.Health.Status}}' $1 | grep -c ^healthy 2>&1)
echo "$output"

exit 0