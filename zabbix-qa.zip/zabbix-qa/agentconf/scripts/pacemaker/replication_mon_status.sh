masternode=$(sudo /usr/sbin/crm_mon --one-shot|grep -i Masters|awk -F'[' '{print $2}'|awk '{print $1}')
thishost=$(hostname)
if [ $thishost == $masternode ]
then
sudo /usr/sbin/crm_mon -A -1 | grep -q SOK
echo $?
else
echo 0
fi
