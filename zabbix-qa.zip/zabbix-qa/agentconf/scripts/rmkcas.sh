###############################################
##Author: Sreekanth KP
#RMK CAS API script
#version 1.0, 16/02/2017
################################################

#!/bin/bash
case $1 in RS)   DC="";;
           DC12) DC=12;;
           DC17) DC=17;;
           DC19) DC=19;;
           *)    exit ;;
esac

HTTP_CODE=`curl -s -o /dev/null -w "%{http_code}" https://api$DC\.jobs2web.com/members/manageUserAccount/oAuth`
echo $HTTP_CODE

