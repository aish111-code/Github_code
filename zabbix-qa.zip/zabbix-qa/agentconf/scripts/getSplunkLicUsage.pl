#!/usr/bin/perl
use strict;
use Data::Dumper;

use JSON;

my $inp_dc = $ARGV[0];
my $inp_prd = $ARGV[1];
my $inp_grp = $ARGV[2];
if( ! $inp_dc || ! $inp_prd || ! $inp_grp ) {
    die " usage: $0 inp_dc inp_prd inp_grp \n";
}
my $json_text;
{
  local $/; #Enable 'slurp' mode
  open my $fh, "<", "/tmp/splunkUsageGrps.json";
  $json_text = <$fh>;
  close $fh;
}


my $json = decode_json($json_text);
foreach my $data ( @{$json->{data}} ) {
        my $grpName = $data->{GRPNAME};
        my $value = $data->{VALUE};
        $value =~ s/"//g;
        chomp($value);
        my $product = $data->{PRODUCT};
        chomp($product);
        my $dc= $data->{DC};
        chomp($dc);

        if( $inp_dc eq $dc && $inp_prd eq $product && $inp_grp eq $grpName ) {
            print "$value\n";
        }
}

