#Author: Sreekanth KP
#NFS Discovery script
#version 1.0, 13/04/2016

#!/bin/bash


#Usage sh diskvalue.sh <disk> <option>
if [ $# != 2 ]
then
echo "Wrong usage!! Usage sh diskvalue.sh <disk> <option>"
else
Flag=`/usr/sbin/nfsiostat $1|awk '{print $1}'|head -1`
if [ "$Flag" == "Illegal" ]
then
echo "-1"
else
case $2 in
        rttr)
        /usr/sbin/nfsiostat $1 2 2|egrep -v "read|write|Illegal"|tail -2 |head -1|awk '{print $6}' ;;
        rttw)
        /usr/sbin/nfsiostat $1 2 2|egrep -v "read|write|Illegal"|tail -1|awk '{print $6}' ;;
        exer)
        /usr/sbin/nfsiostat $1 2 2|egrep -v "read|write|Illegal"|tail -2|head -1|awk '{print $7}' ;;
        exew)
        /usr/sbin/nfsiostat $1 2 2|egrep -v "read|write|Illegal"|tail -1|awk '{print $7}' ;;
        retransr)
        /usr/sbin/nfsiostat $1 2 2|egrep -v "read|write|Illegal"|tail -2|head -1|awk '{print $5}'|awk -F"%" '{print $1}'|sed 's/(//g' ;;
        retransw)
        /usr/sbin/nfsiostat $1 2 2|egrep -v "read|write|Illegal"|tail -1|awk '{print $5}'|awk -F"%" '{print $1}'|sed 's/(//g' ;;
        *) echo "There is no such option $2. Please provide from something below:"
           echo "rttr,rttw,exer,exew,retransr,retransw" ;;
esac
fi
fi

