#!/bin/bash

while [[ $# > 0 ]]; do
        key="$1"

        case $key in
                -c|--command)
                HA_COMMAND="$2"
                shift
                ;;
                -h|--help)
                echo "Use -c or --command to set the comman to check for example: endpoints_down."
                exit 2
                ;;
                *)
                echo "$key is an unavailable option please use -h or --help to see the options."
                exit 1
                ;;
        esac
        shift
done

if [[ -z "$HA_COMMAND" ]]; then
        echo "Please set the command. Use -h or --help for more information."
        exit 1
fi

output=$(docker exec ct_cron_everywhere bundle exec ruby script/show_haproxy_metrics.rb $HA_COMMAND)
echo "$output"

exit 0
