#!/bin/bash

IFS='
'

df -h | grep 'sap' | awk '{print $6}' > /var/log/zabbix/sapmounts.txt
count=0
filecount=`cat /var/log/zabbix/sapmounts.txt | wc -l`

echo "{"
echo -e '"data":['

for i in $(cat /var/log/zabbix/sapmounts.txt);
  do
     count=$(($count+1))
        if [ $count -lt $filecount ]; then
           echo -e "{\"{#FILESYSTEM}\":\"$i\"},"
        else
           echo -e "{\"{#FILESYSTEM}\":\"$i\"}"
        fi
  done
echo -e "]"
echo "}"

rm /var/log/zabbix/sapmounts.txt
