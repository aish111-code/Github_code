#!/bin/bash
CMDB_LOG_DIR=/tmp
MYSQL_USER=$1
MYSQL_PASS=$2
ip=`hostname -i`
# Get Max no of connections from DB
mysql -u${MYSQL_USER} -p${MYSQL_PASS} -h${ip} -e "show variables like 'max_connection%'" 2> /dev/null > ${CMDB_LOG_DIR}/max_connections.log
MAX_CONNECTION=`cat ${CMDB_LOG_DIR}/max_connections.log| grep "max_connections" | awk '{ print $2 }'`
    #echo "Max Connections = $MAX_CONNECTION"
# Get current threads running from DB 
mysql -u${MYSQL_USER} -p${MYSQL_PASS} -h${ip} -e "show global status like 'threads_running'" 2> /dev/null > ${CMDB_LOG_DIR}/threads_running.log
threads_running=`cat ${CMDB_LOG_DIR}/threads_running.log| grep -i "threads_running" | awk '{ print $2 }'`
    #echo "Threads Running = $threads_running"
# Calculate the percentage and trigger alert if the percentage is > 5
percent=$((100*$threads_running/$MAX_CONNECTION))
echo $percent
