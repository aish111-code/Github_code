#!/bin/bash
export ORACLE_HOME=/local/opt/oracle/11.2.0/client_home1
export PATH=$ORACLE_HOME/bin:$PATH


sqlplus $1/$2@//$3:$4/$5 <<END_SCRIPT
select count(*) from JBM_MSG;
exit;
END_SCRIPT
