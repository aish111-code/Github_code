<?php

$SCRIPT_PATH="/etc/zabbix/Zabbix_Monitor/check_ftp";
$SCRIPT_NAME=$argv[0];
$SERVER_NAME=$argv[1];
$USER_NAME=$argv[2];
$PASSWORD=$argv[3];
$ftp_dir=$argv[4];

$local_dir="/tmp";



//----------------------------------------------------------------------------
// Validate Arguments
//----------------------------------------------------------------------------
if(!isset($SERVER_NAME) || !isset($USER_NAME) || !isset($PASSWORD) || !isset($ftp_dir) )
{
echo "usage: ./$SCRIPT_NAME server_name user_name password ftp_directory\n";
exit;
}

if(strcmp($SERVER_NAME,"")==0 || strcmp($USER_NAME,"")==0 || strcmp($PASSWORD,"")==0 || strcmp($ftp_dir,"")==0)
{
echo "usage: ./$SCRIPT_NAME server_name user_name password ftp_directory\n";
exit;
}

//create the test file
$test_str=rtrim(`date +"%m-%d-%Y_%H:%M"`);
$test_file=$SERVER_NAME."_ftp_test.txt";

$local_test_file=$local_dir."/".$test_file;
$ftp_test_file=$ftp_dir."/".$test_file;

$command="echo $test_str > $local_test_file";
system($command);

//timeout on 25 sec
$connection = ftp_connect($SERVER_NAME,21,25);

$login = ftp_login($connection, $USER_NAME, $PASSWORD);

if (!$connection || !$login) 
{ 
echo "Cannot connect to $SERVER_NAME";
 exit;
}

ftp_pasv($connection,TRUE);

$upload = ftp_put($connection, $ftp_test_file, $local_test_file, FTP_ASCII);

if (!$upload)
{ 
echo "Cannot upload file to $SERVER_NAME";
ftp_close($connection);
exit;
}



    //remove local test file
    $command="rm $local_test_file";
    system($command);

$download=ftp_get($connection,$local_test_file,$ftp_test_file,FTP_ASCII);
if (!$download)
{ 
echo "Cannot download file from $SERVER_NAME";
ftp_close($connection);
exit;
}

 #make sure the file got downloaded correctly and contain the correct string
    $file_handle=fopen($local_test_file,"r");
       
    if($file_handle)
    {
     $str=rtrim(fgets($file_handle)); 
    }
    else
    {
    echo "Cannot download file from $SERVER_NAME";
    ftp_close($connection);
    exit;
    }
 
        if(strcmp($str,$test_str)==0)
        {
        print "Success";
        }
        else
        {
        print "Cannot upload/download file from $SERVER_NAME";
        }
        fclose($file_handle);

    ftp_close($connection);

    //remove local test file
    $command="rm $local_test_file";
    system($command);



?>

