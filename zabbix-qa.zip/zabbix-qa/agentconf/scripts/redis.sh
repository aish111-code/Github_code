##Script to discover redis instance ports
##Author: Sreekanth KP
###Version 1.0. Date 17/05/2016
#!/bin/bash

REDIS_HOME="/app/redis"
ports=$(ls ${REDIS_HOME} |grep redis|grep ".pid"  | awk -F"_" '{ print $2 }'|awk                                                                              -F"." '{print $1}')
for port in $(echo $ports)
  do
    if [[ -z ${portList[@]} ]]; then
      portList=($port);
    else
      portList=("${portList[@]}" ${port})
    fi
  done

if [[ ! -z ${portList[@]} ]]; then
    count=0
    echo "{"
    echo -e "\"data\":["
    for port in "${portList[@]}"
      do
        count=$(($count+1))
        if [[ $count -lt ${#portList[@]} ]]; then
          echo -e "{\"{#PORT}\":\"$port\"},"
        else
          echo -e "{\"{#PORT}\":\"$port\"}"
        fi
   done
   echo -e "]"
   echo "}"
fi

