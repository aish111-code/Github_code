#!/bin/bash

#===============================================================================
#
#          FILE: checkZKClusterState_zabbix.sh
#
#         USAGE: ./checkZKClusterState_zabbix.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: Liu Michael, michael.liu03@sap.com
#  ORGANIZATION: SuccessFactors, an SAP Company
#       CREATED: 06/15/2016 18:24
#      REVISION: 002
#===============================================================================

NODELIST=`grep "^server." /usr/local/zookeeper/zoo_sf.cfg --color | awk -F= '{print $2}' | awk -F: '{print $1}'`
NUMOFDOWNNODE=0
DOWNNODEARR=()
for node in $NODELIST
do
  state=`(echo ruok | netcat $node 2181) 2> /dev/null`
  if [ "$state" != "imok" ]
  then
    DOWNNODEARR[$NUMOFDOWNNODE]=$node
    NUMOFDOWNNODE=$(( $NUMOFDOWNNODE +1 ))
  fi
done
if [ $NUMOFDOWNNODE -gt 2 ]
then
  echo $NUMOFDOWNNODE
  exit 1
else
  echo $NUMOFDOWNNODE
  exit 0
fi
