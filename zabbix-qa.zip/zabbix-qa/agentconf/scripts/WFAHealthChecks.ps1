Param(
	[string]$URL = "https://analytics4.successfactors.com/WFAHealthCheck/status.aspx",
	[string]$checkParam = "Hana"
)

$URL = $URL + "?check=" + $checkParam
$web = New-Object System.Net.WebClient
$web.UseDefaultCredentials = $true
$urlstatus = 0

#Write-Host $URL

Try
{
	If ($web.DownloadString(�$URL�) | select-string �OK�)
		{
			$urlstatus = 1
		}
		ElseIf ($web.DownloadString(�$URL�) | select-string �ODS Replication Critical Errors: No�)
		{
			$urlstatus = 1
		}
		ElseIf ($web.DownloadString(�$URL�) | select-string �Not Reachable Consumer Services: None�)
		{
			$urlstatus = 1
		}
	}
Catch
{
	$urlstatus =0
}
Write-Host $urlstatus