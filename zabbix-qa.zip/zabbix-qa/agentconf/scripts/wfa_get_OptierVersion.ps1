$tpath = test-path "C:\optier\data\corefirst\logs\cf-ContextAgent.log"
if ($tpath -eq "true")
{
[String]$fpath = Get-Content -Path C:\optier\data\corefirst\logs\cf-ContextAgent.log -TotalCount 2
$ver = $fpath.substring($fpath.IndexOf(" APM")+5,6) }
Else {
$ver = 0 }
write-host $ver
