#!/bin/bash

cluster_Region=$1

if [ "$cluster_Region" == "EUROPE" ];then
	clusters="ANALYTICS|d985e2b66da74bd1860a09a9347c3506.elkeu.ondemand.com,Bizx Operations|90d1db8601c543058dde31f381000113.elkeu.ondemand.com,Database Operations|6ab46e5afaec454092a9b0d564275fd5.elkeu.ondemand.com,Platform Operations|53aad80ec9c741469f3300e6403dc12b.elkeu.ondemand.com,Bizx Engineering|b848ac0c9a8b48e8b99db3a4f96218d4.elkeu.ondemand.com"

elif [ "$cluster_Region" == "US" ];then
	clusters="Analytics|18e5c7e47f52440faae74078e6404f0d.elkus.ondemand.com,Bizx Operations|07ece18c8a2e418b8e62ee16291d400f.elkus.ondemand.com,Database Operations|2bbc31a73f0b42678e6580aba8fb0f8f.elkus.ondemand.com,Platform Operations|528e55b3f7cf403ca4f1ab002c1977fd.elkus.ondemand.com,Bizx Engineering|fc62b1fbe7d144178ccadc719f63833c.elkus.ondemand.com"

fi
count=0
IFS=$','
for i in `echo "$clusters"`
do
	((count=count+1))
done
echo "{"
echo -e "\"data\":["

for i in `echo "$clusters"`
do
	name=`echo "$i"|awk -F "|" '{print $1}'`
	id=`echo "$i"|awk -F "|" '{print $2}'`
	if [ $count -eq 1 ];then
		echo -e "{\"{#NAME}\":\"$name\",\"{#ID}\":\"$id\"}"		
	else
		echo -e "{\"{#NAME}\":\"$name\",\"{#ID}\":\"$id\"},"
	fi
	((count=count-1))
done
echo -e "]"
echo "}"
