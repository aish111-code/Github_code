#!/bin/bash

##################################################################
# Author        : Vikky Omkar
# Purpose       : BizX Image conversion Functionality
# Reviewer      : Sandeep M.R
# Version       : August 6th 2015 
#
####################################################################


        SAMPLENAME=/tmp/sample
        ERRORLOG=/tmp/error.log
        TXT_PDF=/tmp/txt_pdf.log
        PDF_JPG=/tmp/pdf_jpg.log
	PDF_LOCK=/tmp/.~lock.sample.pdf

       rm -rf  $SAMPLENAME.txt $SAMPLENAME.jpg $PDF_LOCK
        echo "This is the test file to check .txt to .pdf functionality" > $SAMPLENAME.txt


                if [  -d /usr/local/JAVA_HOME/ ]
                  then
                  timeout 20s /usr/local/JAVA_HOME/bin/java -jar /etc/zabbix/zabbix_agentd_custom_scripts/check_imageconversion/ImageConverter.jar $SAMPLENAME.txt $SAMPLENAME.pdf > $TXT_PDF 2>&1

                elif [  -d /export/home/sfuser/ ]
                  then
                        cd /export/home/sfuser/
                        . /export/home/sfuser/.bash_profile
                        timeout 20s $JAVA_HOME/bin/java -jar /etc/zabbix/zabbix_agentd_custom_scripts/check_imageconversion/ImageConverter.jar $SAMPLENAME.txt $SAMPLENAME.pdf > $TXT_PDF  2>&1

                elif [  -d /home/sfuser/ ]
                  then
                        cd /home/sfuser/
                        . /home/sfuser/.bash_profile
                        timeout 20s $JAVA_HOME/bin/java -jar /etc/zabbix/zabbix_agentd_custom_scripts/check_imageconversion/ImageConverter.jar $SAMPLENAME.txt $SAMPLENAME.pdf > $TXT_PDF  2>&1

                fi


        convert -density 100 -verbose -colorspace RGB $SAMPLENAME.pdf $SAMPLENAME.jpg > $PDF_JPG 2>&1
        CONVRESULT=`identify $SAMPLENAME.jpg 2> $ERRORLOG`

        if [[ $? -eq 1 || "$CONVRESULT" = "" ]]
        then
        echo 1    #failed
        else
        echo 0	  #success
        fi
