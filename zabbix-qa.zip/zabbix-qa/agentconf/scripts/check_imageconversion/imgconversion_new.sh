#!/bin/bash

##################################################################
# Author        : Chaithanya(i536848)
# Purpose       : BizX Image conversion Functionality
# Updated       : Jibin (i501754)
# Version       : Feb 10th 2022
#
####################################################################

        chmod 757 /var/log/zabbix/
        if [ ! -d /var/log/zabbix/image_zabbix ];then
                mkdir /var/log/zabbix/image_zabbix
        fi
        chmod 777 /var/log/zabbix/image_zabbix
        SAMPLENAME=/var/log/zabbix/image_zabbix/zabbixsample
        ERRORLOG=/var/log/zabbix/image_zabbix/error.log
        TXT_PDF=/var/log/zabbix/image_zabbix/txt_pdf.log
        PDF_JPG=/var/log/zabbix/image_zabbix/pdf_jpg.log
        PDF_LOCK=/var/log/zabbix/image_zabbix/.~lock.zabbixsample.pdf

       rm -f ${SAMPLENAME}.txt
       rm -f ${SAMPLENAME}.jpg
        rm -f "${PDF_LOCK}"
        echo "This is the test file to check .txt to .pdf functionality" > ${SAMPLENAME}.txt



                if [  -d /export/home/sfuser/ ]
                  then
                        timeout 20s  /opt/libreoffice6.1/program/python ImageConverter.py ${SAMPLENAME}.txt ${SAMPLENAME}.pdf > $TXT_PDF  2>&1
                fi


        convert -density 100 -verbose -colorspace RGB ${SAMPLENAME}.pdf ${SAMPLENAME}.jpg > $PDF_JPG 2>&1
        CONVRESULT=`identify ${SAMPLENAME}.jpg 2> $ERRORLOG`

        if [[ $? -eq 1 || "$CONVRESULT" = "" ]]
        then
        echo 1    #failed
        else
        echo 0    #success
        fi
