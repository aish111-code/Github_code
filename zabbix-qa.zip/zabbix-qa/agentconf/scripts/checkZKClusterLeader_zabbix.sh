#!/bin/bash

#===============================================================================
#
#          FILE: checkZKClusterLeader_zabbix.sh
#
#         USAGE: ./checkZKClusterLeader_zabbix.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: Liu Michael, michael.liu03@sap.com
#  ORGANIZATION: SuccessFactors, an SAP Company
#       CREATED: 06/15/2016 18:24
#      REVISION: 002
#===============================================================================


NODELIST=`grep "^server." /usr/local/zookeeper/zoo_sf.cfg --color | awk -F= '{print $2}' | awk -F: '{print $1}'`
LEADER=false
for node in $NODELIST
do
  mode=`(echo srvr | netcat $node 2181 | grep "Mode:" | awk -F: '{print $2}' | tr -d [:space:]) 2> /dev/null`
  if [ "$mode" = "leader" ]
  then
    LEADER=true
  fi
done
if [ "$LEADER" = "false" ]
then
  echo "NoLeader"
  exit 1
else
  echo "Success"
  exit 0
fi

