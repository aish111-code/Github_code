set linesize 200
set pagesize 0
set feedback off
column c1 heading "Tier" Format a45
column c2 heading "Transaction_class" Format a45

select distinct vlt.tier_label_or_name c1,'|',vltc.TRAN_CLASS_LABEL_OR_NAME c2
from v_m_tc_and_tiers vmtc
inner join v_l_tiers vlt on vmtc.target_tier_id = vlt.tier_id
inner join v_l_applications vla on vmtc.application_id = vla.application_id
inner join V_L_TRANSACTION_CLASSES vltc on vmtc.tc_id = vltc.TRANSACTION_CLASS_ID
where vlt.tier_label_or_name like 'BizX%'
and vmtc.start_time >= sysdate - 1/144 and vmtc.start_time < sysdate - 1/288
and vmtc.AGGREGATION_TIME_LEVEL=0
and vmtc.AGGREGATION_TYPE =1 and
vltc.TRAN_CLASS_LABEL_OR_NAME in
('BizX Login Page','BizX Homepage','Learning','Objectives - Goal Management (create/edit)','PM-Send Performance Review to Next Step','PM-Open Performance Review','Job Search - To get Job search data to render the home page or search result page -DWR,','Job Search -- Search Job posting DWR','PM Home','Form Saved: Opened from PM Inbox','Load Home Page Tile Content ','Career Site- Pre Login Page','External Portal Career - Job Search')
group by vlt.tier_label_or_name,vmtc.target_tier_id,TC_ID,vlt.host_name,vltc.TRAN_CLASS_LABEL_OR_NAME
order by vlt.tier_label_or_name;
