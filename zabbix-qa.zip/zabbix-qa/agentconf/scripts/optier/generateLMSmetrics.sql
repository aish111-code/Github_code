set linesize 300
set pagesize 0
set feedback off

column c1 heading "Tier" Format a40
column c2 heading "Volume" Format 999999
column c3 heading "Avg_Proc_Time" Format 99999
column c4 heading "Avg_Resp_Time" Format 99999
column c5 heading "Error_per" Format 99999.9999
column c7 heading "Transaction class" Format a70


select
vlt.tier_label_or_name c1,'|',
vltc.TRAN_CLASS_LABEL_OR_NAME c7,'|',
trunc(sum(vmtc.TRANSACTION_IN_TIER_COUNT),3) c2,'|',
trunc(DECODE(sum(vmtc.TRANSACTION_IN_TIER_COUNT),0,0,sum(vmtc.SERVICE_TIME_TOTAL_SUM)/sum(vmtc.TRANSACTION_IN_TIER_COUNT))/1000,0) c3,'|',
trunc(DECODE(sum(vmtc.TRANSACTION_IN_TIER_COUNT),0,0,sum(vmtc.ELAPSED_TIME_TOTAL_SUM)/sum(vmtc.TRANSACTION_IN_TIER_COUNT)),0) c4,'|',
((nvl(sum(VMTC.compl_count_application_errors),0) + nvl(sum(VMTC.compl_count_protocol_errors),0))/trunc(sum(vmtc.TRANSACTION_IN_TIER_COUNT),3))*100 c5
FROM
v_m_tc_and_tiers vmtc
inner join v_l_tiers vlt on vmtc.target_tier_id = vlt.tier_id
inner join v_l_applications vla on vmtc.application_id = vla.application_id
inner join V_L_TRANSACTION_CLASSES vltc on vmtc.tc_id = vltc.TRANSACTION_CLASS_ID
WHERE
vmtc.start_time >= sysdate-1/144 and vmtc.start_time < sysdate - 1/288
and (vlt.tier_label_or_name like 'LMS%')
and vmtc.AGGREGATION_TIME_LEVEL=0
and vmtc.AGGREGATION_TYPE =1
and vltc.TRAN_CLASS_LABEL_OR_NAME in ('HTTP:///learning/user/login.jsp','HTTP:///learning/user/login.do','HTTP:///learning/student_acegi_authenticate/user/login.do','HTTP:///learning/user/personal/landOnPortalHome.do','HTTP:///learning/user/onlineaccess/launchOnlineComponent.do/','HTTP:///learning/user/onlineaccess/finishModuleAction.do','HTTP:///learning/PwsAicc','HTTP:///learning/user/catalogsearch/catalogSearchDispatchAction.do','HTTP:///learning/user/catalogsearch/getCatalogSearchLearningResults.do','HTTP:///learning/user/catalog/performCatalogAction.do','HTTP:////learning/user/catalog/createSearchResults.do','HTTP:///learning/user/catalog/viewSearchResults.do','HTTP:///learning/user/site/routeAdvancedSearchCriteria.do')
group by vlt.tier_label_or_name,vmtc.target_tier_id,TC_ID,vlt.host_name,vltc.TRAN_CLASS_LABEL_OR_NAME,TIER_CLASS_DESC
order by vlt.tier_label_or_name;
