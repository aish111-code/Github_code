#!/bin/sh
#
# Optier sqlplus wrapper that executes local sql script, and writes output to scriptname.log
# Additional 'User Parameters' will need to be setup to access the information in the scriptname.log
#
# Usage: $0 db_user db_password db_host db_sid db_port localScriptName.sql
#  
sqlplus=$(find /app/oracle /local -name sqlplus -type f 2>/dev/null | tail -1)
ORACLE_HOME=${sqlplus%/bin/sqlplus}
export ORACLE_HOME
export PATH=$ORACLE_HOME/bin:$PATH

#Executing the SQL in silent mode
sqlplus -s $1/$2@//$3:$4/$5 <<EOF
SET TERMOUT OFF
SET ECHO OFF
spool $6.log
@$6
spool off
exit
EOF
