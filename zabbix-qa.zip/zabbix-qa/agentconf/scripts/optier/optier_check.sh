#!/bin/bash

##########################################################################################
# Purpose : Script for autodiscovery of optier tier names and generate optier metrics
# Author  : Sandeep M.R
# Reviewer : Patrick Presto
##########################################################################################

# SQL output log path
if [[ ! -d ${HOME} || ! -w ${HOME} ]]; then
  if [[ -d /tmp ]]; then
    mkdir -p "/tmp/optier"
    logPath="/tmp/optier"
  fi
elif [[ -d ${HOME} && ! -d ${HOME}/optier ]]; then
  mkdir -p ${HOME}/optier
  logPath="${HOME}/optier"
else
  logPath="${HOME}/optier"
fi

# Get curent working directory
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd ${wdir}

# SQL output log
#logPath="/home/zabbix/optier"

checktype=$1


discover()
{

optierlog1="${logPath}/${app}_tiers_${db_sid}.log"

#$wdir/buildOptierLog_v1.sh optier_reports optier_reports $db_host $db_port $db_sid 0 0 $1 ${optierlog1}
$wdir/buildOptierLog_v1.sh $db_user $db_passwd $db_host $db_port $db_sid 0 0 $1 ${optierlog1}

sed -i 's/[ \t]*$//g' ${optierlog1}
sed -i 's/[()]//g' ${optierlog1}         # to remove special character ( )

ora=`grep -w "ORA" ${optierlog1}`

if [ ! -z $ora ]
then
rm ${optierlog1}
fi

}

generateItem()
{

optierlog1="${logPath}/${app}_tiers_${db_sid}.log"


count=0

echo "{"
echo -e "\"data\":["

IFS=''
tiercount=`wc -l ${optierlog1} | awk '{print $1}'`

while read optier_names
do
	count=$(($count+1))
	if [[ $count -lt $tiercount ]] 
	then
		tierName=`echo ${optier_names} | cut -d'|' -f1 | sed 's/[ \t]*$//g'` 
		txnName=`echo ${optier_names} | cut -d'|' -f2 | sed 's/^[ \t]*//g' | sed 's/[ \t]*$//g'`
		echo -e "{\"{#TIERNAME}\":\"$tierName\",\"{#TXNNAME}\":\"${txnName}\"},"
	else
		tierName=`echo ${optier_names} | cut -d'|' -f1 | sed 's/[ \t]*$//g'`
                txnName=`echo ${optier_names} | cut -d'|' -f2 | sed 's/^[ \t]*//g' | sed 's/[ \t]*$//g'`
		echo -e "{\"{#TIERNAME}\":\"$tierName\",\"{#TXNNAME}\":\"${txnName}\"}"
	fi
done < ${optierlog1}

echo -e "]"
echo "}"


}

generateMetrics()
{

# code to generate metrics data

optierlog1="${logPath}/optier_metrics_${app}_${db_sid}.log"

#$wdir/buildOptierLog_v1.sh optier_reports optier_reports $db_host $db_port $db_sid 0 0 $1 ${optierlog1}
$wdir/buildOptierLog_v1.sh $db_user $db_passwd $db_host $db_port $db_sid 0 0 $1 ${optierlog1}

sed -i 's/[ \t]*$//g' ${optierlog1}

}

case $checktype in

"discover")

		db_user=$2
		db_passwd=$3
		db_host=$4
		db_port=$5
		db_sid=$6
		app=$7
		desc=$8
		if [ $app == "BIZX" ]
		then
		discoversql="discoverBIZX.sql"
		metricssql="generateBIZXmetrics.sql"
		elif [ $app == "LMS" ]
		then
                discoversql="discoverLMS.sql"
                metricssql="generateLMSmetrics.sql"

		fi
		generateMetrics ${metricssql}		
		discover ${discoversql}
		;;


"createItem" )

		db_user=$2
		db_passwd=$3
		db_host=$4
		db_port=$5
		db_sid=$6
		app=$7
		desc=$8
		generateItem 
		;;


*) 
		echo "Incorrect check type: $1"
		;;
esac

