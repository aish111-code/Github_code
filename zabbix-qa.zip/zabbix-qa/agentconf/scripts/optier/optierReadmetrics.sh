#!/bin/bash

#######################################################
# Script to read optier metrics for discovered items
# Author : Sandeep M.R (C5182416)
# Reviewer : Patrick Presto
# Date : 24th July 2014
#######################################################

# SQL output log path
if [[ ! -d ${HOME} || ! -w ${HOME} ]]; then
  if [[ -d /tmp ]]; then
    mkdir -p "/tmp/optier"
    logPath="/tmp/optier"
  fi
elif [[ -d ${HOME} && ! -d ${HOME}/optier ]]; then
  mkdir -p ${HOME}/optier
  logPath="${HOME}/optier"
else
  logPath="${HOME}/optier"
fi

app=$1
tiername=$2
txnname=$3
checktype=$4
db_sid=$5

optierlog1="${logPath}/optier_metrics_${app}_${db_sid}.log"

                case $checktype in

                "fetch_volume" )
                                returnvalue=`grep -w "$tiername" ${optierlog1} | grep  -w "${txnname}" | awk -F'|' '{print $3}' | sed 's/ //g'`
                                if [ -z $returnvalue ]
                                then
                                returnvalue=0
				#echo "<WARNING> fetch_volume - No Data Found ($app $tiername $txnname $checktype $db_sid)" >> ${logPath}/optier.errors
                                fi
                                echo $returnvalue
                                ;;

                "fetch_avg_proc_time" )
                                returnvalue=`grep -w "$tiername" ${optierlog1} | grep  -w "${txnname}" | awk -F'|' '{print $4}' | sed 's/ //g'`
                                if [ -z $returnvalue ]
                                then
                                returnvalue=0
				#echo "<WARNING> fetch_avg_proc_time - No Data Found ($app $tiername $txnname $checktype $db_sid)" >> ${logPath}/optier.errors
                                fi
                                echo $returnvalue

                                ;;
                "fetch_avg_res_time" )
                                returnvalue=`grep -w "$tiername" ${optierlog1} | grep  -w "${txnname}" | awk -F'|' '{print $5}' | sed 's/ //g'`
                                 if [ -z $returnvalue ]
                                then
                                returnvalue=0
				#echo "<WARNING> fetch_avg_res_time - No Data Found ($app $tiername $txnname $checktype $db_sid)" >> ${logPath}/optier.errors
                                fi
                                echo $returnvalue

                                ;;
		 "fetch_error_per" )
                                returnvalue=`grep -w "$tiername" ${optierlog1} | grep  -w "${txnname}" | awk -F'|' '{print $6}' | sed 's/ //g'`
                                if [ -z $returnvalue ]
                                then
                                returnvalue="0.00000"
				#echo "<WARNING> fetch_error_per - No Data Found ($app $tiername $txnname $checktype $db_sid)" >> ${logPath}/optier.errors
                                fi
                                echo $returnvalue

                                ;;

                *)
                                echo "Incorrect check type"
                                ;;
                esac

