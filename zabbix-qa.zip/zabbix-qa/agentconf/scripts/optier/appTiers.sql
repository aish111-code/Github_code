select
vlt.tier_label_or_name Tier,
trunc(sum(vmtc.TRANSACTION_IN_TIER_COUNT),3) Volume,
trunc(DECODE(sum(vmtc.TRANSACTION_IN_TIER_COUNT),0,0,sum(vmtc.SERVICE_TIME_TOTAL_SUM)/sum(vmtc.TRANSACTION_IN_TIER_COUNT))/1000,0) Avg_ProcessingTime_ms,
trunc(DECODE(sum(vmtc.TRANSACTION_IN_TIER_COUNT),0,0,sum(vmtc.ELAPSED_TIME_TOTAL_SUM)/sum(vmtc.TRANSACTION_IN_TIER_COUNT)),0) Avg_ResponseTime_ms
FROM
v_m_tc_and_tiers vmtc
inner join v_l_tiers vlt on vlt.tier_id = vmtc.target_tier_id
inner join v_l_applications vla on vla.application_id = vmtc.application_id
WHERE
vmtc.start_time >= sysdate-1/96
and (vlt.tier_label_or_name like 'BizX%' or vlt.tier_label_or_name like 'LMS%')
and vlt.tier_label_or_name not like '%NonCF%'
and vla.application_name='BizX'
and vmtc.AGGREGATION_TYPE =1
and vmtc.AGGREGATION_TIME_LEVEL=0
group by
vlt.tier_label_or_name,vmtc.target_tier_id
order by vlt.tier_label_or_name;
