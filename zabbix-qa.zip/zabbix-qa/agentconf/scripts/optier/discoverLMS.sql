set linesize 200
set pagesize 0
set feedback off
column c1 heading "Tier" Format a45
column c2 heading "Transaction_class" Format a70


select distinct vlt.tier_label_or_name c1,'|',vltc.TRAN_CLASS_LABEL_OR_NAME c2
from v_m_tc_and_tiers vmtc
inner join v_l_tiers vlt on vmtc.target_tier_id = vlt.tier_id
inner join v_l_applications vla on vmtc.application_id = vla.application_id
inner join V_L_TRANSACTION_CLASSES vltc on vmtc.tc_id = vltc.TRANSACTION_CLASS_ID
where
vlt.tier_label_or_name like 'LMS%' and vmtc.start_time >= sysdate - 1/144 and vmtc.start_time < sysdate - 1/288 and vltc.TRAN_CLASS_LABEL_OR_NAME in ('HTTP:///learning/user/login.jsp','HTTP:///learning/user/login.do','HTTP:///learning/student_acegi_authenticate/user/login.do','HTTP:///learning/user/personal/landOnPortalHome.do','HTTP:///learning/user/onlineaccess/launchOnlineComponent.do/','HTTP:///learning/user/onlineaccess/finishModuleAction.do','HTTP:///learning/PwsAicc','HTTP:///learning/user/catalogsearch/catalogSearchDispatchAction.do','HTTP:///learning/user/catalogsearch/getCatalogSearchLearningResults.do','HTTP:///learning/user/catalog/performCatalogAction.do','HTTP:////learning/user/catalog/createSearchResults.do','HTTP:///learning/user/catalog/viewSearchResults.do','HTTP:///learning/user/site/routeAdvancedSearchCriteria.do')
group by vlt.tier_label_or_name,vmtc.target_tier_id,TC_ID,vlt.host_name,vltc.TRAN_CLASS_LABEL_OR_NAME
order by vlt.tier_label_or_name;
