#!/bin/bash

#
# Should have the following input parameters db_user/db_password, db_host, db_sid, db_port, $sql_param1, $sql_param2, $filename
#
# Usage:
#   ./buildOptierLog.sh optier_reports optier_reports 10.24.244.70 1521 ashopt01 0 0 bizx_lms_tiers.sql
#


  sqlplus=$(find /app/oracle/product /app/oracle /local/opt/oracle -maxdepth 4 -name sqlplus -type f 2>/dev/null | tail -1)
  if [[ ! -z $sqlplus ]]; then
    ORACLE_HOME=${sqlplus%/bin/sqlplus}
    export ORACLE_HOME
  else
    ORACLE_HOME=/local/opt/oracle/11.2.0/client_home1
    export ORACLE_HOME
  fi
  export PATH=$ORACLE_HOME/bin:$PATH


  #Executing the SQL  in silent mode with user/password@host:port sid
  sqlplus -s $1/$2@//$3:$4/$5 <<EOF
  SET TERMOUT OFF
  SET ECHO OFF
  spool $9
  @$8 $6 $7
  spool off
  exit
  EOF

