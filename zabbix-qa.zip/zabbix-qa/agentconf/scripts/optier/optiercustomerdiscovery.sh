#!/bin/bash


cust=$(cat /tmp/cust.txt)

for c in $(echo $cust)
  do
    if [[ -z ${custList[@]} ]]; then
      custList=($c);
    else
      custList=("${custList[@]}" ${c})
    fi
  done


if [[ ! -z ${custList[@]} ]]; then
    count=0
    echo "{"
    echo -e "\"data\":["
    for p in "${custList[@]}"
      do
        count=$(($count+1))
        if [[ $count -lt ${#custList[@]} ]]; then
          echo -e "{\"{#CUSTOMERNAME}\":\"$p\"},"
        else
          echo -e "{\"{#CUSTOMERNAME}\":\"$p\"}"
        fi
   done
   echo -e "]"
   echo "}"
fi

