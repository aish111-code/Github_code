#!/bin/bash
#  JMX threadDump Usage
#  java -jar tdump-6_1.1.jar -h host:12345 -f ./test.tdump

JAVA_HOME=/usr/java/jdk1.6.0_26
tdump=tdump-6_1.1.jar
#tdump=tdump-7_1.0.jar
LOG="logs/zabbix_tdump.log"

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 host port"
  exit 1;
fi

echo -n "$(date +%m%d%Y_%H%M):  $JAVA_HOME/bin/java -jar $tdump -h ${1}:${2} -f /tmp/${1}_$(date +%m%d%Y).tdump" >> $LOG
$JAVA_HOME/bin/java -jar $tdump -h ${1}:${2} -f /tmp/${1}_$(date +%m%d%Y).tdump >> $LOG

