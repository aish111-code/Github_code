#!/usr/bin/perl

$SCRIPT_NAME="tnsping";

#----------------------------------------------------------------------------
# Validate Arguments
#----------------------------------------------------------------------------
if($ARGV[0] eq "" || $ARGV[1] eq "" || $ARGV[2] eq "") 
{
print "usage: ./$SCRIPT_NAME.pl db_hostname db_port db_sid \n";
exit;
}


$ORACLE_HOME='/local/opt/oracle/11.2.0/client_home1';
$db_hostname=$ARGV[0];
$db_port=$ARGV[1];
$db_sid=$ARGV[2];


$command="export ORACLE_HOME=$ORACLE_HOME; $ORACLE_HOME/bin/tnsping '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = $db_hostname)(PORT = $db_port)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = $db_sid)))' | tail -1 ";


#print $command;

$result=`$command`;

#print $result;

$error_num=30000;

if( index($result,"OK")==-1 || index($result,"msec")==-1 || index($result,"(")==-1 )
{
#if the result is not ok, then return 30 seconds
print $error_num;
exit;
}

$start_pos=index($result,"(");
$start_pos+=1;
$end_pos=index($result," ",$start_pos);
$length=$end_pos-$start_pos;

$num=substr($result,$start_pos,$length);

print $num;

