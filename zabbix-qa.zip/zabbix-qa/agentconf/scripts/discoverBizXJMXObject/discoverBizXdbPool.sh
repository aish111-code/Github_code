#!/bin/bash
##################################################################################################################
# script name: jmx_wrapper.sh
# script purpose : To discover objectname for jmx auto discovery
# usage : objectname=$1 and attribute=$2
# script written date : 21-May-2014
# script written by : surekha pattnaik - c5188034
# Last updated :  Sandeep M.R C5182416 June 18th 2015
#################################################################################################################

# Usage Function
Usage() {
  echo "Usage - $0 <jmxPort#> <targetHost> <ObjectName>" 
}

# Check Arguments and set global variables
if [[ $# -lt 3 ]]; then
  Usage
  exit
elif [[ $# -gt 3 ]]; then
  Usage
  exit
else
  jmxPort=$1
  host=$2
  objName="${3}*"
  objName="jboss.jca:service=ManagedConnectionPool,name=*dbPool*"
fi

# Using Bash Shell to find current relative path
baseDir=${0%/*}
fullPath="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Set latest Java binary to $java 
# Note: sometimes JAVA_HOME is incorrectly set or has a very old JDK.

java="$(find /usr/local/opt  /app/sapjvm_7/ /app/sapjvm/ -maxdepth 4 -name java 2>/dev/null | sort -u | tail -1)"

getJMXObject()
{
for obj in $(echo $objects )
  do
    if [[ -z ${obj_name[@]} ]]; then
      obj_name=($obj);
   else
      obj_name=("${obj_name[@]}" ${obj})
    fi
  done
}

find_object()
{
#objects=$($java -cp ${baseDir}/JMXClient_V1.4.jar:au-V4-service-1.2.2249.84.2.jar JMXMBeanInfo jmxport=12345 jmxobjectname="${objName}"  remotehost=localhost | awk -F"|" '{print $1}' | sort -u) getJMXObject 
objects=$($java -cp ${baseDir}/JMXClient_V1.4.jar:${baseDir}/au-V4-service-1.2.2249.84.2.jar JMXMBeanInfo jmxport=12345 jmxobjectname="${objName}"  remotehost=localhost | awk -F"|" '{print $1}' | sort -u) getJMXObject 
}

# Main
find_object $1 $2

if [[ ! -z ${obj_name[@]} ]]; then
  count=0
  echo "{"
  echo -e "\"data\":["
  for objs_nms in "${obj_name[@]}"
    do
      count=$(($count+1))
      if [[ $count -lt ${#obj_name[@]} ]]; then
        echo -e "{\"{#OBJECT}\":\"$objs_nms\"},"
      else
        echo -e "{\"{#OBJECT}\":\"$objs_nms\"}"
      fi
    done
  echo -e "]"
  echo "}"
fi
