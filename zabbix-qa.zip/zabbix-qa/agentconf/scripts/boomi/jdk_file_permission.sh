#!/bin/bash

ls -lRd /export/home/boomi/jdk1.8.0_*/* | awk '$3 != "boomi" {print $9}' | awk -F"/" '{print $NF}' > /var/log/zabbix/jdkout.txt

if [ -s /var/log/zabbix/jdkout.txt ]; then
awk '{print $1}' /var/log/zabbix/jdkout.txt | xargs | sed -e 's/ /,/g'
else
echo "Permissions are correct"
fi

rm /var/log/zabbix/jdkout.txt

