#!/bin/sh

path="/var/log/zabbix"

#log rotation
if [ -f $path/lognrunning_processes.txt ]; then
    SIZE=$(ls -la $path/lognrunning_processes.txt |awk '{print $5}')
else
    touch $path/lognrunning_processes.txt
    SIZE=0
fi
if [ ${SIZE} -gt 2048000 ]; then
    rm $path/lognrunning_processes.txt
fi
#log rotation

FLAG=0
if [ -f $path/output.txt ]
then
rm $path/output.txt
fi

if [ -f $path/pid_list.txt ]
then
rm $path/pid_list.txt
fi

ctime=`date +%s`

/bin/ps -A -www -o lstart,pid,user,args | /usr/bin/grep  "execution-" | /usr/bin/grep -v "grep" > /var/log/zabbix/output.txt
/bin/ps -ef > $path/out.txt
#/bin/cat /tmp/out.txt | /usr/bin/egrep -i "execution"|wc -l
cat $path/output.txt|  awk '{print $6}' > $path/pid_list.txt
/bin/cat /dev/null > $path/a.txt
list=`cat $path/pid_list.txt`
for pid in $(cat $path/pid_list.txt)
do
       #echo -n  "pid = $pid ; "

        time_field=`grep $pid $path/output.txt | awk -F "$pid" '{print $1}'`
echo $time_field >> $path/za.txt
        stime=`date -d "$time_field" "+%s"`
echo $stime >> $path/za.txt
        time_elapse=`expr $ctime - $stime`
echo $time_elapse >> $path/za.txt
#      echo "elapse time = $time_elapse seconds"
        if [ $time_elapse -gt 86400 ]
        then
        echo $pid >> $path/a.txt
        FLAG=1
        fi

done
if [ $FLAG == 1 ]; then
result=`awk '{print $1}' $path/a.txt | xargs | sed -e 's/ /,/g'`
echo $result
echo "###########`date`#########" >> $path/lognrunning_processes.txt
        for id in `cat $path/a.txt`
        do
        ps -www  $id >> $path/lognrunning_processes.txt
        done


else
        echo "no processes"
fi
