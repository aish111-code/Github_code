#!/bin/bash
max=`cat /etc/security/limits.conf | grep -v '#' |grep boomi | grep soft | awk '{print $4}'`
#echo "max limit $max"
current=`/usr/bin/sudo lsof -u boomi |wc -l`
#echo "current value:$current"
filecount_perc=$(( 100*current/max ))
echo $filecount_perc
