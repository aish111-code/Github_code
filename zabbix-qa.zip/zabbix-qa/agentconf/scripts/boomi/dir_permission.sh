#!/bin/bash

#ls -lRd /export/home/boomi/jdk1.8.0_*/* | awk '$3 == "boomi" {print $9}' > /var/log/zabbix/out.txt
ls -ld /tmp/hsperfdata_boomi | awk '$3 != "boomi" {print $9}' >> /var/log/zabbix/out.txt
ls -ld /boomilocaldisk/boomi/accounts | awk '$3 != "boomi" {print $9}' >> /var/log/zabbix/out.txt
ls -l /tmp/i4jdaemon__u01_boomi* | awk '$3 != "boomi" {print $9}' >> /var/log/zabbix/out.txt

if [ -s /var/log/zabbix/out.txt ]; then
awk '{print $1}' /var/log/zabbix/out.txt | xargs | sed -e 's/ /,/g'
else
echo "Permissions are correct"
fi

rm /var/log/zabbix/out.txt
