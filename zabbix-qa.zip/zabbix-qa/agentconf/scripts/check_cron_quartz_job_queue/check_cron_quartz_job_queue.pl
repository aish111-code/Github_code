#!/usr/bin/perl

$SCRIPT_NAME="check_cron_quartz_job_queue";
$SCRIPT_PATH="/etc/zabbix/zabbix_agentd/scripts/$SCRIPT_NAME";


#----------------------------------------------------------------------------
# Validate Arguments
#----------------------------------------------------------------------------
if($ARGV[0] eq "" || $ARGV[1] eq "" || $ARGV[2] eq "" || $ARGV[3] eq "" || $ARGV[4] eq "" )
{
print "usage: ./$SCRIPT_NAME.pl db_user db_password db_hostname db_port db_sid\n";
exit;
}

$DB_USER=$ARGV[0];
$DB_PASSWORD=$ARGV[1];
$DB_HOSTNAME=$ARGV[2];
$DB_PORT=$ARGV[3];
$DB_SID=$ARGV[4];


$command="$SCRIPT_PATH/$SCRIPT_NAME.sh $DB_USER $DB_PASSWORD $DB_HOSTNAME $DB_PORT $DB_SID";

#print $command."\n";
$command_result=`$command`;
#print $command_result."\n";
@lines=split('\n',$command_result);
$result_found=0;
for($i=0;$i<scalar(@lines);$i++)
{
if(index(@lines[$i],'CRON')!=-1)
{
@temp=split(" ",@lines[$i]);
print @temp[0]."\n";
$result_found=1;
break;
}
}#end for loop

if($result_found==0)
{
print -1;
}

sub trim {
     my ($self, $text) = @_;
     $text = $self
           if ref(\$self) =~ m/^SCALAR/i;
     # return empty string if $text is not defined
     return "" unless $text;
     $text =~ s/^\s+//;
     $text =~ s/\s+$//;
     return $text;
}

