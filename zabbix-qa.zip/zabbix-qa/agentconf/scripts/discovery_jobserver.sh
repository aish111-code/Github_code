#Job server discovery script
#Author: Sreekanth KP
#Version: 1.0, 12/05/2017

#!/bin/bash
IP=$1
HOST=`hostname`
if [ "$HOST" == "pc16zbxpxy01" ]
then
JSERVER=`curl -s http://$IP:8080/server_statuses|grep "servers.push("|awk -F'"' {'print $2}'`
else
JSERVER=`curl -s http://$IP/server_statuses|grep "servers.push("|awk -F'"' {'print $2}'`
fi
for n in $(echo $JSERVER)
do
  if [[ -z ${List[@]} ]]; then
    List=($n);
  else
    List=("${List[@]}" ${n})
  fi
done

if [[ ! -z ${List[@]} ]]; then
count=0
echo "{"
echo -e "\"data\":["
for js in "${List[@]}"
do
   count=$(($count+1))
   if [[ $count -lt ${#List[@]} ]]; then
   echo -e "{\"{#JSERV}\":\"$js\"},"
   else
   echo -e "{\"{#JSERV}\":\"$js\"}"
   fi
done
echo -e "]"
echo "}"
fi

