#!/bin/bash

############################################
# Author  : Sandeep M. R ( i342288)
# Purpose : Get docker container statistics
# Version : 1.0
#############################################

#if [[ -z "$1" ]]; then
#    echo "Please provide all input values"
#    exit 1
#fi
statinfo()
{
        stat=`echo -e "GET /v1.21/containers/$1/stats HTTP/1.0\r\n" | netcat -q 1 -U /var/run/docker.sock|tail -1 |python -mjson.tool`
}

inspectinfo()
{
        stat=`echo -e "GET /v1.21/containers/$1/json HTTP/1.0\r\n" | netcat -q 1 -U /var/run/docker.sock|tail -1 |python -mjson.tool`
}

dockerinfo()
{
        stat=`echo -e "GET /v1.21/info HTTP/1.0\r\n" | netcat -q 1 -U /var/run/docker.sock|tail -1 |python -mjson.tool`
}


cid=$1
cname=$2
testtype=$3

case $testtype in

cpuperc)
cpupertemp=`/usr/bin/docker container stats $cname --no-stream --format "{{.CPUPerc}}" | sed 's/%//g'`
echo $cpupertemp
;;
memperc)
memperc=`/usr/bin/docker container stats $cname --no-stream --format "{{.MemPerc}}"| sed 's/%//g'`
echo $memperc
;;
pids)
pids=`/usr/bin/docker container stats $cname --no-stream --format "{{.PIDs}}"`
echo $pids
;;
cpucore)
statinfo $cid
cpucore=$( echo $stat | python -c "import sys, json; print json.load(sys.stdin)['cpu_stats']['online_cpus']")
echo $cpucore
;;
memlimit)
statinfo $cid
memlimit=$( echo $stat | python -c "import sys, json; print json.load(sys.stdin)['memory_stats']['limit']")
echo $memlimit
;;
memusage)
statinfo $cid
memusage=$( echo $stat | python -c "import sys, json; print json.load(sys.stdin)['memory_stats']['usage']")
echo $memusage
;;
dockerversion)
dockerversion=`/usr/bin/docker --version|awk '{print $3}'|sed 's/,//g'`
echo $dockerversion
;;

totalcont)
dockerinfo
totalcont=$( echo $stat | python -c "import sys, json; print json.load(sys.stdin)['Containers']")
echo $totalcont
;;

pausedcont)
dockerinfo
pausedcont=$( echo $stat | python -c "import sys, json; print json.load(sys.stdin)['ContainersPaused']")
echo $pausedcont
;;

runningcont)
dockerinfo
runningcont=$( echo $stat | python -c "import sys, json; print json.load(sys.stdin)['ContainersRunning']")
echo $runningcont
;;

stoppedcont)
dockerinfo
stoppedcont=$( echo $stat | python -c "import sys, json; print json.load(sys.stdin)['ContainersStopped']")
echo $stoppedcont
;;


esac
