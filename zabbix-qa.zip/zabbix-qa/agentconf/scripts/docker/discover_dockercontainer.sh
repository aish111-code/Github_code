#!/bin/bash

################################################
# Author  : Sandeep Renuka ( i342288 )
# Purpose : Discover all installed containers
# Version : 1.0
#################################################

containerlist=`docker ps --format "{{.ID}}:{{.Names}}"`

for n in $(echo $containerlist)
do
  if [[ -z ${ConList[@]} ]]; then
    ConList=($n);
  else
    ConList=("${ConList[@]}" ${n})
  fi
done

if [[ ! -z ${ConList[@]} ]]; then
count=0
echo "{"
echo -e "\"data\":["
for c in "${ConList[@]}"
do
   count=$(($count+1))
   if [[ $count -lt ${#ConList[@]} ]]; then

   cid=`echo $c | cut -d':' -f1`
   cname=`echo $c | cut -d':' -f2`

   echo -e "{\"{#CID}\":\"$cid\",\"{#CNAME}\":\"$cname\"},"

   else
   cid=`echo $c | cut -d':' -f1`
   cname=`echo $c | cut -d':' -f2`
   echo -e "{\"{#CID}\":\"$cid\",\"{#CNAME}\":\"$cname\"}"
   fi
done
echo -e "]"
echo "}"
fi
