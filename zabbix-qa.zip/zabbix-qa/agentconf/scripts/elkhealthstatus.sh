#!/bin/bash
curl -k -u "zabbix_user:Zabb1x@123" "https://$1:9200/_cat/health" 2> /dev/null | awk '{print $4}'
