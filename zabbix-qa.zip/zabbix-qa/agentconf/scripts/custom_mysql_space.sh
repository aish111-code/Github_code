#!/bin/bash
# This script was created for /mysql mounts monitoring by i350351 Kartik Gupta
#(source /tmp/test.sh) &> /dev/null
#for i in $(cat /var/log/zabbix/mysqlmounts.txt);
#  do
mount=$1
spacepercent=`df -h | grep -w $mount| awk '{print $5}'|cut -d '%' -f1`
echo $spacepercent
#  done

