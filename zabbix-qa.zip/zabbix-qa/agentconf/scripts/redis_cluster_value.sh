#Redis Cache script
#Author: Sreekanth K P
#Version: 1.1, 20/06/2016

#!/bin/bash

if [ $1 == "ActiveConn" ]
then
        wget -O /var/log/zabbix/cache_output  http://$2:8080/cache  > /dev/null 2>&1
fi
VALUE=`grep "<Cluster>.*.</Cluster>" /var/log/zabbix/cache_output|grep -i cluster- |awk -F"$1" '{print $2}'|sed 's/>//g'|cut -d"<" -f1`
if [ "$VALUE" == "" ]
	then
	echo "9999999"
else
	echo $VALUE
fi

