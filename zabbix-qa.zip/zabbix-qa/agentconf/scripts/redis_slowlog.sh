today=`date '+%Y_%m_%d'`
mkdir -p /var/log/zabbix/redis/
/usr/local/bin/redis-cli -p $1 -a "BjXqQQ@0%*-s#p*XTL2s" slowlog get 128 >> /var/log/zabbix/redis/redis_slowlog-$1_$today.log 2>&1
/usr/local/bin/redis-cli -p $1 -a "BjXqQQ@0%*-s#p*XTL2s" slowlog reset > /dev/null 2>&1
find /var/log/zabbix/redis/ -name "redis_slowlog-*" -type f -mtime +7 -delete
echo $?
