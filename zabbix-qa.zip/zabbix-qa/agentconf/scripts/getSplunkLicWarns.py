#!/opt/python27/bin/python2.7
import json
import sys
# Fetch some information from a LabKey server using the client API

inSlaveId = sys.argv[1]

splunkLicWarnFile = open('/tmp/splunkLicenseWarnings.json','r')
text = splunkLicWarnFile.read()
jsonToTextData = json.loads(text)
first = 1
JSONData = []
if jsonToTextData['data']:
    for splWarnData in jsonToTextData['data']:
        hostName = splWarnData['HOSTNAME']
        slaveId  = splWarnData['SLAVEID']
        message = splWarnData['MESSAGE']
        severity = splWarnData['SEVERITY']
        if inSlaveId == slaveId:
            sys.stdout.write("slaveId={},hostName={},message={},severity={}".format(slaveId,hostName,message,severity))
            sys.stdout.write("\n")
            sys.exit(0)
else:
    sys.stdout.write("No warning details found \n")
splunkLicWarnFile.close()

