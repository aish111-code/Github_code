#!/usr/bin/perl

use DBI;

$ENV{'ORACLE_HOME'}='/local/opt/oracle_x64/product/11.2.0/client_1';

$SCRIPT_NAME="check_long_running_quartz_job_queue_server_list";

#----------------------------------------------------------------------------
# Validate Arguments
#----------------------------------------------------------------------------
if($ARGV[0] eq "" || $ARGV[1] eq "" || $ARGV[2] eq "" || $ARGV[3] eq "" || $ARGV[4] eq "" || $ARGV[5] eq "" || $ARGV[6] eq "")
{
print "usage: ./$SCRIPT_NAME.pl db_user db_password db_hostname db_port db_sid time_limit(hour) jobs_limit\n";
exit;
}


#oracle db info
$oracle_db_username=$ARGV[0];
$oracle_db_password=$ARGV[1];
$oracle_db_hostname=$ARGV[2];
$oracle_db_port=$ARGV[3];
$oracle_db_sid=$ARGV[4];
$time_limit=$ARGV[5]; #in hour
$jobs_limit=$ARGV[6];

$oracle_dbh = DBI->connect("dbi:Oracle://$oracle_db_hostname:$oracle_db_port/$oracle_db_sid",$oracle_db_username,$oracle_db_password);

# prepare and execute the SQL statement
$oracle_sql="select count(*),INSTANCE_NAME from qrtz_fired_triggers
where ((cast(SYS_EXTRACT_UTC(systimestamp) as date)-to_date('1970-1-1','yyyy-mm-dd'))*24 - fired_time/3600000) > $time_limit group by INSTANCE_NAME having count(*)> $jobs_limit";

#print $oracle_sql."\n";

$oracle_sth = $oracle_dbh->prepare($oracle_sql);
$oracle_sth->execute;

$server_list="";

while(  my $oracle_ref = $oracle_sth->fetchrow_hashref() ) {

if($server_list eq "")
{
$server_list.=$oracle_ref->{'INSTANCE_NAME'} . ":" . $oracle_ref->{'COUNT(*)'};
}
else
{
$server_list.=", ".$oracle_ref->{'INSTANCE_NAME'} . ":" . $oracle_ref->{'COUNT(*)'};
}

} #end while loop

$oracle_dbh->disconnect();

print $server_list;

