#!/bin/bash
curl -k -u "zabbix_user:Zabb1x@123" "https://$1:9200/_cat/allocation" 2> /dev/null | grep $1 | awk '{print $6}'
