#!/bin/bash

##############################################################
# Script to monitor directory size
# Usage ./dir.check <PATH> <DIRECTORY NAME PATTERN> <SIZE>
# <SIZE> format 5c/w/k/M/G where c for bytes,w for words, k for KB, M for MB and G for GB. If no units are specified, default unit b(block) is assumed
# Date 10th April 2014
################################################################

if [[ ! -z $1 ]] && [[ ! -z $2 ]] && [[ ! -z $3 ]]
then
        path=$1
        pattern=$2
        size=$3
		find ${path} -type d -name ${pattern} -size +${size} 2>/dev/null
fi


