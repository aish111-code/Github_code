#!/bin/bash

LOGFILEDATEPATTERN=$(date +"%Y-%m-%d")
LOGFILENAME="redis_getput_1mbl_$LOGFILEDATEPATTERN.log"
LOGFILENAMEPATTERN="redis_getput_1mbl_*.log"
LOGFILEFOLDER="/var/log/zabbix/custom_redis_logs"
LOGPATH="$LOGFILEFOLDER/$LOGFILENAME"
TEMPDATA="/var/log/zabbix/redis_getput_1mbl_out"
REDISHOST=$(hostname)

PARAMETERS=("Get" "Put")

FINALLOGSTRING=""
DATESTRING=$(date +"%a %b %d %H:%M:%S %Y")

mkdir -p $LOGFILEFOLDER

wget -O $TEMPDATA http://$REDISHOST:8080/cache?action=getCachePerformance\&isZabbix=true 2> /dev/null

for param in "${PARAMETERS[@]}"
do
  LOGSTRING="$DATESTRING Method=$param"
  VALUE=`awk -F "$param cache L1MB cost" '{print $2}' $TEMPDATA | awk -F "ms<" '{print $1}' | awk '{print $2}'`
  if [ "$VALUE" != "" ]; then
    VALUE_STRING="L1MB_Cost=$VALUE"
    LOGSTRING="$LOGSTRING, $VALUE_STRING"
  fi

  if [ "$FINALLOGSTRING" == "" ]; then
    FINALLOGSTRING="$LOGSTRING"
  else
    FINALLOGSTRING="$FINALLOGSTRING\n$LOGSTRING"
  fi
  LOGSTRING=""
done

find $LOGFILEFOLDER -name "$LOGFILENAMEPATTERN" -type f -mtime +0 -delete
echo -e "${FINALLOGSTRING}" >> $LOGPATH

