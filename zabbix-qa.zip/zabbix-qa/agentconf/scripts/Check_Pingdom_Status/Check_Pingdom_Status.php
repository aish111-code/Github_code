#!/usr/bin/php
<?php

$checkid=$argv[1];

// Init cURL
$curl = curl_init();

// Set target URL
curl_setopt($curl, CURLOPT_URL, "https://api.pingdom.com/api/2.0/checks/$checkid");

// Disable Peer Check
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

// Set the desired HTTP method (GET is default, see the documentation for each request)
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");

// Set user (email) and password
curl_setopt($curl, CURLOPT_USERPWD, "hosting_mgr@plateau.com:NjZhZjRmOGY3");

// Add a http header containing the application key (see the Authentication section of this document)
curl_setopt($curl, CURLOPT_HTTPHEADER, array("App-Key: 1vq3y94eeuthoqw32dvq0qu7xmqoydz2"));

// Ask cURL to return the result as a string
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

// Execute the request and decode the json result into an associative array
$response = json_decode(curl_exec($curl),true);

// Check for errors returned by the API
if (isset($response['error'])) {
		print "Error: " . $response['error']['errormessage'] . "\n";
		exit;
}


// Fetch the list of checks from the response
$check = $response['check'];

if($check['status']=='down')
{
echo "0";
}
else if($check['status']=='up')
{
echo "1";
}
else if($check['status']=='unconfirmed_down')
{
echo "2";
}
else if($check['status']=='unknown')
{
echo "3";
}
else if($check['status']=='paused')
{
echo "4";
}
else
{
echo "-1";
}



?>

