#!/bin/bash
#######################################################################
# Author : Platform Services MSS (C5176337)
# Purpose : To find the correct TMS log file & its usage
# Date : October 17th 2016
########################################################################
cd /local/customers/plateau/plateau-talent-management/logs
LogName="$(ls -ltrh TMS-*.log | grep -v perflog | awk -F" " '{print $9}')"
du -b $LogName |awk -F" " '{printf$1}'
