#!/bin/bash
#This script was created for /mysql mounts monitoring by i350351 Kartik Gupta
IFS='
'

df -h | grep 'mysql' | awk '{print $6}' > /var/log/zabbix/mysqlmounts.txt
count=0
filecount=`cat /var/log/zabbix/mysqlmounts.txt | wc -l`

echo "{"
echo -e '"data":['

for i in $(cat /var/log/zabbix/mysqlmounts.txt);
  do
     count=$(($count+1))
        if [ $count -lt $filecount ]; then
           echo -e "{\"{#FILESYSTEM}\":\"$i\"},"
        else
           echo -e "{\"{#FILESYSTEM}\":\"$i\"}"
        fi
  done
echo -e "]"
echo "}"


