###############################################
##Author: Sreekanth KP
#Safemode check
#version 1.0, 17/05/2016
################################################

wget -O /var/log/zabbix/getCachePerformance http://$2:8080/cache?action=getCachePerformance\&isZabbix=true 2> /dev/null
cat /var/log/zabbix/getCachePerformance|awk -F "$1 cache L1MB cost" '{print $2}'|awk -F "ms<" '{print $1}'|awk '{print $2}'

