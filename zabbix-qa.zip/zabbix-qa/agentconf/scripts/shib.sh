#!/bin/bash

SHIB_PATH=/etc/shibboleth

if [[ -z $1 ]]; then
  exit
fi

findCustomers () {
  customers=$(find /etc/shibboleth/ -type d | grep -v certs)
  if [[ ! -z $customers ]]; then
    for cust in $(echo $customers)
    do
      if [[ ${cust#*/etc/shibboleth/} ]]; then
        if [[ -z ${custList[@]} ]]; then
          custList=(${cust#*/etc/shibboleth/});
        else
          custList=("${custList[@]}" ${cust#*/etc/shibboleth/})
        fi
      fi
    done
  else
    custList=""
  fi
}
case $1 in

# Return 0 if entityID is found in shibboleth2.xml.  Return 1 if not found.
"entityID")
  if [[ ! -z $2 ]]; then
    CUST=$2
    if [[ -f ${SHIB_PATH}/${CUST}/idp.xml ]]; then
      entityID=$(grep entityID ${SHIB_PATH}/${CUST}/idp.xml | sed "s/.*entityID=\"\(.*\)\".*/\1/g" | awk -F "\"" '{ print $1 }')
      if [[ $(grep ${entityID} ${SHIB_PATH}/shibboleth2.xml) ]]; then
        echo "0"
      else
        echo "1"
      fi
    fi
  fi
;;

"discovery")
  findCustomers
  echo ${custList[@]}
  if [[ ! -z ${custList[@]} ]]; then
    count=0
    echo "{"
    echo -e "\"data\":["
    for cust in "${custList[@]}"
      do
        count=$(($count+1))
        if [[ $count < ${#custList[@]} ]]; then
          echo -e "{\"{#CUST}\":\"$cust\"},"
        else
          echo -e "{\"{#CUST}\":\"$cust\"}"
        fi
      done
    echo -e "]"
    echo "}"
  fi
  ;;

*)
  echo "unknown param"
  ;;
esac
