#!/bin/bash

if [ $# -ne 2 ]
then
  echo "Failed-MissingParameters"
  exit 1
fi

JAVA_PATH=`cat /proc/$(pgrep -u sfuser -f 'java.*-server')/cmdline | awk -F- '{print $1}'`
JAVA_BIN=`dirname $JAVA_PATH`
JAVA_HOME=`dirname $JAVA_BIN`

export PATH=$JAVA_BIN:$PATH
export JAVA_HOME

username=$1
password=$2

LOCALIP=`/sbin/ifconfig | awk '/inet addr:/ { print $2 }' | egrep -v "addr:127.0.0.1|addr:1.1.1.1" | head -1 | awk -F: '{print $2}'`

JBOSSHOME=`ps -efww | grep java | sed -n 's/.*-Djboss.home.dir=\(.*\)/\1/p' | awk '{print $1}'`

CHECK_RESULT=`($JBOSSHOME/bin/jboss-cli.sh -c --user=$username --password=$password --controller=$LOCALIP:9999 --timeout=30000 "/subsystem=messaging/hornetq-server=default:read-attribute(name=started),/subsystem=messaging/hornetq-server=default:read-attribute(name=active) ,/subsystem=messaging/hornetq-server=default/cluster-connection=my-cluster:read-resource(include-runtime=true)" | egrep '"result" => true|nodes=2|members=2' | wc -l) 2> /dev/null`

if [[ $CHECK_RESULT -eq 3 ]]
then
  echo "Success"
else
  echo "Failed"
fi
