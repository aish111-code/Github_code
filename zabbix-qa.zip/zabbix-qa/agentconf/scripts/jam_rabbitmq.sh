#!/bin/bash

while [[ $# > 0 ]]; do
        key="$1"

        case $key in
                -q|--queue)
                QUEUE="$2"
                shift
                ;;
                -h|--help)
                echo "Use -q or --queue to set the queue to check for example: searchindexing."
                exit 2
                ;;
                *)
                echo "$key is an unavailable option please use -h or --help to see the options."
                exit 1
                ;;
        esac
        shift
done

if [[ -z "$QUEUE" ]]; then
        echo "Please set the queue. Use -h or --help for more information."
        exit 1
fi

output=$(docker exec ct_cron_everywhere bundle exec ruby script/show_dj_queue_sizes.rb $QUEUE)
echo $output

exit 0
