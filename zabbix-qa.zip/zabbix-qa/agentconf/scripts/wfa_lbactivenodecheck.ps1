Param(
	[string]$lhost
)

$lbstatus = 6
$r1 = $null
$resp1 = $null
$reqstream1 = $null
$sr1 = $null
$result1 = $null

$r1 = [System.Net.WebRequest]::Create($lhost)
$resp1 = $r1.GetResponse()
$reqstream1 = $resp1.GetResponseStream()
$sr1 = new-object System.IO.StreamReader $reqstream1
$result1 = $sr1.ReadToEnd()

$idx = $result1.IndexOf("App")
$result1 = $result1.Substring($idx+3, 2)
if (($result1 -ne "01") -and ($result1 -ne "02"))
{
	$result1 = -1
}
Write-Host $result1
$date = Get-Date 
[String]$res = "LB is active on node" + "$result1" + " @ " + "$date"
$res >> "C:\Program Files\WFA Scripts\log\lbresult_log.txt"

$resp1.Close()