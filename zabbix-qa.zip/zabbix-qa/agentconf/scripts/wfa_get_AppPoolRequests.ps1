Param(
	[string]$appPoolName = "DefaultAppPool"
)

$appcmd = "c:\windows\system32\inetsrv\appcmd.exe"

$processid = &$appcmd list wps /apppool.name:"$appPoolName" /text:WP.NAME


[String]$req = &$appcmd list requests /wp.name:$processid

$reqc = ([regex]::Matches($req, "REQUEST " )).count

write-host $reqc
