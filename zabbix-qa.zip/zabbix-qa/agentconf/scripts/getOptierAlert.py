#!/opt/python27/bin/python2.7
import json
import sys
# Fetch some information from a LabKey server using the client API

inpMetricId = int(sys.argv[1])
ipAdd = str(sys.argv[2])

optierMetricFile = open('/tmp/optierMetric.json','r')
text = optierMetricFile.read()
jsonToTextData = json.loads(text)
first = 1
JSONData = []
if jsonToTextData['data']:
    for metricData in jsonToTextData['data']:
        metricName = metricData['METRICNAME']
        metricId = int(metricData['METRICID'])
        metricStatus = metricData['STATUS']
        if inpMetricId == metricId:
            sys.stdout.write(metricStatus)
            sys.stdout.write("\n")
            sys.exit(0)
else:
    sys.stdout.write("No Metric details found \n")
optierMetricFile.close()
