#Author: Sreekanth KP
#NFS Discovery script
#version 1.0, 13/04/2016
#!/bin/bash


nfs=`mount|grep "type nfs"|awk '{print $3}'|sed 's:/:\\\/:g'`
for n in $(echo $nfs)
do
  if [[ -z ${devList[@]} ]]; then
    devList=($n);
  else
    devList=("${devList[@]}" ${n})
  fi
done

if [[ ! -z ${devList[@]} ]]; then
count=0
echo "{"
echo -e "\"data\":["
for device in "${devList[@]}"
do
   count=$(($count+1))
   if [[ $count -lt ${#devList[@]} ]]; then
   echo -e "{\"{#NFS}\":\"$device\"},"
   else
   echo -e "{\"{#NFS}\":\"$device\"}"
   fi
done
echo -e "]"
echo "}"
fi

