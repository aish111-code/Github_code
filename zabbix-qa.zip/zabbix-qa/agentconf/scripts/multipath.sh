#!/bin/bash
#

#
# LUN path health checking
#


# 05/12/2017  Zsombor Bolyoczki



ERRORS_FOUND=0


####################################################################################################
# Linux
####################################################################################################
if [ $(uname) == "Linux" ]; then

  if [ $(lsmod | grep -E "multipath" -c) -gt 0 ]; then

    if [ $(multipath -ll 2>/dev/null | grep -E "  \|\-" | grep -E -cv " active ") -gt 0 ]; then
      ERRORS_FOUND=1
    fi

  elif [ $(which powermt >/dev/null 2>&1; echo $?) -eq 0 ]; then

    if [ $(powermt display dev=all 2>/dev/null | grep " fnic " | grep -E -vc " alive ") -gt 0 ]; then
      ERRORS_FOUND=1
    fi

  fi

fi

####################################################################################################
# Solaris
####################################################################################################
if [ $(uname) == "SunOS" ]; then

  if [ $(which powermt >/dev/null 2>&1; echo $?) -eq 0 ]; then

    if [ $(powermt display dev=all 2>/dev/null | grep " pci" | grep -cv " alive ") -gt 0 ]; then
      ERRORS_FOUND=1
    fi

  fi

fi


####################################################################################################
# Return the status
####################################################################################################

if [ ${ERRORS_FOUND} -eq 1 ]; then
  echo "NOK"
else
  echo "OK"
fi

