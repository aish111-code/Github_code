#!/bin/bash

mount=$1

spacepercent=`df -h | grep -w $mount| awk '{print $5}'|cut -d '%' -f1`
echo $spacepercent
