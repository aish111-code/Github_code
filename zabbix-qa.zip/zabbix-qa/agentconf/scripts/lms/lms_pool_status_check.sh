#!/bin/bash

if [[ -e /etc/puppet/puppet.conf ]] && [[ `grep 'server=' /etc/puppet/puppet.conf|wc -l` -gt 1 || `grep 'server =' /etc/puppet/puppet.conf|wc -l` -gt 1 ]]; then

echo -e `echo "
$(export FACTERLIB=$FACTERLIB:/var/lib/puppet/lib/facter;facter hostname),
$(export FACTERLIB=$FACTERLIB:/var/lib/puppet/lib/facter;facter sf_lms_pool),
$(export FACTERLIB=$FACTERLIB:/var/lib/puppet/lib/facter;facter sf_lms_ver),
$(export FACTERLIB=$FACTERLIB:/var/lib/puppet/lib/facter;facter sf_lms_ver_installtime),
$(export FACTERLIB=$FACTERLIB:/var/lib/puppet/lib/facter;facter sf_lms_java_running),
$(export FACTERLIB=$FACTERLIB:/var/lib/puppet/lib/facter;facter sf_lms_java_starttime),
$(export FACTERLIB=$FACTERLIB:/var/lib/puppet/lib/facter;facter sf_lms_login)" | tr -d "\n"`

else
sf_hostname=`ohai -d /opt/ohai_plugins/ sf_hostname | grep '"' | awk -F '"' '{print $2}'`
app_pool=`ohai -d /opt/ohai_plugins/ sf_lms_app/app_pool | grep '"' | awk -F '"' '{print $2}'`
version=`ohai -d /opt/ohai_plugins/ sf_lms_app/version | grep '"' | awk -F '"' '{print $2}'`
version_installtime=`ohai -d /opt/ohai_plugins/ sf_lms_app/version_installtime | grep '"' | awk -F '"' '{print $2}'`
java_running=`ohai -d /opt/ohai_plugins/ sf_lms_app/java_running | grep '"' | awk -F '"' '{print $2}'`
java_starttime=`ohai -d /opt/ohai_plugins/ sf_lms_app/java_starttime | grep '"' | awk -F '"' '{print $2}'`
login_status=`ohai -d /opt/ohai_plugins/ sf_lms_app/login_status | grep '"' | awk -F '"' '{print $2}'`

echo -e `echo "${sf_hostname},${app_pool},${version},${version_installtime},${java_running},${java_starttime},${login_status}" | tr -d "\n"`

fi