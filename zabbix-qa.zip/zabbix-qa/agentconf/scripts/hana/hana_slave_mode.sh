#!/bin/sh
IFS=''

slave_file1="/etc/zabbix/zabbix_agentd/scripts/hana/slave_file"
slave_file2="/usr/local/etc/zabbix_agentd.conf.d/scripts/hana/slave_file"
if [ -f $slave_file1 ]
then
slave_file=$slave_file1
elif [ -f $slave_file2 ]
then
slave_file=$slave_file2
else
slave_file="NOSTATUS"
fi
cat $slave_file

