#!/bin/bash

##################################################################################################
# Date Created : 12th Dec 2015
# Author       : Sandeep M.R  C5182416
# Review       : Patrick Presto
# Purpose      : To discover {HANACELL-SID1}{HANACELL-INSTANCE1}{#HANACELL-PORT}{#HANACELLPORT-NAME}
##################################################################################################

IFS='
'

#Initialize Variables

baseDir=${0%/*}
working_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
today=`date +"%m-%d-%y"`
log_dir="/var/log/zabbix"
log_file="/var/log/zabbix/hana.log"
mode_file=$working_dir/mode_file
DB_user="HCHECK"
DB_pwd="M2SNVhxZNxyrV"
service_file="/usr/sap/sapservices"

### Discover all checks ( port number, port name, check id and check name) from hana database table _sys_statistics.STATISTICS_LAST_CHECKS     {HANAALERTID} {HANAALERTNAME}

master_fun() {
HANASID=$1
HANAINSTANCE=$2
DB_user=$3
DB_pwd=$4
scount=$5
#Discover Ports

#echo "{"
#echo -e "\"data\":["
IFS=''


# Read DB state

     i=`grep $HANASID /usr/sap/sapservices`
     host_name=`echo $i | awk -F'/' '{print $18}'|tr -d [:space:]| cut -d'_' -f3 | cut -d'-' -f1`
     SID=`echo $HANASID | tr '[:upper:]' '[:lower:]'`
     #result=`sudo su - ${SID}adm -c "python /usr/sap/$HANASID/HDB$HANAINSTANCE/exe/python_support/landscapeHostConfiguration.py" | grep -w "$host_name" | awk -F'|' '{print$13}'`
     #DBSTATE=`echo $result | xargs`
     #echo $DBSTATE

        if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
        then
     db_result=`/usr/sap/$HANASID/hdbclient/hdbsql  -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS'  2>&1 >/dev/null`
        else
        if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
        then
     db_result=`/mnt/shared/$HANASID/hdbclient/hdbsql  -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS'  2>&1 >/dev/null`
        else
        if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
        then
     db_result=`/hana/shared/$HANASID/hdbclient/hdbsql  -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS'  2>&1 >/dev/null`
        fi
        fi
        fi
     #echo $db_result

    sql_error=`echo $db_result | grep "SQLSTATE: 28000"`
    conn_refused=`echo $db_result | grep 'Connection refused'`
    error_refuse="* -10709: Connection failed (RTE:[89006] System call 'connect' failed, rc=111:Connection refused)"
    invalidcredential="* 10: invalid username or password:  SQLSTATE: 28000"
    authenticationfailed="* 10: authentication failed SQLSTATE: 28000"

    if [[ "${sql_error}" == "${invalidcredential}" ]]
        then
            if [ $scount -eq 1 ]
            then
            echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"9990\", \"{#HANACELL_ALERTNAME}\":\"AUTHENTICATIONERROR\"}"
            else
            echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"9990\", \"{#HANACELL_ALERTNAME}\":\"AUTHENTICATIONERROR\"},"

            fi

    elif [[ "${conn_refused}" == "${error_refuse}" ]]
    #elif [[ ${conn_refused} == '* -10709: Connection failed (RTE:[89006] System call 'connect' failed, rc=111:Connection refused)' ]]
          then
           if [ $scount -eq 1 ]
            then
            echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"9991\", \"{#HANACELL_ALERTNAME}\":\"CONNECTIONREFUSED\"}"
            else
            echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"9991\", \"{#HANACELL_ALERTNAME}\":\"CONNECTIONREFUSED\"},"
           fi
    elif [[ ${sql_error} == "${authenticationfailed}" ]]

        then
            if [ $scount -eq 1 ]
            then
            echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"9990\", \"{#HANACELL_ALERTNAME}\":\"AUTHENTICATIONERROR\"}"
            else
            echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"9990\", \"{#HANACELL_ALERTNAME}\":\"AUTHENTICATIONERROR\"},"

            fi

    else

if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/checks_discovered
else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/checks_discovered
else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/checks_discovered
fi
fi
fi

tail -n +2 ${working_dir}/checks_discovered | head -n -2 > ${working_dir}/checks_disc  # to delete unwanted header and trailer records from discovered checks file for further processing
sed -i 's/[/-]//g' ${working_dir}/checks_disc
sed -i 's/[()]//g' ${working_dir}/checks_disc
sed -i 's/[_]//g' ${working_dir}/checks_disc
sed -i 's/[#"`*?[]{}~$!&;()<>|#@]//g' ${working_dir}/checks_disc
count=0
rm ${working_dir}/checks_discovered
IFS=''
tiercount=`cat ${working_dir}/checks_disc | wc -l | awk '{print $1}'`

while read ids
do
        count=$(($count+1))
        if [[ $count -lt $tiercount ]]
        then
                HANAALERTID=`echo $ids|awk -F',' '{print $1}'`
                HANAALERTNAME=`echo $ids | awk -F',' '{print $2}'| sed  's/\"//g'`

                echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"$HANAALERTID\", \"{#HANACELL_ALERTNAME}\":\"$HANAALERTNAME\"},"
        elif [ $scount -eq 1 ]
        then
                HANAALERTID=`echo $ids|awk -F',' '{print $1}'`
                HANAALERTNAME=`echo $ids | awk -F',' '{print $2}' |sed  's/\"//g'`
                echo -e "{\"{#HANACELL_SID2}\":\"$HANASID\", \"{#HANACELL_INSTANCE2}\":\"$HANAINSTANCE\", \"{#HANACELL_ALERTID}\":\"$HANAALERTID\", \"{#HANACELL_ALERTNAME}\":\"$HANAALERTNAME\"}"
        fi
done < ${working_dir}/checks_disc
rm ${working_dir}/checks_disc


   fi



}
##identify function till jun 2018##
#identify_mode() {
### Code to identify if database is currently running in MASTER/SLAVE mode without querying the database by only running the python script provided by hana
#mod=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} -o ${working_dir}/db_result 'select TOP 2 ALERT_ID from _sys_statistics.STATISTICS_LAST_CHECKS'`
#db_result=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' 2>&1`


#db_result=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' 2>&1 >/dev/null`
 #echo "db result is $db_result" >> $log_file
  #        sql_error=`echo $db_result | grep "SQLSTATE: 28000"`
   #        if [[ ${sql_error} == '* 10: invalid username or password:  SQLSTATE: 28000' ]]
    #        then
#        echo '{'
 #       echo -e '"data":['
  #      echo -e "{\"{#HANASID}\":\"$HANASID\", \"{#HANAINSTANCE}\":\"$HANAINSTANCE\", \"{#HANAALERTID}\":\"99\", \"{#HANAALERTNAME}\":\"Invalid Username Password\", \"{#STATE}\":\"$STATE\"}"
   #     echo -e ']'
    #    echo '}'
     #   exit 1
      #  fi
#
 #       statistics_proc=`ps -ef|grep hdbstatisticsserver | grep -v grep`
  #      statistics_process=`echo $?`
   #     echo $statistics_process >> $log_file
    #    conn_refuse=`echo $db_result | grep 'Connection refused'`
     #   error_refuse="* -10709: Connection failed (RTE:[89006] System call 'connect' failed, rc=111:Connection refused)"
      #  if [ $statistics_process -eq 1 ] && [ $conn_refuse == $error_refuse ]
       # then
#        echo '{'
 #       echo -e '"data":['
  #      echo -e "{\"{#HANASID}\":\"$HANASID\", \"{#HANAINSTANCE}\":\"$HANAINSTANCE\", \"{#HANAALERTID}\":\"11111\", \"{#HANAALERTNAME}\":\"NO ALERTNAME\", \"{#STATE}\":\"SLAVE\"}"
   #     echo -e ']'
    #    echo '}'
     #   exit 1
      #  else
       # echo "Some other Database error kindly check hana.log" >> $log_file
        #fi

#statistics_proc=`ps -ef|grep hdbstatisticsserver | grep -v grep`
 #statistics_process=`echo $?`
  #echo $statistics_process >> $log_file
   #if [ $statistics_process -eq 0 ] && [[ $conn_refuse != $error_refuse ]]   # hdbstatisticsserver process is always present in the master server and connection failed error should not come for master
    #then
     #echo "$host_name is master" >> $log_file
#STATE=MASTER
 #master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd $STATE
  #else
   #STATE=SLAVE
    #echo "$host_name is slave" >> $log_file
     #fi

### Code to identify if database is currently running in MASTER/SLAVE mode without querying the database by only running the python script provided by hana
##############################################################################################################################################################


#STATE=$(sudo su -c"cat /usr/sap/$HANASID/SYS/global/hdb/custom/config/nameserver.ini" | grep "$host_name" | grep active_master | awk '{print $1}' | cut -c 8-|tr '[:lower:]' '[:upper:]' )

#if [ "$STATE" = "MASTER" ]
#then
#echo "$host_name is master at `date`" >> $log_file
#master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd $SID_count
#else
#echo "$host_name is not master at `date`" >> $log_file
#fi

#}
#identify_mode $HANASID $HANAINSTANCE

identify_mode() {
HANASID=$1
INSTANCE=$2
host_name=$3
DB_user=$4
DB_pwd=$5

if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${INSTANCE} -u ${DB_user} -p ${DB_pwd} "select  CASE WHEN INDEXSERVER_ACTUAL_ROLE = 'SLAVE' THEN 'WORKER' ELSE  INDEXSERVER_ACTUAL_ROLE END AS ROLE from M_LANDSCAPE_HOST_CONFIGURATION T1 JOIN m_host_information T2  on T1.HOST = T2.HOST  where T2.KEY = 'net_realhostname' AND ( T1.HOST = '$host_name' OR  T2.VALUE = '$host_name')" &> /var/log/zabbix/db_state
else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${INSTANCE} -u ${DB_user} -p ${DB_pwd} "select  CASE WHEN INDEXSERVER_ACTUAL_ROLE = 'SLAVE' THEN 'WORKER' ELSE  INDEXSERVER_ACTUAL_ROLE END AS ROLE    from M_LANDSCAPE_HOST_CONFIGURATION T1 JOIN m_host_information T2  on T1.HOST = T2.HOST  where T2.KEY = 'net_realhostname' AND ( T1.HOST = '$host_name' OR  T2.VALUE = '$host_name')" &> /var/log/zabbix/db_state
else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${INSTANCE} -u ${DB_user} -p ${DB_pwd} "select  CASE WHEN INDEXSERVER_ACTUAL_ROLE = 'SLAVE' THEN 'WORKER' ELSE  INDEXSERVER_ACTUAL_ROLE END AS ROLE    from M_LANDSCAPE_HOST_CONFIGURATION T1 JOIN m_host_information T2  on T1.HOST = T2.HOST  where T2.KEY = 'net_realhostname' AND ( T1.HOST = '$host_name' OR  T2.VALUE = '$host_name')" &> /var/log/zabbix/db_state
fi
fi
fi
echo "db state by discoverHanAalert " >> $log_file
cat /var/log/zabbix/db_state >> $log_file
grep -q "Connection failed" /var/log/zabbix/db_state
conn_fail=`echo $?`

if [ "$conn_fail" -eq "0" ]
then
 DBSTATE="standby"
else
 DBSTATE=`cat /var/log/zabbix/db_state | awk 'FNR==2 {print}' | tr '[:upper:]' '[:lower:]' | cut -d '"' -f2`
fi

if [ "$DBSTATE" = "master" ]
then
echo "$host_name is master at discoverHanAalert.sh `date`" >> $log_file
master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd $SID_count
else
echo "$host_name is not master at `date`" >> $log_file
if [ $SID_count -eq 1 ];then
echo "{}"
fi
fi

}

# Check if more than 1 instances are present
SID_count=`awk '/LD_LIBRARY_PATH/{n++}; END {print n+0}' $service_file`

#echo $SID_count

count=`grep -F LD_LIBRARY_PATH $service_file`
echo "{"
echo -e "\"data\":["
for i in $count
                do
                        HANASID=`echo $i | awk -F'/' '{print $4}'|tr -d [:space:]`
                        HANAINSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print substr($0,4,2)}'`
                        INSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print ($0)}'`
                        host_name=`echo $i | awk -F'/' '{print $18}'|tr -d [:space:]| cut -d'_' -f3 | cut -d'-' -f1`
                        #identify_mode $HANASID $HANAINSTANCE
                        #master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd $SID_count
                        identify_mode $HANASID $HANAINSTANCE $host_name $DB_user $DB_pwd
                        SID_count=$(($SID_count-1))

                done
echo -e "]"
echo "}"

#echo "Script execution finished at `date`" >> $log_file

