#!/bin/bash

##################################################################################################
# Date Created : 12th Dec 2015 
# Author       : Sandeep M.R  C5182416 
# Purpose      : To read metric data for hanacell metrics 
#########################################################################################

IFS='
'

#Initialize Variables 

baseDir=${0%/*}
working_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
today=`date +"%m-%d-%y"`
log_dir="/var/log/zabbix"
log_file="/var/log/zabbix/hana.log"
mode_file=$working_dir/mode_file
DB_user="HCHECK"
#DB_user="$1"
#DB_pwd="$2"
DB_pwd="M2SNVhxZNxyrV"
service_file="/usr/sap/sapservices"
HANASID=$1
HANAINSTANCE=$2
HANAALERTID=$3

#echo "Script execution started at `date`" > $log_file

i=`grep $HANASID /usr/sap/sapservices`
host_name=`echo $i | awk -F'/' '{print $18}'|tr -d [:space:]| cut -d'_' -f3 | cut -d'-' -f1`

master_fun() {
HANASID=$1
HANAINSTANCE=$2
DB_user=$3
DB_pwd=$4
STATE=$5

if [ $HANAALERTID -eq 9990 ]
then
	HANALCR=9990
	echo $HANALCR
elif [ $HANAALERTID -eq 9991 ]
then
	HANALCR=9991
        echo $HANALCR
else

HANA_LCR=`/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select ALERT_LAST_CHECK_RATING from _sys_statistics.STATISTICS_LAST_CHECKS where ALERT_ID=${HANAALERTID}"` 

    sql_error=`echo $HANA_LCR | grep "SQLSTATE: 28000"`
    conn_refused=`echo $db_result | grep 'Connection refused'`
    error_refuse="* -10709: Connection failed (RTE:[89006] System call 'connect' failed, rc=111:Connection refused)"
    invalidcredential="* 10: invalid username or password:  SQLSTATE: 28000"
    authenticationfailed="* 10: authentication failed SQLSTATE: 28000"

    if [[ "${sql_error}" == "${invalidcredential}" ]]
        then
             HANA_LCR=9990
             echo $HANA_LCR

    elif [[ "${conn_refused}" == "${error_refuse}" ]]
          then
             HANA_LCR=9991
             echo $HANA_LCR
 
     elif [[ ${sql_error} == "${authenticationfailed}" ]]
        then
	    HANA_LCR=9990
            echo $HANA_LCR
    else
HANALCR=`echo $HANA_LCR | awk '{print $2}'`
echo $HANALCR
    fi


fi

}

master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd 

#echo "Script execution finished at `date`" >> $log_file

