#!/bin/sh

########################################################################################################################################################################################
#Date Created : 05th-Jan-2015
#Author       : Surekha Pattnaik ( C5188034 )
#Script Name  : hana_lastcheckrating.sh
#Purpose      : To discover the HANA LAST CHECK RATING value which decides the serverity for alert creation in zabbix
########################################################################################################################################################################################
IFS='
'
#IFS=''
#### variables defined section
#working_dir="/usr/local/etc/zabbix_agentd.conf.d/scripts/hana"
baseDir=${0%/*}
working_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
today=`date +"%m-%d-%y"`
log_dir="/var/log/zabbix"
log_file="/var/log/zabbix/hana.log"
#vsaname=`uname -a`
#host_name=`echo $vsaname | awk '{print $2}'`
host_name=`cat /usr/sap/sapservices |grep 'LD_LIBRARY_PATH'| awk '{print $3}' | awk -F'_' '{print $NF}' | uniq`
#echo "Script hana_lastcheckrating.sh execution started at `date`" >> $log_file

#DB_user=$1
#DB_pwd=$2
HANASID=$1
HANAINSTANCE=$2
HANAALERTID=$3
HANAALERTNAME="$4"

DB_user="HCHECK"
DB_pwd="M2SNVhxZNxyrV"
#echo $DB_user $DB_pwd

#echo "HANASID=$HANASID" >> $log_file
#echo "HANAINSTANCE=$HANAINSTANCE" >> $log_file
#echo "HANAALERTID=$HANAALERTID" >> $log_file
#echo "HANAALERTNAME=$HANAALERTNAME" >> $log_file

hana_lcr() {
#HANA_LCR=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select ALERT_LAST_CHECK_RATING from _sys_statistics.STATISTICS_LAST_CHECKS where ALERT_ID=${HANAALERTID}"`
if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
HANA_LCR=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select ALERT_LAST_CHECK_RATING from _sys_statistics.STATISTICS_LAST_CHECKS where ALERT_ID=${HANAALERTID}"`

else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
HANA_LCR=`/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select ALERT_LAST_CHECK_RATING from _sys_statistics.STATISTICS_LAST_CHECKS where ALERT_ID=${HANAALERTID}"`

else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
HANA_LCR=`/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select ALERT_LAST_CHECK_RATING from _sys_statistics.STATISTICS_LAST_CHECKS where ALERT_ID=${HANAALERTID}"`

fi
fi
fi

#HANA_LCR=`/usr/local/etc/zabbix_agentd.conf.d/scripts/hana/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS" 2>$1 >/dev/null`
#HANA_LCR=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select ALERT_LAST_CHECK_RATING from _sys_statistics.STATISTICS_LAST_CHECKS where ALERT_ID=${HANAALERTID}" 2>&1 >/dev/null`

        HANALCR=`echo $HANA_LCR | awk '{print $2}'`
#       HANALCR=`echo $HANALCR |head -2|tail -1`
        echo $HANALCR
        echo "HANALCR=$HANALCR" >> $log_file
echo "Script hana_lastcheckrating.sh execution finished at `date`" >> $log_file
}
count=0
#`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS" 2>$1 >/dev/null`
#db_output=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS"`
if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
db_output=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS"`

else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
db_output=`/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS"`

else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
db_output=`/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} "select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS"`

fi
fi
fi

	conn_success=`echo $db_output|grep '1 row selected'`
        if [ $? -eq 0 ]
        then
        db_result='0'
        fi

	conn_failed=`echo $db_output|grep 'SQLSTATE: 28000'`
	if [ $? -eq 0 ]
	then
	db_result='10'
	fi	
	
	conn_failed=`echo $db_output|grep 'Insufficient Privilege'`
	if [ $? -eq 0 ]
	then
	db_result='258'
	fi

        conn_failed=`echo $db_output|grep 'Invalid SID'`
        if [ $? -eq 0 ]
        then
        db_result='127'
	fi


#db_result=`echo $?`

case $db_result in
     10)
          return_value="Invalid DB Username Password"
          echo "$return_value 10"  >> $log_file
          HANALCR='10'
          echo $HANALCR
          ;;
      43)
          return_value="Invalid HANA INSTANCE"
          echo "$return_value 43" >> $log_file
          HANALCR='43'
          echo $HANALCR
          ;;
      127)
          return_value="Invalid SID"
          echo "$return_value 127" >> $log_file
          HANALCR='127'
          echo $HANALCR
          ;;
      258)
          return_value="Insufficient Privilege"
          echo "$return_value 258" >> $log_file
          HANALCR='258'
          echo $HANALCR
          ;;
       0)
          return_value="OK"
          echo "$return_value 0" >> $log_file
          hana_lcr
          ;;
        *)
          echo "Randon number 99" >> $log_file
          HANALCR='99'
          echo $HANALCR
          ;;
esac

