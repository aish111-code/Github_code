#!/bin/bash

##################################################################################################
# Date Created : 12th Dec 2015
# Author       : Sandeep M.R  C5182416
# Review       : Patrick Presto
# Purpose      : To discover {HANACELL-SID1}{HANACELL-INSTANCE1}{#HANACELL-PORT}{#HANACELLPORT-NAME}
##################################################################################################
# Modified Date : 31st Oct 2016
# Change by : Nandhini Chander C5242481
# Review : KP Sreekanth
# Change Description : To discover only Learnfit ports with SID LA6. Only one Leranfit server
#                      in zabbix i.e dc8lfhdb01. Script is called in Learnfir template
##################################################################################################

IFS='
'

#Initialize Variables

baseDir=${0%/*}
working_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
today=`date +"%m-%d-%y"`
log_dir="/var/log/zabbix"
log_file="/var/log/zabbix/hana.log"
mode_file=$working_dir/mode_file
DB_user="HCHECK"
#DB_user="$1"
#DB_pwd="$2"
DB_pwd="M2SNVhxZNxyrV"
service_file="/usr/sap/sapservices"




#echo "Script execution started at `date`" > $log_file


### Discover all checks ( port number, port name, check id and check name) from hana database table _sys_statistics.STATISTICS_LAST_CHECKS     {HANAALERTID} {HANAALERTNAME}

master_fun() {
HANASID=$1
HANAINSTANCE=$2
DB_user=$3
DB_pwd=$4
scount=$5
#Discover Ports

#echo "{"
#echo -e "\"data\":["
IFS=''

           echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"00\", \"{#HANACELL_PORTNAME}\":\"daemon\"},"
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"01\", \"{#HANACELL_PORTNAME}\":\"nameserver\"},"
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"02\", \"{#HANACELL_PORTNAME}\":\"preprocessor\"},"
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"03\", \"{#HANACELL_PORTNAME}\":\"indexserver-service\"},"
               echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"15\", \"{#HANACELL_PORTNAME}\":\"indexserver-sql\"},"
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"80"$HANAINSTANCE"\", \"{#HANACELL_PORTNAME}\":\"sapwdisp_hdb80\"},"
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"43"$HANAINSTANCE"\", \"{#HANACELL_PORTNAME}\":\"sapwdisp_hdb43\"},"
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"06\", \"{#HANACELL_PORTNAME}\":\"webdispatcher06\"},"
                #echo -e "{\"{#HANACELL-SID1}\":\"$HANASID\", \"{#HANACELL-INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL-PORT}\":\"80"$HANAINSTANCE"\", \"{#HANACELL-PORTNAME}\":\"webdispatcher80\"},"
                #echo -e "{\"{#HANACELL-SID1}\":\"$HANASID\", \"{#HANACELL-INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL-PORT}\":\"43"$HANAINSTANCE"\", \"{#HANACELL-PORTNAME}\":\"webdispatcher43\"},"
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"07\", \"{#HANACELL_PORTNAME}\":\"xsengine07\"},"
                if [ $scount -eq 1 ]
                then

                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"08\", \"{#HANACELL_PORTNAME}\":\"xsengine08\"}"
                else
                echo -e "{\"{#HANACELL_SID1}\":\"$HANASID\", \"{#HANACELL_INSTANCE1}\":\"$HANAINSTANCE\", \"{#HANACELL_PORT}\":\"3"$HANAINSTANCE"08\", \"{#HANACELL_PORTNAME}\":\"xsengine08\"},"

                fi

}

identify_mode() {
### Code to identify if database is currently running in MASTER/SLAVE mode without querying the database by only running the python script provided by hana
#mod=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} -o ${working_dir}/db_result 'select TOP 2 ALERT_ID from _sys_statistics.STATISTICS_LAST_CHECKS'`
#db_result=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' 2>&1`
db_result=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' 2>&1 >/dev/null`
echo "db result is $db_result" >> $log_file

        sql_error=`echo $db_result | grep "SQLSTATE: 28000"`
        if [[ ${sql_error} == '* 10: invalid username or password:  SQLSTATE: 28000' ]]
        then
        echo '{'
        echo -e '"data":['
        echo -e "{\"{#HANASID}\":\"$HANASID\", \"{#HANAINSTANCE}\":\"$HANAINSTANCE\", \"{#HANAALERTID}\":\"99\", \"{#HANAALERTNAME}\":\"Invalid Username Password\", \"{#STATE}\":\"$STATE\"}"
        echo -e ']'
        echo '}'
        exit 1
        fi

        statistics_proc=`ps -ef|grep hdbstatisticsserver | grep -v grep`
        statistics_process=`echo $?`
        echo $statistics_process >> $log_file
        conn_refuse=`echo $db_result | grep 'Connection refused'`
        error_refuse="* -10709: Connection failed (RTE:[89006] System call 'connect' failed, rc=111:Connection refused)"
        if [ $statistics_process -eq 1 ] && [ $conn_refuse == $error_refuse ]
        then
        echo '{'
        echo -e '"data":['
        echo -e "{\"{#HANASID}\":\"$HANASID\", \"{#HANAINSTANCE}\":\"$HANAINSTANCE\", \"{#HANAALERTID}\":\"11111\", \"{#HANAALERTNAME}\":\"NO ALERTNAME\", \"{#STATE}\":\"SLAVE\"}"
        echo -e ']'
        echo '}'
        exit 1
        else
        echo "Some other Database error kindly check hana.log" >> $log_file
        fi

statistics_proc=`ps -ef|grep hdbstatisticsserver | grep -v grep`
statistics_process=`echo $?`
echo $statistics_process >> $log_file
if [ $statistics_process -eq 0 ] && [[ $conn_refuse != $error_refuse ]]   # hdbstatisticsserver process is always present in the master server and connection failed error should not come for master
then
echo "$host_name is master at `date`" >> $log_file
STATE=MASTER
master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd $STATE
else
STATE=SLAVE
echo "$host_name is slave at `date`" >> $log_file
fi


}
### Code to identify if database is currently running in MASTER/SLAVE mode without querying the database by only running the python script provided by hana
##############################################################################################################################################################

#identify_mode $HANASID $HANAINSTANCE

# Check if more than 1 instances are present
SID_count=`awk '/LD_LIBRARY_PATH/{n++}; END {print n+0}' $service_file`

#echo $SID_count

count=`grep -F LD_LIBRARY_PATH $service_file`
echo "{"
echo -e "\"data\":["
for i in $count
                do
                        HANASID=`echo $i | awk -F'/' '{print $4}'|tr -d [:space:]`
                        HANAINSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print substr($0,4,2)}'`
                        INSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print ($0)}'`
                        host_name=`echo $i | awk -F'/' '{print $18}'|tr -d [:space:]| cut -d'_' -f3 | cut -d'-' -f1`
                        if [ $HANASID = "LA6" ]; then
                                master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd $SID_count
                        fi
                        SID_count=$(($SID_count-1))

                done

echo -e "]"
echo "}"

echo "Script execution finished at `date`" >> $log_file

