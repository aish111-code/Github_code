#!/bin/bash
##################################################################
# Author        : Nandhini
# Purpose       : Discovers the ports with respctive to the DB state i.e MASTER/SLAVE.
#                                 Only on the WFA HANA DB servers
# Reviewer      : Sreekanth KP
# Version       : Dec 09 2016 - Initial code
#
####################################################################


IFS='
'

baseDir=${0%/*}
working_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
today=`date +"%m-%d-%y"`
log_dir="/var/log/zabbix"
log_file="/var/log/zabbix/hana.log"
mode_file=$working_dir/mode_file
DB_user="$1"
DB_pwd="$2"
service_file="/usr/sap/sapservices"


### Check whether services file exists
#########################################################################
if [ ! -f $service_file ]
then
echo "$service_file doesn't exist so not able to identify SID and INSTANCEID" | tee -a $log_file
exit 1
fi

### Check if more than 1 instances are present
#########################################################################
SID_count=`awk '/LD_LIBRARY_PATH/{n++}; END {print n+0}' $service_file`


### Get SID, INSTANCE, HOSTNAME
#########################################################################

host_name=`cat /usr/sap/sapservices | awk '{print $3}' | awk -F'_' '{print $NF}' | uniq`

count=`grep -F LD_LIBRARY_PATH $service_file`
for i in $count
                do
                        HANASID=`echo $i | awk -F'/' '{print $4}'|tr -d [:space:]`
                        HANAINSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print substr($0,4,2)}'`
                        INSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print ($0)}'`
                done

rm /var/log/zabbix/error.txt

#/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt
if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt
else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt
else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt
fi
fi
fi

grep -q "Connection failed" /var/log/zabbix/error.txt
conn_fail=`echo $?`

if [ "$conn_fail" -eq "1" ]   # hdbstatisticsserver process is always present in the master server and connection failed error should not come for master
    then
    echo "$host_name is master at `date`" >> $log_file
    STATE=MASTER

	echo "{"
	echo -e "\"data\":["

	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"00\", \"{#HANA_PORTNAME}\":\"daemon\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"01\", \"{#HANA_PORTNAME}\":\"nameserver\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"02\", \"{#HANA_PORTNAME}\":\"preprocessor\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"03\", \"{#HANA_PORTNAME}\":\"indexserver-service\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"15\", \"{#HANA_PORTNAME}\":\"indexserver-sql\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"80"$HANAINSTANCE"\", \"{#HANA_PORTNAME}\":\"sapwdisp_hdb80\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"43"$HANAINSTANCE"\", \"{#HANA_PORTNAME}\":\"sapwdisp_hdb43\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"06\", \"{#HANA_PORTNAME}\":\"webdispatcher06\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"80"$HANAINSTANCE"\", \"{#HANA_PORTNAME}\":\"webdispatcher80\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"43"$HANAINSTANCE"\", \"{#HANA_PORTNAME}\":\"webdispatcher43\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"07\", \"{#HANA_PORTNAME}\":\"xsengine07\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"08\", \"{#HANA_PORTNAME}\":\"xsengine08\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"10\", \"{#HANA_PORTNAME}\":\"compileserver\"}"

	echo -e "]"
	echo "}"

else
     STATE=SLAVE

	echo "{"
	echo -e "\"data\":["

	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"00\", \"{#HANA_PORTNAME}\":\"daemon\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"01\", \"{#HANA_PORTNAME}\":\"nameserver\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"02\", \"{#HANA_PORTNAME}\":\"preprocessor\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"03\", \"{#HANA_PORTNAME}\":\"indexserver-service\"},"
	echo -e "{\"{#HANA_SID}\":\"$HANASID\", \"{#HANA_INSTANCE}\":\"$HANAINSTANCE\", \"{#HANA_PORT}\":\"3"$HANAINSTANCE"10\", \"{#HANA_PORTNAME}\":\"compileserver\"}"

	echo -e "]"
	echo "}"
     echo "$host_name is slave at `date`" >> $log_file
fi
