#!/bin/bash
#set -x
########################################################################################################################################################################################
#Date Created : 19th-Nov-2014
#Author       : Surekha Pattnaik ( C5188034 )
#Script Name  : alert_id_name.sh
#Purpose      : To discover the HANA SID (system ID) and Instance Number for further processing
########################################################################################################################################################################################
IFS='
'

#### variables defined section
#working_dir="/usr/local/etc/zabbix_agentd.conf.d/scripts/hana"
baseDir=${0%/*}
working_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
today=`date +"%m-%d-%y"`
log_dir="/var/log/zabbix"
log_file="/var/log/zabbix/hana.log"
mode_file=$working_dir/mode_file
#vsaname=`uname -a`
#host_name=`echo $vsaname | awk '{print $2}'`
#DB_user="SYSTEM"
DB_user="$1"
DB_pwd="$2"
#DB_pwd="Manager123"
#DB_pwd="HANAuser15"
service_file="/usr/sap/sapservices"
#### variables defined section
###############################################################################################################################################################
### check if services file exists which gives the SID and INSTANCE name and ID
if [ ! -f $service_file ]
then
echo "$service_file doesn't exist so not able to identify SID and INSTANCEID" | tee -a $log_file
exit 1
fi
host_name=`cat /usr/sap/sapservices | awk '{print $3}' | awk -F'_' '{print $NF}' | uniq`
### check if services file exists which gives the SID and INSTANCE name and ID
###############################################################################################################################################################


###############################################################################################################################################################
### Check if more than 1 instances are present
SID_count=`awk '/LD_LIBRARY_PATH/{n++}; END {print n+0}' $service_file`
### Check if more than 1 instances are present
###############################################################################################################################################################



###############################################################################################################################################################
### Code to get SID and INSTANCE in JSON format to make it readable in zabbix custom script.
### Code handles sindle as well as multiple SID/INSTANCE occurrences.
count=`grep -F LD_LIBRARY_PATH $service_file`
for i in $count
                do
                        HANASID=`echo $i | awk -F'/' '{print $4}'|tr -d [:space:]`
                        HANAINSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print substr($0,4,2)}'`
                        INSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print ($0)}'`
                done
### Code to get SID and INSTANCE in JSON format to make it readable in zabbix custom script.
### Code handles sindle as well as multiple SID/INSTANCE occurrences.
###############################################################################################################################################################
#echo "alert_id_name.sh script execution started at `date`" >> $log_file

#echo "first parameter is $1 i.e. hana SID" >> $log_file
#HANASID=$1
#echo "Second parameter is  $2 i.e. hana instance" >> $log_file
#HANAINSTANCE=$2

### DR-2 Discover all checks ( check id and check name) from hana database table _sys_statistics.STATISTICS_LAST_CHECKS     {HANAALERTID} {HANAALERTNAME}
##############################################################################################################################################################

master_fun() {
HANASID=$1
HANAINSTANCE=$2
DB_user=$3
DB_pwd=$4
STATE=$5

#/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/checks_discovered

if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/checks_discovered
else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/checks_discovered
else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/checks_discovered
fi
fi
fi

#checks_discovered=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID,ALERT_NAME,ALERT_LAST_CHECK_RATING,ALERT_LAST_CHECK_TIMESTAMP,INTERVAL,ALERT_DESCRIPTION,ALERT_USERACTION from _sys_statistics.STATISTICS_LAST_CHECKS'`

### The complete list of check ids along with the status required for the metrics file is listed in metrics_file
#/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select ALERT_ID, ALERT_LAST_CHECK_RATING from _sys_statistics.STATISTICS_LAST_CHECKS' > ${working_dir}/metrics_file
#checks_disc=`tail -n +2 ${working_dir}/checks_discovered | head -n -2`
tail -n +2 ${working_dir}/checks_discovered | head -n -2 > ${working_dir}/checks_disc  # to delete unwanted header and trailer records from discovered checks file for further processing
sed -i 's/[/-]//g' ${working_dir}/checks_disc
sed -i 's/[()]//g' ${working_dir}/checks_disc
sed -i 's/[_]//g' ${working_dir}/checks_disc
sed -i 's/[#"`*?[]{}~$!&;()<>|#@]//g' ${working_dir}/checks_disc
count=0
rm ${working_dir}/checks_discovered
echo "{"
echo -e "\"data\":["
IFS=''
#tiercount=`wc -l ${working_dir}/checks_disc | awk '{print $1}'`
tiercount=`cat ${working_dir}/checks_disc | wc -l | awk '{print $1}'`

while read ids
do
        count=$(($count+1))
        if [[ $count -lt $tiercount ]]
        then
                HANAALERTID=`echo $ids|awk -F',' '{print $1}'`
                HANAALERTNAME=`echo $ids | awk -F',' '{print $2}'`

        #       echo -e "{\"$HANAALERTID\":\"$HANAALERTNAME\"}" >> $log_file
                echo -e "{\"{#HANASID}\":\"$HANASID\", \"{#HANAINSTANCE}\":\"$HANAINSTANCE\", \"{#HANAALERTID}\":\"$HANAALERTID\", \"{#HANAALERTNAME}\":$HANAALERTNAME, \"{#STATE}\":\"$STATE\"},"
#               echo -e "{\"{HANAALERTID}\":\"$HANAALERTID\", \"{HANAALERTNAME}\":\"$HANAINSTANCE\"},"
        else
                HANAALERTID=`echo $ids|awk -F',' '{print $1}'`
                HANAALERTNAME=`echo $ids | awk -F',' '{print $2}'`
#               echo -e "{\"$HANAALERTID\":\"$HANAALERTNAME\"}" >> $log_file
                echo -e "{\"{#HANASID}\":\"$HANASID\", \"{#HANAINSTANCE}\":\"$HANAINSTANCE\", \"{#HANAALERTID}\":\"$HANAALERTID\", \"{#HANAALERTNAME}\":$HANAALERTNAME, \"{#STATE}\":\"$STATE\"}"
#               echo -e "{\"{HANAALERTID}\":\"$HANAALERTID\", \"{HANAALERTNAME}\":\"$HANAINSTANCE\"}"
        fi
done < ${working_dir}/checks_disc
rm ${working_dir}/checks_disc
echo -e "]"
echo "}"
echo "Master function executed at `date`" >> $log_file
}
##############################################################################################################################################################

identify_mode() {
### Code to identify if database is currently running in MASTER/SLAVE mode without querying the database by only running the python script provided by hana
#mod=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} -o ${working_dir}/db_result 'select TOP 2 ALERT_ID from _sys_statistics.STATISTICS_LAST_CHECKS'`
#db_result=`/usr/sap/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' 2>&1`
#db_result=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' 2>&1 >/dev/null`
rm /var/log/zabbix/error.txt

#/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt

if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt
else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt
else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select count(*) from _sys_statistics.STATISTICS_LAST_CHECKS' &> /var/log/zabbix/error.txt
fi
fi
fi


#echo "db result is $db_result" >> $log_file
grep -q "Connection failed" /var/log/zabbix/error.txt
conn_fail=`echo $?`
if [ "$conn_fail" -eq "1" ]   # hdbstatisticsserver process is always present in the master server and connection failed error should not come for master
then
echo "$host_name is master at `date`" >> $log_file
STATE=MASTER
master_fun $HANASID $HANAINSTANCE $DB_user $DB_pwd $STATE
else
STATE=SLAVE

echo "{"
echo -e "\"data\":["
echo -e "]"
echo "}"

echo "$host_name is slave at `date`" >> $log_file

fi

### Code to identify if database is currently running in MASTER/SLAVE mode without querying the database by only running the python script provided by hana
##############################################################################################################################################################

}
identify_mode $HANASID $HANAINSTANCE

echo "Script execution finished at `date`" >> $log_file

