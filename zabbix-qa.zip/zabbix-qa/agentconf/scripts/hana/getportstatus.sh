#!/bin/bash

HANASID=$1
INSTANCE=$2
port=$3
portname=$4
DB_user=HCHECK
DB_pwd=M2SNVhxZNxyrV

# determine db state

          i=`grep $HANASID /usr/sap/sapservices`
          host_name=`echo $i | awk -F'/' '{print $18}'|tr -d [:space:]| cut -d'_' -f3 | cut -d'-' -f1`
          SID=`echo $HANASID | tr '[:upper:]' '[:lower:]'`
#result=`sudo su - ${SID}adm -c "python /usr/sap/$HANASID/HDB$INSTANCE/exe/python_support/landscapeHostConfiguration.py" | grep -w "$host_name" | awk -F'|' '{print$13}'`
#result=`sudo su - ${SID}adm -c"python /usr/sap/$HANASID/HDB$INSTANCE/exe/python_support/landscapeHostConfiguration.py" | grep -w "$host_name" | awk -F'|' '{print$13}'`
 #         DBSTATE=`echo $result | xargs`

#masternode=$(sudo su -c"cat /usr/sap/$HANASID/SYS/global/hdb/custom/config/nameserver.ini"|grep active_master|awk '{print $3}'|awk -F: '{print $1}')

#standbynode=$( sudo su -c"cat /usr/sap/$HANASID/SYS/global/hdb/custom/config/nameserver.ini"|grep "^standby"|awk '{print $3}')

#if [ "$masternode" == "$host_name" ]
# then
# DBSTATE="master"
#elif [ "$standbynode" == "$host_name" ]
#then
# DBSTATE="standby"
#else
# DBSTATE="worker"
#fi

rm /var/log/zabbix/db_state

if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${INSTANCE} -u ${DB_user} -p ${DB_pwd} "select  CASE WHEN INDEXSERVER_ACTUAL_ROLE = 'SLAVE' THEN 'WORKER' ELSE  INDEXSERVER_ACTUAL_ROLE END AS ROLE from M_LANDSCAPE_HOST_CONFIGURATION T1 JOIN m_host_information T2  on T1.HOST = T2.HOST  where T2.KEY = 'net_realhostname' AND ( T1.HOST = '$host_name' OR  T2.VALUE = '$host_name')" &> /var/log/zabbix/db_state
else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
/mnt/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${INSTANCE} -u ${DB_user} -p ${DB_pwd} "select  CASE WHEN INDEXSERVER_ACTUAL_ROLE = 'SLAVE' THEN 'WORKER' ELSE  INDEXSERVER_ACTUAL_ROLE END AS ROLE    from M_LANDSCAPE_HOST_CONFIGURATION T1 JOIN m_host_information T2  on T1.HOST = T2.HOST  where T2.KEY = 'net_realhostname' AND ( T1.HOST = '$host_name' OR  T2.VALUE = '$host_name')" &> /var/log/zabbix/db_state
else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
/hana/shared/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${INSTANCE} -u ${DB_user} -p ${DB_pwd} "select  CASE WHEN INDEXSERVER_ACTUAL_ROLE = 'SLAVE' THEN 'WORKER' ELSE  INDEXSERVER_ACTUAL_ROLE END AS ROLE    from M_LANDSCAPE_HOST_CONFIGURATION T1 JOIN m_host_information T2  on T1.HOST = T2.HOST  where T2.KEY = 'net_realhostname' AND ( T1.HOST = '$host_name' OR  T2.VALUE = '$host_name')" &> /var/log/zabbix/db_state
fi
fi
fi

grep -q "Connection failed" /var/log/zabbix/db_state
conn_fail=`echo $?`

if [ "$conn_fail" -eq "0" ]
then
 DBSTATE="standby"
else
 DBSTATE=`cat /var/log/zabbix/db_state | awk 'FNR==2 {print}' | tr '[:upper:]' '[:lower:]' | cut -d '"' -f2`
fi

status=`netstat -an | grep $port | head -1 | awk '{print $6}'`

if [ ! -z $status ]
then
  if [ $status == LISTEN ]
  then
      echo success 
  elif [ $DBSTATE == standby ] && [ "$portname" == "indexserver-sql" ]
  then
      echo success
  elif [ $DBSTATE == worker ] && [ "$portname" == "hdbdispatcher43" ] || [ $portname == "hdbdispatcher80" ] || [ $portname == "hdbdispatcher06" ] || [ $portname == "xsengine07" ]
  then

      echo success
  elif [ $DBSTATE == standby ] && [ $portname == "hdbdispatcher43" ] || [ $portname == "hdbdispatcher80" ] || [ $portname == "hdbdispatcher06" ] || [ $portname == "xsengine07" ]
  then
      echo success
  else
      echo fail
  fi

elif [ "$DBSTATE" == standby ] && [ "$portname" == "indexserver-sql" ]
  then
  echo success 
elif [ $DBSTATE == worker ] && [ $portname == "hdbdispatcher43" ] || [ $portname == "hdbdispatcher80" ] || [ $portname == "hdbdispatcher06" ] || [ $portname == "xsengine07" ]
 then
  echo success 
 elif [ $DBSTATE == standby ] && [ $portname == "hdbdispatcher43" ] || [ $portname == "hdbdispatcher80" ] || [ $portname == "hdbdispatcher06" ] || [ $portname == "xsengine07" ]
  then
  echo success
  else
  echo fail
fi 
