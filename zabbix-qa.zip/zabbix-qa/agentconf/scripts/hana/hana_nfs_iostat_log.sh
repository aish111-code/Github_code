#!/usr/bin/env bash

LOGFILEDATEPATTERN=$(date +"%Y-%m-%d")
LOGFILENAME="hana_nfsiostat_value_$LOGFILEDATEPATTERN.log"
LOGFILENAMEPATTERN="hana_nfsiostat_value_*.log"
LOGFILEFOLDER="/var/log/zabbix/custom_hana_logs"
LOGPATH="$LOGFILEFOLDER/$LOGFILENAME"
TEMPFILE="/tmp/nfsiostat.txt"

if [[ ! -d "$LOGFILEFOLDER" ]]; then
  mkdir -p $LOGFILEFOLDER
fi

if [[ -f $TEMPFILE ]]; then
  > $TEMPFILE
fi

find $LOGFILEFOLDER -name "$LOGFILENAMEPATTERN" -type f -mtime +1 -delete

/usr/sbin/nfsiostat 2 2 | grep -v read | grep -v write | grep -v 'op/s' | grep -v '^$' > $TEMPFILE
NFS_SHARE=`cat /tmp/nfsiostat.txt | grep mounted | awk '{print $1}' | sort | uniq`

FINALLOGSTRING=""
DATESTRING=$(date +"%a %b %d %H:%M:%S %Y")

for i in `echo $NFS_SHARE`; do
  LOGSTRING=""
  LOGSTRING="$DATESTRING NFS=$i,"
  MOUNT_POINT=`cat /tmp/nfsiostat.txt | grep "$i" | awk '{print $4}'| awk -F':' '{print $1}' | sort | uniq`
  LOGSTRING="$LOGSTRING MOUNT_POINT=$MOUNT_POINT,"
  op_persec=`cat /tmp/nfsiostat.txt| grep -A1 "$i" | tail -1 | awk '{print $1}'`
  LOGSTRING="$LOGSTRING op_persec=$op_persec,"
  rpc_bklog=`cat /tmp/nfsiostat.txt | grep -A1 "$i" | tail -1 | awk '{print $2}'`
  LOGSTRING="$LOGSTRING rpc_bklog=$rpc_bklog,"
  read_ops_persec=`cat /tmp/nfsiostat.txt| grep -A2 "$i" | tail -1 | awk '{print $1}'`
  LOGSTRING="$LOGSTRING read_ops_persec=$read_ops_persec,"
  read_KB_persec=`cat /tmp/nfsiostat.txt | grep -A2 "$i" | tail -1 | awk '{print $2}'`
  LOGSTRING="$LOGSTRING read_KB_persec=$read_KB_persec,"
  read_KB_ops=`cat /tmp/nfsiostat.txt | grep -A2 "$i" | tail -1 | awk '{print $3}'`
  LOGSTRING="$LOGSTRING read_KB_ops=$read_KB_ops,"
  read_retrans=`cat /tmp/nfsiostat.txt | grep -A2 "$i" | tail -1 | awk '{print $4}'`
  LOGSTRING="$LOGSTRING read_retrans=$read_retrans,"
  read_retrans_perc=`cat /tmp/nfsiostat.txt | grep -A2 "$i" | tail -1 | awk '{print $5}' | sed 's/(//g' | sed 's/)//g' | sed 's/%//g'`
  LOGSTRING="$LOGSTRING read_retrans_perc=$read_retrans_perc,"
  read_avgRTT_ms=`cat /tmp/nfsiostat.txt | grep -A2 "$i" | tail -1 | awk '{print $6}'`
  LOGSTRING="$LOGSTRING read_avgRTT_ms=$read_avgRTT_ms,"
  read_avgexe_ms=`cat /tmp/nfsiostat.txt | grep -A2 "$i" | tail -1 | awk '{print $7}'`
  LOGSTRING="$LOGSTRING read_avgexe_ms=$read_avgexe_ms,"
  write_ops_persec=`cat /tmp/nfsiostat.txt | grep -A3 "$i" | tail -1 | awk '{print $1}'`
  LOGSTRING="$LOGSTRING write_ops_persec=$write_ops_persec,"
  write_KB_persec=`cat /tmp/nfsiostat.txt | grep -A3 "$i" | tail -1 | awk '{print $2}'`
  LOGSTRING="$LOGSTRING write_KB_persec=$write_KB_persec,"
  write_KB_ops=`cat /tmp/nfsiostat.txt | grep -A3 "$i" | tail -1 | awk '{print $3}'`
  LOGSTRING="$LOGSTRING write_KB_ops=$write_KB_ops,"
  write_retrans=`cat /tmp/nfsiostat.txt | grep -A3 "$i" | tail -1 | awk '{print $4}'`
  LOGSTRING="$LOGSTRING write_retrans=$write_retrans,"
  write_retrans_perc=`cat /tmp/nfsiostat.txt | grep -A3 "$i" | tail -1 | awk '{print $5}' | sed 's/(//g' | sed 's/)//g' | sed 's/%//g'`
  LOGSTRING="$LOGSTRING write_retrans_perc=$write_retrans_perc,"
  write_avgRTT_ms=`cat /tmp/nfsiostat.txt | grep -A3 "$i" | tail -1 | awk '{print $6}'`
  LOGSTRING="$LOGSTRING write_avgRTT_ms=$write_avgRTT_ms,"
  write_avgexe_ms=`cat /tmp/nfsiostat.txt | grep -A3 "$i" | tail -1 | awk '{print $7}'`
  LOGSTRING="$LOGSTRING write_avgexe_ms=$write_avgexe_ms"
  if [ "$FINALLOGSTRING" == "" ]; then
    FINALLOGSTRING="$LOGSTRING"
  else
    FINALLOGSTRING="$FINALLOGSTRING\n$LOGSTRING"
  fi
done

echo -e $FINALLOGSTRING >> $LOGPATH

if [ -e $LOGPATH ]; then
  echo "SUCCCESS"
else
  echo "FAILED"
fi
