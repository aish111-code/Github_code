#!/bin/bash

HANASID=$1
INSTANCE=$2
port=$3
portname=$4

# determine db state

          i=`grep $HANASID /usr/sap/sapservices`
          host_name=`echo $i | awk -F'/' '{print $18}'|tr -d [:space:]| cut -d'_' -f3 | cut -d'-' -f1`
          SID=`echo $HANASID | tr '[:upper:]' '[:lower:]'`
#result=`sudo su - ${SID}adm -c "python /usr/sap/$HANASID/HDB$INSTANCE/exe/python_support/landscapeHostConfiguration.py" | grep -w "$host_name" | awk -F'|' '{print$13}'`
#result=`su - ${SID}adm -c"python /usr/sap/$HANASID/HDB$INSTANCE/exe/python_support/landscapeHostConfiguration.py" | grep -w "$host_name" | awk -F'|' '{print$13}'`
 #         DBSTATE=`echo $result | xargs`


status=`netstat -an | grep $port | head -1 | awk '{print $6}'`

if [ ! -z $status ]
then
  if [ $status == LISTEN ]
  then
      echo success
  elif [ $DBSTATE == standby ] && [ "$portname" == "indexserver-sql" ]
  then
      echo success
  elif [ $DBSTATE == standby ] && [ $portname == "sapwdisp_hdb43" ] || [ $portname == "sapwdisp_hdb80" ] || [ $portname == "webdispatcher06" ] || [ $portname == "xsengine07" ] || [ $portname == "xsengine08" ]
  then
      echo success
  else
      echo fail
  fi

elif [ "$DBSTATE" == standby ] && [ "$portname" == "indexserver-sql" ]
  then
  echo success
 elif [ $DBSTATE == standby ] && [ $portname == "sapwdisp_hdb43" ] || [ $portname == "sapwdisp_hdb80" ] || [ $portname == "webdispatcher06" ] || [ $portname == "xsengine07" ] || [ $portname == "xsengine08" ]
  then
  echo success
  else
  echo fail
fi

