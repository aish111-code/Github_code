#!/bin/bash
##################################################################
# Author        : Nandhini
# Purpose       : Checks whether the HANA Port is UP/DOWN.
# Reviewer      : Sreekanth KP
# Version       : Dec 09 2016 - Initial code
#
####################################################################
HANASID=$1
INSTANCE=$2
port=$3
portname=$4

# Gets the hostname and HANA SID

          i=`grep $HANASID /usr/sap/sapservices`
          host_name=`echo $i | awk -F'/' '{print $18}'|tr -d [:space:]| cut -d'_' -f3 | cut -d'-' -f1`
          SID=`echo $HANASID | tr '[:upper:]' '[:lower:]'`

status=`netstat -an | grep $port | head -1 | awk '{print $6}'`

if [ ! -z $status ]
then
  if [ $status == LISTEN ]
  then
      echo 1
      echo "$port is UP" >> /var/log/zabbix/hana.log
   else
      echo 0
      echo "$port is DOWN" >> /var/log/zabbix/hana.log
  fi
fi

