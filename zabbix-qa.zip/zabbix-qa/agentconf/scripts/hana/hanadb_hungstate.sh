#!/bin/bash
##########################################################
# This script alerts if the DB is in hung state for more
# than 10 seconds on any HANA servers.
##########################################################
IFS='
'

service_file="/usr/sap/sapservices"
DB_user="HCHECK"
DB_pwd="M2SNVhxZNxyrV"
rm /var/log/zabbix/output.txt
host_name=`cat /usr/sap/sapservices | awk '{print $3}' | awk -F'_' '{print $NF}' | uniq`
SID_count=`awk '/LD_LIBRARY_PATH/{n++}; END {print n+0}' $service_file`
count=`grep -F LD_LIBRARY_PATH $service_file`
for i in $count
                do
                        HANASID=`echo $i | awk -F'/' '{print $4}'|tr -d [:space:]`
                        HANAINSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print substr($0,4,2)}'`
                        INSTANCE=`echo $i |awk -F'/' '{print $5}'|tr -d [:space:]|awk '{print ($0)}'`
                done
#output=`/usr/sap/$HANASID/hdbclient/hdbsql -n ${host_name} -i ${HANAINSTANCE} -u ${DB_user} -p ${DB_pwd} 'select now() from dummy'`
#echo $output > /var/log/zabbix/output.txt
#rm /var/log/zabbix/output
#timeout 10 /usr/sap/$HANASID/hdbclient/hdbsql -n $host_name -i $HANAINSTANCE -u $DB_user -p $DB_pwd "select now() from dummy" > /var/log/zabbix/output.txt
if [ -s "/usr/sap/$HANASID/hdbclient/hdbsql" ]
then
timeout 10 /usr/sap/$HANASID/hdbclient/hdbsql -n $host_name -i $HANAINSTANCE -u $DB_user -p $DB_pwd "select now() from dummy" > /var/log/zabbix/output.txt
else
if [ -s "/mnt/shared/$HANASID/hdbclient/hdbsql" ]
then
timeout 10 /mnt/shared/$HANASID/hdbclient/hdbsql -n $host_name -i $HANAINSTANCE -u $DB_user -p $DB_pwd "select now() from dummy" > /var/log/zabbix/output.txt
else
if [ -s "/hana/shared/$HANASID/hdbclient/hdbsql" ]
then
timeout 10 /hana/shared/$HANASID/hdbclient/hdbsql -n $host_name -i $HANAINSTANCE -u $DB_user -p $DB_pwd "select now() from dummy" > /var/log/zabbix/output.txt
fi
fi
fi
status=`echo $?`
if [ $status == 0 ] || [ $status == 43 ] ; then
echo "0"
else
echo "1"
fi

###Below logic limits the content of hana.log to latest 10 Lakh lines ####
log_file_tmp="/var/log/zabbix/hanalog.tmp"
log_file="/var/log/zabbix/hana.log"
tail -n 1000000 $log_file > $log_file_tmp
cat $log_file_tmp > $log_file
> $log_file_tmp
##########################################################################
