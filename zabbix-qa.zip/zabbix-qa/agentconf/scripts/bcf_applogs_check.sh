#!/bin/bash
HOSTN=`/bin/hostname`
DOMN=`/bin/domainname -d`
function strconta
{
string=$1
str=$2
if [ "${string}" != "${string/${str}/}" ]; then
   /bin/true
else
/bin/false
fi

}
if [ -f /etc/mcollective/monsoonfacts.yaml ] && strconta ${DOMN} sap.corp
then
HOSTN=`/usr/local/bin/moname`
fi
if [ -f /etc/sysconfig/network/virtualip ] && strconta ${DOMN} od.sap.biz
then
HOSTN=`/usr/local/bin/moname`
fi

#echo $HOSTN
user=$(ls -ld  /nfs/applogs/$HOSTN|awk '{print $3}')
#echo $user
group=$(ls -ld  /nfs/applogs/$HOSTN|awk '{print $4}')
#echo $group
perm=$(ls -ld  /nfs/applogs/$HOSTN|awk '{print $1}'|cut -c 2- )
#echo $perm

if [ "$user" != "sfuser" ] || [ "$group" != "sfuser" ] || [ "$perm" != "rwxr-xr-x" ]
then
echo 1
else
echo 0
fi
