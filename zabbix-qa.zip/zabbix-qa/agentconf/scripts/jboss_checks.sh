#!/bin/bash
#
# Jboss Monitoring Fuctions
# 
# - getSystemProperty (pass propery name you are looking for and get value returned)
# - checkForHeapDumps (looks for files in HeapDumpPath)
# - getCorePath (find core path in zing custom location, else JBOSS_HOME, else /var/crash)
# - checkForCore (find cores or logs in CorePath location and return count)
# - isCorePathWriteable (check if Path is world writeable, or owned by user $1 (default=sfuser)
# - isHeapDumpPathWriteable (check if Path is world writeable, or owned by user $1 (default=sfuser)
# - checkAllCoreLocations (check all known core file locations for azcore* or hs_err*, mv hs_err* to ./logs, and echo total count)
#

JbossHome=/export/home/jboss/jboss-4.3.0
JbossLogs=/export/home/jboss/jboss-4.3.0/server/sfv4Cluster01/log
jbossProcess="program.name=run.sh"
coreFilePattern="azcore*"
  
# Provide the bizx system property you are looking for to get its value.
function getSystemProperty() {
  if [[ ! -z "$1" ]]; then
    property="$1"
  else
    exit
  fi

  if [[ $(ps -ef | grep java | grep "${jbossProcess}" | grep -w "$property" | grep -v grep) ]]; then
    tmp=$(ps -ef | grep java | grep "${jbossProcess}" | grep -w "$property")
  elif [[ -r ${JbossHome}/server/sfv4Cluster01/run.conf ]]; then
    tmp=$(grep -w "${property}" ${JbossHome}/server/sfv4Cluster01/run.conf | sed "s/\"//g")
  else
    echo "Not Found"
    exit
  fi

  for prop in $(echo $tmp)
    do
      if [[ $( echo $prop | grep "${property}") ]]; then
        echo "${prop##*=}"
        found=1
        exit
      fi
    done
   
   if [[ -z $found ]]; then
     echo "Not Found"
   fi
   exit
}

# Use HeapDumpPath from JAVA_OPTIONS to find new Heap Dumps.
function checkForHeapDumps () {
  heapDumpPath="$(getSystemProperty HeapDumpPath)"
  if [[ -d ${heapDumpPath} ]]; then
    if [[ $(find ${heapDumpPath} -type f | grep hprof) ]]; then
      echo $(find ${heapDumpPath} -type f | grep hprof | wc -l)
    else
      echo 0
    fi
  else
    echo 0
  fi
}

function getCorePath () {
  # Get Zing Core Path from custom script that should point to /dumps/java/core
  if [[ -f /usr/sbin/zing-core-pattern-hook && $(grep -w "\$dir =" /usr/sbin/zing-core-pattern-hook | grep "/dumps") ]]; then
	echo $(grep -w "\$dir =" /usr/sbin/zing-core-pattern-hook | grep "/dumps" | tail -1 | awk '{ print $3 }' | sed "s/\(\"\|;\)//g")
  # If zing script or /dumps/java/core is not found then use JbossHome
  elif [[ -d ${JbossHome}/bin ]]; then
    echo ${JbossHome}/bin
  else
  # If nothing is found use the OS crash directory
    echo "/var/crash"
  fi
}

function isCorePathWriteable () {
  # default to sfuser as directory owner to look for
  if [[ ! -z "$1" ]]; then
    user="$1"
  else
    user="sfuser"
  fi
  #Get the core file path
  Path="$(getCorePath)"
  parentDir=${Path%/*}
  curDir=${Path##*/}
  # check for world write access, or that $user owns the directory being written too.
  if [[ -w $Path ]]; then
    echo "Success: $Path"
  elif [[ ! -w $Path && $Path == "/var/crash" ]]; then
    echo "ERROR: Using /var/crash.  No Zing Location (or ${JbossHome}/bin Not Found"
  elif [[ -d $Path ]]; then
    getUser=$(ls -al ${parentDir} | grep ${curDir} | awk '{ print $3 }')
	if [[ $getUser == $user ]]; then
	  echo "Success: $Path"
	else
	  echo "ERROR: $getUser owns $Path"
	fi
  else
    echo "ERROR: Not Found $Path"
  fi
}

function isHeapDumpPathWriteable () {
  # default to sfuser as directory owner to look for
  if [[ ! -z "$1" ]]; then
    user="$1"
  else
    user="sfuser"
  fi
  #Get the core file path
  Path="$(getSystemProperty HeapDumpPath)"
  parentDir=${Path%/*}
  curDir=${Path##*/}
  # check for world write access, or that $user owns the directory being written too.
  if [[ -w $Path ]]; then
    echo "Success: $Path"
  elif [[ -d $Path ]]; then
    getUser=$(ls -al ${parentDir} | grep ${curDir} | awk '{ print $3 }')
	if [[ "$getUser" == "$user" ]]; then
	  echo "Success: $Path"
	else
	  echo "ERROR: $getUser owns $Path"
	fi
  elif [[ $Path == "" ]]; then
    echo "ERROR: HeapDumpPath Not Defined in JAVA_OPTIONS"
  else
    echo "ERROR: Not Writeable $Path"
  fi
}

function checkForCore () {
count=0
corePath=$(getCorePath)
if [[ $(find ${corePath} -type f -maxdepth 1 -name ${coreFilePattern} 2>/dev/null) ]]; then
  echo $(find ${corePath} -type f -maxdepth 1 -name ${coreFilePattern} | wc -l)
elif [[ $(find ${corePath} -type f -maxdepth 1 -name hs_err* -mmin 60 2>/dev/null) ]]; then
  for i in $(find ${corePath} -type f -maxdepth 1 -name hs_err* -mmin 60)
  do
    if [[ -d /var/log/zabbix && ! -f /var/log/zabbix/jboss_checks.tmp ]]; then
      tmpFile="/var/log/zabbix/jboss_checks.tmp"
      touch $tmpFile
    elif [[ -d /var/log/zabbix && -f /var/log/zabbix/jboss_checks.tmp ]]; then
      tmpFile="/var/log/zabbix/jboss_checks.tmp"
    else
      tmpFile="/tmp/jboss_checks.tmp"
      touch $tmpFile
    fi
    if [[ $(cat $tmpFile | grep -w "checkForCore_$i") ]]; then
      continue
    else
      echo "checkForCore_${i}" >> $tmpFile
      count=$((1+${count}))
    fi
  done
  echo $count
elif [[ $(find ${corePath} -type f -maxdepth 1 -name core* 2>/dev/null) ]]; then
  echo $(find ${corePath} -type f -maxdepth 1 -name core* | wc -l)
else
  echo 0
fi
}

function checkAllCoreLocations () {
  core_count=0
  # Get Zing Core Path from custom script that should point to /dumps/java/core
  if [[ -f /usr/sbin/zing-core-pattern-hook && $(grep -w "\$dir =" /usr/sbin/zing-core-pattern-hook | grep "/dumps") ]]; then
	corePath=$(grep -w "\$dir =" /usr/sbin/zing-core-pattern-hook | grep "/dumps" | tail -1 | awk '{ print $3 }' | sed "s/\(\"\|;\)//g")
	files=$(find ${corePath} -type f -name ${coreFilePattern} -o -type f -name hs_err* -o -type f -name core*)
	for i in $(echo $files | grep hs_err)
	do
	  mv $i ${JbossLogs}/
	done
	core_count=$(($(find ${corePath} -type f -name ${coreFilePattern} -o -type f -name hs_err* -o -type f -name core* | wc -l)+${core_count}))
  fi
  # If zing script or /dumps/java/core is not found then use JbossHome
  if [[ -d ${JbossHome}/bin ]]; then
    corePath="${JbossHome}/bin"
	files=$(find ${corePath} -type f -name ${coreFilePattern} -o -type f -name hs_err* -o -type f -name core*)
	for i in $(echo $files | grep hs_err)
	do
	  mv $i ${JbossLogs}/
	done
	core_count=$(($(find ${corePath} -type f -name ${coreFilePattern} -o -type f -name hs_err* -o -type f -name core* | wc -l)+${core_count}))
  fi
  if [[ -d /var/crash ]]; then
  # If nothing is found use the OS crash directory
    corePath="/var/crash"
	files=$(find ${corePath} -type f -name ${coreFilePattern} -o -type f -name hs_err* -o -type f -name core*)
	for i in $(echo $files | grep hs_err)
	do
	  mv $i ${JbossLogs}/
	done
	core_count=$(($(find ${corePath} -type f -name ${coreFilePattern} -o -type f -name hs_err* -o -type f -name core* | wc -l)+${core_count}))
  fi
  echo $core_count
}

# If no function is passed then default to "checkForCore"
if [[ ! -z "$1" ]]; then
    $1 $2
  else
    checkForCore
fi