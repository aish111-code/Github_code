#!/bin/bash
#####################################################
# top_cpu_process.sh
# returns names of most CPU time consuming processes
#####################################################




ps axwwo %cpu,pid,user,cmd | sort -k 1 -r -n|sed -e '/^%/d'|head -1|awk '{print "CPU:"$1 "% PID:" $2 " CMD: " $4,$5}'
