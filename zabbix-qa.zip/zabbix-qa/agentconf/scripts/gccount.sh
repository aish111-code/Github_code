#/bin/bash
curl -s "http://$1:8080/search/admin/metrics?group=jvm&prefix=gc.G1-Old-Generation.count" | /usr/bin/python -c 'import json,sys;obj=json.load(sys.stdin);print obj["metrics"]["solr.jvm"]["gc.G1-Old-Generation.count"]'
