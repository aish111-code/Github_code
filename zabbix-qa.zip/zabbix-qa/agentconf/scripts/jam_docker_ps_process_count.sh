#!/bin/bash

output=$(docker exec ps pgrep -fc '^Passenger RubyApp' || echo 0)
echo "$output"

exit 0