#!/usr/bin/env ruby
envroot = Dir.glob('/var/www/ct/*/')[0]
confroot = "#{envroot}current/config"
instance = File.read("#{confroot}/instance").chomp
config = "#{confroot}/deploy/instances/#{instance}.rb"

def checkConn(host,port)
        print "#{host}:#{port} => "
        params = "-z -w 5 #{host} #{port}"
        system "nc #{params}"
        retval = $?.exitstatus
        if retval == 127 then
                system "netcat #{params}"
                retval = $?.exitstatus
        end

        case retval
        when 0
                puts "OK"
        when 1
                puts "FAIL"
                exit(false)
        else
                puts "SCRIPT ERROR"
                exit(2)
        end
end

hosts = (eval File.read(config)).delete_if{|k,v| k.to_s !~ /.+hosts?$/}

if ( ARGV[0] == "-q" ) then
	$stdout.reopen '/dev/null'
	ARGV.shift
end

if ( ARGV.size != 2 || !hosts.has_key?(ARGV[0].intern)) then
        STDERR.puts "Usage: #{__FILE__} [-q] <host group> <port>\n\n" \
                "Available host groups:"
       
	hosts.keys.map{|k| k = k.to_s}.sort.each {|k| STDERR.puts "\t- #{k}"}
        
	exit(false)
end

selKey = ARGV[0].intern
selHosts = hosts[selKey]
selPort = Integer(ARGV[1])

if (!selHosts.is_a?(Array)) then
	selHosts = Array(selHosts)
end

selHosts.each {|host| 
	checkConn(host,selPort)
}


