#!/bin/bash
if [ -n "$(find /nfs/vaultapp -maxdepth 1 -type f -name 'raft.snap.*' -mmin -70 -print -quit 2>/dev/null)" ]; then echo 0; else echo 1; fi
