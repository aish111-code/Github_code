#!/bin/bash
####################################################
# Script to get the overall cluster disk utilization
#####################################################

total=`curl -k -u "zabbix_user:Zabb1x@123" "https://$1:9200/_cluster/stats?human&pretty" 2> /dev/null | grep "total_in_bytes" | awk 'FNR==2 {print}' | awk -F ':' '{print $2}' | cut -d ',' -f1`

available=`curl -k -u "zabbix_user:Zabb1x@123" "https://$1:9200/_cluster/stats?human&pretty" 2> /dev/null | grep "available_in_bytes" | awk -F ':' '{print $2}'`

used=$((total - $available))

used_percent=$(echo "scale=3; 100*$used/$total" |bc)
echo $used_percent
