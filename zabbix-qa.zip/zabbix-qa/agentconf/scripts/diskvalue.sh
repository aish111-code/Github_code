#!/bin/bash
# Collects disk performance
#Usage sh diskvalue.sh <disk> <option>
if [ $# != 2 ]
then
echo "Wrong usage!! Usage sh diskvalue.sh <disk> <option>"
else
which iostat > /dev/null 2>&1
if [ $? != 0 ]
then
exit
fi

case $2 in
        rps)
        iostat -xN $1 2 2|grep "$1 "|awk '{print $4}'|tail -1 ;;
        wps)
        iostat -xN $1 2 2|grep "$1 "|awk '{print $5}'|tail -1 ;;
        avgrqsz-sec)
        iostat -xN $1 2 2|grep "$1 "|awk '{print $8}'|tail -1 ;;
        avgqu-sz)
        iostat -xN $1 2 2|grep "$1 "|awk '{print $9}'|tail -1 ;;
        await)
        iostat -xN $1 2 2|grep "$1 "|awk '{print $10}'|tail -1 ;;
        svctm)
        iostat -xN $1 2 2|grep "$1 "|awk '{print $11}'|tail -1 ;;
        perc-util)
        iostat -xN $1 2 2|grep "$1 "|awk '{print $12}'|tail -1 ;;
        perc-iowait)
        iostat -c 2 2|egrep -v 'Linux|avg-cpu'|grep -v "^$"|awk '{print $4}'|tail -1 ;;
        *) echo "There is no such option $2. Please provide from something below:"
           echo "rps, wps, avgrqsz-sec, avgqu-sz, await, svctm, perc-util, perc-iowait" ;;
esac
fi

