#!/bin/bash

#===============================================================================
#
#          FILE: postCheckUpdateRequest.sh
#
#         USAGE: ./postCheckUpdateRequest.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: Liu Michael, michael.liu03@sap.com
#  ORGANIZATION: SuccessFactors, an SAP Company
#       CREATED: 05/19/2016 19:20
#      REVISION: For Solr4.10.40
#===============================================================================

workDir=`dirname $0`
#LOCALIP=`/sbin/ifconfig eth0 | awk '/inet addr:/ { print $2 }' | sed 's/addr://'`
LOCALIP=`host $(hostname) | awk '{print $NF}'`
existOrNot=`curl -s -o /dev/null -w "%{http_code}" http://$LOCALIP:8080/search/sitescope/admin/ping?wt=json`

if [ $existOrNot -ne 404 ]
then
  HTTPCODE=`curl -s -o /dev/null -w "%{http_code}"  http://$LOCALIP:8080/search/sitescope/update?commit=true -H "Content-Type: text/xml" --data-binary "<add><doc><field name=\"id\">service_monitor_dummy_data</field><field name=\"indexType\">DUMMY</field></doc></add>"`
  if [ $HTTPCODE -ne 200 ]
  then
    echo $HTTPCODE
  else
	echo "success"
  fi
fi

