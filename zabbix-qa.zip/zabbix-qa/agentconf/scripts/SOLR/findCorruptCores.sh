#!/bin/bash

#===============================================================================
#
#          FILE: findCorruptCores.zabbix.sh
#
#         USAGE: ./findCorruptCores.zabbix.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: Liu Michael, michael.liu03@sap.com, Kevin Jin kevin.jin01@sap.com, Wang, Lyle, lyle.wang@sap.com
#  ORGANIZATION: SuccessFactors, an SAP Company
#       CREATED: 01/07/2019 19:01
#===============================================================================
# Pulling Auth key from zookepper
export JAVA_HOME=/app/sapjvm
Clustername=`/app/solr/bin/solr.in.sh | grep ZK_HOST|  cut -d/ -f2,3`
ZK_1st_Node=`/app/solr/bin/solr.in.sh | grep ZK_HOST | cut -f2 | cut -d: -f1`
export SOLR_AUTHORIZATION_HEADER=`/app/solr/server/scripts/cloud-scripts/zkcli.sh -zkhost $ZK_1st_Node:2181 -cmd get /$Clustername/sf_conf.json 2>/dev/null | grep ldap.client.credential | cut -d'"' -f4 | awk '{ print $2 }'`

function healthcheck_OptierSolr()
{
  SOLR_HOME=/app/solrfiles/data
  JETTY_HOME=/app/solr
  SHELLPID=$$
  HEALTHCHECKLOG=/var/log/zabbix/healthcheck.json.$SHELLPID
  ZKHOST=`sed -n 's/^ZK_HOST=\(.*\)$/\1/p' $SOLR_HOME/../solr.in.sh | uniq`
  CLUSTERSTATES=/var/log/zabbix/clusterstates.$SHELLPID
  cd $SOLR_HOME
  CORES_LIST=(`find . -noleaf  -maxdepth 1 -type d  ! -path "./bin" ! -path "./conf" ! -path "./lost+found" ! -path "." -exec basename {} \; | awk -F'_' '{print $1}'`)
  cd - > /dev/null
  LIST_SIZE=${#CORES_LIST[@]}

  i=0

  #while true
  for core in $CORES_LIST
  do
    #In case that there's too many collections
    i=$(( i + 1 ))

    $JETTY_HOME/bin/solr healthcheck -c $core -z $ZKHOST > ${HEALTHCHECKLOG}.${core} 2> /dev/null

        #In case that there's too many collections
    if [ $i -ge 3 ]
    then
      break
    fi

  done
  cat ${HEALTHCHECKLOG}* | /etc/zabbix/zabbix_agentd_custom_scripts/SOLR/solr-healthcheck/bin/jq -r 'del(.shards[].replicas[].uptime) | del(.shards[].replicas[].memory) | del(.shards[].replicas[].name) | .shards[].replicas[] | tostring' > $CLUSTERSTATES
  INACTIVE_AMOUNTS=`grep -v '"status":"active"' $CLUSTERSTATES | wc -l`

  rm -f ${HEALTHCHECKLOG}*
  rm -f ${CLUSTERSTATES}*
  if [ $INACTIVE_AMOUNTS -gt 0 ]
  then
#    echo "There have $INACTIVE_AMOUNTS corrupt cores. For the next actions, please refer to https://github.wdf.sap.corp/HCM-APPMGMT/Solr4_scripts/blob/master/Solr4_cluster_remediation_plan.docx"
      echo $INACTIVE_AMOUNTS
    exit 1
  else
    #echo "There's no corrupt core."
    echo "0"
    exit 0
  fi
}

function healthcheck_BizXSolr()
{
  SHELLPID=$$
  HEALTHCHECKLOG=/var/log/zabbix/healthcheck.json.$SHELLPID
  SOLR_HOME=/app/solr
  SHELLPID=$$
  HEALTHCHECKLOG=/var/log/zabbix/healthcheck.json.$SHELLPID
  ZKHOST=`sed -n 's/^ZK_HOST=\(.*\)$/\1/p' $SOLR_HOME/bin/solr.in.sh | uniq`
  CLUSTERSTATES=/var/log/zabbix/clusterstates.$SHELLPID
  cd $SOLR_HOME/server/solr
  CORES_LIST=(`find . -noleaf -maxdepth 1 -type d ! -path "./configsets" ! -path "./bin" ! -path "./conf" ! -path "./search.war" ! -path "./lost+found" ! -path "." -exec basename {} \;`)
  cd - > /dev/null
  LIST_SIZE=${#CORES_LIST[@]}

  i=0

  while true
  do
    i=$(( i + 1 ))
    core=${CORES_LIST[$(( $RANDOM % $LIST_SIZE ))]}
    $SOLR_HOME/bin/solr healthcheck -c $core -z $ZKHOST > ${HEALTHCHECKLOG}.${core} 2> /dev/null
    if [ $? -ne 0 ]
    then
      break
    fi
    if [ $i -ge 3 ]
    then
      break
    fi

  done
  cat ${HEALTHCHECKLOG}* | /etc/zabbix/zabbix_agentd_custom_scripts/SOLR/solr-healthcheck/bin/jq -r 'del(.shards[].replicas[].uptime) | del(.shards[].replicas[].memory) | del(.shards[].replicas[].name) | .shards[].replicas[] | tostring' > $CLUSTERSTATES 2> /dev/null
  INACTIVE_AMOUNTS=`grep -v '"status":"active"' $CLUSTERSTATES | wc -l`

  rm -f ${HEALTHCHECKLOG}*
  rm -f ${CLUSTERSTATES}*
  if [ $INACTIVE_AMOUNTS -gt 0 ]
  then
    #echo "There have $INACTIVE_AMOUNTS corrupt cores. For the next actions, please refer to https://github.wdf.sap.corp/HCM-APPMGMT/Solr4_scripts/blob/master/Solr4_cluster_remediation_plan.docx"
    echo $INACTIVE_AMOUNTS
    exit 1
  else
    #echo "There's no corrupt core."
    echo "0"
    exit 0
  fi
}

# ====== Start ======
LOCALIP=`host $(hostname) | awk '{print $NF}' | egrep "([0-9]{1,3}\.){3}[0-9]{1,3}"`
if [[ "$LOCALIP" = "" ]]
then
  LOCALIP=`/sbin/ifconfig eth0 | awk '/inet addr:/ { print $2 }' | sed 's/addr://'`
fi

if [ -d "/app/solr" ]
then
  if [ -d "/app/solrfiles" ]
  then
    SOLRTYPE="OptierSOLR"
  else
    SOLRTYPE="BizXSOLR"
  fi
else
  SOLRTYPE="UNKNOWN"
fi

if [[ "$SOLRTYPE" = "BizXSOLR" ]]
then
  py_script="
import os, sys, json, urllib2, time;
solr_authorization_header = os.getenv('SOLR_AUTHORIZATION_HEADER')
corrupt_cores_count = 0
url = 'http://${LOCALIP}:8080/search/admin/zookeeper?_='+ str(time.time()) +'&detail=true&path=%2Fclusterstate.json&rows=2000&start=0&wt=json&view=graph'
req = urllib2.Request(url)
if solr_authorization_header:
    req.add_header('Authorization', 'Basic ' + solr_authorization_header)
cluster_state = json.loads(urllib2.urlopen(req).read())
cluster_data = json.loads(cluster_state['znode']['data'])
for collection_name in cluster_data.keys():
  core_state = []
  for collection_data in cluster_data[collection_name]['shards']['shard1']['replicas'].values():
    core_state.append(collection_data['state'])

  if (len(core_state) == core_state.count('down')) or core_state.count('recovery_failed') > 0:
    corrupt_cores_count += 1
print corrupt_cores_count
    "
    count=`python -c "$py_script"`
    count=${count:=0}

  if [ $count -gt 0 ]
  then
    echo $count
    exit 1
  else
    healthcheck_BizXSolr
    exit 0
  fi
elif [ "$SOLRTYPE" = "OptierSOLR" ]
then
  healthcheck_OptierSolr
fi
# ====== End ======
