#!/bin/bash

#===============================================================================
#
#          FILE: findMissingReplicas.zabbix.sh
#
#         USAGE: ./findMissingReplicas.zabbix.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: Liu Michael, michael.liu03@sap.com, Kevin Jin, kevin.jin01@sap.com, Wang, Lyle, lyle.wang@sap.com
#  ORGANIZATION: SuccessFactors, an SAP Company
#       CREATED: 01/08/2019 13:21
#      REVISION: 002
#===============================================================================

# Find missed replicas
# ====== Start ======
# Pulling Auth key from zookepper
export JAVA_HOME=/app/sapjvm
Clustername=`/app/solr/bin/solr.in.sh | grep ZK_HOST|  cut -d/ -f2,3`
ZK_1st_Node=`/app/solr/bin/solr.in.sh | grep ZK_HOST | cut -f2 | cut -d: -f1`
export SOLR_AUTHORIZATION_HEADER=`/app/solr/server/scripts/cloud-scripts/zkcli.sh -zkhost $ZK_1st_Node:2181 -cmd get /$Clustername/sf_conf.json 2>/dev/null | grep ldap.client.credential | cut -d'"' -f4 | awk '{ print $2 }'`

LOCALIP=`host $(hostname) | awk '{print $NF}' | egrep "([0-9]{1,3}\.){3}[0-9]{1,3}"`
if [[ "$LOCALIP" == "" ]]
then
  LOCALIP=`/sbin/ifconfig eth0 | awk '/inet addr:/ { print $2 }' | sed 's/addr://'`
fi

if [ -d "/app/solr" ]
then
  if [ -d "/app/solrfiles" ]
  then
    SOLRTYPE="OptierSOLR"
  else
    SOLRTYPE="BizXSOLR"
  fi
else
  SOLRTYPE="UNKNOWN"
fi

if [ "$SOLRTYPE" = "BizXSOLR" ]
then
  py_script="
import os, sys, json, urllib2;
url = 'http://${LOCALIP}:8080/search/admin/zookeeper?detail=true&path=%2Flive_nodes'
solr_authorization_header = os.getenv('SOLR_AUTHORIZATION_HEADER')
req = urllib2.Request(url)
if solr_authorization_header:
    req.add_header('Authorization', 'Basic ' + solr_authorization_header)
live_nodes = json.loads(urllib2.urlopen(req).read())
children = live_nodes['tree'][0]['children']
search_nodes = []
for child in children:
  if child.has_key('text'):
    search_nodes.append(child['text'])
  else:
    search_nodes.append(child['data']['title'])
print search_nodes
    "
  SEARCH_NODES=`python -c "$py_script"`

  py_script="
import os, sys, json, urllib2, time;
missing_replica_count = 0
url = 'http://${LOCALIP}:8080/search/admin/zookeeper?_='+ str(time.time()) +'&detail=true&path=%2Fclusterstate.json&rows=2000&start=0&wt=json&view=graph'
solr_authorization_header = os.getenv('SOLR_AUTHORIZATION_HEADER')
req = urllib2.Request(url)
if solr_authorization_header:
    req.add_header('Authorization', 'Basic ' + solr_authorization_header)
cluster_state = json.loads(urllib2.urlopen(req).read())
cluster_data = json.loads(cluster_state['znode']['data'])
for collection_data in cluster_data.values():
  replicas = collection_data['shards']['shard1']['replicas']
  if len(replicas.values()) < len(${SEARCH_NODES}):
    missing_replica_count += 1
print missing_replica_count
    "
    MISSING_REPLICA_COUNT=`python -c "$py_script"`
fi

if [ "$MISSED_REPLICA_COUNT" == "0" ]
then
  echo 0
  exit 0
else
  echo $MISSING_REPLICA_COUNT
  exit 1
fi
# ====== End ======

