#!/bin/bash

#===============================================================================
#
#          FILE: checkOverseerQueueSize_Preview.sh
#
#         USAGE: ./checkOverseerQueueSize_Preview.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: Liu Michael, michael.liu03@sap.com
#  ORGANIZATION: SuccessFactors, an SAP Company
#       CREATED: 01/19/2017 13:51
#      REVISION: For Solr4.10.4
#===============================================================================

# Pulling Auth key from zookepper
export JAVA_HOME=/app/sapjvm
Clustername=`/app/solr/bin/solr.in.sh | grep ZK_HOST|  cut -d/ -f2,3`
ZK_1st_Node=`/app/solr/bin/solr.in.sh | grep ZK_HOST | cut -f2 | cut -d: -f1`
export SOLR_AUTHORIZATION_HEADER=`/app/solr/server/scripts/cloud-scripts/zkcli.sh -zkhost $ZK_1st_Node:2181 -cmd get /$Clustername/sf_conf.json 2>/dev/null | grep ldap.client.credential | cut -d'"' -f4 | awk '{ print $2 }'`

LOCALIP=`host $(hostname) | awk '{print $NF}' | egrep "([0-9]{1,3}\.){3}[0-9]{1,3}"`
if [[ "$LOCALIP" == "" ]]
then
  LOCALIP=`/sbin/ifconfig eth0 | awk '/inet addr:/ { print $2 }' | sed 's/addr://'`
fi

py_script="
import os, sys, json, urllib2, time;
overseer_queue_size = 0
url = 'http://${LOCALIP}:8080/search/admin/collections?action=OVERSEERSTATUS&wt=json&_='+ str(time.time())
solr_authorization_header = os.getenv('SOLR_AUTHORIZATION_HEADER')
req = urllib2.Request(url)
if solr_authorization_header:
    req.add_header('Authorization', 'Basic ' + solr_authorization_header)
overseer_status = json.loads(urllib2.urlopen(req).read())
overseer_queue_size = overseer_status.get('overseer_queue_size')
print overseer_queue_size
    "

OVERSEER_QUEUE_SIZE=`python -c "$py_script"`

if [ $OVERSEER_QUEUE_SIZE -gt 10000 ]
then
  echo $OVERSEER_QUEUE_SIZE
  exit 1
else
  echo 0
fi
