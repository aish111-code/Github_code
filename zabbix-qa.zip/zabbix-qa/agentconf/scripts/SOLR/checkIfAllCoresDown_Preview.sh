#!/bin/bash

#===============================================================================
#
#          FILE: checkIfAllCoresDown_Preview.sh
#
#         USAGE: ./checkIfAllCoresDown_Preview.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: Liu Michael, michael.liu03@sap.com, Kevin Jin, kevin.jin01@sap.com, Wang, Lyle, lyle.wang@sap.com
#  ORGANIZATION: SuccessFactors, an SAP Company
#       CREATED: 01/08/2019 19:00
#===============================================================================

# Pulling Auth key from zookepper
export JAVA_HOME=/app/sapjvm
Clustername=`/app/solr/bin/solr.in.sh | grep ZK_HOST|  cut -d/ -f2,3`
ZK_1st_Node=`/app/solr/bin/solr.in.sh | grep ZK_HOST | cut -f2 | cut -d: -f1`
export SOLR_AUTHORIZATION_HEADER=`/app/solr/server/scripts/cloud-scripts/zkcli.sh -zkhost $ZK_1st_Node:2181 -cmd get /$Clustername/sf_conf.json 2>/dev/null | grep ldap.client.credential | cut -d'"' -f4 | awk '{ print $2 }'`

LOCALIP=`host $(hostname) | awk '{print $NF}' | egrep "([0-9]{1,3}\.){3}[0-9]{1,3}"`
if [[ "$LOCALIP" == "" ]]
then
  LOCALIP=`/sbin/ifconfig eth0 | awk '/inet addr:/ { print $2 }' | sed 's/addr://'`
fi

if [ -d "/app/solr" ]
then
  if [ -d "/app/solrfiles" ]
  then
    SOLRTYPE="OptierSOLR"
  else
    SOLRTYPE="BizXSOLR"
  fi
else
  SOLRTYPE="UNKNOWN"
fi

if [ "$SOLRTYPE" = "BizXSOLR" ]
then
  py_script="
import os, sys, json, urllib2, time;
number_of_active_cores=0
url = 'http://${LOCALIP}:8080/search/admin/zookeeper?_='+ str(time.time()) +'&detail=true&path=%2Fclusterstate.json&rows=2000&start=0&wt=json&view=graph'
solr_authorization_header = os.getenv('SOLR_AUTHORIZATION_HEADER')
req = urllib2.Request(url)
if solr_authorization_header:
    req.add_header('Authorization', 'Basic ' + solr_authorization_header)
cluster_state = json.loads(urllib2.urlopen(req).read())
cluster_data = json.loads(cluster_state['znode']['data'])
for collection, collection_status in cluster_data.items():
  if collection_status['shards']['shard1']['state'] == 'active':
    replicas = collection_status['shards']['shard1']['replicas']
    for replica, replica_status in replicas.items():
      if replica_status['state'] == 'active':
        number_of_active_cores +=1
print number_of_active_cores
    "
    count=`python -c "$py_script"`

  if [ $count -eq 0 ]
  then
    echo 0
    exit 1
  else
    echo $count
    exit 0
  fi
fi
