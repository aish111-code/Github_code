#!/bin/bash

LOGFILEDATEPATTERN=$(date +"%Y-%m-%d")
LOGFILENAME="redis_cluster_perfload_$LOGFILEDATEPATTERN.log"
LOGFILENAMEPATTERN="redis_cluster_perfload_*.log"
LOGFILEFOLDER="/var/log/zabbix/custom_redis_logs"
LOGPATH="$LOGFILEFOLDER/$LOGFILENAME"
TEMPDATA="/var/log/zabbix/redis_cluster_perfload_out"
REDISHOST=$(hostname)

PARAMETERS=("ActiveConn" "IdleConn" "MaxActiveConn" "MaxIdleConn" "MinIdleConn")

DATESTRING=$(date +"%a %b %d %H:%M:%S %Y")

mkdir -p $LOGFILEFOLDER

LOGSTRING=""
for param in "${PARAMETERS[@]}"
do
  if [ $param == "ActiveConn" ]
  then
    wget -O $TEMPDATA  http://$REDISHOST:8080/cache  > /dev/null 2>&1
  fi
  
  VALUE=`grep "<Cluster>.*.</Cluster>" $TEMPDATA | grep -i cluster- | awk -F"$param" '{print $2}' | sed 's/>//g' | cut -d"<" -f1`
  if [ "$VALUE" != "" ]; then
    VALUE_STRING="$param=$VALUE"
    if [ "$LOGSTRING" == "" ]; then
      LOGSTRING="$DATESTRING $VALUE_STRING"
    else
      LOGSTRING="$LOGSTRING, $VALUE_STRING"
    fi
  fi
done

find $LOGFILEFOLDER -name "$LOGFILENAMEPATTERN" -type f -mtime +0 -delete
echo -e "${LOGSTRING}" >> $LOGPATH

