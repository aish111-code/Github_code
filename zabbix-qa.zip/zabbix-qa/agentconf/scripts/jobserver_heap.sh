#Job server time/heap memory script
#Author: Sreekanth KP
#Version: 1.0, 12/05/2017
#Changes done by Nandhini for MSS-4994
#!/bin/bash


Option=$1
Server=$2
IP=$3
case $1 in
        memory) cat /tmp/server_statuses|sed -n "/>$Server/,/tr>/p"|sed -n 4p|awk -F'>' '{print $2}'|awk -F'%' '{print $1}' ;;
        time  )
#               value=`curl -s http://$IP/server_statuses|sed -n "/>$Server/,/tr>/p"|sed -n 6p|awk  '{print $4}'|awk -F'<' '{print $1}'|sed 's/>//'|sed 's/-/:/'`
		value=`curl -s http://$IP/server_statuses|sed -n "/>$Server/,/tr>/p"|sed -n 8p|awk '{print $3}'`              
  		hr=`echo $value|awk -F":" '{print $1}'`
                min=`echo $value|awk -F":" '{print $2}'`
                Time=`expr 60 \* $hr + $min`
                echo $Time
                ;;
esac

