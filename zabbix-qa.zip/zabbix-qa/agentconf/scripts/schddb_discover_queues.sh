#Author :Jibin Sunny
#Date:13-2-2019

#!/bin/bash

#hit db and get master node.

#if master node is this one execute below.

mysql -h "$1" -u "$2" --password="$3" -e "SELECT * FROM scheduler.scheduler_queues" 2>/dev/null |awk '{print $2}'|tail -n+2 > /var/log/zabbix/mysqlqueue.txt 2>/dev/null

q_count=$(cat /var/log/zabbix/mysqlqueue.txt |wc -l)
IFS='
'
#echo "count $q_count"
echo "{"
echo -e "\"data\":["

for i in $(cat /var/log/zabbix/mysqlqueue.txt)
  do
     count=$(($count+1))
        if [ $count -lt $q_count ]; then
           echo -e "{\"{#QUEUE_NAME}\":\"$i\"},"
        else
           echo -e "{\"{#QUEUE_NAME}\":\"$i\"}"
        fi

  done

echo -e "]"
echo "}"
rm /var/log/zabbix/mysqlqueue.txt

