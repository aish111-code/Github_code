#Redis Cache discovery script
##Author: Sreekanth K P
#Version: 1.0, 12/04/2016

#!/bin/bash

wget -O /var/log/zabbix/redisdiscovery  http://$1:8080/cache  > /dev/null 2>&1

#REDIS=`cat output |grep -i CONCURRENT|cut -d">" -f3|cut -d"<" -f1`
REDIS=`cat /var/log/zabbix/redisdiscovery |grep -i -e MIXEDSFEDIS -e SUPERSFEDIS|cut -d">" -f3|cut -d"<" -f1`
if [ "$REDIS" == "" ]
then
REDIS="NO_MIXEDSFEDIS_CACHE_FOUND"
fi
for n in $(echo $REDIS)
do
  if [[ -z ${List[@]} ]]; then
    List=($n);
  else
    List=("${List[@]}" ${n})
  fi
done

if [[ ! -z ${List[@]} ]]; then
count=0
echo "{"
echo -e "\"data\":["
for cache in "${List[@]}"
do
   count=$(($count+1))
   if [[ $count -lt ${#List[@]} ]]; then
   echo -e "{\"{#CACHENAME}\":\"$cache\"},"
   else
   echo -e "{\"{#CACHENAME}\":\"$cache\"}"
   fi
done
echo -e "]"
echo "}"
fi
