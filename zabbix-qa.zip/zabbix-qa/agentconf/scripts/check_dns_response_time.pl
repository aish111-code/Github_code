#!/usr/bin/perl

$SCRIPT_NAME="check_dns_response_time.pl";

if($ARGV[0] eq "" )
{
print "usage: ./$SCRIPT_NAME DNS_NAME\n";
exit;
}

$DNS_NAME=$ARGV[0];

$result=`(time dig $DNS_NAME +trace) 2>&1| grep real | cut -f 2`;

@time=split('m',$result);

$min=$time[0];


@time=split("s",$time[1]);
$sec=$time[0];


#convert to ms
$response_time=($min*60+$sec)*1000;
print $response_time;

