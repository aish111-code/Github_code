#!/usr/bin/perl
use strict;
use Data::Dumper;

my %productNGrpMap = ();
open FH, ">", "/tmp/splunkUsageGrps.json" or die "Can not open \n";
my $first = 1;
print FH "{\n";
print FH "\t\"data\":[\n\n";


my @lmsgroups=`curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch getLMSAllGroups" https://localhost:8089/services/search/jobs/export -d output_mode=csv`; 
######################################################################################################################################################################################
#DC2 LMS
#####################################################################################################################################################################################
my @resDC2LMS = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC2All_LMS" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;  #>  /opt/splunk/etc/scripts/splunkLicenseDC2.txt
foreach my $line ( @resDC2LMS ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC2}{LMS}{$grpName} = $value;
}
foreach my $discoverGrp ( @lmsgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC2}{LMS}{$discoverGrp} ) {
         $productNGrpMap{DC2}{LMS}{$discoverGrp} = 0;
    }

}


#####################################################################################################################################################################################
#DC4 LMS
#####################################################################################################################################################################################
my @resDC4LMS = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC4All_LMS" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;  #>  /opt/splunk/etc/scripts/splunkLicenseDC2.txt
foreach my $line ( @resDC4LMS ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC4}{LMS}{$grpName} = $value;
}
foreach my $discoverGrp ( @lmsgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC4}{LMS}{$discoverGrp} ) {
         $productNGrpMap{DC4}{LMS}{$discoverGrp} = 0;
    }

}

#####################################################################################################################################################################################
#DC8 LMS
#####################################################################################################################################################################################
my @resDC8LMS = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC8All_LMS" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC8LMS ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC8}{LMS}{$grpName} = $value;
}
foreach my $discoverGrp ( @lmsgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC8}{LMS}{$discoverGrp} ) {
         $productNGrpMap{DC8}{LMS}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC10 LMS
#####################################################################################################################################################################################
my @resDC10LMS = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC10All_LMS" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC10LMS ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC10}{LMS}{$grpName} = $value;
}
foreach my $discoverGrp ( @lmsgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC10}{LMS}{$discoverGrp} ) {
         $productNGrpMap{DC10}{LMS}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC15 LMS
#####################################################################################################################################################################################
my @resDC15LMS = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC15All_LMS" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC15LMS ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC15}{LMS}{$grpName} = $value;
}
foreach my $discoverGrp ( @lmsgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC15}{LMS}{$discoverGrp} ) {
         $productNGrpMap{DC15}{LMS}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC16 LMS
#####################################################################################################################################################################################
my @resDC16LMS = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC16All_LMS" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC16LMS ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC16}{LMS}{$grpName} = $value;
}
foreach my $discoverGrp ( @lmsgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC16}{LMS}{$discoverGrp} ) {
         $productNGrpMap{DC16}{LMS}{$discoverGrp} = 0;
    }
}

my @bizxgroups=`curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch getBIZXAllGroups" https://localhost:8089/services/search/jobs/export -d output_mode=csv`; 
my @resDC2BIZX = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC2All_BIZX" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC2BIZX ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC2}{BIZX}{$grpName} = $value;
}
foreach my $discoverGrp ( @bizxgroups) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC2}{BIZX}{$discoverGrp} ) {
         $productNGrpMap{DC2}{BIZX}{$discoverGrp} = 0;
    }
}
my @resDC4BIZX = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC4All_BIZX" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC4BIZX ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC4}{BIZX}{$grpName} = $value;
}
foreach my $discoverGrp ( @bizxgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC4}{BIZX}{$discoverGrp} ) {
         $productNGrpMap{DC4}{BIZX}{$discoverGrp} = 0;
    }

}
#####################################################################################################################################################################################
#DC8 BIZX
#####################################################################################################################################################################################
my @resDC8BIZX = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC8All_BIZX" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC8BIZX ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC8}{BIZX}{$grpName} = $value;
}
foreach my $discoverGrp ( @bizxgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC8}{BIZX}{$discoverGrp} ) {
         $productNGrpMap{DC8}{BIZX}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC10 BIZX
#####################################################################################################################################################################################
my @resDC10BIZX = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC10All_BIZX" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC10BIZX ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC10}{BIZX}{$grpName} = $value;
}
foreach my $discoverGrp ( @bizxgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC10}{BIZX}{$discoverGrp} ) {
         $productNGrpMap{DC10}{BIZX}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC15 BIZX
#####################################################################################################################################################################################
my @resDC15BIZX = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC15All_BIZX" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC15BIZX ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC15}{BIZX}{$grpName} = $value;
}
foreach my $discoverGrp ( @bizxgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC15}{BIZX}{$discoverGrp} ) {
         $productNGrpMap{DC15}{BIZX}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC16 BIZX
#####################################################################################################################################################################################
my @resDC16BIZX = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC16All_BIZX" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC16BIZX ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC16}{BIZX}{$grpName} = $value;
}
foreach my $discoverGrp ( @bizxgroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC16}{BIZX}{$discoverGrp} ) {
         $productNGrpMap{DC16}{BIZX}{$discoverGrp} = 0;
    }
}

my @wfagroups=`curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch getWFAAllGroups" https://localhost:8089/services/search/jobs/export -d output_mode=csv`; 
#####################################################################################################################################################################################
#DC2 WFA
#####################################################################################################################################################################################
my @resDC2WFA = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC2All_WFA" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC2WFA ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC2}{WFA}{$grpName} = $value;
}
foreach my $discoverGrp ( @wfagroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC2}{WFA}{$discoverGrp} ) {
         $productNGrpMap{DC2}{WFA}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC4 WFA
#####################################################################################################################################################################################
my @resDC4WFA = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC4All_WFA" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC4WFA ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC4}{WFA}{$grpName} = $value;
}
foreach my $discoverGrp ( @wfagroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC4}{WFA}{$discoverGrp} ) {
         $productNGrpMap{DC4}{WFA}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC8 WFA
#####################################################################################################################################################################################
my @resDC8WFA = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC8All_WFA" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC8WFA ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC8}{WFA}{$grpName} = $value;
}
foreach my $discoverGrp ( @wfagroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC8}{WFA}{$discoverGrp} ) {
         $productNGrpMap{DC8}{WFA}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC10 WFA
#####################################################################################################################################################################################
my @resDC10WFA = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC10All_WFA" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC10WFA ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC10}{WFA}{$grpName} = $value;
}
foreach my $discoverGrp ( @wfagroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC10}{WFA}{$discoverGrp} ) {
         $productNGrpMap{DC10}{WFA}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC12 WFA
#####################################################################################################################################################################################
my @resDC12WFA = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC12All_WFA" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC12WFA ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC12}{WFA}{$grpName} = $value;
}
foreach my $discoverGrp ( @wfagroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC12}{WFA}{$discoverGrp} ) {
         $productNGrpMap{DC12}{WFA}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC15 WFA
#####################################################################################################################################################################################
my @resDC15WFA = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC15All_WFA" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC15WFA ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC15}{WFA}{$grpName} = $value;
}
foreach my $discoverGrp ( @wfagroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC15}{WFA}{$discoverGrp} ) {
         $productNGrpMap{DC15}{WFA}{$discoverGrp} = 0;
    }
}

#####################################################################################################################################################################################
#DC16 WFA
#####################################################################################################################################################################################
my @resDC16WFA = `curl -k -s -u  platformapi:platform\@MSS2017 -d "search=savedsearch splunkLicenseDC16All_WFA" https://localhost:8089/services/search/jobs/export -d output_mode=csv`;
foreach my $line ( @resDC16WFA ) {
    next if( $line =~ /Group/ );
    my ($grpName,$value) = split /,/, $line;
    $grpName =~ s/"//g;
    $value =~ s/"//g;
    chomp($value);
    $value = 0 if $value == "";
    $productNGrpMap{DC16}{WFA}{$grpName} = $value;
}
foreach my $discoverGrp ( @wfagroups ) {
    next if( $discoverGrp =~ /Group/ );
    $discoverGrp =~ s/"//g;
    chomp($discoverGrp);
    if( ! exists $productNGrpMap{DC16}{WFA}{$discoverGrp} ) {
         $productNGrpMap{DC16}{WFA}{$discoverGrp} = 0;
    }
}
#if( scalar @resDC16WFA ) {
#    foreach my $line ( @resDC16WFA ) {
#        ##remove * character before returning
#        next if( $line =~ /Group/ );
#        print FH ",\n" if not $first;
#        $first = 0;
#        my ($grpName,$value) = split /,/, $line;
#        $grpName =~ s/"//g;
#        $value =~ s/"//g;
#        chomp($value);
#        $value = 0 if $value == "";
#        print FH "\t{\n";
#       print FH "\t\t\"GRPNAME\":\"$grpName\",\n";
#      print FH "\t\t\"PRODUCT\":\"WFA\",\n";
#        print FH "\t\t\"VALUE\":\"$value\",\n";
#        print FH "\t\t\"DC\":\"DC16\"\n";
#        print FH "\t}";
#    }
#}

foreach my $DC ( keys %productNGrpMap ) {
    foreach my $product ( keys %{$productNGrpMap{$DC}} ) {
        foreach my $grpName (  keys %{$productNGrpMap{$DC}{$product}} ) {
            my $value = $productNGrpMap{$DC}{$product}{$grpName};
            print FH ",\n" if not $first;
            $first = 0;
            print FH "\t{\n";
            print FH "\t\t\"GRPNAME\":\"$grpName\",\n";
            print FH "\t\t\"PRODUCT\":\"$product\",\n";
            print FH "\t\t\"VALUE\":\"$value\",\n";
            print FH "\t\t\"DC\":\"$DC\"\n";
            print FH "\t}";
        }
    }
}
print FH "\n\t]\n";
print FH "}\n";
close(FH);

