#Author :Jibin Sunny
#Date:13-2-2019
#!/bin/bash
MYIP="$1"
#hit db and get master node.
MASTERIP=`mysql -u "$2" --password="$3" -h $MYIP -e "SELECT member_host as 'primary master' FROM performance_schema.global_status JOIN performance_schema.replication_group_members WHERE variable_name = 'group_replication_primary_member' AND member_id=variable_value" 2> /dev/null | tail -1 2> /dev/null`
#if master node is this one execute below.

if [[ "${MYIP}" == "${MASTERIP}" ]]
then
echo 1
else
echo 0
fi
