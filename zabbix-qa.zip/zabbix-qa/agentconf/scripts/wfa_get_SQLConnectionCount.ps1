$tpath = test-path "C:\Program Files\WFA Scripts\log\concount.txt"
if ($tpath -eq "true")
{
	if (((Get-Date) - (Get-ChildItem "C:\Program Files\WFA Scripts\log\concount.txt").LastWriteTime).TotalMinutes -gt 3) {
	$res = 0
	Write-Host $res
	}
	else {
	[string]$res = Get-Content -Path "C:\Program Files\WFA Scripts\log\concount.txt"
	Write-Host $res	}
}
Else { 
$res = 0
Write-Host $res
}
