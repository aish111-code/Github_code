$discovery = @{data=@()}
$services = Get-WmiObject -Class Win32_Service
foreach ($service in $services) {
    $data = @{}
    $data["{#SERVICE.NAME}"] = $service.Name
    $data["{#SERVICE.DISPLAYNAME}"] = $service.DisplayName
    $data["{#SERVICE.USER}"] = $service.StartName
    $data["{#SERVICE.STATE}"] = switch ($service.State.Replace(' ', '').ToLower()) {
        "running" {"0"}
        "paused" {"1"}
        "startpending" {"2"}
        "pausepending" {"3"}
        "continuepending" {"4"}
        "stoppending" {"5"}
        "stopped" {"6"}
        default {"7"}
    }
    $data["{#SERVICE.STATENAME}"] = $service.State
    $startMode = $service.StartMode.ToLower()
    if ($startMode -eq "auto") {
        if ($service.DelayedAutoStart) {
            $data["{#SERVICE.STARTUP}"] = "1"
            $data["{#SERVICE.STARTUPNAME}"] = "Automatic delayed"
        } else {
            $data["{#SERVICE.STARTUP}"] = "0"
            $data["{#SERVICE.STARTUPNAME}"] = "Automatic"
        }
    } else {
        $data["{#SERVICE.STARTUP}"] = switch ($startMode) {
            "manual" {2}
            "disabled" {3}
            default {4}
        }
        $data["{#SERVICE.STARTUPNAME}"] = $service.StartMode
    }
    $discovery["data"] += $data
}
$discovery_data = ConvertTo-Json $discovery
Write-Host $discovery_data

