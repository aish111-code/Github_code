#!/bin/bash
##################################################################################################################
# script name: jmx_wrapper.sh
# script purpose : To discover objectname for jmx auto discovery
# usage : objectname=$1 and attribute=$2
# script written date : 21-May-2014
# script written by : surekha pattnaik - c5188034
#################################################################################################################

# Usage Function
Usage() {
  echo "$0 <jmxPort#> <targetHost> <ObjectName>* <AttributeName>"
}

# Check Arguments and set global variables
if [[ $# -lt 4 ]]; then
  Usage
  exit
elif [[ $# -gt 4 ]]; then
  Usage
  exit
else
  jmxPort=$1
  host=$2
  objName="${3}*"
  attrName=$4
fi
# Using Bash Shell to find current relative path
#baseDir=${0%/*}
baseDir=$(dirname "$0")
fullPath="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Set latest Java binary to $java 
# Note: sometimes JAVA_HOME is incorrectly set or has a very old JDK.
#java="$(find /usr/local/opt  /app/sapjvm_7/ -maxdepth 4 -name java 2>/dev/null | sort -u | tail -1)"
java="$(find /local/opt/sapjvm_7/jre/bin/java /local/opt/sapjvm_8/jre/bin/ -maxdepth 4 -name java 2>/dev/null | sort -u | tail -1)"
getJMXObject()
{
for obj in $(echo $objects )
  do
    if [[ -z ${obj_name[@]} ]]; then
      obj_name=($obj);
    else
      obj_name=("${obj_name[@]}" ${obj})
    fi
  done
}

find_object()
{
  objects=$($java -jar ${baseDir}/JMXClient_V1.3.jar jmxport=${jmxPort} jmxobjectname="${objName}" remotehost=${host} | grep ${attrName} | awk -F "|" '{ print $1 }')
  #objects=$(/local/opt/jdk1.6.0_27/bin/java -jar /root/c5188034/JMXClient_V1.3.jar jmxport=9004 jmxobjectname="oracle.ucp.admin.UniversalConnectionPoolMBean:name=UniversalConnectionPoolManager*" remotehost=localhost | grep maxPoolSize | awk -F "|" '{ print $1 }')
  getJMXObject 
}

# Main
find_object $1 $2

if [[ ! -z ${obj_name[@]} ]]; then
  count=0
  echo "{"
  echo -e "\"data\":["
  for objs_nms in "${obj_name[@]}"
    do
      count=$(($count+1))
      if [[ $count -lt ${#obj_name[@]} ]]; then
        echo -e "{\"{#OBJECT}\":\"$objs_nms\"},"
      else
        echo -e "{\"{#OBJECT}\":\"$objs_nms\"}"
      fi
    done
  echo -e "]"
  echo "}"
fi
