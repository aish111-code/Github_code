import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

public abstract class BaseJMXClient {

	private final String fieldNameDelimiter = ",";

	private int jmxPort = 0;
	private String inetAddressString = null;
	private String jmxObjectName = null;
	private String jmxAttribute = null;
	private List<String> jmxFieldNames = null;

	public List<String> getJmxFieldNames() {
		return jmxFieldNames;
	}

	public int getJmxPort() {
		return jmxPort;
	}

	public String getInetAddressString() {
		return inetAddressString;
	}

	public String getJmxObjectName() {
		return jmxObjectName;
	}

	public String getJmxAttribute() {
		return jmxAttribute;
	}

	private MBeanServerConnection mBeanServerConnection;

	public MBeanServerConnection getmBeanServerConnection() {
		return mBeanServerConnection;
	}

	public void setJmxObjectName(String jmxObjectName) {
		this.jmxObjectName = jmxObjectName;
	}

	public void setJmxAttribute(String jmxAttribute) {
		this.jmxAttribute = jmxAttribute;
	}

	public void setInetAddressString(String inetAddressString) {
		this.inetAddressString = inetAddressString;
	}

	public void setJmxPort(int jmx_port) {
		this.jmxPort = jmx_port;
	}

	private void parseArguments(String[] array) {
		for (String argument : array) {

			if (argument.startsWith("jmxobjectname")) {
				setJmxObjectName(argument.substring(argument.indexOf("=") + 1));
			} else if (argument.startsWith("jmxport")) {
				setJmxPort(Integer.parseInt(argument.substring(argument
						.indexOf("=") + 1)));
			} else if (argument.startsWith("jmxattribute")) {
				setJmxAttribute(argument.substring(argument.indexOf("=") + 1));
			} else if (argument.startsWith("remotehost")) {
				setInetAddressString(argument
						.substring(argument.indexOf("=") + 1));
			} else if (argument.startsWith("jmxfieldnames")) {
				StringTokenizer jmxFieldNamesSt = (new StringTokenizer(
						argument.substring(argument.indexOf("=") + 1),
						fieldNameDelimiter));

				while (jmxFieldNamesSt.hasMoreTokens()) {
					if (jmxFieldNames == null) {
						jmxFieldNames = new ArrayList<String>();
					}
					jmxFieldNames.add(jmxFieldNamesSt.nextToken());
				}
			}

		}

		if (jmxObjectName == null || jmxPort == 0) {
			System.out
					.println("Please provide a valid jmx port , object and attribute");
			System.exit(0);
		}
	}

	public BaseJMXClient(String args[]) {
		parseArguments(args);
		JMXServiceURL jmxServiceURL;
		try {
			jmxServiceURL = new JMXServiceURL("rmi", "", 0, "/jndi/rmi://"
					+ (this.inetAddressString != null ? this.inetAddressString
							: "localhost") + ":" + this.jmxPort + "/jmxrmi");

			JMXConnector jmxConnector = JMXConnectorFactory
					.connect(jmxServiceURL);

			mBeanServerConnection = jmxConnector.getMBeanServerConnection();

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected boolean isPrimitiveArray(Object attribute) {
		List<?> clazzez = new ArrayList(Arrays.asList(boolean[].class,
				byte[].class, short[].class, char[].class, int[].class,
				long[].class, float[].class, double[].class, String[].class));

		return (clazzez.contains(attribute.getClass()) ? true : false);
	}

	protected boolean isPrimitiveAttribute(Object attribute) {
		List<?> clazzez = new ArrayList(Arrays.asList(Boolean.class,
				Byte.class, Short.class, Integer.class, Long.class,
				Float.class, Double.class, String.class));

		return (clazzez.contains(attribute.getClass()) ? true : false);
	}

	public void printMbeanDetails() throws MalformedObjectNameException,
			NullPointerException, AttributeNotFoundException,
			InstanceNotFoundException, MBeanException, ReflectionException,
			IOException, IntrospectionException {

	}
}
