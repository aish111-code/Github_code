import java.io.IOException;
import java.io.NotSerializableException;
import java.rmi.UnmarshalException;
import java.util.Set;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.RuntimeMBeanException;
import javax.management.openmbean.CompositeData;

public class JMXMBeanInfo extends BaseJMXClient {
	
	

	public JMXMBeanInfo(String args[]) {
		super(args);
	}
	
	static StringBuffer stringBufferAttributes =null;
	static String lastTitle ="",headerTitle="";

	private void printAttributeDetails(Object attribute, String attributeName,StringBuffer strbuff)
			throws AttributeNotFoundException, InstanceNotFoundException,
			MBeanException, ReflectionException, IOException {
		
		printAttributeDetails(attribute, attributeName, null,strbuff);
	}

	private void printAttributeDetails(Object attribute, String attributeName,
			MBeanAttributeInfo mBeanAttributeInfo,StringBuffer strbuff)
			throws AttributeNotFoundException, InstanceNotFoundException,
			MBeanException, ReflectionException, IOException {
		
		if (attribute != null) {
			
			if (isPrimitiveAttribute(attribute)) {
				// Print out the attribute
				//System.out.println("value -->"+attributeName);
				//System.out.println("Name:"+attributeName + " - Value:" + attribute.toString());
				
				
				//System.out.println("0-----------"+lastTitle);
				
				String value = lastTitle+"|"+attributeName + "-" + attribute.toString();
				//System.out.println(""+value);
				//stringBufferAttributes.append("$"+lastTitle+"."+attributeName+"-"+attribute.toString()+"");
				stringBufferAttributes.append("\n"+value);
				strbuff.append(value);
				//System.out.println("buffered value -->"+strbuff.toString());
				
			} else if (isPrimitiveArray(attribute)) {
				for (Object objectAttribute : (Object[]) attribute) {
					printAttributeDetails(objectAttribute, attributeName,strbuff);
				}
			} else if (attribute instanceof CompositeData) {
				CompositeData comp = (CompositeData) attribute;
				Set<String> keys = comp.getCompositeType().keySet();
				// Add a tag here to make it searchable
				//System.out.println("----------"+mBeanAttributeInfo != null ? mBeanAttributeInfo.getName() : null);
				String title =mBeanAttributeInfo != null ? mBeanAttributeInfo.getName() : null;
				lastTitle = "\n"+lastTitle+"|"+title;
				//System.out.println("1-----------"+title);
				//stringBufferAttributes.append("|"+title+"$");
				
				for (String key : keys) {

					if (getJmxFieldNames() != null && !getJmxFieldNames().contains(key)) {
						continue;
					}

					// System.out.print(key + " - ");
					printAttributeDetails(comp.get(key), key,strbuff);

				}
				lastTitle = headerTitle;
			}
		}
	}

	private void fetchAttributes(ObjectName objectName, Object attribute,StringBuffer strbuff)
			throws AttributeNotFoundException, InstanceNotFoundException,
			MBeanException, ReflectionException, IOException,
			IntrospectionException {
		
		if (getJmxAttribute() != null) {
			printAttributeDetails(
					getmBeanServerConnection().getAttribute(objectName,
							getJmxAttribute()), getJmxAttribute(),strbuff);
			//System.out.println("first");
		} else {
			//System.out.println("second");
			MBeanInfo mBeanInfo = getmBeanServerConnection().getMBeanInfo(
					objectName);
			MBeanAttributeInfo[] mBeanAttributeInfo = mBeanInfo.getAttributes();
			
			for (MBeanAttributeInfo attributeObj : mBeanAttributeInfo) {
				try {
					printAttributeDetails(getmBeanServerConnection()
							.getAttribute(objectName, attributeObj.getName()),
							attributeObj.getName(), attributeObj,strbuff);
					
					
				} catch (ReflectionException e) {
					//System.out.println("Eating up exception" + e.getMessage());
				} catch (UnmarshalException e) {
					//System.out.println("Eating up exception" + e.getMessage());
				} catch (UnsupportedOperationException e) {
					//System.out.println("Eating up exception" + e.getMessage());
				} catch (RuntimeMBeanException e) {
					//System.out.println("Eating up exception" + e.getMessage());
				} catch (ClassCastException e) {
					//System.out.println("Eating up exception" + e.getMessage());
				} catch (AttributeNotFoundException e) {
					//System.out.println("Eating up exception" + e.getMessage());
				}
			}
			
			stringBufferAttributes.append("\n");
		}
	}

	@Override
	public void printMbeanDetails() throws MalformedObjectNameException,
			NullPointerException, AttributeNotFoundException,
			InstanceNotFoundException, MBeanException, ReflectionException,
			IOException, IntrospectionException {
		StringBuffer strbuff = new StringBuffer();
		if (getJmxObjectName().contains("*")) {
			for (ObjectName name : getmBeanServerConnection().queryNames(
					(getJmxObjectName().equals("*") ? null : new ObjectName(
							getJmxObjectName())), null)) {
				//System.out.println("discovered object " + name);
				lastTitle = name.toString();
				headerTitle = "\n"+lastTitle;
				stringBufferAttributes.append(name+"");
				fetchAttributes(name, getJmxAttribute(),strbuff);
				
			}
		} else {
			//System.out.println("Object name " + getJmxObjectName());

			fetchAttributes(new ObjectName(getJmxObjectName()),
					getJmxAttribute(),strbuff);
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JMXMBeanInfo jmxMBeanInfo = new JMXMBeanInfo(args);
		try {
			stringBufferAttributes = new StringBuffer();
			
			jmxMBeanInfo.printMbeanDetails();
			
			System.out.println(""+stringBufferAttributes.toString());
			
		} catch (MalformedObjectNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AttributeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstanceNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MBeanException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ReflectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IntrospectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
