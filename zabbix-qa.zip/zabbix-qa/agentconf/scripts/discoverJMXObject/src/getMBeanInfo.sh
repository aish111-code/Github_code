export JAVA_HOME="/local/opt/sapjvm_7"
export PATH=$JAVA_HOME/bin:$PATH

java -jar JMXMbeanClient.jar jmxport=9004 jmxobjectname="java.lang:type=MemoryPool,name=CMS*" remotehost=localhost
#java -jar JMXMbeanClient.jar jmxport=9004 jmxobjectname="oracle.ucp.admin.UniversalConnectionPoolMBean:name=UniversalConnectionPoolManager-*" remotehost=localhost
#java -jar JMXMbeanClient.jar jmxport=9004 jmxobjectname="Catalina:type=Cache,host=localhost,context=*" remotehost=localhost