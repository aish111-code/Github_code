###############################################
#Author: Sreekanth KP
#Discover redis cluster environments
#version 1.0, 06/03/2017
################################################


cat /var/log/zabbix/redis/redisinst_status.out|tr "\n" "\t" |awk -F "$1" '{print $2}'|awk -F'%' '{print $1}'|awk -F ">" '{print $3}'

