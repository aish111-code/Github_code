#!/bin/bash

if [[ -z $1 ]]; then
  exit
fi

findSID () {
  # Pick the Last SID Found.  Should not be important for this check.
  SIDs=$(ps -ef | grep pmon | grep -v ASM | grep -v grep | awk '{ print $NF }')
  if [[ ! -z $SIDs ]]; then
    for sid in $(echo $SIDs)
    do
      if [[ -z ${sidList[@]} ]]; then
        sidList=(${sid##*_});
      else
        sidList=("${sidList[@]}" ${sid##*_})
      fi
    done
    # Set SID to first value to load oracle env.
    #export ORACLE_SID=${sidList[0]}

    #if [[ $(echo ${#sidList[@]}) == 1 ]]; then
    #  export ORACLE_SID=${sidList[0]}
    #fi
  else
    if [[ $(cat $HOME/.bash_profile | grep ORACLE_SID= | cut -d"=" -f2) ]]; then
      sidList=$(cat $HOME/.bash_profile | grep ORACLE_SID= | cut -d"=" -f2)
    fi
  fi
  export ORACLE_SID=${sidList[0]}
}
setOraEnv () {
  # send ORACLE_SID as parameter.  If nothing is sent and only 1 pmon proc found it will be used by default
  if [[ -z $1 ]]; then
  #  SID=$(pmon=$(ps -ef | grep pmon | grep -v ASM | grep -v grep | awk '{ print $NF }');echo ${pmon##*_})
  #  if [[ $(echo $SID | wc -w) == 1 ]]; then
  #    export ORACLE_SID=$SID
  #  fi
    findSID
  else
    export ORACLE_SID=$1
  fi
  export LD_LIBRARY_PATH=$ORACLE_HOME/lib
  export ORACLE_BASE=/app/oracle/base
  export PATH=$PATH:/usr/local/bin:/usr/local/sbin
  #export ORACLE_SID=DC8PRD01
  ORAENV_ASK=NO
  . /usr/local/bin/oraenv -s
  ORAENV_ASK=YES
}

runGGSCI () {
ggsci=$(cd /tmp; find /u01/software/goldengate /app/software/goldengate -name ggsci 2>/dev/null | tail -1)
cd ${ggsci%/*}
./ggsci << EOF
INFO ALL
EOF
}

getTotalSeconds () {
  time=$1
  hours=$(($(echo $time| cut -d: -f1 | sed s"/^0//")*3600))
  minutes=$(($(echo $time| cut -d: -f2 | sed s"/^0//")*60))
  seconds=$(($(echo $time| cut -d: -f3 | sed s"/^0//")*1))
  
  total_sec=$((${hours}+${minutes}+${seconds}))
  echo $total_sec
}

case $1 in
"timeSinceChkpt")
  if [[ ! -z $2 ]]; then
    GROUP=$2
    if [[ $(setOraEnv; runGGSCI | grep -w $GROUP| awk '{ print $5 }') ]]; then
      time=$(setOraEnv; runGGSCI | grep -w $GROUP| awk '{ print $5 }')
      getTotalSeconds $time
    else
      echo "undefined"
    fi
  fi
  ;;
"lagAtChkpt")
  if [[ ! -z $2 ]]; then
    GROUP=$2
    if [[ $(setOraEnv; runGGSCI | grep -w $GROUP | awk '{ print $4 }') ]]; then
      time=$(setOraEnv; runGGSCI | grep -w $GROUP| awk '{ print $4 }')
      getTotalSeconds $time
    else
      echo "undefined"
    fi
  fi
  ;;
"status")
  if [[ ! -z $2 ]]; then
    GROUP=$2
    if [[ $(setOraEnv; runGGSCI | grep -w $GROUP| awk '{ print $2 }') ]]; then
      echo $(setOraEnv; runGGSCI | grep -w $GROUP| awk '{ print $2 }')
    else
      echo "undefined"
    fi
  fi
  ;;
"discovery")
  findSID
  if [[ ! -z ${sidList[@]} ]]; then
    echo "{"
    echo -e "\"data\":["
    for sid in "${sidList[0]}"
      do
        groupList=($(setOraEnv "$sid"; runGGSCI | grep EXTRACT |awk '{ print $3 }'))
        count=0
        for db in ${groupList[@]}
        do
          count=$(($count+1))
          if [[ $count < ${#groupList[@]} ]]; then
            echo -e "{\"{#GROUP}\":\"$db\"},"
          else
            echo -e "{\"{#GROUP}\":\"$db\"}"
          fi
        done
      done
    echo -e "]"
    echo "}"
  fi
  ;;

"all")
  setOraEnv; runGGSCI
  ;;
*)
  echo "unknown param"
  ;;
esac

