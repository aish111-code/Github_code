#!/bin/bash

MAXLATENCY=`echo mntr | netcat localhost 2181 | grep zk_max_latency | awk '{print $2}'`
# If the Zookeeper response time is more than 2 ticks
if [[ -n $MAXLATENCY && $MAXLATENCY -gt 40000 ]]
then
  echo $MAXLATENCY
  exit 1
else
  echo 0
  exit 0
fi
