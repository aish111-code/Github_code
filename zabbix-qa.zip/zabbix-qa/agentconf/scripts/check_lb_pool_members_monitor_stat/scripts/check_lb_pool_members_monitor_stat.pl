#!/usr/bin/perl
use SOAP::Lite;
use UNIVERSAL 'isa';

# PERL MODULES WE WILL BE USING
use DBI;
use DBD::mysql;
use MIME::Base64;

###################################################################
#Pleaase specify the directory containing the iControlTypeCast.pm
#####################################################################
BEGIN {push (@INC, "/etc/zabbix/zabbix_agentd/scripts/check_lb_pool_members_monitor_stat/lib");}



use iControlTypeCast;
$ENV{'PERL_LWP_SSL_VERIFY_HOSTNAME'} = 0;


#----------------------------------------------------------------------------
# Validate Arguments
#----------------------------------------------------------------------------
if($ARGV[0] eq "" || $ARGV[1] eq "" || $ARGV[2] eq "")
{
print "usage: ./check_lb_pool_members_monitor_stat.pl datacenter lb_host_ip pool_name\n";
exit;
}


##################################################################
#system setting
##################################################################
my $DATACENTER=$ARGV[0];

my $HOST = $ARGV[1];        # EM Host
my $POOL_NAME=$ARGV[2];

my $PORT = "";
my $USER_NAME ="";
my $PASSWORD = "";

# MYSQL CONFIG VARIABLES
$mysql_host = "localhost";
$mysql_database = "bizx";

$mysql_user = "bizx";
$mysql_pw = "ov35adnd89hf";

$mysql_dsn="dbi:mysql:$mysql_database:$mysql_host:3306";

$mysql_connection=DBI->connect($mysql_dsn, $mysql_user, $mysql_pw) or die "Unable to connect: $DBI::errstr\n";

 # Now retrieve data from the table.
  my $sth = $mysql_connection->prepare("SELECT * FROM lb_hosts WHERE datacenter='$DATACENTER' and host_ip='$HOST'");
  $sth->execute();
  if (my $result = $sth->fetchrow_hashref()) {
          $PORT = $result->{'host_port'};
          $USER_NAME = $result->{'username'};        # EM User
          $PASSWORD = decode_base64($result->{'password'});        # EM Password
  }
  $sth->finish();

  # Disconnect from the database.
  $mysql_connection->disconnect();


my $proxy_uri = sprintf("https://%s:$PORT/iControl/iControlPortal.cgi", $HOST);
my $soap = SOAP::Lite->proxy($proxy_uri);

sub SOAP::Transport::HTTP::Client::get_basic_credentials {
    return $USER_NAME => $PASSWORD;
}

sub checkResponse {
    my ($resp) = (@_);
    die "$resp->faultcode $resp->faultstring\n" if $resp->fault;
      
    if (@{$resp->result}) {
       # print "\tItem: $_\n" foreach (@{$resp->result});
    }
    else {
        printf "\tResult: %s\n", $resp->result;
    }
}

#----------------------------------------------------------------------------
sub getPoolMemberObjectStatus
{
    my ($pool_name)=(@_);
    # Get the list of pool members state for all the pools.
    # use LocalLB/Pool in  BIG-IP_v11.0.0
    $soapResponse = $soap->uri("urn:iControl:LocalLB/PoolMember")->get_object_status
    (
        SOAP::Data->name(pool_names => [$pool_name])
    );
    checkResponse($soapResponse);
    @member_status_lists = @{$soapResponse->result};

    return @member_status_lists;
}


#----------------------------------------------------------------------------
sub IP_to_Hostname
{
my ($ip)=(@_);
$soapResponse = $soap->uri("urn:iControl:LocalLB/NodeAddress")->get_screen_name
    (
        SOAP::Data->name(node_addresses => [$ip])
    );
    checkResponse($soapResponse);
    @hostname= @{$soapResponse->result};

    return @hostname[0];

}
#----------------------------------------------------------------------------
#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

@member_status_lists=getPoolMemberObjectStatus($POOL_NAME);

$has_problem=0;
$problem_members="";

foreach $members(@{@member_status_lists[0]})
{
$member=$members->{"member"};
$object_status= $members->{"object_status"};

if($object_status->{"status_description"} eq "Pool member has been marked down by a monitor")
{
$hostname="";
$hostname=IP_to_Hostname($member->{"address"});
if($hostname eq "")
{
$str=$member->{"address"};
}
else
{
$str=$hostname;
}

if($problem_members eq "")
{
$problem_members.=$str;
}
else
{
$problem_members.=",".$str;
}

$has_problem=1;

}#end if status check

}#end foreach


if($has_problem==1)
{
print $problem_members."\n";
}
else
{
#print "0\n";
}

