#===========================================================================
#
# /home/joep/src/perforce/maint1000/f5_build/iControl/sdk/dist_image/iControl-10.2.0/sdk/samples/soap/perl/soaplite//iControlTypeCast.pm
#
#===========================================================================
#
# The contents of this file are subject to the "END USER LICENSE AGREEMENT FOR F5
# Software Development Kit for iControl"; you may not use this file except in
# compliance with the License. The License is included in the iControl
# Software Development Kit.
#
# Software distributed under the License is distributed on an "AS IS"
# basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
# the License for the specific language governing rights and limitations
# under the License.
#
# The Original Code is iControl Code and related documentation
# distributed by F5.
#
# The Initial Developer of the Original Code is F5 Networks,
# Inc. Seattle, WA, USA. Portions created by F5 are Copyright (C) 1996-2004 F5 Networks,
# Inc. All Rights Reserved.  iControl (TM) is a registered trademark of F5 Networks, Inc.
#
# Alternatively, the contents of this file may be used under the terms
# of the GNU General Public License (the "GPL"), in which case the
# provisions of GPL are applicable instead of those above.  If you wish
# to allow use of your version of this file only under the terms of the
# GPL and not to allow others to use your version of this file under the
# License, indicate your decision by deleting the provisions above and
# replace them with the notice and other provisions required by the GPL.
# If you do not delete the provisions above, a recipient may use your
# version of this file under either the License or the GPL.
#

package iControlTypeCast;
require SOAP::Lite;

my $urnMap;

sub BEGIN
{
	$urnMap = 
	{
		"{urn:iControl}ASM.ApplyLearningType" => 1,
		"{urn:iControl}ASM.DynamicSessionsInUrlType" => 1,
		"{urn:iControl}ASM.FlagState" => 1,
		"{urn:iControl}ASM.PolicyTemplate" => 1,
		"{urn:iControl}ASM.ProtocolType" => 1,
		"{urn:iControl}ASM.SeverityName" => 1,
		"{urn:iControl}ASM.ViolationName" => 1,
		"{urn:iControl}ASM.WebApplicationLanguage" => 1,
		"{urn:iControl}Common.ArmedState" => 1,
		"{urn:iControl}Common.AuthenticationMethod" => 1,
		"{urn:iControl}Common.AvailabilityStatus" => 1,
		"{urn:iControl}Common.DaemonStatus" => 1,
		"{urn:iControl}Common.EnabledState" => 1,
		"{urn:iControl}Common.EnabledStatus" => 1,
		"{urn:iControl}Common.FileChainType" => 1,
		"{urn:iControl}Common.HAAction" => 1,
		"{urn:iControl}Common.HAState" => 1,
		"{urn:iControl}Common.IPHostType" => 1,
		"{urn:iControl}Common.ProtocolType" => 1,
		"{urn:iControl}Common.SourcePortBehavior" => 1,
		"{urn:iControl}Common.StatisticType" => 1,
		"{urn:iControl}Common.TMOSModule" => 1,
		"{urn:iControl}GlobalLB.AddressType" => 1,
		"{urn:iControl}GlobalLB.AutoConfigurationState" => 1,
		"{urn:iControl}GlobalLB.AvailabilityDependency" => 1,
		"{urn:iControl}GlobalLB.LBMethod" => 1,
		"{urn:iControl}GlobalLB.LDNSProbeProtocol" => 1,
		"{urn:iControl}GlobalLB.LinkWeightType" => 1,
		"{urn:iControl}GlobalLB.MetricLimitType" => 1,
		"{urn:iControl}GlobalLB.MonitorAssociationRemovalRule" => 1,
		"{urn:iControl}GlobalLB.MonitorInstanceStateType" => 1,
		"{urn:iControl}GlobalLB.MonitorRuleType" => 1,
		"{urn:iControl}GlobalLB.RegionDBType" => 1,
		"{urn:iControl}GlobalLB.RegionType" => 1,
		"{urn:iControl}GlobalLB.ServerType" => 1,
		"{urn:iControl}GlobalLB.Application.ApplicationObjectType" => 1,
		"{urn:iControl}GlobalLB.DNSSECKey.KeyAlgorithm" => 1,
		"{urn:iControl}GlobalLB.DNSSECKey.KeyType" => 1,
		"{urn:iControl}GlobalLB.Monitor.IntPropertyType" => 1,
		"{urn:iControl}GlobalLB.Monitor.StrPropertyType" => 1,
		"{urn:iControl}GlobalLB.Monitor.TemplateType" => 1,
		"{urn:iControl}LocalLB.AddressType" => 1,
		"{urn:iControl}LocalLB.AuthenticationMethod" => 1,
		"{urn:iControl}LocalLB.AvailabilityStatus" => 1,
		"{urn:iControl}LocalLB.ClientSSLCertificateMode" => 1,
		"{urn:iControl}LocalLB.ClonePoolType" => 1,
		"{urn:iControl}LocalLB.CompressionMethod" => 1,
		"{urn:iControl}LocalLB.CookiePersistenceMethod" => 1,
		"{urn:iControl}LocalLB.CredentialSource" => 1,
		"{urn:iControl}LocalLB.EnabledStatus" => 1,
		"{urn:iControl}LocalLB.HardwareAccelerationMode" => 1,
		"{urn:iControl}LocalLB.HttpChunkMode" => 1,
		"{urn:iControl}LocalLB.HttpCompressionMode" => 1,
		"{urn:iControl}LocalLB.HttpRedirectRewriteMode" => 1,
		"{urn:iControl}LocalLB.LBMethod" => 1,
		"{urn:iControl}LocalLB.MonitorAssociationRemovalRule" => 1,
		"{urn:iControl}LocalLB.MonitorInstanceStateType" => 1,
		"{urn:iControl}LocalLB.MonitorRuleType" => 1,
		"{urn:iControl}LocalLB.MonitorStatus" => 1,
		"{urn:iControl}LocalLB.PersistenceMode" => 1,
		"{urn:iControl}LocalLB.ProfileContextType" => 1,
		"{urn:iControl}LocalLB.ProfileMode" => 1,
		"{urn:iControl}LocalLB.ProfileType" => 1,
		"{urn:iControl}LocalLB.RamCacheCacheControlMode" => 1,
		"{urn:iControl}LocalLB.RtspProxyType" => 1,
		"{urn:iControl}LocalLB.SSLOption" => 1,
		"{urn:iControl}LocalLB.ServerSSLCertificateMode" => 1,
		"{urn:iControl}LocalLB.ServiceDownAction" => 1,
		"{urn:iControl}LocalLB.SessionStatus" => 1,
		"{urn:iControl}LocalLB.SnatType" => 1,
		"{urn:iControl}LocalLB.TCPCongestionControlMode" => 1,
		"{urn:iControl}LocalLB.TCPOptionMode" => 1,
		"{urn:iControl}LocalLB.UncleanShutdownMode" => 1,
		"{urn:iControl}LocalLB.VirtualAddressStatusDependency" => 1,
		"{urn:iControl}LocalLB.Class.ClassType" => 1,
		"{urn:iControl}LocalLB.Class.FileFormatType" => 1,
		"{urn:iControl}LocalLB.Class.FileModeType" => 1,
		"{urn:iControl}LocalLB.Monitor.IntPropertyType" => 1,
		"{urn:iControl}LocalLB.Monitor.StrPropertyType" => 1,
		"{urn:iControl}LocalLB.Monitor.TemplateType" => 1,
		"{urn:iControl}LocalLB.ProfilePersistence.PersistenceHashMethod" => 1,
		"{urn:iControl}LocalLB.ProfileUserStatistic.UserStatisticKey" => 1,
		"{urn:iControl}LocalLB.RAMCacheInformation.RAMCacheVaryType" => 1,
		"{urn:iControl}LocalLB.RateClass.DirectionType" => 1,
		"{urn:iControl}LocalLB.RateClass.DropPolicyType" => 1,
		"{urn:iControl}LocalLB.RateClass.QueueType" => 1,
		"{urn:iControl}LocalLB.RateClass.UnitType" => 1,
		"{urn:iControl}LocalLB.VirtualServer.VirtualServerCMPEnableMode" => 1,
		"{urn:iControl}LocalLB.VirtualServer.VirtualServerType" => 1,
		"{urn:iControl}Management.DebugLevel" => 1,
		"{urn:iControl}Management.LDAPPasswordEncodingOption" => 1,
		"{urn:iControl}Management.LDAPSSLOption" => 1,
		"{urn:iControl}Management.LDAPSearchMethod" => 1,
		"{urn:iControl}Management.LDAPSearchScope" => 1,
		"{urn:iControl}Management.OCSPDigestMethod" => 1,
		"{urn:iControl}Management.ZoneType" => 1,
		"{urn:iControl}Management.EventNotification.EventDataType" => 1,
		"{urn:iControl}Management.EventSubscription.AuthenticationMode" => 1,
		"{urn:iControl}Management.EventSubscription.EventType" => 1,
		"{urn:iControl}Management.EventSubscription.ObjectType" => 1,
		"{urn:iControl}Management.EventSubscription.SubscriptionStatusCode" => 1,
		"{urn:iControl}Management.KeyCertificate.CertificateType" => 1,
		"{urn:iControl}Management.KeyCertificate.KeyType" => 1,
		"{urn:iControl}Management.KeyCertificate.ManagementModeType" => 1,
		"{urn:iControl}Management.KeyCertificate.SecurityType" => 1,
		"{urn:iControl}Management.KeyCertificate.ValidityType" => 1,
		"{urn:iControl}Management.Provision.ProvisionLevel" => 1,
		"{urn:iControl}Management.SNMPConfiguration.AuthType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.DiskCheckType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.LevelType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.ModelType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.PrefixType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.PrivacyProtocolType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.SinkType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.TransportType" => 1,
		"{urn:iControl}Management.SNMPConfiguration.ViewType" => 1,
		"{urn:iControl}Management.UserManagement.UserRole" => 1,
		"{urn:iControl}Networking.FilterAction" => 1,
		"{urn:iControl}Networking.FlowControlType" => 1,
		"{urn:iControl}Networking.LearningMode" => 1,
		"{urn:iControl}Networking.MediaStatus" => 1,
		"{urn:iControl}Networking.MemberTagType" => 1,
		"{urn:iControl}Networking.MemberType" => 1,
		"{urn:iControl}Networking.PhyMasterSlaveMode" => 1,
		"{urn:iControl}Networking.RouteEntryType" => 1,
		"{urn:iControl}Networking.STPLinkType" => 1,
		"{urn:iControl}Networking.STPModeType" => 1,
		"{urn:iControl}Networking.STPRoleType" => 1,
		"{urn:iControl}Networking.STPStateType" => 1,
		"{urn:iControl}Networking.ARP.NDPState" => 1,
		"{urn:iControl}Networking.Interfaces.MediaType" => 1,
		"{urn:iControl}Networking.ProfileWCCPGRE.WCCPGREForwarding" => 1,
		"{urn:iControl}Networking.STPInstance.PathCostType" => 1,
		"{urn:iControl}Networking.SelfIPPortLockdown.AllowMode" => 1,
		"{urn:iControl}Networking.Trunk.DistributionHashOption" => 1,
		"{urn:iControl}Networking.Trunk.LACPTimeoutOption" => 1,
		"{urn:iControl}Networking.Trunk.LinkSelectionPolicy" => 1,
		"{urn:iControl}Networking.Tunnel.TunnelDirection" => 1,
		"{urn:iControl}Networking.VLANGroup.VLANGroupTransparency" => 1,
		"{urn:iControl}Networking.iSessionLocalInterface.NatSourceAddress" => 1,
		"{urn:iControl}Networking.iSessionPeerDiscovery.DiscoveryMode" => 1,
		"{urn:iControl}Networking.iSessionPeerDiscovery.FilterMode" => 1,
		"{urn:iControl}Networking.iSessionRemoteInterface.NatSourceAddress" => 1,
		"{urn:iControl}Networking.iSessionRemoteInterface.OriginState" => 1,
		"{urn:iControl}System.CPUMetricType" => 1,
		"{urn:iControl}System.FanMetricType" => 1,
		"{urn:iControl}System.HardwareType" => 1,
		"{urn:iControl}System.PSMetricType" => 1,
		"{urn:iControl}System.TemperatureMetricType" => 1,
		"{urn:iControl}System.ConfigSync.ConfigExcludeComponent" => 1,
		"{urn:iControl}System.ConfigSync.ConfigIncludeComponent" => 1,
		"{urn:iControl}System.ConfigSync.LoadMode" => 1,
		"{urn:iControl}System.ConfigSync.SaveMode" => 1,
		"{urn:iControl}System.ConfigSync.SyncMode" => 1,
		"{urn:iControl}System.Disk.RAIDStatus" => 1,
		"{urn:iControl}System.Failover.FailoverMode" => 1,
		"{urn:iControl}System.Failover.FailoverState" => 1,
		"{urn:iControl}System.Services.ServiceAction" => 1,
		"{urn:iControl}System.Services.ServiceStatusType" => 1,
		"{urn:iControl}System.Services.ServiceType" => 1,
		"{urn:iControl}System.Statistics.GtmIQueryState" => 1,
		"{urn:iControl}System.Statistics.GtmPathStatisticObjectType" => 1,
	}
}
sub END {}

#Implement Typecast for iControl enumeration Elements
sub SOAP::Deserializer::typecast
{
	my ($self, $value, $name, $attrs, $children, $type) = @_;
	my $retval = undef;
	if ( 1 == $urnMap->{$type} )
	{
		$retval = $value;
	}
	return $retval;
}
# End Of File
