#!/bin/bash
export ORACLE_HOME=/local/opt/oracle_x64/product/11.2.0/client_1
export PATH=$ORACLE_HOME/bin:$PATH


sqlplus $1/$2@//$3:$4/$5 <<END_SCRIPT
select count(*) from $1.qrtz_rpt_fired_triggers 
where ((cast(SYS_EXTRACT_UTC(systimestamp) as date)-to_date('1970-1-1','yyyy-mm-dd'))*24 - fired_time/3600000) > $6;
exit;
END_SCRIPT

