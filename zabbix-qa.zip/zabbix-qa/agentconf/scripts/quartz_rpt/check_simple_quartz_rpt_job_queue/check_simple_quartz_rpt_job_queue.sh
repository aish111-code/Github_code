#!/bin/bash
export ORACLE_HOME=/local/opt/oracle_x64/product/11.2.0/client_1
export PATH=$ORACLE_HOME/bin:$PATH


sqlplus $1/$2@//$3:$4/$5 <<END_SCRIPT
select count(*) ,trigger_type from ( select TRIGGER_NAME,JOB_NAME,JOB_GROUP,to_date('1970-01-01', 'YYYY-MM-DD') + (start_time/ 86400000) as start_time,
to_date('1970-01-01', 'YYYY-MM-DD') + (NEXT_FIRE_TIME/ 86400000) as NEXT_FIRE_TIME ,TRIGGER_TYPE ,trigger_state from  $1.qrtz_rpt_triggers 
order by next_fire_time) where to_char(NEXT_FIRE_TIME,'ss')<>'00'  group by trigger_type;
exit;
END_SCRIPT

