
cluster_id=$1
api_type=$2
metric=$3

case $api_type in

stats)
Metric_value=$(curl -s -k -u "zabbix_user:Zabb1x@123" "https://$cluster_id/_cluster/stats?pretty"|grep -w "$metric"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g')
echo $Metric_value
;;

health)
Metric_value=$(curl -s -k -u "zabbix_user:Zabb1x@123" "https://$cluster_id/_cluster/health?pretty"|grep -w "$metric"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g')
echo $Metric_value
;;

nodes)
Metric_value=$(curl -s -k -u "zabbix_user:Zabb1x@123" "https://$cluster_id/_cluster/stats?pretty"|grep -wA 7 "nodes"|grep -w "$metric"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g')
echo $Metric_value
;;

_nodes)
Metric_value=$(curl -s -k -u "zabbix_user:Zabb1x@123" "https://$cluster_id/_cluster/stats?pretty"|grep -wA 4 "_nodes"|grep -w "$metric"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g')
echo $Metric_value
;;

fs)
Metric_value=$(curl -s -k -u "zabbix_user:Zabb1x@123" "https://$cluster_id/_cluster/stats?pretty"|grep -wA 4 '"fs"'|grep -w "$metric"|awk -F ": " '{print $2}'|cut -d ',' -f1|sed 's/"//g')
echo $Metric_value
;;

esac
