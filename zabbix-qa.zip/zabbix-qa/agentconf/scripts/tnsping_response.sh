##################################################################
# Author        : Sreekanth K P
# Purpose       : Scanner domain/IP discovery script
# Version       : 20/12/2016 - Initial code
#
####################################################################

#!/bin/bash
export ORACLE_HOME=/usr/local/opt/oracle/11.2.0/client_home1
export PATH=$ORACLE_HOME/bin:$PATH
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
echo quit  | netcat -w 5  -v $1 1521 > /dev/null  2>&1
if [ $? -ne 0 ]
then
echo "-1"
exit
fi
tnsping $1|tail -1|grep msec|awk '{print $2}'|sed 's/(//g'

