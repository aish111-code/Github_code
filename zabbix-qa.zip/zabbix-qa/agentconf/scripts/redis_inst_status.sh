###############################################
#Author: Sreekanth KP
#Instance doen for cluster
#version 1.1, 16/03/2017
################################################
cluster_count=`grep -i $1 /var/log/zabbix/redis/redisinst_status.out|wc -l`
if [ $cluster_count != 0 ]
then
        status=`cat /var/log/zabbix/redis/redisinst_status.out|tr "\n" "\t"|awk -F "$1" '{print $2}'|awk -F"/Cluster" '{print $1}'|grep 'server address'|tr -s "=" "\n"|grep '/server'|awk -F'"' '{print $2}'`
        if [ "$status" ]
        then
                echo "$status"
        else
                echo "OK"
        fi
else
        echo "Not OK - Cluster $1 is not found in /var/log/zabbix/redis/redisinst_status.out file"
        exit
fi
