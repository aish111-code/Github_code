action=$2
maxtime=$1

if [ "$maxtime" == "" ] ; then
        echo -e "Usage: \n  longqueries.sh <maxtime> <action>\n\n  If action is blank, return a list.  If action is "kill", kill long queries."
        exit 0
fi

/opt/mysql/bin/mysql -uscript -p"temp123"  -B -e"show processlist"   | grep Query | grep -v 'mg4zbxserver01' | egrep -v SQL_NO_CACHE | grep "SELECT  DISTINCT  t.triggerid,t.state" | cut -f1,6,7,8,3 -s | sed 's/*/xx/g' > chkevil
/opt/mysql/bin/mysql -uscript -p"temp123"  -B -e"show processlist"   | grep Query | grep -v 'mg4zbxserver01' | egrep -v SQL_NO_CACHE | grep "SELECT   COUNT" | grep  t.triggerid | cut -f1,6,7,8,3 -s | sed 's/*/xx/g' >> chkevil
/opt/mysql/bin/mysql -uscript -p"temp123"  -B -e"show processlist"   | grep Query | grep -v 'mg4zbxserver01' | egrep -v SQL_NO_CACHE | grep "h.clock" | cut -f1,6,7,8,3 -s | sed 's/*/xx/g' >> chkevil

chkevil=`cat chkevil`
#rm chkevil

killcount=0

while read chk
do
   thisid=`echo "$chk" | awk 'BEGIN {FS="\t"};{print $1}'`
   thisrt=`echo "$chk" | awk 'BEGIN {FS="\t"};{print $3}'`
#   thisstat=`echo $chk | awk '{print $3}'`
#   thisq=`echo $chk | awk '{print $4}'`
   thisstat=`echo "$chk" | awk 'BEGIN {FS="\t"};{print $4}'`
   thisq=`echo "$chk" | awk 'BEGIN {FS="\t"};{print $5}'`
   thish1=`echo "$chk" | awk 'BEGIN {FS="\t"};{print $2}'`
   thishost=`echo "$thish1" | cut -f1 -d"."`

#   echo "[ $thisid | $thisrt ]"
   if [ "$thisrt" -gt "$maxtime" ]
   then
        echo "$thisid | $thisrt | $thishost | $thisstat | $thisq "
           if [ "$action" == "kill" ]
           then
                echo "Killing: $thisid "
                logline=`echo "$thisid ($thisrt secs): $thisq"`
                /opt/mysql/bin/mysql -uscript -p"temp123"   -e"kill $thisid;"
                fulllog=`echo "$fulllog\n$logline"`
           fi
   fi
done < chkevil

if  [ "$action" == "kill" ]
then
        echo "--------------------------------------------------"  >>/var/log/evilqueries.log
        date  >>/var/log/evilqueries.log

        echo -e "$fulllog" >>/var/log/evilqueries.log
fi


exit



for chk in $chkevil
do
        echo "[ $chk ]"
        thisid=`echo $chk | cut -f1 -d" "`
        thisrt=`echo $chk | cut -f2`
#       echo "$thisid | $thisrt"
done

exit




/opt/mysql/bin/mysql -uscript -p"temp123" -B -e"show processlist"   | grep Sleep | cut -f1 -s > /tmp/plist.tmp


procs=`cat /tmp/plist.tmp`
#/bin/rm /tmp/plist.tmp

for i in $procs; do
        echo "$thishost: $i"
        /opt/mysql/bin/mysql -uscript -p"temp123"  -e"kill $i;"
done
