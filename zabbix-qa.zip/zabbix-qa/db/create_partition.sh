#!/bin/sh
rm -f /tmp/kill_all.txt
/opt/mysql/bin/mysql -uzabbixproddb -p'' -e "select concat('KILL ',id,';') from information_schema.processlist where db='zabbix' and host like 'mg4%' into outfile '/tmp/kill_all.txt'"
/opt/mysql/bin/mysql -uzabbixproddb -p'' -e "source /tmp/kill_all.txt"
/opt/mysql/bin/mysql -uzabbixproddb -p'' -e "CALL zabbix.drop_partitions('zabbix')"
/opt/mysql/bin/mysql -uzabbixproddb -p'' -e "CALL zabbix.create_next_partitions('zabbix')"
