import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python template_remove.py --user user --password pwd --dc "DC01" --template "template" --hostlist "hostname1,hostname2"
#a tempfile created by jenkins when dc:host input is given and it is used by the python script .
#add details in text file template_add in the below format 
#<DC<no>>:<hostname>
#Eg:
#DC01:ss03zbxprxy0002.dc003.sf.priv
def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"",["user=","password=","dc=","hostlist=","drtestticket=","drtestedby=","drtestdat="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    dc =opts['--dc']
    template = f"T_PAYROLL-{dc}-DRTEST"
    drtestedby = opts['--drtestedby']
    drtestdat = opts['--drtestdat']
    drtestticket = opts['--drtestticket']
    hostList = opts['--hostlist'].split(',')
    creds = [opts['--user'],opts['--password']]

    return creds,dc,template,hostList,drtestedby,drtestdat,drtestticket

def get_template_data(token,zabbix_url,template):
    # Get trigger details
    print("template name")
    print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output


def get_host_data(token,zabbix_url,host):

    host_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "host.get",
                            "params": {
                                "filter":{
                                "host": [host]
                            }},
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=host_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def remove_template(zabbix_url, token,templateid,hostid):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"host.update",
        "params":{
        "hostid": hostid,
        "templates_clear": [{"templateid": templateid}]  
        }, 
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output
def add_tag_and_status(zabbix_url, token, hostid, drtestedby, drtestdat, drtestticket):
    # Fetch existing tags
    host_details_payload = json.dumps({
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "output": ["hostid", "tags"],
            "selectTags": "extend",
            "hostids": hostid
        },
        "auth": token,
        "id": 1
    })
    host_details_response = requests.post(url=zabbix_url, data=host_details_payload, verify=False, headers={"Content-Type": "application/json"})
    existing_tags = host_details_response.json().get('result', [{}])[0].get('tags', [])
    print("Existing Tags response: ", host_details_response.json())
    # Update or add new tags
    tag_map = {tag['tag']: tag for tag in existing_tags}  # Create a map of existing tags by name
    print("Tag Map Before Update: ", tag_map)
    tag_map['drtestedby'] = {"tag": "drtestedby", "value": drtestedby}  # Update or add the tag
    tag_map['drtestdat'] = {"tag": "drtestdat", "value": drtestdat}    # Update or add the tag
    tag_map['drtestticket'] = {"tag": "drtestticket", "value": drtestticket}  # Update or add the tag

    # Combine updated tags
    combined_tags = list(tag_map.values())
    print("Combined Tags: ", combined_tags)

    # Update host with combined tags
    createPayload = json.dumps({
        "jsonrpc": "2.0",
        "method": "host.update",
        "params": {
            "hostid": hostid,
            "status": 0,
            "tags": combined_tags
        },
        "auth": token,
        "id": 1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output
###### Main Script #####

creds,dc,template,hostList,drtestedby,drtestdat,drtestticket = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print('###############################')
print(dc)
zabbix_url = config[dc]['env-url']
token = common.authenticate(zabbix_url)
templateDetails=get_template_data(token,zabbix_url,template)
#get template id 
templateid=templateDetails['templateid']
print(templateid)

for host in hostList:
    hostDetails=get_host_data(token,zabbix_url,host)
    hostid=hostDetails['hostid']
    print(hostid)
    try :
        output = remove_template(zabbix_url, token,templateid,hostid)
        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        else :
            print(output.json())
            print("template remove is success for "+host)
    except :
        print("template remove failed for "+host)
    print('\n')
    try:
        response = add_tag_and_status(zabbix_url,token,hostid,drtestedby,drtestdat,drtestticket)
        if 'error' in  response.json().keys():
            error = response.json()['error']['data']
            print(error)
        else :
            print(response.json())
            print("Tagging is success for "+host)
    except :
        print("Tagging is failed for "+host)
    print('\n')