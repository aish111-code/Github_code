
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
##this script is called after enable_host_validation.py it takes hostlist from successnodes.txt file.
# python remove_permanent_maintenance.py --user user --password pwd --dc "DC01"  --enabledby "Name" --enabledat "12Dec2023-2210" --enableticket "123"

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:d:mby:mat",["user=","password=","dc=","hostlist=","drtestedby=","drtestdat=","drtestticket="])
    opts=dict(opts)

    creds = [opts['--user'],opts['--password']]
    dc =opts['--dc']
    drtestedby = opts['--drtestedby']
    drtestdat = opts['--drtestdat']
    drtestticket = opts['--drtestticket']
    hostList = opts['--hostlist'].split(',')
    return  creds,dc,hostList,drtestedby,drtestdat,drtestticket


def get_hostgroup_data(token,zabbix_url,hostgroup):
    # Get trigger details

    hostgroup_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "hostgroup.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "name":[hostgroup]
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })


    output = requests.post(url=zabbix_url, data=hostgroup_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output


def get_host_data(token,zabbix_url,host):

    host_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "host.get",
                            "params": {
                                "filter":{
                                "host": [host]
                            }},
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=host_finder, verify=False, headers={"Content-Type": "application/json"})   
    print(output)
    print(output.text)
    output = output.json()['result'][0]
    print(output)
    return output

def remove_hostgroup(zabbix_url, token,groupid,hostid):

    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"hostgroup.massremove",
        "params":{
        "hostids": [hostid],
        "groupids": [groupid]
        }, 
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print(output)
    return output

def add_tag_and_status(zabbix_url, token, hostid, drtestedby, drtestdat, drtestticket):
    # Fetch existing tags
    host_details_payload = json.dumps({
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "output": ["hostid", "tags"],
            "selectTags": "extend",
            "hostids": hostid
        },
        "auth": token,
        "id": 1
    })
    host_details_response = requests.post(url=zabbix_url, data=host_details_payload, verify=False, headers={"Content-Type": "application/json"})
    existing_tags = host_details_response.json().get('result', [{}])[0].get('tags', [])
    print("Existing Tags response: ", host_details_response.json())
    # Update or add new tags
    cleaned_tags = [{"tag": tag["tag"], "value": tag["value"]} for tag in existing_tags]
    tag_map = {tag['tag']: tag for tag in cleaned_tags}  # Create a map of existing tags by name
    print("Tag Map Before Update: ", tag_map)
    tag_map['drtestedby'] = {"tag": "drtestedby", "value": drtestedby}  # Update or add the tag
    tag_map['drtestdat'] = {"tag": "drtestdat", "value": drtestdat}    # Update or add the tag
    tag_map['drtestticket'] = {"tag": "drtestticket", "value": drtestticket}  # Update or add the tag

    # Combine updated tags
    combined_tags = list(tag_map.values())
    print("Combined Tags: ", combined_tags)


    # Update host with combined tags
    createPayload = json.dumps({
        "jsonrpc": "2.0",
        "method": "host.update",
        "params": {
            "hostid": hostid,
            "status": 0,
            "tags": combined_tags
        },
        "auth": token,
        "id": 1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output

def read_hostlist():
    with open("successnodes.txt", "r") as file:
      lines = file.readlines()
    lines = [line.strip() for line in lines]
    return lines


###### Main Script #####

creds,dc,hostList,drtestedby,drtestdat,drtestticket = get_input()
user = creds[0]
password = creds[1]
#hostList = read_hostlist()
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print('###############################')
print(dc)
zabbix_url = config[dc]['env-url']
print("zabbix url")
print(zabbix_url)
token = common.authenticate(zabbix_url)
hostgroup = 'All-NotLive-Hosts-Maintenance'
hostgroupDetails=get_hostgroup_data(token,zabbix_url,hostgroup)
groupid=hostgroupDetails['groupid']
print("Below nodes are getting removed from maintenance ")
print(hostList)
for host in hostList:
    hostDetails=get_host_data(token,zabbix_url,host)
    hostid=hostDetails['hostid']
    print(groupid)
    print(hostid)
    try :
        output = remove_hostgroup(zabbix_url, token,groupid,hostid)
        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        else :
            print(output.json())
            print(host+":Enable monitoring   permanent_mainteanance => Live - Success")
    except :
        print(host+":Enable monitoring    permanent_mainteanance => Live - Failed")
    print('\n')
    try:
        response = add_tag_and_status(zabbix_url,token,hostid,drtestedby,drtestdat,drtestticket)
        if 'error' in  response.json().keys():
            error = response.json()['error']['data']
            print(error)
        else :
            print(response.json())
            print("Tagging is success for "+host)
    except :
        print("Tagging is failed for "+host)
    print('\n')
