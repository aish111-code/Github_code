import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml

import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python item_update.py --ref_dc DC70 --dcs DC23,DC01 --user user --password pwd --item "item" --template "template"
# ref_dc : Reference dc on which the item is already created
# dcs : dcs on which the item has to be added


def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"r:d:u:p:i:t:",["ref_dc=","dcs=","user=","password=","item=","template="])
    # script --dc DC --u user -p password -item itemname -template template
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    dc =opts['--ref_dc']
    template = opts['--template']
    item = opts['--item']
    dcList = opts['--dcs']

    inputData = {}
    [inputData['dc'],inputData['template'],inputData['itemName']] = [dc,template,item]
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')

    return inputData, creds, dcList

def get_item_data(token,zabbix_url,inputData):
    # Get item details
    template = inputData['template']
    itemName = inputData['itemName']
    item_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "item.get",
                            "params": {
                                "output":"extend",
                                "host": template,
                                "search":{
                                    "name":itemName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=item_finder, verify=False, headers={"Content-Type": "application/json"})   
    output = output.json()['result'][0]
    return output

def update_item(zabix_url, token, itemDetails, inputData):

    #get itemid. Adding a try catch block to cover cases where the item is not present. Add code to create the item if not present
    try :
        out = get_item_data(token,zabbix_url,inputData)
        itemid = out['itemid']
    except :
        print("The item is not present in the given template")
        return {'error':'Item is not present in the template'}

    ### Update item ###
    itemDetails['itemid'] = itemid
    # itemDetails['key_'] = 'system.cpu.util[,idle,avg5]'
    updatePayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"item.update",
        "params":itemDetails,
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=updatePayload, verify=False, headers={"Content-Type": "application/json"})
    return output

###### Main Script #####
inputData,creds ,dcList = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

zabbix_url = config[inputData['dc']]['env-url']
print(zabbix_url)

try :
    token = common.authenticate(zabbix_url)
except :
    print("Login failed in "+inputData['dc'])
    exit()

if token=="Invalid credentials":
    print("Invalid credentials for "+ inputData['dc'])
    exit()
    
try :    
    itemDetails = get_item_data(token,zabbix_url,inputData)

except :
    print("Item details fetch failed in "+inputData['dc'])
    exit()

# Remove unwanted keys
toDelete = ['itemid','interfaceid','templateid','valuemapid','master_itemid','description','flags','history','inventory_link','lastclock','discover','error',
'lastns','lastvalue','prevvalue','snmp_oid','state','hostid']

for val in toDelete :
    del itemDetails[val]

template = inputData['template']
print(dcList)
for dc in dcList :
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    # if dc==inputData['dc'] :
    #     continue
    token = common.authenticate(zabbix_url)
    try :
        output = update_item(zabbix_url, token, itemDetails,inputData)

        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        
        else :
            print(output.json())
    except :
        print("Item updation failed for "+dc)
    print('\n')