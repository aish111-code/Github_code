import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml

import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python item_delete.py --dcs DC01 --user user --password pwd --item "itemname" --template "template" --discovery "discoveryname"


def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"d:u:p:i:t:a",["dcs=","user=","password=","item=","template=","discovery="])
    # script --dc DC --u user -p password -item itemname -template template
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    template = opts['--template']
    item = opts['--item']
    discovery_name = opts['--discovery']
    dcList = opts['--dcs']

    inputData = {}
    [inputData['template'],inputData['itemName'],inputData['discoveryName']] = [template,item,discovery_name]
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')

    return inputData, creds, dcList

def get_item_prototype_data(token,zabbix_url,inputData,):
    # Get template id details
    template = inputData['template']
    itemName = inputData['itemName']
    discoveryName = inputData['discoveryName']
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})
    hostid = output.json()['result'][0]['templateid']
    print(hostid)

    # Get discovery rule id 
    discovery_finder = json.dumps({"jsonrpc": "2.0",
                            "method": "discoveryrule.get",
                            "params": {
                                "output":"extend",
                                "hostids":hostid,
                                "filter":{
                                    "name":discoveryName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=discovery_finder, verify=False, headers={"Content-Type": "application/json"})
    discoveryid = output.json()['result'][0]['itemid']   

    # Get item prototype details

    item_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "itemprototype.get",
                            "params": {
                                "output":"extend",
                                "hostids": hostid,
                                "discoveryids":discoveryid,
                                "search":{
                                    "name":itemName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })

    output = requests.post(url=zabbix_url, data=item_finder, verify=False, headers={"Content-Type": "application/json"})
    output = output.json()['result'][0]
    try :
        output = output.json()['result'][0]
    except : 
        output = "Item Prototype not found"
    return output

def delete_item_prototype(zabbix_url, token, itemid):

    deletePayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"itemprototype.delete",
        "params":[itemid],
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=deletePayload, verify=False, headers={"Content-Type": "application/json"})
    return output

###### Main Script #####
inputData,creds ,dcList = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)

with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print(dcList)


for dc in dcList :
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']

    try :
        token = common.authenticate(zabbix_url)
    except :
        print("Login failed in "+dc)
        continue

    if token=="Invalid credentials":
        print("Invalid credentials for "+ dc)
        continue

    itemDetails = get_item_prototype_data(token,zabbix_url,inputData)
    #if multple trigger id present exit.
    if itemDetails== "Item not found" :
        print("Item/Template not found in "+dc)
    else:
        itemid=itemDetails['itemid']
        print(itemid)

        try :
            output = delete_item_prototype(zabbix_url, token, itemid)

            if 'error' in  output.json().keys():
                error = output.json()['error']['data']
                print(error)
            
            else :
                print(output.json())
        except :
            print("Item deletion failed for "+dc)
        print('\n')
