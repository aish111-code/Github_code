
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
# python hostgroup_add.py --user user --password pwd --dc "DC01" --hostlist "hostname1,hostname2"

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:d:hl",["user=","password=","dc=","hostlist=","maintainedticket=","maintainedby=","maintaineddat="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()

    inputData = {}
    creds = [opts['--user'],opts['--password']]
    dc =opts['--dc']
    hostList = opts['--hostlist'].split(',')
    hostgroup="All-NotLive-Hosts-Maintenance"
    maintainedticket = opts['--maintainedticket']
    maintainedby = opts['--maintainedby']
    maintaineddat = opts['--maintaineddat']
    return  creds,dc,hostgroup,hostList,maintainedticket,maintainedby,maintaineddat


def get_hostgroup_data(token,zabbix_url,hostgroup):
    # Get trigger details
    print("template name")
    print(hostgroup)
    hostgroup_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "hostgroup.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "name":[hostgroup]
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })


    output = requests.post(url=zabbix_url, data=hostgroup_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    print(output)
    return output


def get_host_data(token,zabbix_url,host):

    host_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "host.get",
                            "params": {
                                "filter":{
                                "host": [host]
                            }},
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=host_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def add_hostgroup(zabbix_url, token,groupid,hostid):



    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"hostgroup.massadd",
        "params":{
        "hosts": [{"hostid": hostid}],
        "groups": [{"groupid": groupid}]
        }, 
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print (output)
    return output

def add_tag_and_status(zabbix_url,token,hostid,maintainedby,maintaineddat,maintainedticket):
    
    tags = [{"tag":"maintenanceby", "value":maintainedby}, {"tag":"maintenanceat", "value":maintaineddat}, {"tag":"maintenanceticket", "value":maintainedticket}]

    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"host.update",
        "params":{
        "hostid": hostid,
        "status": 0,
        "tags": tags
        },
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print (output)
    return output

###### Main Script #####

creds,dc,hostgroup,hostList,maintainedticket,maintainedby,maintaineddat = get_input()
user = creds[0]
password = creds[1]

common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print('###############################')
print(dc)
zabbix_url = config[dc]['env-url']
token = common.authenticate(zabbix_url)
hostgroupDetails=get_hostgroup_data(token,zabbix_url,hostgroup)
groupid=hostgroupDetails['groupid']
for host in hostList:
    hostDetails=get_host_data(token,zabbix_url,host)
    hostid=hostDetails['hostid']
    print(groupid)
    print(hostid)
    try :
        output = add_hostgroup(zabbix_url, token,groupid,hostid)
        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        else :
            print(output.json())
            print("host group addition is success for "+host)
    except :
        print("Host group addition failed for "+host)
    print('\n')
    try:
        response = add_tag_and_status(zabbix_url,token,hostid,maintainedby,maintaineddat,maintainedticket)
        if 'error' in  response.json().keys():
            error = response.json()['error']['data']
            print(error)
        else :
            print(response.json())
            print("Tagging is success for "+host)
    except :
        print("Tagging is failed for "+host)
    print('\n')
