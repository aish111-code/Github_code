
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
# python host_disable.py --user user --password pwd --dc "DC01" --hostlist "hostname1,hostname2" --tobedecommissioned "yes" --disableticket "123" --disabledby "Name" --disabledat "12Dec2023-2210"

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:d:hl:tbd:t:mby:mat",["user=","password=","dc=","hostlist=","tobedecommissioned=","disableticket=","disabledby=","disabledat="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()

    inputData = {}
    creds = [opts['--user'],opts['--password']]
    dc =opts['--dc']
    hostList = opts['--hostlist'].split(',')
    hostgroup="hosts-decommissioned"
    tbd = opts['--tobedecommissioned']
    disableticket = opts['--disableticket']
    disabledby = opts['--disabledby']
    disabledat = opts['--disabledat']

    return  creds,dc,hostgroup,hostList,tbd,disableticket,disabledby,disabledat


def get_hostgroup_data(token,zabbix_url,hostgroup):

    #print(hostgroup)
    hostgroup_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "hostgroup.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "name":[hostgroup]
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })


    output = requests.post(url=zabbix_url, data=hostgroup_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    # print(output)
    return output


def get_host_data(token,zabbix_url,host):
    try:
        host_finder =  json.dumps({"jsonrpc": "2.0",
                                "method": "host.get",
                                "params": {
                                    "filter":{
                                    "host": [host]
                                }},
                                "auth": token,
                                "id": 1
                                })
        output = requests.post(url=zabbix_url, data=host_finder, verify=False, headers={"Content-Type": "application/json"})   
        #print(output)
        #print(output.text)
        output = output.json()['result'][0]
        #print(output)
        return output
    except Exception as e:
        print(e)
        print(f"{host} not found in zabbix. Please check in zabbix ui and enter correct hostname.zabbix url inventory:https://operate360.cfapps.us10.hana.ondemand.com/index.html#/operations/linkmanager/services/tools/links")
        sys.exit(1)

def add_hostgroup(zabbix_url, token,groupid,hostid):

    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"hostgroup.massadd",
        "params":{
        "hosts": [{"hostid": hostid}],
        "groups": [{"groupid": groupid}]
        }, 
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print (output)
    return output

def add_tag_and_status(zabbix_url,token,hostid,tbd,disableticket,disabledby,disabledat):
    
    tags = [{"tag":"to-be-decommissioned", "value":tbd}, {"tag":"disableticket", "value":disableticket},  {"tag":"disabledby", "value":disabledby}, {"tag":"disabledat", "value":disabledat}]

    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"host.update",
        "params":{
        "hostid": hostid,
        'status': 1,
        "tags": tags
        },
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print (output)
    return output


###### Main Script #####

creds,dc,hostgroup,hostList,tbd,disableticket,disabledby,disabledat = get_input()
user = creds[0]
password = creds[1]

common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print('###############################')
print(dc)
zabbix_url = config[dc]['env-url']
print(zabbix_url)
print(user)
print(password)
try :
    token = common.authenticate(zabbix_url)
except :
    print("Login failed in "+zabbix_url)
    print("---- script operation failed-----")
    print("###############################")
    exit()

if token=="Invalid credentials":
    print("Invalid credentials for "+ zabbix_url)
    exit()

if tbd.lower()=='yes':
    hostgroupDetails=get_hostgroup_data(token,zabbix_url,hostgroup)
    groupid=hostgroupDetails['groupid']
    for host in hostList:
        hostDetails=get_host_data(token,zabbix_url,host)
        hostid=hostDetails['hostid']
        print(groupid)
        print(hostid)
        try :
            output = add_hostgroup(zabbix_url, token,groupid,hostid)
            if 'error' in  output.json().keys():
                error = output.json()['error']['data']
                print(error)
            else :
                print(output.json())
                print("host group addition is success for "+host)
        except :
            print("Host group addition failed for "+host)
            
        try:
            response = add_tag_and_status(zabbix_url,token,hostid,tbd,disableticket,disabledby,disabledat)
            if 'error' in  response.json().keys():
                error = response.json()['error']['data']
                print(error)
            else :
                print(response.json())
                print("Tagging is success and host disabled for "+host)
        except :
            print("Tagging and status update is failed for "+host)
        print('\n')
elif tbd.lower()=='no':
    for host in hostList:
        hostDetails=get_host_data(token,zabbix_url,host)
        hostid=hostDetails['hostid']
        print(hostid)            
        try:
            response = add_tag_and_status(zabbix_url,token,hostid,tbd,disableticket,disabledby,disabledat)
            if 'error' in  response.json().keys():
                error = response.json()['error']['data']
                print(error)
            else :
                print(response.json())
                print("Tagging is success and host disabled for "+host)
        except :
            print("Tagging and status update is failed for "+host)
        print('\n')



else:
    print("Nothing to be decommissioned")
