#Author : Jibin Sunny
#Date : 1/06/2023
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python trigger_update.py --ref_dc DC70 --dcs DC23,DC01 --user user --password pwd --old_trigger "triggername" --new_trigger "triggername" --template "template"
# ref_dc : Reference dc on which the trigger is already created
# dcs : dcs on which the trigger has to be added
#old_trigger : name of trigger to be changed
#new_trigger : if trigger name is changed give new trigger name .else keep old_trgger name and  new_rigger name same 

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"r:d:u:p:ot:nt:t",["ref_dc=","dcs=","user=","password=","old_trigger=","new_trigger=","template="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    dc =opts['--ref_dc']
    template = opts['--template']
    old_trigger = opts['--old_trigger']
    new_trigger = opts['--new_trigger']
    dcList = opts['--dcs']

    inputData = {}
    [inputData['dc'],inputData['template'],inputData['oldTriggerName'],inputData['newTriggerName']] = [dc,template,old_trigger,new_trigger]
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')

    return inputData, creds, dcList

def get_trigger_data(token,zabbix_url,inputData):
    # Get trigger details
    template = inputData['template']
    triggerName = inputData['triggerName']
    print(triggerName)
    trigger_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "trigger.get",
                            "params": {
                                "output":"extend",
                                "host": template,
                                "search":{
                                    "description":triggerName
                                },
                                "expandExpression": "true"
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=trigger_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    print(output.text)
    output = output.json()['result']
    #print(output)
    return output

def update_trigger(zabbix_url, token, triggerDetails):



    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"trigger.update",
        "params":triggerDetails,
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output


###### Main Script #####

inputData,creds ,dcList = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

zabbix_url = config[inputData['dc']]['env-url']
print(zabbix_url)
# try :
#     token = common.authenticate(zabbix_url)
#     print("token details")
#     print(token)
# except :
#     print("Login failed in "+inputData['dc'])
#     exit()
token = common.authenticate(zabbix_url)
print("token details")
print(token)

inputData['triggerName']=inputData['newTriggerName']
try :    
    triggerDetails = get_trigger_data(token,zabbix_url,inputData)
    print(triggerDetails)
except :
    print("triggerDetails fetch failed in "+inputData['dc'])
    exit()
size=len(triggerDetails)
if size > 1:
    print("duplicate trigger name present .Trigger copy failed from "+inputData['dc'])
    exit()

print("trigger details before delete")
print(triggerDetails)
triggerDetails=triggerDetails[0]
# Remove unwanted keys
toDelete = ['triggerid','value','lastchange','error','templateid','state','flags','type']

for val in toDelete :
    del triggerDetails[val]

print("trigger details after delete")
print(triggerDetails)

template = inputData['template']
print(dcList)
for dc in dcList :
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    if dc==inputData['dc'] :
        continue
    try :
        token = common.authenticate(zabbix_url)
        print("token details")
        print(token)
    except :
        print("Login failed in "+dc)
        continue

    inputData['triggerName']=inputData['oldTriggerName']
    try :   
        targerTriggerDetails = get_trigger_data(token,zabbix_url,inputData)
        print(targerTriggerDetails)
    except :
        print("targetTriggerDetails fetch failed in "+dc)
        exit()
    size=len(targerTriggerDetails)
    if size > 1:
        print("duplicate trigger name present in "+dc)
        exit()
    
    triggerid=targerTriggerDetails[0]['triggerid']
    print("printing trigger id")
    print(triggerid)
    triggerDetails['triggerid']=triggerid
    try :
        output = update_trigger(zabbix_url, token, triggerDetails)

        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        
        else :
            print(output.json())
    except :
        print("Trigger creation failed for "+dc)
    print('\n')
    try :
        output = update_trigger(zabbix_url, token, triggerDetails)

        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        
        else :
            print(output.json())
            print("Trigger:"+inputData['newTriggerName']+" updation success in "+dc)
    except :
        print("Trigger:"+inputData['newTriggerName']+" updation failed in "+dc)
    print('\n')


