import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python template_remove.py --user user --password pwd --dc "DC01" --template "template" --hostlist "hostname1,hostname2"
#a tempfile created by jenkins when dc:host input is given and it is used by the python script .
#add details in text file template_add in the below format 
#<DC<no>>:<hostname>
#Eg:
#DC01:ss03zbxprxy0002.dc003.sf.priv
def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:d:t:hl",["user=","password=","dc=","template=","hostlist="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    template = opts['--template']
    dc =opts['--dc']
    hostList = opts['--hostlist'].split(',')
    creds = [opts['--user'],opts['--password']]

    return creds,dc,template,hostList

def get_template_data(token,zabbix_url,template):
    # Get trigger details
    print("template name")
    print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output


def get_host_data(token,zabbix_url,host):

    host_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "host.get",
                            "params": {
                                "filter":{
                                "host": [host]
                            }},
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=host_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def remove_template(zabbix_url, token,templateid,hostid):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"host.update",
        "params":{
        "hostid": hostid,
        "templates_clear": [{"templateid": templateid}]  
        }, 
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output

###### Main Script #####

creds,dc,template,hostList = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print('###############################')
print(dc)
zabbix_url = config[dc]['env-url']
token = common.authenticate(zabbix_url)
templateDetails=get_template_data(token,zabbix_url,template)
#get template id 
templateid=templateDetails['templateid']
print(templateid)

for host in hostList:
    hostDetails=get_host_data(token,zabbix_url,host)
    hostid=hostDetails['hostid']
    print(hostid)
    try :
        output = remove_template(zabbix_url, token,templateid,hostid)
        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        else :
            print(output.json())
            print("template remove is success for "+host)
    except :
        print("template remove failed for "+host)
    print('\n')