dir=/var/lib/zabbix
dns=$1
sev=$4
if [ ! -d $dir/mssql_job_temp_files ];then
 mkdir $dir/mssql_job_temp_files
 chown zabbix:zabbix $dir/mssql_job_temp_files
fi

echo "select j.name as JOBNAME from msdb.dbo.sysjobs as j INNER JOIN msdb.dbo.sysjobschedules as js on j.job_id = js.job_id INNER JOIN msdb.dbo.sysschedules as sch on js.schedule_id = sch.schedule_id where j.enabled =1 and sch.enabled = 1;
quit">$dir/isql.txt

isql $1 $2 "$3" -b < $dir/isql.txt >$dir/mssql_job_temp_files/job_${dns}_${sev}.txt
IFS=$'\n'
sev=$4
echo "{
    \"data\": ["

if [ "$sev" == "IMMEDIATE" ];then
        job_names=`cat $dir/mssql_job_temp_files/job_${dns}_${sev}.txt|grep -iEv "SQLRowCount|rows fetched|JOBNAME"|awk -F "|" '{print $2}'|sed '/^$/d'|sed 's/^ //g'|awk '{$1=$1;print}'|grep -i "DatabaseIntegrityCheck"`
elif [ "$sev" == "HIGH" ];then
        job_names=`cat $dir/mssql_job_temp_files/job_${dns}_${sev}.txt|grep -iEv "SQLRowCount|rows fetched|JOBNAME"|awk -F "|" '{print $2}'|sed '/^$/d'|sed 's/^ //g'|awk '{$1=$1;print}'|grep -i "DD Boost Backup"`
else
        job_names=`cat $dir/mssql_job_temp_files/job_${dns}_${sev}.txt|grep -iEv "SQLRowCount|rows fetched|JOBNAME"|awk -F "|" '{print $2}'|sed '/^$/d'|sed 's/^ //g'|awk '{$1=$1;print}'|grep -Eiv "DD Boost Backup|DatabaseIntegrityCheck"`
fi

count=`echo "$job_names"|wc -l`


for i in `echo "$job_names"`
do
        if [ $count -ne 1 ];then
                if [ `echo "$i"|grep -i "DatabaseIntegrityCheck"|wc -l` -eq 1  ];then
                        echo "{\"{#JOBNAME_IMMEDIATE}\": \"${i}\"},"
                elif [ `echo "$i"|grep -i "DD Boost Backup"|wc -l` -eq 1 ];then
                        echo "{\"{#JOBNAME_HIGH}\": \"${i}\"},"
                else
                        echo "{\"{#JOBNAME}\": \"${i}\"},"
                fi
        else
                if [ `echo "$i"|grep -i "DatabaseIntegrityCheck"|wc -l` -eq 1 ];then
                        echo "{\"{#JOBNAME_IMMEDIATE}\": \"${i}\"}"
                elif [ `echo "$i"|grep -i "DD Boost Backup"|wc -l` -eq 1 ];then
                        echo "{\"{#JOBNAME_HIGH}\": \"${i}\"}"
                else
                        echo "{\"{#JOBNAME}\": \"${i}\"}"
                fi

        fi
        ((count=count -1))
done
echo "
    ]
}"

rm -f $dir/mssql_job_temp_files/job_${dns}_${sev}.txt
