#!/usr/bin/sh
###############################################################################################################################################
# SAP Success Factors
#
# Description : Wrapper for the SPC_Notification.pl script that creates incidents in SPC
#
# Changes :
# Date Modified              Developer           CID               Description of the changes made                                                                #
# -------------              ---------           ---               -------------------------------                                                                #
#  10/09/2012               Ketan Vittal       C5165361                   Initial Code
#  12/27/2012               Sandeep M.R        C5182416                   Implemented enhancements for autoclosure
#  02/10/2013               Sandeep M.R        C5182416                   Changed log file format
#  02/27/2013               Sandeep M.R        C5182416                   Implemented BLD Web service enhancement
#  04/17/2013               Sandeep M.R        C5182416                   Fixed bug wrt 'Product' calculation
#  07/11/2014               Sandeep M.R        C5182416                   5 digit check id format for mapping file
#  10/07/2014               Sandeep M.R        C5182416                   Removed hard coded values,uploaded to repo
#  03-Mar-2015              Surekha P          C5188034                   Added trigger name and check_group check_id 
#  07-Oct-2016              Sandeep M.R        C5182416                   Added rules for Hana CELL FMC Alerts
######################################################################################################################################

################################################################# Initializations ####################################################################

ZabbixParam1=$1
ZabbixParam2=$2
ZabbixParam3=$3

LogDir="/var/log/zabbix/SPC"
ExecutePath="/usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC"

toMail_list="sandeep.madhu.renuka@sap.com";


rdate=`date +%Y%m%d_%H:%M:%S`

Event=`echo ${ZabbixParam2} | awk -F"+~" '{ print $2 }'`
HostName=`echo ${ZabbixParam3} | awk -F"@@" '{ print $7 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
Hostgroupname=`echo ${ZabbixParam3} | awk -F"@@" '{ print $9 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
Templatename=`echo ${ZabbixParam3} | awk -F"@@" '{ print $10 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
TriggerID=`echo ${ZabbixParam3} | awk -F"@@" '{ print $11 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
TriggerName=`echo ${ZabbixParam3} | awk -F"@@" '{ print $12 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`


EventDate=`echo ${ZabbixParam3} | awk -F"@@" '{ print $5 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
EventTime1=`echo ${ZabbixParam3} | awk -F"@@" '{ print $6 }' | awk -F":" '{ for (i=2; i<=NF; i++) print ":"$i }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
EventState=`echo ${ZabbixParam3} | awk -F"@@" '{ print $2 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
EventSeverity=`echo ${ZabbixParam3} | awk -F"@@" '{ print $3 }' | awk -F":" '{ print $2 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
EventItem1=`echo ${ZabbixParam3} | awk -F"@@" '{ print $8 }' | awk -F":" '{ for (i=2; i<=NF; i++) print $i":" }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
Product=`cat ${ExecutePath}/spcConf/Product_Host_Map.config | grep -w "${HostName}" | awk -F":" '{ print $1 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`

Item=`echo ${ZabbixParam3} | awk -F"@@" '{ print $8 }' | awk -F":~" '{ print $2 }' | awk -F")" '{ print $1 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`

Item2=`echo ${ZabbixParam3} | awk -F"@@" '{ print $12 }'| awk -F"+~" '{print $2}'`  # planet

ItemPass=`echo ${ZabbixParam3} | awk -F"@@" '{ print $8 }' | awk -F":~" '{ print $2 }' | awk -F"[" '{ print $1 }' | awk -F")" '{ print $1 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`

Item1=`echo ${Item} | sed 's/[^a-z|0-9|A-Z]//g' | sed 's/^[ \t]*//;s/[ \t]*$//'`
#Host_Env=`cat ${ExecutePath}/Product_Host_Map.config | grep "${HostName}:" | awk -F":" '{ print $3 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
Host_Env=`cat ${ExecutePath}/spcConf/Product_Host_Map.config | grep "${HostName}:" | awk -F":" '{ print $3 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
#Node_Value=`cat ${ExecutePath}/Product_Host_Map.config | grep "${HostName}:" | awk -F":" '{ print $4 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`
Node_Value=`cat ${ExecutePath}/spcConf/Product_Host_Map.config | grep "${HostName}:" | awk -F":" '{ print $4 }' | sed 's/^[ \t]*//;s/[ \t]*$//'`

EventItemDetail=`echo ${EventItem1} | awk -F"1." '{ print $1 }' | awk -F"2." '{ print $1 }' | awk -F"3." '{ print $1 }'`
export EventBase=`echo ${EventItem1}`
EventItem01=`echo ${EventBase} | sed 's/% /%\n\t/g'`

EventTime=$(echo ${EventTime1} | tr -d '\n')
EventItem=$(echo ${EventItem1} | tr -d '\n')

LogFile="/${LogDir}/${Product}_${HostName}_${Item1}_${TriggerID}.log${rdate}"
SPC_HTML_Response_log="/${LogDir}/SPC_HTML_Response_${Product}_${HostName}_${Item1}_${TriggerID}.log${rdate}"

SIM_HTML_Response_log="/${LogDir}/SIM_HTML_Response.log${rdate}"

echo "Starting time `date`" >> ${LogFile}

echo "ZabbixParam1 = "${ZabbixParam1}"" >> ${LogFile}
echo "ZabbixParam2 = "${ZabbixParam2}"" >> ${LogFile}
echo "ZabbixParam3 = "${ZabbixParam3}"" >> ${LogFile}

echo "Event = "${Event}"" >> ${LogFile}
echo "HostName = "${HostName}"" >> ${LogFile}
echo "EventDate = "${EventDate}"" >> ${LogFile}
echo "EventTime = "${EventTime}"" >> ${LogFile}
echo "EventState = "${EventState}"" >> ${LogFile}
echo "EventSeverity = "${EventSeverity}"" >> ${LogFile}
echo "EventItem = "${EventItem}"" >> ${LogFile}
echo "Product = "${Product}"" >> ${LogFile}
echo "Item = "${Item}"" >> ${LogFile}
echo "Host_Env = "${Host_Env}"" >> ${LogFile}
echo "Node_Value = "${Node_Value}"" >> ${LogFile}
echo "Hostgroup Name = "${Hostgroupname}"" >> ${LogFile}
echo "Template Name = "${Templatename}"" >> ${LogFile}
echo "Trigger ID = "${TriggerID}"" >> ${LogFile}
echo "Trigger Name = "${TriggerName}"" >> ${LogFile}
echo "Item2 = "${Item2}"" >> ${LogFile}

############## Check for federal ashburn servers #####################

case ${Hostgroupname} in

*pf8* )

                ash_fed_flag=0
                ;;

*sf8* )

                ash_fed_flag=0
                ;;

*pfBeltsville* )

		 ash_fed_flag=0
                ;;

*)

                ash_fed_flag=1
                ;;
esac

if [ $ash_fed_flag -eq 0 ]
then
echo "Federal server"  >> ${LogFile}
else
echo "Not federal server" >> ${LogFile}
fi

day=`date +%a`
echo "Today is $day" >> ${LogFile}



#################################################### Checking Product and Host status #################################################################

if [ -z ${Product} ]
then
        echo "Host ${HostName} not recognised. Make an entry of the host details in /${ExecutePath}/Product_Host_Map.config" >> ${LogFile}
         Product="BIZX"
         echo ${HostName} >> ${ExecutePath}/NEW_HOST_FOUND.txt
         #echo "Host ${HostName} not recognised" | mailx -s "SPC Alert - New Host" $toMail_list
fi

Deactive_State=`grep "${HostName}:" ${ExecutePath}/spcConf/Product_Host_Map.config | cut -c 1 | head -1`

if [ -z  ${Deactive_State} ]
then
 Deactive_State="A"
fi

if [ ${Deactive_State} == "#" ]
then
        echo "Alerting has been disabled for ${HostName}. To re-activate, please visit /${ExecutePath}/Product_Host_Map.config" >> ${LogFile}
        exit 1
fi

#cat ${ExecutePath}/spcConf/${Product}_CheckID_Mapping.config | sed 's/[^a-z|0-9|A-Z|~]//g' > /${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}
cat ${ExecutePath}/spcConf/${Product}_CheckID_Mapping.config  > /${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}


############################################ Extracting Check Group and Check ID ###############################################################

#Check_Group=`grep -w "${Item1}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $3 }'`
##Check_Group=`grep -w "${Item2}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $3 }'`  # planet
#Check_Group=`grep -w "${Item2}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $3 }'`  # planet
Check_Group=`grep "^~${Item2}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $3 }'`  # planet

#Check_ID=`grep -w "${Item1}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $4 }'`
##Check_ID=`grep -w "${Item2}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $4 }'`     # planet
#Check_ID=`grep -w "${Item2}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $4 }'`     # planet
Check_ID=`grep "^~${Item2}" "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}" | awk -F"~" '{ print $4 }'`     # planet

#Newly added on 28-Sept
case ${Hostgroupname} in

*SFAPI* )

               Check_Group=SFSF_SFAPI
               Check_ID=00001
               ;;

*SOAP*)
	
	       Check_Group=SFSF_SFAPI
               Check_ID=00001
               ;;

*)

               echo "Not an SFAPI Server" >> ${LogFile}
               ;;

esac

echo "Check ID is ${Check_ID}" >> ${LogFile}

echo "Check Group is ${Check_Group}" >> ${LogFile}

if [ -z ${Check_Group} ]
then


case ${Item2} in

HANA*Alert*SID*INSTANCE*Internal*statistics*server*problem* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

High*Load*for*Customer* )

                                      Check_Group="CMT_OPTIER"
                                      Check_ID="00300"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;






HANA*Alert*SID*INSTANCE*Disk*usage* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;


HANA*Alert*SID*INSTANCE*Host*CPU*Usage* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Notification*of*medium*and*high*priority*alerts* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*License*expiry* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Existence*of*data*backup* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Licensed*memory*usage* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;
HANA*Alert*SID*INSTANCE*Long*running*serializable*transactions* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Size*of*diagnosis*files* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;
HANA*Alert*SID*INSTANCE*Secure*store*file*system*consistency* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Percentage*of*transactions*blocked* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Granting*of*SAP*SUPPORT*role* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;
HANA*Alert*SID*INSTANCE*Total*memory*usage*of*row*store* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Enablement*of*automatic*log*backup* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Number*of*log*segments* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Discrepancy*between*host*server*times* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Database*disk*usage* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

HANA*Alert*SID*INSTANCE*Dbspace*usage* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00069"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;


HANA*Alert*SID*INSTANCE* )

				      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*HANA*Port*Check*Failed*on* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*Hana*Port*Check*Failed*on* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*HANA*DB*Hung* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*HANA*CPU*idle* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*HANA*CPU*Load* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;


*HANA*Alert*SID*INSTANCE* )

					 Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*hdb*Space*Low* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*hdb*Inodes* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*hana*Space*Low* )

                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*hana*Inodes* )


                                      Check_Group="SFSF_HDB"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;


*GoldenGateGroup* )

       					Check_Group="${Product}_DB"
                                      Check_ID="00099"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;
*ManagedConnectionPool* )

					 Check_Group="BIZX_APP"
                                      Check_ID="00040"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

				       ;;

*NetApp*Z8E* | *NetApp*Z05* | *NetApp*Z1Q* |  *NetApp*Z9F* | *NetApp*ZAZ* )
                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*ZLP* | *NetApp*ZPC* | *NetApp*ZPH* |  *NetApp*ZPS* | *NetApp*ZSB* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*ZT9* | *NetApp*ZZT* | *NetApp*Z8A* |  *NetApp*ZB3* | *NetApp*ZBS* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*ZC8* | *NetApp*ZYL* | *NetApp*ZAE* |  *NetApp*ZDB* | *NetApp*Z1X* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*Z26* | *NetApp*Z7X* | *NetApp*Z8M* |  *NetApp*Z9B* | *NetApp*Z9V* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*Z9W* | *NetApp*ZC4* | *NetApp*ZT8* |  *NetApp*ZB9* | *NetApp*Z9D* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*Z7O* | *NetApp*Z8H* | *NetApp*Z8N* |  *NetApp*Z8O* | *NetApp*Z9G* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*Z9U* | *NetApp*Z9Z* | *NetApp*ZAO* |  *NetApp*ZAQ* | *NetApp*ZBH* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*ZBO* | *NetApp*ZBQ* | *NetApp*ZBT* |  *NetApp*ZKG* | *NetApp*ZPK* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*ZV6* | *NetApp*ZAP* | *NetApp*ZBP* |  *NetApp*Z01* | *NetApp*Z0G* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*Z0L* | *NetApp*Z1C* | *NetApp*Z1H* |  *NetApp*Z1T* | *NetApp*ZA2* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*ZAS* | *NetApp*ZCS* | *NetApp*ZD9* |  *NetApp*ZDG* | *NetApp*ZE0* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*ZMC* | *NetApp*ZN0* | *NetApp*ZN1* |  *NetApp*ZN5* | *NetApp*ZNC* )


                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;

*NetApp*ZP8* | *NetApp*ZP9* | *NetApp*ZPR* |  *NetApp*ZPX* | *NetApp*ZW1* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*ZYJ* | *NetApp*ZYT* | *NetApp*ZZF* |  *NetApp*ZZI* | *NetApp*Z0I* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*Z15* | *NetApp*ZCV* | *NetApp*ZT5* |  *NetApp*ZZQ* | *NetApp*Z1U* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*Z20* | *NetApp*ZCU* | *NetApp*ZCW* |  *NetApp*ZD8* | *NetApp*ZDE* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*ZDK* | *NetApp*ZKM* | *NetApp*ZO7* |  *NetApp*ZO8* | *NetApp*ZZL* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;


*NetApp*ZAC* | *NetApp*ZDJ* | *NetApp*ZKP* |  *NetApp*ZD5* )

                                      Product="IBP"
                                      Check_Group="IBP_OS"
                                      Check_ID="00001"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}
                                      ;;



*NetApp* )

                                      Check_Group="SFSF_OS"
                                      Check_ID="00040"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;


*Update*time*difference*is*more*than*10*mins* )

                                      Check_Group="BIZX_APP"
                                      Check_ID="00038"
                                      echo "Check Group is ${Check_Group}" >> ${LogFile}
                                      echo "Check ID is ${Check_ID}" >> ${LogFile}

                                      ;;

*)
      echo "Add a Check Group/ID entry for Trigger ${Item2} on Host ${HostName} : Template ${Templatename} in ${ExecutePath}/${Product}_CheckID_Mapping.config" >> ${LogFile}

      #echo "Add a Check Group/ID entry for Trigger ${TriggerName} on Host ${HostName} : Template ${Templatename} in ${ExecutePath}/${Product}_CheckID_Mapping.config" | mailx -s "SPC - New Mapping found on ${HostName} ${Templatename}" -r "ZBX-SPC@sap.com" $toMail_list  
      
       #Check_Group="BIZX_OS"
       Check_Group="${Product}_OS"
       Check_ID="00099"
	;;
esac


fi



rm "/${LogDir}/${Product}_${HostName}_${Item1}_CheckID_Mapping.config${rdate}"

echo "Timestamp of script execution `date +%Y%m%d_%H:%M:%S:%N`" >> ${LogFile}




#################################################### Perl Script Call ##############################################################


echo "Calling /${ExecutePath}/SPC_SIM_Notification.pl " >> ${LogFile}




( /${ExecutePath}/SPC_SIM_Notification.pl "${EventSeverity} ${Check_Group}_${Check_ID} ${ItemPass}" "${ItemPass}" "${Event}" "${EventItem}" "${EventDate}${EventTime}" "${Product}" "${HostName}" "${Host_Env}" "${SPC_HTML_Response_log}" "${EventState}" "${Item1}" "${TriggerID}" "${EventSeverity}" "${EventItem01}" "${ash_fed_flag}" "${Hostgroupname}" "${Templatename}" "${LogDir}" "${ExecutePath}/spcConf" "${TriggerName}" "${Check_Group}" "${Check_ID}" >> ${LogFile} & )



echo "Timestamp of script completion `date`" >> ${LogFile}

RC=$?

if [ $RC -ne 0 ]
then
        echo "Error in Perl Script. Error Code is " $RC >> ${LogFile}
        exit 1
fi


echo "Ending time `date`" >> ${LogFile}

