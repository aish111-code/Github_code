#!/usr/bin/sh


zabbixinput=$2

hostname=`echo ${zabbixinput} | cut -d' ' -f1`
metadata=`echo ${zabbixinput} | cut -d' ' -f2`

echo "$hostname $metadata" > /var/log/zabbix/METADATA/${hostname}




