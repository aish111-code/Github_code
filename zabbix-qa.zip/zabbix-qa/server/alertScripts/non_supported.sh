#!/bin/bash

email='sreekanth.kp@sap.com, natalia.pyalling@sap.com, pradip.kumar.k@sap.com'
echo "$3"| mail -r NOTSUPPORTED@sap.com -s "$2" $email
