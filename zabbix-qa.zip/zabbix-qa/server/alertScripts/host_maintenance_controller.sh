#!/bin/bash


hostName=$2
monitoringValue=$3

status=`echo $monitoringValue | awk -F'=' '{print $2}'`

cmd="/usr/local/etc/zbxAdm/2.2/scripts/zabbixMaint.pl -monitoring $status -hostname $hostName"


echo $1, $2, $3  >> /usr/local/share/zabbix/alertScripts/maintenance.log
echo "Running $cmd" >> /usr/local/share/zabbix/alertScripts/maintenance.log
$cmd


