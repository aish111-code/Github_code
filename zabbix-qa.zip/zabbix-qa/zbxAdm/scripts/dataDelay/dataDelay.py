import argparse
import json
import requests
import sys
import warnings
import time
from datetime import datetime
import subprocess  # for email alert via mailx
import os

warnings.filterwarnings("ignore")


# ====== Common Tools (inlined here) ======
class common_tools:
    def __init__(self, user, password):
        self.user = user
        self.password = password

    def authenticate(self, zabbix_url):
        data = json.dumps({
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": self.user,
                "password": self.password
            },
            "id": 1
        })
        r = requests.post(zabbix_url, data=data, headers={'Content-Type': 'application/json'}, verify=False)
        r = r.json()
        if 'result' not in r:
            return "Invalid credentials"
        return r["result"]


# ====== Constants ======
ITEM_KEY_TO_CHECK = "system.cpu.load[,avg5]"
DELAY_THRESHOLD = 1800  # 30 minutes


def parse_arguments():
    parser = argparse.ArgumentParser(description="Zabbix item delay checker")
    parser.add_argument("--user", required=True, help="Zabbix username")
    parser.add_argument("--password", required=True, help="Zabbix password")
    parser.add_argument("--dc", required=True, help="Datacenter name (e.g., DC01, DC22)")
    parser.add_argument("--hosts-file", required=True, help="Path to file containing hostnames (one per line)")
    return parser.parse_args()


def normalize_dc(dc_input):
    dc_input = dc_input.strip().upper()
    if dc_input.startswith("DC") and dc_input[2:].isdigit():
        return f"DC{dc_input[2:].zfill(2)}"
    else:
        raise ValueError("Invalid DC format. Use e.g., DC01, dc22.")


def load_inventory(file_path):
    """Load plain text inventory file: DC=URL"""
    config = {}
    if not os.path.exists(file_path):
        print(f"[ERROR] Inventory file '{file_path}' not found.")
        sys.exit(1)

    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):  # skip blanks/comments
                continue
            if "=" in line:
                dc, url = line.split("=", 1)
                config[dc.strip().upper()] = {"env-url": url.strip()}
    return config


def get_hostid(token, zabbix_url, hostname):
    payload = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {"output": ["hostid"], "filter": {"host": [hostname]}},
        "auth": token,
        "id": 1,
    }
    response = requests.post(zabbix_url, json=payload, verify=False, headers={"Content-Type": "application/json"})
    result = response.json().get("result", [])
    return result[0]["hostid"] if result else None


def get_item_lastclock(token, zabbix_url, hostid, key_name):
    payload = {
        "jsonrpc": "2.0",
        "method": "item.get",
        "params": {"output": ["name", "key_", "lastclock"], "hostids": [hostid], "search": {"key_": key_name}},
        "auth": token,
        "id": 1,
    }
    response = requests.post(zabbix_url, json=payload, verify=False, headers={"Content-Type": "application/json"})
    result = response.json().get("result", [])

    for item in result:
        if item["key_"] == key_name:
            lastclock = item.get("lastclock", None)
            if lastclock is None or lastclock == 0:
                return None  # Indicates no data has been collected
            return int(lastclock)

    return None  # If item is not found at all


def send_email_alert(hostnames, recipients):
    subject = f"Data collection delay on {', '.join(hostnames)}"
    body = f"Data collection delay detected on the following nodes: {', '.join(hostnames)}."
    sender = "sapsfplatformmonitoring@sapsf.com"
    mail_cmd = f'echo "{body}" | mailx -r "{sender}" -s "{subject}" {recipients}'
    subprocess.run(mail_cmd, shell=True)


def main():
    args = parse_arguments()
    try:
        dc = normalize_dc(args.dc)
    except ValueError as e:
        print(f"[ERROR] {e}")
        sys.exit(1)

    # Load inventory from plain text file
    inventory_file = "zbxAdm/inventory.txt"
    config = load_inventory(inventory_file)

    if dc not in config:
        print(f"[ERROR] DC '{dc}' not found in inventory file.")
        sys.exit(1)

    zabbix_url = config[dc]["env-url"]
    common = common_tools(args.user, args.password)
    token = common.authenticate(zabbix_url)

    if token == "Invalid credentials":
        print("[ERROR] Authentication failed. Check username/password.")
        sys.exit(1)

    # Load hostnames from file
    if not os.path.exists(args.hosts_file):
        print(f"[ERROR] Hosts file '{args.hosts_file}' not found.")
        sys.exit(1)

    with open(args.hosts_file, "r") as f:
        hostnames = [line.strip() for line in f if line.strip()]

    delayed_nodes = []  # List to track delayed nodes
    for hostname in hostnames:
        print(f"\nChecking '{ITEM_KEY_TO_CHECK}' for host '{hostname}' in {dc}...")
        hostid = get_hostid(token, zabbix_url, hostname)
        if not hostid:
            print(f"[ERROR] Host '{hostname}' not found in {dc}")
            continue

        lastclock = get_item_lastclock(token, zabbix_url, hostid, ITEM_KEY_TO_CHECK)
        if lastclock is None or lastclock == 0:
            # If lastclock is None, it means no data was collected
            print(f"[ALERT] No data collection found for item '{ITEM_KEY_TO_CHECK}' on host '{hostname}'")
            delayed_nodes.append(hostname)  # Mark as delayed node
            continue

        delay = int(time.time()) - lastclock
        lastclock_dt = datetime.fromtimestamp(lastclock).strftime("%Y-%m-%d %H:%M:%S")
        if delay >= DELAY_THRESHOLD:
            print(f"[ALERT] Delay detected: {delay} seconds since last collection.")
            print(f"[INFO] Last data collection time: {lastclock_dt}")
            delayed_nodes.append(hostname)  # Add to delayed nodes list
        else:
            print(f"[OK] Last data collected {delay} seconds ago within threshold.")
            print(f"[INFO] Last data collection time: {lastclock_dt}")

    # Check if 2 or more nodes are delayed
    if len(delayed_nodes) >= 2:
        print(f"\n[INFO] {len(delayed_nodes)} nodes are delayed. Sending email alert...")
        recipients = "aishwarya.venkatesh@sap.com"
        send_email_alert(delayed_nodes, recipients)
    else:
        print(f"\n[INFO] Only {len(delayed_nodes)} nodes are delayed. No email sent.")


if __name__ == "__main__":
    main()
