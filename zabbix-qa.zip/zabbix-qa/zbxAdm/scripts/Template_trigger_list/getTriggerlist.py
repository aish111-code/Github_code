import json
import requests
import sys
import getopt
import pandas as pd
import yaml
import warnings
import os
warnings.filterwarnings("ignore")

sys.path.insert(0, './common')
from common_tools import common_tools

# Usage:
# python getTriggerlist.py --user user --password pwd --dcs DC01 

def get_input():
    argv = sys.argv[1:]
    opts, args = getopt.getopt(argv, "u:p:d:t:i", ["user=", "password=", "dcs=", "template="])
    opts = dict(opts)
    
    creds = [opts['--user'], opts['--password']]
    dcList = opts['--dcs'].split(',')
    template = opts.get('--template', None)
    return creds, dcList, template

def get_templates_with_hosts(token, zabbix_url):
    payload_templates = {
        "jsonrpc": "2.0",
        "method": "template.get",
        "params": {"output": ["templateid", "name"]},
        "auth": token,
        "id": 1
    }

    response_templates = requests.post(
        zabbix_url,
        headers={"Content-Type": "application/json"},
        data=json.dumps(payload_templates),
        verify=False,
        timeout=15
    )
    response_templates.raise_for_status()
    templates = response_templates.json().get("result", [])

    payload_hosts = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "output": ["hostid", "host"],
            "selectParentTemplates": ["templateid", "name"]
        },
        "auth": token,
        "id": 2
    }

    response_hosts = requests.post(
        zabbix_url,
        headers={"Content-Type": "application/json"},
        data=json.dumps(payload_hosts),
        verify=False,
        timeout=30
    )
    response_hosts.raise_for_status()
    hosts = response_hosts.json().get("result", [])

    template_ids_with_hosts = set()
    template_id_to_hostnames = {}
    for host in hosts:
        host_name = host.get("host")
        for tmpl in host.get("parentTemplates", []):
            tid = tmpl["templateid"]
            template_ids_with_hosts.add(tid)
            template_id_to_hostnames.setdefault(tid, []).append(host_name)

    templates_with_hosts = [t for t in templates if t["templateid"] in template_ids_with_hosts]
    print(f"[DEBUG] Found {len(templates_with_hosts)} templates with at least one host attached")
    return templates_with_hosts, template_id_to_hostnames

def get_trigger_list(token, zabbix_url, templateid):
    payload = {
        "jsonrpc": "2.0",
        "method": "trigger.get",
        "params": {
            "templateids": templateid,
            "output": ["triggerid", "description", "priority", "status"]
        },
        "auth": token,
        "id": 1
    }

    try:
        response = requests.post(
            url=zabbix_url,
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            verify=False,
            timeout=15
        )
        response.raise_for_status()
        output = response.json().get("result", [])

    except Exception as e:
        print(f"[ERROR] Failed to fetch triggers for template {templateid}: {e}")
        return []

    triggers = []
    

    for trig in output:
      description = trig.get("description", "").replace("{HOST.NAME}", "").replace("{ITEM.VALUE1}", "").strip()
      status_val = int(trig.get("status", 0))
      severity_val = int(trig.get("priority", 0))
      triggers.append({
        "triggerid": trig.get("triggerid", ""),
        "description": description,
        "severity": severity_val,
        "status": "Enabled" if status_val == 0 else "Disabled"
    })


    return triggers

def export_triggers_to_excel(token, zabbix_url, filename="zabbix_triggers.xlsx"):
    templates, template_id_to_hostnames = get_templates_with_hosts(token, zabbix_url)

    data = []
    for template in templates:
        templateid = template["templateid"]
        templatename = template["name"]
        hostnames = ", ".join(template_id_to_hostnames.get(templateid, []))
        triggerdetails = get_trigger_list(token, zabbix_url, templateid)

        for trig in triggerdetails:
            data.append({
                "Template Name": templatename,
                "Trigger ID": trig["triggerid"],
                "Trigger Description": trig["description"],
                "Severity": trig["severity"],
                "Status": trig["status"],
                "Host Names": hostnames
            })

    df = pd.DataFrame(data)

    # Overwrite file safely
    if os.path.exists(filename):
        os.remove(filename)

    df.to_excel(filename, index=False)
    print(f"✅ Exported {len(data)} triggers to {filename}")

###### Main Script #####

creds, dcList, template = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user, password)

with open("./zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)
        sys.exit(1)

for dc in dcList:
    print('###############################')
    print(f"Processing Data Center: {dc}")
    zabbix_url = config[dc]['env-url']
    if not zabbix_url.endswith("/api_jsonrpc.php"):
        zabbix_url = zabbix_url.rstrip("/") + "/api_jsonrpc.php"

    token = common.authenticate(zabbix_url)
    export_triggers_to_excel(token, zabbix_url)
