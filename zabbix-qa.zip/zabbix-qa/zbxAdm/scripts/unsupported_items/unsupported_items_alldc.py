import argparse
import requests
import csv
import sys
import json
import os
from requests.exceptions import ConnectionError, Timeout, RequestException
import urllib3
# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#***********#
#usage
#python3 unsupported_items.py --user '' --password ''
#**********#

# Change working directory to basedir
basedir = "/usr/local/etc/zbxAdm/scripts/unsupported_items/"
# basedir = "/Users/I501754/Documents/GitHub/zabbix/zbxAdm/scripts/unsupported_items"
try:
    os.chdir(basedir)
    print(f"Changed working directory to {basedir}")
except FileNotFoundError:
    print(f"[ERROR] Base directory '{basedir}' not found.")
    sys.exit(1)

group_name = 'All-DB-MYSQL'
inventory_file = "./inventory.txt"

# Connection settings
REQUEST_TIMEOUT = 30  # 30 seconds timeout
MAX_RETRIES = 2

class common_tools:
    def __init__(self, user, password):
        self.user = user
        self.password = password

    def authenticate(self, zabbix_url):
        data = json.dumps({
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": self.user,
                "password": self.password
            },
            "id": 1
        })
        
        try:
            r = requests.post(
                zabbix_url, 
                data=data, 
                headers={'Content-Type': 'application/json'}, 
                verify=False,
                timeout=REQUEST_TIMEOUT
            )
            r = r.json()
            if 'result' not in r:
                return "Invalid credentials"
            return r["result"]
        except ConnectionError:
            return "Connection failed"
        except Timeout:
            return "Connection timeout"
        except RequestException as e:
            return f"Request failed: {str(e)}"
        except json.JSONDecodeError:
            return "Invalid response format"
        except Exception as e:
            return f"Unexpected error: {str(e)}"
    
def parse_arguments():
    parser = argparse.ArgumentParser(description="Zabbix item delay checker")
    parser.add_argument("--user", required=True, help="Zabbix username")
    parser.add_argument("--password", required=True, help="Zabbix password")
    return parser.parse_args()

def load_inventory(file_path):
    """Load plain text inventory file: DC=URL"""
    config = {}
    if not os.path.exists(file_path):
        print(f"[ERROR] Inventory file '{file_path}' not found.")
        sys.exit(1)

    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):  # skip blanks/comments
                continue
            if "=" in line:
                dc, url = line.split("=", 1)
                config[dc.strip()] = url.strip()
    return config


# Get hostgroup ID from name
def get_hostgroup_id(auth_token, group_name, zabbix_url):
    payload = {
        "jsonrpc": "2.0",
        "method": "hostgroup.get",
        "params": {
            "output": ["groupid", "name"],
            "filter": {"name": group_name}
        },
        "auth": auth_token,
        "id": 2
    }
    
    try:
        response = requests.post(
            zabbix_url, 
            json=payload, 
            verify=False, 
            timeout=REQUEST_TIMEOUT
        )
        response = response.json()
        result = response.get("result", [])
        return result[0]["groupid"] if result else None
    except (ConnectionError, Timeout, RequestException, json.JSONDecodeError) as e:
        print(f"[ERROR] Failed to get hostgroup ID: {str(e)}")
        return None
    except Exception as e:
        print(f"[ERROR] Unexpected error getting hostgroup ID: {str(e)}")
        return None

# Get hosts in a hostgroup
def get_hosts_in_group(auth_token, groupid, zabbix_url):
    payload = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "groupids": groupid,
            "output": ["hostid", "host"]
        },
        "auth": auth_token,
        "id": 3
    }
    
    try:
        response = requests.post(
            zabbix_url, 
            json=payload, 
            verify=False, 
            timeout=REQUEST_TIMEOUT
        )
        response = response.json()
        return response.get("result", [])
    except (ConnectionError, Timeout, RequestException, json.JSONDecodeError) as e:
        print(f"[ERROR] Failed to get hosts in group: {str(e)}")
        return []
    except Exception as e:
        print(f"[ERROR] Unexpected error getting hosts: {str(e)}")
        return []

# Resolve template name if item inherited
def resolve_template_name(auth_token, template_itemid, zabbix_url):
    try:
        # Step 1: get parent item (inside template)
        payload = {
            "jsonrpc": "2.0",
            "method": "item.get",
            "params": {
                "output": ["itemid", "hostid"],
                "itemids": template_itemid,
            },
            "auth": auth_token,
            "id": 10
        }
        response = requests.post(
            zabbix_url, 
            json=payload, 
            verify=False, 
            timeout=REQUEST_TIMEOUT
        )
        response = response.json()
        result = response.get("result", [])
        if not result:
            return None

        template_hostid = result[0]["hostid"]
        
        # Step 2: get template name
        payload = {
            "jsonrpc": "2.0",
        "method": "template.get",
            "params": {
                "output": ["templateid", "name"],
                "templateids": template_hostid
            },
            "auth": auth_token,
            "id": 11
        }
        response = requests.post(
            zabbix_url, 
            json=payload, 
            verify=False, 
            timeout=REQUEST_TIMEOUT
        )
        response = response.json()
        result = response.get("result", [])
        return result[0]["name"] if result else None
        
    except (ConnectionError, Timeout, RequestException, json.JSONDecodeError) as e:
        print(f"[WARNING] Failed to resolve template name: {str(e)}")
        return "Template name unavailable"
    except Exception as e:
        print(f"[WARNING] Unexpected error resolving template name: {str(e)}")
        return "Template name unavailable"

# Get unsupported items for a host
def get_unsupported_items_for_host(auth_token, hostid, zabbix_url):
    payload = {
        "jsonrpc": "2.0",
        "method": "item.get",
        "params": {
            "hostids": hostid,
            "output": ["itemid", "name", "key_", "state", "error", "templateid"],
            "filter": {"state": 1}  # unsupported only
        },
        "auth": auth_token,
        "id": 4
    }
    
    try:
        response = requests.post(
            zabbix_url, 
            json=payload, 
            verify=False, 
            timeout=REQUEST_TIMEOUT
        )
        response = response.json()
        return response.get("result", [])
    except (ConnectionError, Timeout, RequestException, json.JSONDecodeError) as e:
        print(f"[WARNING] Failed to get unsupported items for host {hostid}: {str(e)}")
        return []
    except Exception as e:
        print(f"[WARNING] Unexpected error getting unsupported items for host {hostid}: {str(e)}")
        return []

# Save to CSV
def save_to_csv(data, filename="unsupported_items.csv"):
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Hostgroup", "Host", "Template", "Item", "Key", "Error"])  # header
        for row in data:
            writer.writerow(row)

def combine_csv_files(dc_files, final_filename="unsupported_items.csv"):
    """Combine multiple CSV files into one final CSV file"""
    all_data = []
    
    for dc_file in dc_files:
        if os.path.exists(dc_file):
            with open(dc_file, mode="r", newline="", encoding="utf-8") as file:
                reader = csv.reader(file)
                header = next(reader)  # Skip header for individual files
                for row in reader:
                    all_data.append(row)
    
    # Write combined data
    if all_data:
        with open(final_filename, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Hostgroup", "Host", "Template", "Item", "Key", "Error"])  # header
            for row in all_data:
                writer.writerow(row)
        print(f"Combined report saved as '{final_filename}' with {len(all_data)} records.")
    else:
        print("No data found to combine.")

if __name__ == "__main__":

    args = parse_arguments()

    # Load inventory from plain text file
    config = load_inventory(inventory_file)

    dc_files = []
    dc_counter = 1

    for dc, zabbix_url in config.items():
        print(f"\n{'='*50}")
        print(f"Processing DC {dc_counter}: {dc}")
        print(f"URL: {zabbix_url}")
        print(f"{'='*50}")
        
        dc_filename = f"unsupported_items-{dc}.csv"
        dc_data = []
        
        common = common_tools(args.user, args.password)
        token = common.authenticate(zabbix_url)

        # Handle all authentication/connection failures
        if token in ["Invalid credentials", "Connection failed", "Connection timeout"] or token.startswith("Request failed") or token.startswith("Unexpected error"):
            print(f"[ERROR] Failed to connect to DC '{dc}': {token}")
            print(f"[INFO] Skipping DC '{dc}' and moving to next datacenter...")
            dc_counter += 1
            continue

        groupid = get_hostgroup_id(token, group_name, zabbix_url)
        if not groupid:
            print(f"[WARNING] Hostgroup '{group_name}' not found in DC '{dc}' or connection failed.")
            print(f"[INFO] Skipping DC '{dc}' and moving to next datacenter...")
            dc_counter += 1
            continue

        hosts = get_hosts_in_group(token, groupid, zabbix_url)
        if not hosts:
            print(f"[WARNING] No hosts found in hostgroup '{group_name}' for DC '{dc}' or connection failed.")
            print(f"[INFO] Skipping DC '{dc}' and moving to next datacenter...")
            dc_counter += 1
            continue

        print(f"Found {len(hosts)} hosts in DC '{dc}'")
        
        for host_idx, host in enumerate(hosts, 1):
            hostid = host["hostid"]        
            hostname = host["host"]
            print(f"Processing host {host_idx}/{len(hosts)}: '{hostname}' (ID: {hostid})")   
            
            unsupported_items = get_unsupported_items_for_host(token, hostid, zabbix_url)
            
            if unsupported_items:
                print(f"  Found {len(unsupported_items)} unsupported items")
                for item in unsupported_items:
                    item_name = item["name"]
                    key = item["key_"]
                    error = item.get("error", "")
                    
                    if item.get("templateid") and item["templateid"] != "0":
                        template_name = resolve_template_name(token, item["templateid"], zabbix_url)
                    else:
                        template_name = "Directly on host"
                    
                    dc_data.append([group_name, hostname, template_name, item_name, key, error])
            else:
                print(f"  No unsupported items found")

        # Save DC-specific CSV
        if dc_data:
            save_to_csv(dc_data, dc_filename)
            dc_files.append(dc_filename)
            print(f"[SUCCESS] DC '{dc}' report saved as '{dc_filename}' with {len(dc_data)} records.")
        else:
            print(f"[INFO] No unsupported items found in DC '{dc}'.")
        
        dc_counter += 1

    # Combine all DC CSV files into final report
    print(f"\n{'='*50}")
    print("Combining all DC reports...")
    print(f"{'='*50}")
    
    if dc_files:
        combine_csv_files(dc_files)
        
        # Optionally clean up individual DC files (uncomment if desired)
        # print("Cleaning up individual DC files...")
        # for dc_file in dc_files:
        #     if os.path.exists(dc_file):
        #         os.remove(dc_file)
        #         print(f"Removed {dc_file}")
        
        print(f"Individual DC files kept: {', '.join(dc_files)}")
    else:
        print("No DC files were created. No unsupported items found in any datacenter.")