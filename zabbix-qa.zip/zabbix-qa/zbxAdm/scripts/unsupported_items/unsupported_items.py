import argparse
import requests
import csv
import sys
import json
import os
#***********#
#usage
#python3 unsupported_items.py --user '' --password '' --dc 81
#**********#

# Change working directory to basedir
basedir = "/usr/local/etc/zbxAdm/scripts/unsupported_items/"
try:
    os.chdir(basedir)
    print(f"Changed working directory to {basedir}")
except FileNotFoundError:
    print(f"[ERROR] Base directory '{basedir}' not found.")
    sys.exit(1)

group_name = 'All-DB-MYSQL'
inventory_file = "../inventory.txt"
class common_tools:
    def __init__(self, user, password):
        self.user = user
        self.password = password

    def authenticate(self, zabbix_url):
        data = json.dumps({
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": self.user,
                "password": self.password
            },
            "id": 1
        })
        r = requests.post(zabbix_url, data=data, headers={'Content-Type': 'application/json'}, verify=False)
        r = r.json()
        if 'result' not in r:
            return "Invalid credentials"
        return r["result"]
    
def parse_arguments():
    parser = argparse.ArgumentParser(description="Zabbix item delay checker")
    parser.add_argument("--user", required=True, help="Zabbix username")
    parser.add_argument("--password", required=True, help="Zabbix password")
    parser.add_argument("--dc", required=True, help="Datacenter name (e.g., DC01, DC22)")
    return parser.parse_args()

def normalize_dc(dc_input):

    if dc_input.isdigit() and len(dc_input) == 2:
        return dc_input
    else:
        raise ValueError("Invalid DC format. Use e.g., 01, 22.")


def load_inventory(file_path):
    """Load plain text inventory file: DC=URL"""
    config = {}
    if not os.path.exists(file_path):
        print(f"[ERROR] Inventory file '{file_path}' not found.")
        sys.exit(1)

    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):  # skip blanks/comments
                continue
            if "=" in line:
                dc, url = line.split("=", 1)
                config[dc.strip()] = url.strip()
    return config


# Get hostgroup ID from name
def get_hostgroup_id(auth_token, group_name,zabbix_url):
    payload = {
        "jsonrpc": "2.0",
        "method": "hostgroup.get",
        "params": {
            "output": ["groupid", "name"],
            "filter": {"name": group_name}
        },
        "auth": auth_token,
        "id": 2
    }
    response = requests.post(zabbix_url, json=payload).json()
    result = response.get("result", [])
    return result[0]["groupid"] if result else None

# Get hosts in a hostgroup
def get_hosts_in_group(auth_token, groupid):
    payload = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "groupids": groupid,
            "output": ["hostid", "host"]
        },
        "auth": auth_token,
        "id": 3
    }
    response = requests.post(zabbix_url, json=payload).json()
    return response.get("result", [])

# Resolve template name if item inherited
def resolve_template_name(auth_token, template_itemid,zabbix_url):
    # Step 1: get parent item (inside template)
    payload = {
        "jsonrpc": "2.0",
        "method": "item.get",
        "params": {
            # "output": "extend",
            "output": ["itemid", "hostid"],
            "itemids": template_itemid,
        },
        "auth": auth_token,
        "id": 10
    }
    response = requests.post(zabbix_url, json=payload).json()
    result = response.get("result", [])
    if not result:
        return None

    template_hostid = result[0]["hostid"]
    # Step 2: get template name
    payload = {
        "jsonrpc": "2.0",
        "method": "template.get",
        "params": {
            # "output": "extend",            
            "output": ["templateid", "name"],
            "templateids": template_hostid
            
        },
        "auth": auth_token,
        "id": 11
    }
    response = requests.post(zabbix_url, json=payload).json()
    result = response.get("result", [])
    # print("printing template result")
    # print(result)
    return result[0]["name"] if result else None

# Get unsupported items for a host
def get_unsupported_items_for_host(auth_token, hostid,zabbix_url):
    payload = {
        "jsonrpc": "2.0",
        "method": "item.get",
        "params": {
            "hostids": hostid,
            "output": ["itemid", "name", "key_", "state", "error", "templateid"],
            "filter": {"state": 1}  # unsupported only
        },
        "auth": auth_token,
        "id": 4
    }
    response = requests.post(zabbix_url, json=payload).json()
    return response.get("result", [])

# Save to CSV
def save_to_csv(data, filename="unsupported_items.csv"):
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Hostgroup", "Host", "Template", "Item", "Key", "Error"])  # header
        for row in data:
            writer.writerow(row)

if __name__ == "__main__":

    args = parse_arguments()
    try:
        dc = normalize_dc(args.dc)
    except ValueError as e:
        print(f"[ERROR] {e}")
        sys.exit(1)
    print("printing inventory file path")
    print(inventory_file)
    config = load_inventory(inventory_file)

    if dc not in config:
        print(f"[ERROR] DC '{dc}' not found in inventory file.")
        sys.exit(1)
    # Load inventory from plain text file

    zabbix_url = config[dc]
    common = common_tools(args.user, args.password)
    token = common.authenticate(zabbix_url)

    if token == "Invalid credentials":
        print("[ERROR] Authentication failed. Check username/password.")
        sys.exit(1)


    groupid = get_hostgroup_id(token, group_name,zabbix_url)
    if not groupid:
        print(f"Hostgroup '{group_name}' not found.")
        exit(1)

    hosts = get_hosts_in_group(token, groupid)
    # print(hosts)
    if not hosts:
        print(f"No hosts found in hostgroup '{group_name}'.")
        exit(1)

    all_data = []
    for host in hosts:
        hostid = host["hostid"]        
        hostname = host["host"]
        #if hostid==18887 then continue the loop
        # if hostid != '18887':
        #     continue
        print(f"Processing host '{hostname}' (ID: {hostid})")   
        unsupported_items = get_unsupported_items_for_host(token, hostid,zabbix_url)
        for item in unsupported_items:
            item_name = item["name"]
            key = item["key_"]
            error = item.get("error", "")
            print(f"Processing item '{item_name}' on host '{hostname}'")
            # print(item)
            if item.get("templateid") and item["templateid"] != "0":
                template_name = resolve_template_name(token, item["templateid"],zabbix_url)
            else:
                template_name = "Directly on host"
            # print(f"  Template: {template_name},hostname:{hostname}, Key: {key}, Error: {error}")
            all_data.append([group_name, hostname, template_name, item_name, key, error])

    if all_data:
        save_to_csv(all_data)
        print(f"Report saved as 'unsupported_items.csv' with {len(all_data)} records.")
    else:
        print(f"No unsupported items found in hostgroup '{group_name}'.")
