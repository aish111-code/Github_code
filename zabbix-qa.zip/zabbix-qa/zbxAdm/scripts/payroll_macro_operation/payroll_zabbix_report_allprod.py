#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, re, csv, json, datetime, requests
import warnings
warnings.filterwarnings("ignore")

# -------- Config --------
BASEDIR = "/usr/local/etc/zbxAdm/scripts/payroll_macro_operation"
SF_CLIENT_ID = "itu_tanium_user"
SF_TOKEN = sys.argv[1]                       # argv1
ZBX_CLIENT_ID = "ZABBIX_SFSF_API"
ZBX_TOKEN = sys.argv[2]                       # argv2
REQUIRED_KEYWORDS = ("pay", "s4p")           # host filter
BT_OK = re.compile(r"^ZH\d{3}$")             # valid BT
ZABBIX_FETCH_LIMIT = 200000

ZABBIX_DCS = [
    {"url": "https://zabbix-dc70.cld.ondemand.com/api_jsonrpc.php", "dc": "DC70"},
    {"url": "https://zabbix-dc30.cld.ondemand.com/api_jsonrpc.php", "dc": "DC30"},
    {"url": "https://zabbix-dc33.cld.ondemand.com/api_jsonrpc.php", "dc": "DC33"},
    {"url": "https://zabbix-americas-primary.cld.ondemand.com/api_jsonrpc.php", "dc": "DC41"},
    {"url": "https://zabbix-dc50.cld.ondemand.com/api_jsonrpc.php", "dc": "DC50"},
    {"url": "https://zabbix-dc55.cld.ondemand.com/api_jsonrpc.php", "dc": "DC55"},
    {"url": "https://zabbix-dc60.cld.ondemand.com/api_jsonrpc.php", "dc": "DC60"},
    {"url": "https://zabbix-dc64.cld.ondemand.com/api_jsonrpc.php", "dc": "DC64"},
    {"url": "https://zabbix-dc66.cld.ondemand.com/api_jsonrpc.php", "dc": "DC66"},
    {"url": "https://zabbix-dc74.cld.ondemand.com/api_jsonrpc.php", "dc": "DC74"},
    {"url": "https://zabbix-dc80.cld.ondemand.com/api_jsonrpc.php", "dc": "DC80"},
    {"url": "https://zabbix-dc82.cld.ondemand.com/api_jsonrpc.php", "dc": "DC82"},
    {"url": "https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php", "dc": "DC22"}
]

MAIL_FROM = "sapsfsdotoolsandutils@sapsf.com"
MAIL_TO_WRONG = "nagapavan.kalgur@sap.com,jibin.sunny@sap.com,teja.ram.mathi@sap.com,DL_62D50CAEB98ABB02996051B9@global.corp.sap,DL_56F8A7D17BCF84666D00012F@global.corp.sap"

# -------- Utils --------
def ts():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def has_required_keyword(hostname: str) -> bool:
    h = (hostname or "").lower()
    return any(k in h for k in REQUIRED_KEYWORDS)

def extract_sid(hostname: str):
    if not hostname: return None
    h = hostname.strip()
    sid = None
    if len(h) >= 10:
        cand = h[7:10].upper()
        if cand.isalnum():
            sid = cand
    if not sid:
        m = re.search(r'([A-Za-z0-9]{2,4})\.', h)
        if m: sid = m.group(1).upper()
    if not sid:
        m2 = re.search(r'^[a-z0-9]{2,6}([A-Za-z]{2,4})', h, re.IGNORECASE)
        if m2: sid = m2.group(1).upper()
    return sid

def determine_dc(hostname: str) -> str:
    hl = (hostname or "").lower()
    if 'dc022' in hl or 'pc22' in hl: return 'DC22'
    if 'dc023' in hl or 'pc23' in hl: return 'DC23'
    if 'dc082' in hl or 'pc82' in hl: return 'DC82'
    if 'dc084' in hl or 'pc84' in hl: return 'DC84'
    if 'dc060' in hl or 'pc60' in hl: return 'DC60'
    if 'dc047' in hl or 'pc47' in hl: return 'DC47'
    if 'dc066' in hl or 'pc66' in hl: return 'DC66'
    if 'dc080' in hl or 'pc80' in hl: return 'DC80'
    if 'dc074' in hl or 'pc74' in hl: return 'DC74'
    if 'dc064' in hl or 'pc64' in hl: return 'DC64'
    if 'dc050' in hl or 'pc50' in hl: return 'DC50'
    if 'dc055' in hl or 'pc55' in hl: return 'DC55'
    if 'dc041' in hl or 'pc41' in hl: return 'DC41'
    if 'dc033' in hl or 'pc33' in hl: return 'DC33'
    if 'dc070' in hl or 'pc70' in hl: return 'DC70'
    if 'dc030' in hl or 'pc30' in hl: return 'DC30'
    return 'Unknown'

def is_multi_value_bt(bt_raw: str) -> bool:
    if bt_raw is None:
        return False
    s = str(bt_raw).strip()
    if not s:
        return False
    tokens = re.split(r'\s+', s)
    return len(tokens) > 1

def mail_simple(subject: str, body: str, to_addr: str, attach_path: str = None):
    if os.system("command -v mailx >/dev/null 2>&1") != 0:
        return
    if attach_path and os.path.isfile(attach_path):
        cmd = f"echo '{body}' | mailx -s '{subject}' -r {MAIL_FROM} -a '{attach_path}' {to_addr}"
    else:
        cmd = f"echo '{body}' | mailx -s '{subject}' -r {MAIL_FROM} {to_addr}"
    os.system(cmd)

# -------- Remote calls --------
def sftools_token():
    url = "https://sftools-api.cld.ondemand.com/user_auth/auth/login"
    payload = {"username": SF_CLIENT_ID, "password": SF_TOKEN}
    r = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, verify=False, timeout=30)
    r.raise_for_status()
    return r.json()["result"]["authorization_token"]

def fetch_payroll_inventory(token: str):
    url = "https://sftools-api.cld.ondemand.com/splunk/api/splunksearch/zabbix_payroll_inventory"
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, verify=False, timeout=60)
    r.raise_for_status()
    return r.json()["payroll_inventory_zabbix_monitoring_orf_api"]

def zbx_login(zbx_url: str):
    payload = {"jsonrpc":"2.0","method":"user.login",
               "params":{"username": ZBX_CLIENT_ID, "password": ZBX_TOKEN},
               "id":1}
    r = requests.post(zbx_url, data=json.dumps(payload),
                      headers={"Content-Type":"application/json-rpc"},
                      verify=False, timeout=30)
    r.raise_for_status()
    return r.json().get("result")

def zbx_hosts(auth: str, zbx_url: str):
    payload = {"jsonrpc":"2.0","method":"host.get",
               "params":{"output":["hostid","host"], "limit": ZABBIX_FETCH_LIMIT},
               "auth":auth,"id":2}
    r = requests.post(zbx_url, data=json.dumps(payload),
                      headers={"Content-Type":"application/json-rpc"},
                      verify=False, timeout=90)
    r.raise_for_status()
    return r.json().get("result", [])

# -------- Main --------
def main():
    ensure_dir(BASEDIR)
    print("Authenticating to SFTools...")
    token = sftools_token()
    inv = fetch_payroll_inventory(token)

    # Build SID -> raw BT map
    sid_to_bt = {}
    for row in inv:
        sid = (row.get("SID") or "").strip().upper()
        bt  = row.get("BusinessType")
        if sid and sid not in sid_to_bt:
            sid_to_bt[sid] = bt

    # Fetch all hosts
    all_hosts = []
    for dc in ZABBIX_DCS:
        print(f"=== Checking DC: {dc['url']} ===")
        auth = zbx_login(dc["url"])
        if not auth:
            print("  login failed, skipping.")
            continue
        try:
            hosts = zbx_hosts(auth, dc["url"])
            print(f"  fetched {len(hosts)} hosts")
            all_hosts.extend(hosts)
        except Exception as e:
            print(f"  fetch error: {e}")

    print(f"\nTotal hosts fetched across DCs: {len(all_hosts)}")

    now = ts()
    correct_path = os.path.join(BASEDIR, f"Payroll_Zabbix_Correct.csv")
    wrong_path   = os.path.join(BASEDIR, f"Payroll_Zabbix_InCorrect.csv")

    kept = 0
    wrong = 0
    skipped_missing_unknown = 0
    skipped_sid_issues = 0

    with open(correct_path, "w", newline="", encoding="utf-8") as f_ok, \
         open(wrong_path,   "w", newline="", encoding="utf-8") as f_bad:

        w_ok  = csv.writer(f_ok)
        w_bad = csv.writer(f_bad)

        w_ok.writerow(["Hostname", "SID", "BusinessType", "DC"])
        w_bad.writerow(["Hostname", "SID", "BusinessType_raw", "Reason", "DC"])

        for h in all_hosts:
            hostname = (h.get("host") or "").strip()
            if not hostname or not has_required_keyword(hostname):
                continue

            sid = extract_sid(hostname)
            dc  = determine_dc(hostname)

            if not sid or sid not in sid_to_bt:
                skipped_sid_issues += 1
                continue

            bt_raw = sid_to_bt[sid]

            if bt_raw is None or str(bt_raw).strip() in ("", "unknown", "na", "n/a", "-"):
                skipped_missing_unknown += 1
                continue

            s = str(bt_raw).strip()
            if is_multi_value_bt(s):
                wrong += 1
                w_bad.writerow([hostname, sid, s, "BusinessType_multiple_values", dc])
                continue

            if BT_OK.match(s):
                w_ok.writerow([hostname, sid, s, dc])
                kept += 1
            else:
                skipped_missing_unknown += 1
                continue

    print(f"\nWrote correct entries : {kept}  -> {correct_path}")
    print(f"Wrote wrong entries   : {wrong}  -> {wrong_path}")
    print(f"Skipped (SID empty/unknown/internal system): {skipped_missing_unknown + skipped_sid_issues}")

    # -------- UPDATED EMAIL SECTION --------
    PAY_ENV = os.environ.get("PAY_ENV", "Unknown")

    if wrong > 0:
        subject = f"[Payroll/Zabbix] $PAY_ENV MACRO: Wrong (multi-value) BusinessType entries: {wrong} - {now}"
        body = (
            f"{wrong} rows with multi-value BusinessType were saved to:\n"
            f"{wrong_path}\n"
            f"(e.g., 'ZH001 ZH001' or 'ZH036 ZH001').\n\n"
            f"Payroll environment sync from SPC to Zabbix skipped for these nodes, please check"
        )
        mail_simple(subject, body, MAIL_TO_WRONG, attach_path=wrong_path)

# -------- Entry --------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 payroll_zabbix_report_prod_clean_split.py <SFToolsSec> <ZabbixSec>")
        sys.exit(1)
    main()
