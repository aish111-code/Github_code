import requests
import json
import csv

def get_zabbix_hostnames(url, username, password):
    # Zabbix API endpoint
    api_url = f"{url}/api_jsonrpc.php"

    # Login to Zabbix API
    payload = {
        "jsonrpc": "2.0",
        "method": "user.login",
        "params": {
            "username": username,
            "password": password
        },
        "id": 1
    }

    headers = {
        "Content-Type": "application/json-rpc"
    }

    try:
        response = requests.post(api_url, data=json.dumps(payload), headers=headers)
        response.raise_for_status()
        result = response.json()

        if "result" in result:
            auth_token = result["result"]
        else:
            print("Failed to authenticate with Zabbix API.")
            return

        # Get hostnames
        payload = {
            "jsonrpc": "2.0",
            "method": "host.get",
            "params": {
                "output": ["hostid", "host"]
            },
            "auth": auth_token,
            "id": 2
        }

        response = requests.post(api_url, data=json.dumps(payload), headers=headers)
        response.raise_for_status()
        result = response.json()

        if "result" in result:
            hosts = result["result"]
            payroll_hosts = []
            for host in hosts:
                # Check if 'pay' is in the hostname and store hostname and hostid in payroll_hosts
                # if 'pay' in host["host"]:
                if "pay" in host["host"].lower() or "s4p" in host["host"].lower():
                    payroll_hosts.append({"hostname": host["host"], "hostid": host["hostid"]})

            # Print the payroll_hosts array
            print("Payroll Hosts:", payroll_hosts)

            # Read sidmapping.txt and create a mapping of sid to business_type
            sid_to_business_type = {}
            with open("sidmapping.txt", "r") as file:
                for line in file:
                    parts = line.strip().split(",")
                    if len(parts) == 2:
                        sid_to_business_type[parts[0]] = parts[1]

            # Define mapping of business_type to payroll_env
            business_type_to_env = {
                "ZH001": "Prod",
                "ZH002": "Trial",
                "ZH019": "Test",
                "ZH020": "Test",
                "ZH022": "SalesDemo",
                "ZH023": "Dev",
                "ZH030": "Internal",
                "ZH036": "Stock"
            }

            # Perform the operation only if the hostname matches the specified value
            specified_hostname = "pc50payh0401.dc050.sf.priv"

            # Open a CSV file to write the output
            with open("payroll_hosts_output.csv", "w", newline="") as csvfile:
                csvwriter = csv.writer(csvfile)
                # Write the header row
                csvwriter.writerow(["Hostname", "SID", "Business Type", "Payroll Env", "Payroll Env ZBX"])

                # Iterate through payroll_hosts and find matching sid, business_type, payroll_env, and payroll_env_zbx
                for host_entry in payroll_hosts:
                    hostname = host_entry["hostname"]
                    hostid = host_entry["hostid"]

                    # Check if the hostname matches the specified hostname
                    # if hostname == specified_hostname:

                    for sid, business_type in sid_to_business_type.items():
                        if sid.lower() == hostname[7:10].lower():
                        # if sid.lower() in hostname.lower():
                            payroll_env = business_type_to_env.get(business_type, "Unknown")

                            # Corrected usermacro.get method call
                            payload = {
                                "jsonrpc": "2.0",
                                "method": "usermacro.get",
                                "params": {
                                    "hostids": hostid,
                                    "output": "extend"
                                },
                                "auth": auth_token,
                                "id": 3
                            }

                            response = requests.post(api_url, data=json.dumps(payload), headers=headers)
                            response.raise_for_status()
                            macro_result = response.json()

                            macro_found = False
                            if "result" in macro_result:
                                for macro in macro_result["result"]:
                                    if macro["macro"] == "{$PAYROLL_ENV}":
                                        macro_found = True
                                        if payroll_env != macro["value"]:
                                            # Update the usermacro {$PAYROLL_ENV} with the value of payroll_env
                                            update_payload = {
                                                "jsonrpc": "2.0",
                                                "method": "usermacro.update",
                                                "params": {
                                                    "hostmacroid": macro["hostmacroid"],
                                                    "value": payroll_env
                                                },
                                                "auth": auth_token,
                                                "id": 4
                                            }

                                            update_response = requests.post(api_url, data=json.dumps(update_payload), headers=headers)
                                            update_response.raise_for_status()
                                            update_result = update_response.json()

                                            if "result" in update_result:
                                                print(f"Updated usermacro {{$PAYROLL_ENV}} for hostname {hostname} to {payroll_env}.")
                                            else:
                                                print(f"Failed to update usermacro {{$PAYROLL_ENV}} for hostname {hostname}.")
                                        break

                            if not macro_found:
                                # Create the usermacro {$PAYROLL_ENV} with the value of payroll_env
                                create_payload = {
                                    "jsonrpc": "2.0",
                                    "method": "usermacro.create",
                                    "params": {
                                        "hostid": hostid,
                                        "macro": "{$PAYROLL_ENV}",
                                        "value": payroll_env
                                    },
                                    "auth": auth_token,
                                    "id": 5
                                }

                                create_response = requests.post(api_url, data=json.dumps(create_payload), headers=headers)
                                create_response.raise_for_status()
                                create_result = create_response.json()

                                if "result" in create_result:
                                    print(f"Created usermacro {{$PAYROLL_ENV}} for hostname {hostname} with value {payroll_env}.")
                                else:
                                    print(f"Failed to create usermacro {{$PAYROLL_ENV}} for hostname {hostname}.")
                            payroll_env_zbx = payroll_env
                            # Write the row to the CSV file
                            print(f"Hostname: {hostname}, SID: {sid}, Business Type: {business_type}, Payroll Env: {payroll_env}, Payroll Env ZBX: {payroll_env_zbx}")
                            csvwriter.writerow([hostname, sid, business_type, payroll_env, payroll_env_zbx])

            print("Output has been written to payroll_hosts_output.csv for the specified hostname.")

        else:
            print("Failed to retrieve hostnames.")

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    # Replace with your Zabbix URL, username, and password
    zabbix_url = "https://zabbix-dc50.cld.ondemand.com/api_jsonrpc.php"
    zabbix_username = ""
    zabbix_password = ""

    get_zabbix_hostnames(zabbix_url, zabbix_username, zabbix_password)
