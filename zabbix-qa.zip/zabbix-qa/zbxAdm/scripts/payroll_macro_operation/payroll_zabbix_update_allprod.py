import requests
import json
import csv
import warnings
import sys

warnings.filterwarnings("ignore")

# ---------------- Configuration ----------------
ZBX_CLIENT_ID = "ZABBIX_SFSF_API"
csv_file = "/usr/local/etc/zbxAdm/scripts/payroll_macro_operation/Payroll_Zabbix_Correct.csv"

# Map DC to Zabbix URL (multiple DCs may share same URL)
dc_to_zabbix_url = {
    "DC70": "https://zabbix-dc70.cld.ondemand.com/api_jsonrpc.php",
    "DC30": "https://zabbix-dc30.cld.ondemand.com/api_jsonrpc.php",
    "DC33": "https://zabbix-dc33.cld.ondemand.com/api_jsonrpc.php",
    "DC41": "https://zabbix-americas-primary.cld.ondemand.com/api_jsonrpc.php",
    "DC50": "https://zabbix-dc50.cld.ondemand.com/api_jsonrpc.php",
    "DC55": "https://zabbix-dc55.cld.ondemand.com/api_jsonrpc.php",
    "DC64": "https://zabbix-dc64.cld.ondemand.com/api_jsonrpc.php",
    "DC66": "https://zabbix-dc66.cld.ondemand.com/api_jsonrpc.php",
    "DC74": "https://zabbix-dc74.cld.ondemand.com/api_jsonrpc.php",
    "DC80": "https://zabbix-dc80.cld.ondemand.com/api_jsonrpc.php",
    # Both DC60 and DC47 hosts use the same URL
    "DC47": "https://zabbix-dc60.cld.ondemand.com/api_jsonrpc.php",
    "DC60": "https://zabbix-dc60.cld.ondemand.com/api_jsonrpc.php",
    # Both DC82 and DC84 hosts use the same URL
    "DC82": "https://zabbix-dc82.cld.ondemand.com/api_jsonrpc.php",
    "DC84": "https://zabbix-dc82.cld.ondemand.com/api_jsonrpc.php",
    # Both DC22 and DC23 hosts use the same URL
    "DC22": "https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php",
    "DC23": "https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php",
}

# Mapping of BusinessType -> Payroll Environment
business_type_to_env = {
    "ZH001": "Prod",
    "ZH002": "Trial",
    "ZH019": "Test",
    "ZH020": "Test",
    "ZH022": "SalesDemo",
    "ZH023": "Dev",
    "ZH030": "Internal",
    "ZH036": "Stock"
}

# ---------------- Functions ----------------
def zabbix_login(secret, zabbix_url):
    payload = {
        "jsonrpc": "2.0",
        "method": "user.login",
        "params": {"username": ZBX_CLIENT_ID, "password": secret},
        "id": 1
    }
    headers = {"Content-Type": "application/json-rpc"}
    r = requests.post(zabbix_url, data=json.dumps(payload), headers=headers, verify=False, timeout=30)
    r.raise_for_status()
    result = r.json()
    if "result" not in result:
        raise Exception(f"Failed to authenticate with Zabbix API {zabbix_url}")
    return result["result"]

def get_hostid(auth_token, zabbix_url, hostname):
    payload = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {"output": ["hostid"], "filter": {"host": [hostname]}},
        "auth": auth_token,
        "id": 2
    }
    headers = {"Content-Type": "application/json-rpc"}
    r = requests.post(zabbix_url, data=json.dumps(payload), headers=headers, verify=False, timeout=30)
    r.raise_for_status()
    result = r.json()
    if "result" in result and result["result"]:
        return result["result"][0]["hostid"]
    else:
        print(f"Host '{hostname}' not found in {zabbix_url}")
        return None

def get_macros(auth_token, zabbix_url, hostid):
    payload = {
        "jsonrpc": "2.0",
        "method": "usermacro.get",
        "params": {"hostids": hostid, "output": "extend"},
        "auth": auth_token,
        "id": 3
    }
    headers = {"Content-Type": "application/json-rpc"}
    r = requests.post(zabbix_url, data=json.dumps(payload), headers=headers, verify=False, timeout=30)
    r.raise_for_status()
    return r.json().get("result", [])

def create_or_update_macro(auth_token, zabbix_url, hostid, hostname, macro_name, value):
    macros = get_macros(auth_token, zabbix_url, hostid)
    for macro in macros:
        if macro["macro"] == macro_name:
            if macro["value"] != value:
                payload = {
                    "jsonrpc": "2.0",
                    "method": "usermacro.update",
                    "params": {"hostmacroid": macro["hostmacroid"], "value": value},
                    "auth": auth_token,
                    "id": 4
                }
                r = requests.post(zabbix_url, data=json.dumps(payload),
                                  headers={"Content-Type": "application/json-rpc"}, verify=False, timeout=30)
                r.raise_for_status()
                print(f"Updated {macro_name} for host '{hostname}' (hostid {hostid}) to {value} on {zabbix_url}")
            else:
                print(f"{macro_name} already set to {value} for host '{hostname}' (hostid {hostid}) on {zabbix_url}")
            return
    # Macro not found; create it
    payload = {
        "jsonrpc": "2.0",
        "method": "usermacro.create",
        "params": {"hostid": hostid, "macro": macro_name, "value": value},
        "auth": auth_token,
        "id": 5
    }
    r = requests.post(zabbix_url, data=json.dumps(payload),
                      headers={"Content-Type": "application/json-rpc"}, verify=False, timeout=30)
    r.raise_for_status()
    print(f"Created {macro_name} for host '{hostname}' (hostid {hostid}) with value {value} on {zabbix_url}")

# ---------------- Main ----------------
def main():
    if len(sys.argv) < 2:
        print("Usage: python payroll_zabbix_update_allprod.py <ZBX_TOKEN>")
        sys.exit(1)

    ZBX_TOKEN = sys.argv[1]
    auth_tokens = {}  # cache login per URL

    with open(csv_file, newline="") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            hostname = row["Hostname"]
            business_type = row["BusinessType"]
            dc = row["DC"]

            payroll_env = business_type_to_env.get(business_type, "Unknown")
            if payroll_env == "Unknown":
                print(f"Skipping {hostname} because BusinessType {business_type} is unknown")
                continue

            # Get Zabbix URL for this host's DC
            zabbix_url = dc_to_zabbix_url.get(dc)
            if not zabbix_url:
                print(f"Skipping {hostname}: Unknown DC {dc}")
                continue

            # Login once per URL
            if zabbix_url not in auth_tokens:
                try:
                    auth_tokens[zabbix_url] = zabbix_login(ZBX_TOKEN, zabbix_url)
                    print(f"Authenticated to {zabbix_url}")
                except Exception as e:
                    print(f"Login failed for {zabbix_url}: {e}")
                    continue

            hostid = get_hostid(auth_tokens[zabbix_url], zabbix_url, hostname)
            if hostid:
                create_or_update_macro(auth_tokens[zabbix_url], zabbix_url, hostid, hostname, "{$PAYROLL_ENV}", payroll_env)

if __name__ == "__main__":
    main()
