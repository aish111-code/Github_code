#!/usr/local/etc/zbxAdm/autoregistration/.venv/bin/python3
##
##input to this script is host_discovered group and monsoon group
##loop through the hosts
import sys
sys.path.append('/usr/local/etc/zbxAdm/2.2/lib/zbxpylib')

import re
from pprint import pprint
import subprocess
import errno
import os
import shlex
import json
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import argparse
import re
import sys
import configparser
from zabbix_utils import ZabbixAPI
#import logging

#MAIL_TO = ["ganesan.karuppasamy@sap.com"]

# Datacenter
DATACENTER_HOSTNAME_FILE='/etc/hostname'
DATACENTER_HOSTS_FILE='/etc/hosts'
DATACENTER_PATTERN=r"[a-z]{2}([0-9]{1,2})[a-z]+"

HOST_REGISTRATION_MAIL_SUBJECT='Automated zabbix host registration status'
ANSIBLE_AGENT_MAIL_SUBJECT='Automated zabbix host agent deployment status'
#python autoregister_v5.py -validatehost ph01bcf2001.dc001.sf.priv


def zabbix_api(dcno,config):
    dcno= dcno
    zbxurl = config['zbxurls'][dcno]
    private_key_file = "/etc/zabbix/custom/zabbix_private_key.pem"
    encrypted_data_file = "/etc/zabbix/custom/zabbix_autoregister_password_enc.dat"
    cmd = "openssl rsautl -decrypt -inkey %s -in %s" % (private_key_file, encrypted_data_file)
    # print(cmd)
    args = shlex.split(cmd)
    p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out,err = p.communicate()
    passwd = out.rstrip()
    api = ZabbixAPI(
        url=zbxurl,
        user="ZABBIX_SFSF_API",
        password=passwd
    )
    return api

def get_rsm_config(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    if not config.sections():
        raise Exception(f"Error reading config file: {config_file}")
    return config


def get_host_inventory(api,host):
    inventory = {} ##declare empty dictionary
    #options = { 'output' : [ 'name','host', 'hostid' ] }
    options = { 'output' : 'extend', 'selectInterfaces': [ 'ip', 'port' ] }

    result = api.host.get(options)
    for record in result:
        name = record['name']
        ip = record['interfaces'][0]['ip']
        try:
            inventory[name] += 1
        except:
            inventory[name] = 1
        try:
            inventory[ip] += 1
        except:
            inventory[ip] = 1

    return inventory


def main():
    inp_host_group = 'hosts-discovered'

    config_file = f"./zbx.conf"
    print(f"Using config file: {config_file}")
    config = get_rsm_config(config_file)
    zbxurl = config['zbxurls']
    #itrate through each datacenter
    for dc in zbxurl:
        print(dc)
        print(zbxurl[dc])
        api= zabbix_api(dc,config)
        #get host group id
        inp_host_group_id = api.hostgroup.get({
            'output': 'extend',
            'filter': {
                'name': inp_host_group
            }
        })
        print(inp_host_group_id)
        #get all hosts in the group
        hosts = api.host.get({
            'output': ['name'],
            'groupids': inp_host_group_id[0]['groupid']
        })
        host_names = [host['name'] for host in hosts]
        print('printing host names')
        print(host_names)
        #iterate through item in host_names and call python autoregister_v5.py -validatehost ph01bcf2001.dc001.sf.priv
        for host in host_names:
            print(host)
            #call python autoregister_v5.py -validatehost ph01bcf2001.dc001.sf.priv
            cmd = f"python autoregister_v5.py -validatehost {host}"
            print(cmd)
            args = shlex.split(cmd)
            p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out,err = p.communicate()
            print(out)
            print(err)


            host_inventory = get_host_inventory(api,host)
#        if host_inventory[discovered_host] > 1 or host_inventory[discovered_ip] > 1:
#             print("%s is a duplicate " % (discovered_host))
#             #logging.warning("%s is a duplicate " % (discovered_host))
#             ##add it to failed host group
#             status = "DUPLICATE"
#             add_to_failed_grp(zabbix, discovered_host_id)
#             failedHosts.append(discovered_host)


        #logout from api
        api.logout()
        print("Logging out from Zabbix API")
              
            #   if out:
            #     print("Standard Output:")
            #     for line in out.decode('utf-8').splitlines():
            #         print(line)

            #   if err:
            #     print("Standard Error:")
            #     for line in err.decode('utf-8').splitlines():
            #         print(line)
            # 
                     

#     failed_grp = 'failed_automation'




if __name__ == '__main__':
    main()

