#execution format 
#python autoregister_v5.py -validatehost ph01bcf2001.dc001.sf.priv
import argparse
import re
import sys
import configparser
from zabbix_utils import ZabbixAPI
import subprocess
import shlex

import os
# Parse command-line arguments
def zabbix_api(host,config):
    dcno= host[2:4]
    zbxurl = config['zbxurls'][dcno]
    private_key_file = "/etc/zabbix/custom/zabbix_private_key.pem"
    encrypted_data_file = "/etc/zabbix/custom/zabbix_autoregister_password_enc.dat"
    cmd = "openssl rsautl -decrypt -inkey %s -in %s" % (private_key_file, encrypted_data_file)
    # print(cmd)
    args = shlex.split(cmd)
    p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out,err = p.communicate()
    passwd = out.rstrip()
    api = ZabbixAPI(
        url=zbxurl,
        user="ZABBIX_SFSF_API",
        password=passwd
    )
    return api

def get_rsm_config(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    if not config.sections():
        raise Exception(f"Error reading config file: {config_file}")
    return config


def fetch_all_template_names(api):

    
    params = {'output': ['name']}
    templates = api.template.get(params)
    
    if not templates:
        raise ValueError("No templates found")
    
    template_names = [template['name'] for template in templates]
    return template_names

def get_hostid(api, host):
    params ={'output': ['hostid'], 'filter': {'name': host}}
    result = api.host.get(params)    
    if result and isinstance(result, list) and len(result) > 0:
        return result[0].get('hostid')
    return None
def get_host_mapping(host_mapping_file):
    file_array = []
    with open(host_mapping_file, 'r') as fh:
        for line in fh:
            line = line.strip()
            if line and not line.startswith('#'):
                file_array.append(line)
    return file_array
def check_dup_regex(host, host_mapping_file):
    env=host[:2]
    dcno=host[2:4]
    hostmapper = get_host_mapping(host_mapping_file)
    uniq_hgs = {}
    host_grps_all = []
    duplicate = False

    for line in hostmapper:
        line_array = line.split(':')
        regex, hg = line_array[0], line_array[1]
        if re.search(regex, host, re.IGNORECASE):
            host_grps_all.append(hg)
            # Ensure there are no duplicate host groups for the same regex
            if hg in uniq_hgs:
                duplicate = True
            uniq_hgs[hg] = True

    return duplicate, host_grps_all

def check_valid_regex(host, host_mapping_file):
    hostmapper = get_host_mapping(host_mapping_file)
    valid = False

    for line in hostmapper:
        line_array = line.split(':')
        regex, hg = line_array[0], line_array[1]
        if re.search(regex, host, re.IGNORECASE):
            valid = True
            break

    return valid
def get_host_inventory(api):
    inventory = {} ##declare empty dictionary
    #options = { 'output' : [ 'name','host', 'hostid' ] }
    options = { 'output' : 'extend', 'selectInterfaces': [ 'ip', 'port' ] }

    result = api.host.get(options)
    for record in result:
        name = record['name']
        ip = record['interfaces'][0]['ip']
        try:
            inventory[name] += 1
        except:
            inventory[name] = 1
        try:
            inventory[ip] += 1
        except:
            inventory[ip] = 1

    return inventory


def check_valid_host(api,host,host_mapping_file):

    hostid = get_hostid(api, host)
    if hostid:
        print("Valid host" + hostid) 
    else:   
        return 1, "Host not found", hostid
    # Check for duplicate host IP
    host_inventory=get_host_inventory(api)
    host_ip= get_host_ip(api,hostid)
    if host_inventory[host] > 1 or host_inventory[host_ip] > 1:
            print("%s duplicate entry found " % (host))
            #logging.warning("%s is a duplicate " % (discovered_host))
            ##add it to failed host group
            status = "DUPLICATE"
            return 1, "Duplicate host/IP", hostid
    else:
        print("%s is not a duplicate " % (host))    

    # Check for duplicate regex
    duplicate_ptrn, host_grps = check_dup_regex(host, host_mapping_file)
    if duplicate_ptrn:
        return 1, "Duplicate regex", hostid

    valid_regex_found=check_valid_regex(host, host_mapping_file)
    if not valid_regex_found:
        return 1, "Regex not found", hostid
    else:
        print("Valid regex found")

#check T_OS_BASE template
    host_info = api.host.get({'output': ['hostid'], 'selectParentTemplates': ['name'], 'hostids': hostid})
    current_templates = [template['name'] for template in host_info[0]['parentTemplates']] if 'parentTemplates' in host_info[0] else []
    if 'T_OS_BASE' in current_templates:
        print("T_OS_BASE template found")
    else:
        print("T_OS_BASE template not found")
        return 1, "T_OS_BASE template not found", hostid
    return 0, "check_valid_host:success", hostid

def search_host_groups(host,host_mapping_file):
    match = False
    env=host[:2]
    dcno=host[2:4]
    envnames = {
        'pc': 'PROD',
        'sc': 'PREVIEW',
        'ps': 'SALES'
    }
    envname = envnames.get(env, 'QA')
    print(f"envname: {envname}")
    hostmapper = get_host_mapping(host_mapping_file)
    file_array = []
    for line in hostmapper:
        line_array = line.split(':')
        regex, hg = line_array[0], line_array[1]
        if re.search(regex, host, re.IGNORECASE):
            match = True
            tmp = hg.split(',')
            for i in range(len(tmp)):
                # Check if the tmp contains placeholders
                if '{envname}' in tmp[i]:
                    tmp[i] = tmp[i].replace('{envname}', envname)
                if '{dcno}' in tmp[i]:
                    tmp[i] = tmp[i].replace('{dcno}', dcno)
                if '{env}' in tmp[i]:
                    tmp[i] = tmp[i].replace('{env}', env)
            file_array.extend(tmp)

    if not match:
        file_array.append('NOMATCH')

    return file_array
def generate_host_groups(host_groups):
    groups = []
    for big_group in host_groups:
        parts = big_group.split('_')
        prefixes = []
        prefix = ''
        for part in parts:
            if prefix:
                prefix += '_'+part
            else:
                prefix = part
            prefixes.append(prefix)
        groups.extend(prefixes)
    return list(set(groups))

def generate_template(host,api,host_mapping_file):
    import re
    rcstatus = 0
    env=host[:2]
    dcno=host[2:4]
    envnames = {
        'pc': 'PROD',
        'sc': 'PREVIEW',
        'ps': 'SALES'
    }
    envname = envnames.get(env, 'QA')
    print(f"envname: {envname}")
    file_path = host_mapping_file
    print("generating app templates .....")
    print(f'Regex file path:{file_path}')
    appTemplates=[]

    with open(file_path, "r") as file:
        regex_patterns = file.readlines()
        for regex_pattern in regex_patterns:
            # Compile the regex pattern
            #print(regex_pattern)
            regex_split_array=regex_pattern.split(":")
            #below 1 line is to add ^to the starting of the regex so that it should match from starting of the line .
            #Instead of updating all hostmapping.cnf file and testing it in per script is need.this is solve VIP-pq01jamdb-ilb01 false positive vaidation #
            
            regex_to_search="^"+regex_split_array[0]
            
            additionalAppTemplate=""
            y=re.search(regex_to_search,host)
            if(y):
                print(f'Matched regex:{regex_pattern}')


                if len((regex_split_array)) == 3:
                    additionalAppTemplate=regex_split_array[2].strip()
                    if additionalAppTemplate == "notemplate":
                        print("no app template since notemplate in regex line")
                    else:
                        tmp=additionalAppTemplate.split(",")
                        appTemplates.extend(tmp)
                        ###

                        hostGroupTemplateArray=[]
                        HgArray=regex_split_array[1].strip().split(",")
 
                        filtered_array=[element for element in HgArray if "_" in element]
                        groups=[]
                        for element in filtered_array:
                            parts = element.split('_')
                            prefixes = []
                            prefix = ''
                            for part in parts:
                                if prefix:
                                    prefix += '_'+part
                                    prefixes.append(prefix)
                                else:
                                    prefix = 'T'
                                
                            groups.extend(prefixes)
                        hostGroupTemplateArray=list(set(groups))
                        # print('printing hostgroup template array')
                        # print(hostGroupTemplateArray)

                        ##seach hostgroup template* with template.get 
                        all_templates=fetch_all_template_names(api)
                        # print("printing all templates")
                        # #print(all_templates)
                        matches=[]
                        for element in all_templates:
                            for hostGroupTemplate in hostGroupTemplateArray:
                                if re.search(hostGroupTemplate,element):
                                    if (element == hostGroupTemplate) :
                                        matches.append(element)
                        appTemplates.extend(matches)
                        matches1=[]
                        for hostGroupelement in filtered_array:
                            tmp1=hostGroupelement.split("_",1)
                            hostGroupTemplate1="T_"+tmp1[1]
                            matches1.append(hostGroupTemplate1)
                        
                        matches=[]
                        for element in all_templates:
                            for hostGroupTemplate in matches1:
                                if re.search(hostGroupTemplate,element):
                                    if ( hostGroupTemplate+"_" in element):
                                        matches.append(element)
                        appTemplates.extend(matches)                                   
                elif len((regex_split_array)) == 2:
                    hostGroupTemplateArray=[]
                    HgArray=regex_split_array[1].strip().split(",")
                    filtered_array=[element for element in HgArray if "_" in element]
                    # print("filtered array")
                    # print(filtered_array)
                    groups=[]
                    for element in filtered_array:
                        parts = element.split('_')
                        prefixes = []
                        prefix = ''
                        for part in parts:
                            if prefix:
                                prefix += '_'+part
                                prefixes.append(prefix)
                            else:
                                prefix = 'T'
                            
                        groups.extend(prefixes)
                    hostGroupTemplateArray=list(set(groups))
                    # print("regex has only 2 part")
                    # print('printing hostgroup template array')
                    # print(hostGroupTemplateArray)

                    ##seach hostgroup template* with template.get 
                    all_templates=fetch_all_template_names(api)
                    # print("printing all templates")
                    # #print(all_templates)
                    matches=[]
                    for element in all_templates:
                        for hostGroupTemplate in hostGroupTemplateArray:
                            if re.search(hostGroupTemplate,element):
                                if (element == hostGroupTemplate) :
                                    matches.append(element)
                    appTemplates.extend(matches)
                    matches1=[]
                    for hostGroupelement in filtered_array:
                        tmp1=hostGroupelement.split("_",1)
                        hostGroupTemplate1="T_"+tmp1[1]
                        matches1.append(hostGroupTemplate1)
                    
                    matches=[]
                    for element in all_templates:
                        for hostGroupTemplate in matches1:
                            if re.search(hostGroupTemplate,element):
                                if ( hostGroupTemplate+"_" in element):
                                    matches.append(element)
                    appTemplates.extend(matches)

                else:
                    print("Error in application hostmapping regex")
                for i in range(len(appTemplates)):
                            if '{envname}' in appTemplates[i]:
                                appTemplates[i] = appTemplates[i].replace('{envname}', envname)
                            if '{dcno}' in appTemplates[i]:
                                appTemplates[i] = appTemplates[i].replace('{dcno}', dcno)
                            if '{env}' in appTemplates[i]:
                                appTemplates[i] = appTemplates[i].replace('{env}', env)
                appTemplates1=(set(appTemplates))
                appTemplates= list(appTemplates1)
                if len((appTemplates)) == 0 and additionalAppTemplate != "notemplate" :
                    print("No regex match found")
                else:
                    print(f"app templates:{appTemplates} ")
            ###fectching os template####
                print("generating os templates .....")
                host_id = get_hostid(api, host)
                if host_id is None:
                    print(f"Host {host} not found in Zabbix")
                    # return []
                options = {'output': 'extend', 'filter': {'hostid': host_id, 'key_': 'system.uname'}}
                result = api.item.get(options)
                print(result)
                if not result:
                    print(f"No OS template found for host {host}")
                    rcstatus = 1

                # Extract the OS template name from the result
                # print(f"result: {result}")
                hostos = result[0]['lastvalue']
                # print(f"OS template name: {hostos}")


    ###############
                HgArray=regex_split_array[1].strip().split(",")
                hgparts=[]
                for element in HgArray:
                    parts = element.split('_')
                        # print("filtered array")
                        # print(filtered_array)
                    for part in parts:
                        hgparts.append(part)


                linux_product_templates = {
                    'BIZX-DB': 'T_HANA_Linux',
                    'BIZX': 'T_BizX_Linux',
                    'LMS': 'T_LMS_Linux',
                    'APIGEE': 'T_APIGEE_Linux',
                    'BOOMI': 'T_BOOMI_Linux',
                    'SPLUNK': 'T_SPLUNK_Linux',
                    'JAM': 'T_JAM_Linux',
                    'J2W': 'T_J2W_Linux',
                    'MOB': 'T_MOB_Linux',
                    'HANA': 'T_HANA_Linux',
                    'WFA': 'T_WFA_Linux',
                    'GEOIP': 'T_GeoIP_Linux',
                    'PAYROLL': 'T_PAYROLL_Linux',
                    'S4PAYROLL': 'T_S4PAYROLL_Linux',
                    'CONSUL': 'T_CONSUL_Linux',
                    'MAIL': 'T_MAIL_Linux',
                    'DSLMS': 'T_DS_Linux',
                    'ALL-AFW': 'T_AFW_Linux'
                }

                windows_product_templates = {
                    'DSLMS': 'T_DS_Windows',
                    'ONB': 'T_ONB_Windows',
                    'WFA': 'T_WFA_Windows',
                    'MSSQL_RST': 'T_MSSQL_Windows-RST',
                    'ALL-DB-MSSQL': 'T_MSSQL_Windows'
                }

                if "Linux" in hostos:
                    os_template = "T_OS_Linux"
                    # print(hgparts)
                    for i in hgparts:
                        # print(i)
                        if i.upper() in linux_product_templates:
                            print(linux_product_templates[i.upper()])
                            os_template = linux_product_templates[i.upper()]
                elif "Windows" in hostos:
                    os_template = "T_OS_Windows"
                    # print(hgparts)
                    for i in hgparts:
                        # print(i)
                        if i.upper() in windows_product_templates:
                            os_template = windows_product_templates[i.upper()]
                else:
                        os_template = "none"
                        print('hostos not found')
                        rcstatus = 1
                    
                # print(f"OS template name: {os_template}")
                if os_template == "T_BizX_Linux":
                    appTemplates.append("T_BIZX_AD")
                if os_template == "T_LMS_Linux":
                    appTemplates.append("T_LMS_AD")
                    # return []

                Templates=[]
                Templates.extend(appTemplates)
                Templates.append(os_template)
                #taken only unique values from both above array
                # Templates1=(set(Templates))
                # Templates= list(Templates1)
                return rcstatus,Templates
#########
def check_jmx(hostgroups, jmxcfgfile):
        jmxport = "false"
        with open(jmxcfgfile, 'r') as fh:
            lines = fh.readlines()
            for hstgroup in hostgroups:
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        regex, port = line.split(':')
                        if re.match(regex, hstgroup):
                            jmxport = port
        return jmxport

def host_create_jmxinterface(host_id,host_ip,jmx_port):

    # Check if a JMX interface already exists for the host
    params = {'output': 'extend', 'selectInterfaces': 'extend', 'filter': {'hostid': host_id}}
    host_info = api.host.get(params)
    
    if not host_info or 'interfaces' not in host_info[0]:
        print("Host not found or no interfaces available.")
        return

    for interface in host_info[0]['interfaces']:
        if interface['type'] == '4':  # Type 4 corresponds to JMX interface
            print("JMX interface already exists.")
            return

    # Create a new JMX interface
    new_interface = {
        'type': 4,  # JMX interface type
        'main': 1,  # Mark as default interface
        'useip': 1,  # Use IP instead of DNS
        'ip': host_ip,
        'dns': "",
        'port': jmx_port
    }

    try:
        result = api.hostinterface.create({
            'hostid': host_id,
            **new_interface
        })
        print("JMX interface created successfully:", result)
    except Exception as e:
        print("Error creating JMX interface:", e)


def host_create_macro(api,host_id, host_ip, macro_name):
    # Check if the macro already exists
    params = {'output': 'extend', 'hostids': host_id, 'selectMacros': 'extend'}
    host_info = api.host.get(params)
    
    if not host_info or 'macros' not in host_info[0]:
        print("Host not found or no macros available.")
        return

    for macro in host_info[0]['macros']:
        if macro['macro'] == macro_name:
            print("Macro already exists.")
            return

    # Create a new macro
    new_macro = {
        'hostid': host_id,
        'macro': macro_name,
        'value': host_ip
    }

    try:
        result = api.usermacro.create(new_macro)
        print("Macro created successfully:", result)
    except Exception as e:
        print("Error creating macro:", e)






def get_host_ip(api,host_id):
  options = {'output': 'extend', 'hostids': host_id, 'filter': {'type': '1', 'main': '1'}}
  myresult =api.hostinterface.get(options)
  print(myresult)
######
#[{'interfaceid': '12154', 'hostid': '20611', 'main': '1', 'type': '1', 'useip': '1', 'ip': '10.1.128.28', 'dns': 'pq01loadwin2004.dc001.sf.priv', 'port': '10050', 'available': '0', 'error': '', 'errors_from': '0', 'disable_until': '0', 'details': []}]

  print("prining mysesult ip")
  print(myresult[0]['ip'])
  return myresult[0]['ip'] if 'ip' in myresult[0] else 'NO IP'


def add_hostgroups_to_host(api,hostid, host_groups):

    #add All-NotLive-Hosts-Maintenance group also to to host_groups
    host_groups.append('All-NotLive-Hosts-Maintenance')
    #get groupid from the hostgroup name list host_groups
    group_ids = []
    for group in host_groups:
        params = {'output': 'extend', 'filter': {'name': group}}
        group_info = api.hostgroup.get(params)
        
        if group_info:
            group_ids.append(group_info[0]['groupid'])
        else:
            print(f"Host group {group} not found.")
            #create the host group if not found
            group_info = api.hostgroup.create({
                'name': group
            })
            group_ids.append(group_info['groupids'][0])
            print(f"Created host group {group} with ID {group_info['groupids'][0]}")
    # Check if the host exists
    params = {'output': 'extend', 'hostids': hostid}
    host_info = api.host.get(params)
    
    if not host_info:
        print("Host not found.")
        return

    # Get the group IDs to be added
    group_objects = [{'groupid': group_id} for group_id in group_ids]

    # Update the host with the new groups
    try:
        api.host.update({
            'hostid': hostid,
            'groups': group_objects
        })
        print(f"Updated host {hostid} with new host groups: {group_ids}")
    except Exception as e:
        print(f"Error updating host groups for host {hostid}: {e}")

def add_templates_to_host(api,hostid, tempate_list):
    # Check if the host exists
    params = {'output': 'extend', 'hostids': hostid}
    host_info = api.host.get(params)
    
    if not host_info:
        print("Host not found.")
        return

    # Get the current templates
    current_templates = host_info[0].get('templates', [])
    current_template_ids = {template['templateid'] for template in current_templates}

    # Remove all existing templates from the host
    current_template_ids_list = list(current_template_ids)
    if current_template_ids_list:
        api.template.massremove({
            'templateids': current_template_ids_list,
            'hosts': [{'hostid': hostid}]
        })
        print(f"Removed all existing templates from host {hostid}")

    # Add the new templates to the host
    for template in tempate_list:
        params = {'output': 'extend', 'filter': {'host': template}}
        template_info = api.template.get(params)
        
        if template_info:
            api.host.update({
                'hostid': hostid,
                'templates': [{'templateid': template_info[0]['templateid']}]
            })
            print(f"Added template {template} to host {hostid}")
        else:
            print(f"Template {template} not found.")
def add_to_failed_grp(api,hostid):
    # Check if the host exists
    params = {'output': 'extend', 'hostids': hostid}

    # Get the group IDs to be added
    failed_group = "failed_automation"
    #get groupid from the group name failed_automation
    params = {'output': 'extend', 'filter': {'name': failed_group}}
    group_info = api.hostgroup.get(params)
    if group_info:
        group_id = group_info[0]['groupid']
    else:
        # Create the group if it doesn't exist
        print(f"Group {failed_group} not found..")

    group_objects = [{'groupid': group_id}]  # Replace with the actual group ID for failed hosts

    # Update the host with the new groups
    try:
        api.host.update({
            'hostid': hostid,
            'groups': group_objects
        })
        print(f"Added host to failed_automation group")
    except Exception as e:
        print(f"Error updating host groups for host {hostid}: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="Script to validate or update Zabbix host ."
    )
    parser.add_argument("-validatehost", type=str, help="Validate host")
    parser.add_argument("-updatehost", type=str, help="Update host")

    args = parser.parse_args()

    # Validate required arguments
    if not any(
        [
            args.validatehost,
            args.updatehost,

        ]
    ):
        sys.exit(
            """
            Missing options:
                -validatehost  <host> (OR) -updatehost  <host>  [ -dc DC22 ]


                Example: script.py -updatehost hostA
            """
        )


    config_file = f"./zbx.conf"
    print(f"Using config file: {config_file}")
    config = get_rsm_config(config_file)
    host_mapping_file = config['sap']['hostcfg']
    jmxcfgfile = config['sap']['jmxcfg']
    host = args.validatehost or args.updatehost
    api=zabbix_api(host,config)
    existingTemplates = fetch_all_template_names(api)

    # print(f"Existing templates: {existingTemplates}")
    if args.validatehost :
        print(f"Validating host: {host}")
        rc, msg,hostid = check_valid_host(api,host,host_mapping_file)
        # print(msg)
        # print(rc)
        # if rc:
        #     print(f"{host} {msg}")
        #     print("Aborting.......")
        #     exit(1)

        cgroups = search_host_groups(host,host_mapping_file)
        print(f"Child Hostgroups: {cgroups}")
        host_groups=generate_host_groups(cgroups)
        print(f"Generated host groups: {host_groups}")
        rc,tempate_list=generate_template(host,api,host_mapping_file)
        # if rc:
        #     print(f"{host}")
        #     print("Aborting.......")
        #     exit(1)
        print(f"Generated templates: {tempate_list}")
        current_hostgroups = api.hostgroup.get({'output': 'extend', 'hostids': hostid})
        current_hostgroups = [group['name'] for group in current_hostgroups]
        print(f"Current host groups: {current_hostgroups}")
        current_templates = api.template.get({'output': 'extend', 'hostids': hostid})
        current_templates = [template['name'] for template in current_templates]
        print(f"Current templates: {current_templates}")
        print("Host validation completed")
#####-------------------------------#########
    if args.updatehost: 
        print(f"Validating host: {host}")
        rc, msg,hostid = check_valid_host(api,host,host_mapping_file)
        print(msg)
        print(rc)
        if rc:
            add_to_failed_grp(api,hostid)
            print(f"{host} {msg}")
            print("Aborting.......")
            exit(1)

        cgroups = search_host_groups(host,host_mapping_file)
        print(f"Child Hostgroups: {cgroups}")
        host_groups=generate_host_groups(cgroups)
        print(f"Generated host groups: {host_groups}")
        rc,tempate_list=generate_template(host,api,host_mapping_file)
        print(f"Generated templates: {tempate_list}")
        if rc:
            add_to_failed_grp(api,hostid)
            print(f"{host} {msg}")
            print("Aborting.......")
            exit(1)

        current_hostgroups = api.hostgroup.get({'output': 'extend', 'hostids': hostid})
        current_hostgroups = [group['name'] for group in current_hostgroups]
        print(f"Current host groups: {current_hostgroups}")
        current_templates = api.template.get({'output': 'extend', 'hostids': hostid})
        current_templates = [template['name'] for template in current_templates]
        print(f"Current templates: {current_templates}")
        print("Host validation completed")

        print(f"Updating host: {host}")
        # Get Host IP
        host_ip = get_host_ip(api,hostid)
        print(f"IP: {host_ip}")
        # add_to_logfile(f"IP - {ip}", "")

#         # Create IP user macro
        host_create_macro(api,hostid, host_ip, '{$MY_IP}')
#         add_to_logfile("Created MY_IP macro", "")
# Check JMX Interface
        jmxport = check_jmx(host_groups, config['sap']['jmxcfg'])
        if jmxport == 'false':
            print("JMX Interface Not required")
            # add_to_logfile("JMX Interface Not required", "")
        else:
            host_create_jmxinterface(hostid,host_ip,jmxport)
            print(f"JMX Interface added - Port {jmxport}")
# Add hostgroups to host 
        add_hostgroups_to_host(api,hostid, host_groups)
        print(f"Host groups added: {host_groups}")
# Add templates to host
        add_templates_to_host(api,hostid, tempate_list)
        print(f"Templates added: {tempate_list}")
        print("End of Autoregistration Process")
        print("--------------------------")
    api.logout()
    print("Logged out of Zabbix API")
    #add_to_logfile("End of Autoregistration Process", "")
#
#--------------------------------#########
#add logging to /var/log/zabbix/zbxapi.log




if __name__ == '__main__':
    main()
