#!/usr/bin/perl -w

###########################################################
# Author  : Pradip Kumar K
# Purpose : Script to generate events for a time frame
# Date    : Dec 2016
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);
use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
    chomp $line;
    if ($line ne "" and $line =~ m/lab/ )
    {
        $env = 'qa';
    }
    else { $env = 'prod' ; }
}

# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


my %args;

GetOptions(\%args, "hostGroup=s","time_from=s","time_till=s" ) or die "Invalid arguments \n";
if( ! %args ) {
    die "$0 -hostGroup <grp Name> -time_from <timestamp> -time_till <timestamp>       
        Example: $0 -hostGroup pc2 -time_from 1472728835 -time_till 1479718319
                 where 1472728835=2016-09-01  and 1479718319=2016-11-21 \n";
 ##2016-11-21 = 1479718319
    # 2016-09-01 #1472728835

}

my $time_from = $args{time_from};
my $time_till = $args{time_till};
my %priorityMap = (  
                     0 => 'Not classified',
                     1 => 'Information',
                     2 => 'Warning',
                     3 => 'Average',
                     4 => 'High',
                     5 => 'Immediate'
                  );

my @inp_hostGrps;
# Get hostgroup from commandline
if ( exists $args{hostGroup} ) {
    push @inp_hostGrps, $args{hostGroup};
}

my @HgrpIds = getHostgroupID(@inp_hostGrps);
if( ! @HgrpIds ) {
    print "Host Group doesn't exist in Zabbix or invalid group name \n";
    exit 1;
}

foreach my $hGrpId ( @HgrpIds ) {

    print "Host Name| Host Groups | Alert Name| Current Status| Priority| Alert Generated Time\n";
    my @hostData = getHostIds_fromHostgroup($zabbix, $hGrpId);
    foreach my $hostDataRef( @hostData ) {

    my $hostName = $hostDataRef->{hostname};
    my $hostId   = $hostDataRef->{hostid};
    my $hostGrpStr = $hostDataRef->{hostGrps};
    ##2016-11-21 = 1479718319
    # 2016-09-01 #1472728835
    my %params = ( 'output' => 'extend', 'hostids' => $hostId, 'select_alerts' => 'extend', 'time_from' => $time_from, 'time_till' => $time_till );

    my $myresult = $zabbix->raw('event','get',\%params);
    next if ( ref $myresult eq 'HASH'  &&  ! %$myresult );

    if ( ref($myresult) eq 'ARRAY' ){ 
    foreach my $result ( @$myresult ) {
        my $trigger_status= $result->{value};
        $trigger_status = ($trigger_status == 1 ) ? 'Problem' : 'OK';
        my $triggerId = $result->{objectid};
        my %params = ( 'output' => [ 'description', 'priority' ], 'triggerids' => $triggerId, 'expandDescription' => 1,
                   'filter' => { 'priority' => [ 2,3,4,5 ] } );
        my $trigresult = $zabbix->raw('trigger','get',\%params);
        next if ( ref $trigresult eq 'HASH'  &&  ! %$trigresult );
        my $alertName = $trigresult->{description};
        my $priority = $trigresult->{priority};
        $priority = $priorityMap{$priority};

        my $clock = $result->{clock};
        my $convertedTime = convertTimeStamp($clock);

        print "$hostName| $hostGrpStr | $alertName| $trigger_status| $priority| $convertedTime\n";
    }
    }
    else {
        my $trigger_status= $myresult->{value};
        $trigger_status = ($trigger_status == 1 ) ? 'Problem' : 'OK';
        my $triggerId = $myresult->{objectid};
        my %params = ( 'output' => [ 'description', 'priority' ], 'triggerids' => $triggerId, 'expandDescription' => 1, 'filter' => { 'priority' => [ 2,3,4,5 ] } );
        my $trigresult = $zabbix->raw('trigger','get',\%params);
        next if ( ref $trigresult eq 'HASH'  &&  ! %$trigresult );
        my $alertName = $trigresult->{description};
        my $priority = $trigresult->{priority};
        $priority = $priorityMap{$priority};
        my $clock = $myresult->{clock};
        my $convertedTime = convertTimeStamp($clock);
        print "$hostName| $hostGrpStr | $alertName| $trigger_status| $priority| $convertedTime\n";
    }
    }
}


sub convertTimeStamp {
    my ( $time ) =  @_ ;


    ##onvert epoch to zabbix time format and use EST timezone
    my $convertedTime = `TZ=America/New_York date -d \@$time '+%Y-%m-%d %H:%M:%S'`;
    chomp($convertedTime);

    return $convertedTime;
}

sub getHostIds_fromHostgroup {

    my $zabbix = $_[0];
    my @HG_ID = $_[1];
    my @hostIds;

    my $options = {'output' => 'extend', 'selectGroups' => 'extend', 'groupids' => @HG_ID };
    my $myresult = $zabbix->raw('host','get',$options);
    if ( ref($myresult) eq 'ARRAY' ){
        foreach my $h (@{$myresult}){
            my @childGrps = @{$h->{groups}};
            my $grpStr = "";
            foreach my $childGrp ( @childGrps ) {
                $grpStr = $childGrp->{name} . "~" . $grpStr ;
            }
            $grpStr =~ s/~$//;
            push @hostIds, {'hostid' => $h->{'hostid'}, 'hostname' => $h->{'name'}, 'hostGrps' => $grpStr } ;
        }
    } else{
        my @childGrps = @{$myresult->{groups}};
        my $grpStr = ""; 
        foreach my $childGrp ( @childGrps ) {
            $grpStr = $childGrp->{name} . "~" . $grpStr ;
        }
        $grpStr =~ s/~$//;
        push @hostIds, { 'hostid' => $myresult->{'hostid'},'hostname' => $myresult->{'name'}, 'hostGrps' => $grpStr };
    }
    return @hostIds;
}

