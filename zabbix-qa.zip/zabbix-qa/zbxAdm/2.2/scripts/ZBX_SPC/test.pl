#!/usr/bin/perl
use strict;
use warnings;

use lib qw ( /usr/local/etc/zbxAdm/2.2/lib/perl5 );
use lib qw ( /usr/local/etc/zbxAdm/2.2/lib/myCorelib/lib/perl5 );
use lib qw ( /usr/local/etc/zbxAdm/2.2/lib/lib/perl5 );
use lib qw ( /usr/local/etc/zbxAdm/2.2/lib/myCorelib/lib/perl5/lib/perl5 );

#use File::Basename qw(dirname);
#use Cwd  qw(abs_path);
#use lib dirname(abs_path $0) . '/lib';



use Config::Simple;

my $cfg = new Config::Simple('/usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/zbxSPC.ini');

my $env;

open(my $fh,'< /etc/hosts');
while (my $line = <$fh>) 
{
   chomp $line;
   if ($line ne "" and $line =~ m/lab/ )
	{
	$env = 'qa';
	}
    else { $env = 'prod' ; }
}

close($fh); 

	my $url = $cfg->param("$env.bldurl");
	print "$url\n";
	


