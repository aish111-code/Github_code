#!/usr/bin/perl -w

##################################################################################################################
# Success Factors                                                                                                #
#                                                                                                                #
# Description : Program to create incidents in SPC from Zabbix Monitoring tool                                   #
#               This program is called by SPC_Notification_Wrapper.sh                                            #
#                                                                                                                #
# Changes :                                                                                                      #
# Date Modified              Developer           CID               Description of teh changes made               #
# -------------              ---------           ---               -------------------------------               #
#  03/06/2012               Ketan Vittal       C5165361                   Initial Code                           #
#  07/26/2012               Ketan Vittal       C5165361                 Implemented SIM                          #
#  12/21/2012               Sandeep M.R        C5182416                 Included SFSF Requirements               #
#  12/27/2012               Sandeep M.R        C5182416                 Implemented Zabbix recovery scenario     #
#  02/18/2013		    Sankar B  	       C5149745			Modified Incident description		 #
#  02/27/2013               Sandeep M.R        C5182416                 Implemented changes for BLD Integration  #
#  05/06/2013               Sandeep M.R        C5182416                 Made changes for using generic SPC User  #
#  06/12/2013               Ketan Vittal       C5165361                 Implemented IV_EVENT_KEY element         #
#  Dec 6th 2013             Sandeep M.R        C5182416                 Added code to handle spc maintenance     #
#  Dec 27th 2013            Sandeep M.R        C5182416                 Added Hostgroup and Template name to incident comment #
#  Jan 9th 2015             Sandeep M.R        C5182416                 Bug fix to escape special characters in description #
###################################################################################################################

use strict;
use warnings;

######################################## Libraries included ################################################################################

require LWP;
require HTTP::Request;
use MIME::Base64;       # $encoded = encode_base64('Aladdin:open sesame');
use XML::Simple;
use Data::Dumper;
use Net::SMTP;
use Switch;


######################################## Parameters passed in from the Wrapper Script #########################################################

print "Entering SPC script\n";

my $searchName = $ARGV[0];
my $searchQuery = $ARGV[1]; # $1 - Fully qualified query string with the Check Group and Check ID details within
my $searchTerms = $ARGV[2]; #2 - 
my $ReturnDesc = $ARGV[3]; # $3 - Return description from Zabbix
my $alertTime = $ARGV[4]; # $4 - Time at which the alert occured
my $application = $ARGV[5]; # $5 - Application Name
my $LoggedHost  = $ARGV[6]; # $6 - Host on which the error occured
my $xlandscape = $ARGV[7]; # $7 - Landscape on which the error occured
my $logfile = $ARGV[8]; # $8 - SPC Log Location
#my $logfilesim = $ARGV[9]; # $9 - SIM Log location
#my $nodename = $ARGV[10]; # $10 - Nodename of the XML to be sent to SIM
my $zabbixEventState = $ARGV[9];
my $itemFile = $ARGV[10];
my $lf = $ARGV[11];
my $Severitylevel = $ARGV[12];
#my $eventlist = $ARGV[13];
my $eventlist = xml_encode($ARGV[13]);
my $fed = $ARGV[14];
my $hostgroup = $ARGV[15];
my $template = $ARGV[16];
my $logdir = $ARGV[17];
my $confdirspcConf = $ARGV[18];

print "Arguments Passed are:\n";

print "1 = $searchName\n";
print "2 = $searchQuery\n";
print "3 = $searchTerms\n";
print "4 = $ReturnDesc\n";
print "5 = $alertTime\n";
print "6 = $application\n";
print "7 = $LoggedHost\n";
print "8 = $xlandscape\n";
print "9 = $logfile\n";
#print "10 = $logfilesim\n";
#print "11 = $nodename\n";
print "10 = Zabbix state $zabbixEventState\n";
print "11 = Item1 value $itemFile\n";
print "12 = lock file in perl is $lf\n";
print "13 = $Severitylevel\n";
print "14 = $eventlist\n";
print "15 = $fed\n";
print "16 = $hostgroup\n";
print "15 = $template\n";
print "17 = $logdir\n";
print "18 = $confdirspcConf\n";

######################################## Initialization and Declaration of variables #########################################################

our $myMailSender;
our $myMailReceiver;
our $myMailSMTPServer;
our $myMailSubject;
our $smtp;
my $ALERT_DESCRIPTION  = '';
my $ALERT_CONDITION = '';
my $con_alert_time = '';
my $date = '';
my $timestamp = '';
my $to = '';
my $subject = '';
my $body = '';
my $parameter_line = '';
my $searchPrio = '';
my $i = '';
my $fileencode = '';
my $filestring = '';
my $oldincidentid = '';
my $incidentid = '';
my $r_content = '';
my $r_code = '';
my $r_message = '';
my $r_all = '';
my $counter = '';
my $xml = '';
my $responsetype = '';
my $responseno = '';
my $responsemsg = '';
my $fileContent = '';
my $returnvalue = '';
my $isFirstLine = '1';
my $isSecondLine = '0';
our $to_list;
our $from;
my $fullFileName;
my $closurefile;
our $url;
our $usr;
our $pwd;
my $tenant_id = '';
our $bldurl;
my $simfullFileName;
our $simurl;
our $simusr;
our $simpwd;
my $simoldincidentid = '';
my $simincidentid = '';
my $r_contentsim = '';
my $r_codesim = '';
my $r_messagesim = '';
my $r_allsim = '';
my $simxml = '';
my $MessageResult = '';
my $x;
my $y;
my $z;
my $p;
my $SPCEventState;
my $vdate;

my $IV_SUB = '';
my $queueclose1 = '';
my $updateRC = '';

my %ESCAPES = (
    '&' => '&amp;',
    '<' => '&lt;',
    '>' => '&gt;',
    '"' => '&quot;',
);

my $scriptsource = '';

######################################## Include External Files ################################################################################ 

#require("$confdirspcConf/spcConf/SFSF.config");
require("$confdirspcConf/SFSF.config");

########################################PROGRAM LOGIC STARTS HERE ##############################################################################

open (LOGFILE, "> $logfile") || die "problem opening $logfile\n";

$scriptsource = `hostname`;

my $description = <<EODESC;
***** $application $xlandscape System Alert Details *****

Monitoring Tool : Zabbix
Hostname         : $LoggedHost
Hostgroup         : $hostgroup
Template          : $template
Service Check   : $searchQuery
Event Date/Time : $alertTime

Event state     : $zabbixEventState
Event Severity  : $Severitylevel
Error Summary   :
	$eventlist

Integration Program source : $scriptsource

EODESC



my %data = (
                                client => '000',
                                host => 'TBD',
                                sid => '',
                                description => $description,
                                link => $xlandscape,
                                priority => $searchPrio,
                                subject => "$searchName / $searchQuery",
                                tenant => '',
                                reference => '',
                                checkgroup => '',
                                checkid => ''
);

my $alerttype = $searchName;

print "\n DEBUG: this is the alert type ==> $alerttype \n";

my %hashPriority = (
		"Immediate"  => {"value", '1'},
		"High"      => {"value", '2'},
		"Average"     => {"value", '3'},
		"Warning"      => {"value", '3'},
		"Information" => {"value", '7'},
);

my %hashCheckGroup = (
                "OS"                    => {"value", "$application"."_OS"},
                "APP"                 => {"value", "$application"."_APP"},
                "DB"                   => {"value", "$application"."_DB"},
                "HOST"                 => {"value", "$application"."_HOST"},
		"BASIS"                 => {"value", "$application"."_BASIS"},
);

my @splitAlert = split (/ /, $alerttype);
my @splitGroupAndId = split (/_/, $splitAlert[1]);

$alerttype = "";
for($i=0;$i<@splitAlert;++$i)
{
	if ($i > 1 && !($splitAlert[$i] eq "percent" || $splitAlert[$i] eq "70" || $splitAlert[$i] eq "80" || $splitAlert[$i] eq "90" ))
	{
		$alerttype = $alerttype . " " .  $splitAlert[$i];
	}
}

sub trim($)
{
        my $string = shift;
        $string =~ s/^\s+//;
        $string =~ s/\s+$//;
        return $string;
}

$alerttype = trim($alerttype);
$data{checkgroup} = $hashCheckGroup{$splitGroupAndId[0]}{'value'};
#$data{checkid} = '000' . $splitGroupAndId[1];
$data{checkid} = $splitGroupAndId[1];
$data{priority} = $hashPriority{$splitAlert[0]}{'value'};

print "\n DEBUG: Zabbix Severity is $splitAlert[0] \n";

switch ($application) {

case "BIZX"             { $tenant_id = "000000000740022056"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "LMS"              { $tenant_id = "000000000740022057"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "JAM"              { $tenant_id = "000000000740022053"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "WFA"              { $tenant_id = "000000000740022068"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "NFL"		{ $tenant_id = "000000000510026668"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "BOOMI"            { $tenant_id = "000000000740090103"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "KMS"              { $tenant_id = "000000000740023929"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "J2W"		{ $tenant_id = "000000000740115869"; print "\n DEBUG: tenant value is $tenant_id \n"; }
case "DSLMS"		{ $tenant_id = "000000000500005846"; print "\n DEBUG: tenant value is $tenant_id \n"; }
else                    { $tenant_id = "000000000740022056"; print  "\n DEBUG: tenant value is $tenant_id \n"; }
}

if ( $fed ne "1" )
{

switch ($data{checkgroup}) {

case /OS/             { $tenant_id = "000000000740110622"; print "\n DEBUG: Federal OS tenant value is $tenant_id \n"; }
case /APP/             { $tenant_id = "000000000740111569"; print "\n DEBUG: Federal APP tenant value is $tenant_id \n"; }
else                    { print  "\n DEBUG: tenant value is $tenant_id \n"; }
}



}



my $encoded = '';
my $xmlParser = new XML::Simple();

my $hccontext = <<EOHCC;
        <spr:ContentCollection xmlns:spr="http://www.sap.com/spr"><spr:Content xmlns:spr="http://www.sap.com/spr" ContextId="IncidentCreator" Sanity="" Size="3732">
        <HealthCheckContext>
        <CheckGroup></CheckGroup>
        <CheckID></CheckID>
        <EventID></EventID>
        <EventType/><CreationTimeUTC></CreationTimeUTC><LastUpdateTimeUTC></LastUpdateTimeUTC><SessionNumber></SessionNumber><KeyField1></KeyField1><KeyField2></KeyField2>
        <DiagnosticInformation>
        <Item><Name></Name><Value></Value></Item>
        <Item><Name></Name><Value></Value></Item><Item><Name></Name><Value/></Item>
        <Item><Name></Name><Value></Value></Item>
        </DiagnosticInformation>
        <Description><OptionalURL>/$data{checkgroup}_$data{checkid}/DE_$data{checkgroup}_$data{checkid}_01.xml</OptionalURL>
        </Description>
        <RecommendedAction><OptionalURL>/$data{checkgroup}_$data{checkid}/RA_$data{checkgroup}_$data{checkid}_01.xml</OptionalURL></RecommendedAction>
        <ErrorInformation>
        <Item><Name></Name><Value></Value></Item></ErrorInformation>
        <ErrorInformation/>
        <ContextInformation>
        <Item><Name></Name><Value></Value></Item></ContextInformation>
        <BusinessInformation><SoftwareEntity><SoftwareEntityCode></SoftwareEntityCode><ID></ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>IncidentCategory</SoftwareEntityCode><ID>0000030001</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationComponent</SoftwareEntityCode><ID>LOD-CI</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>BusinessObject</SoftwareEntityCode><ID>ApplicationManagementTaskMonitorEnhancedController</ID><NameSpace>http://sap.com/xi/A1S</NameSpace><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationArea</SoftwareEntityCode><ID>1004</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity></BusinessInformation></HealthCheckContext></spr:Content></spr:ContentCollection>
EOHCC

        #Encode HC Context to Base64
$encoded = encode_base64($hccontext);
$fileencode = '';
$filestring = '';

#my $alertTypeForFileName = $alerttype;
my $alertTypeForFileName = $itemFile;


$alertTypeForFileName =~ s/ /_/g;
$fullFileName = "$logdir/$application-$LoggedHost-$alertTypeForFileName-$xlandscape";

$closurefile= "$fullFileName-OK";


my $response;

my $bldxml = <<EOXML;
                         <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="http://sap.com/xi/SAPGlobal20/Global" xmlns:rfc="urn:sap-com:sap:rfc:functions">
                           <soap:Header/>
                           <soap:Body>
                                  <urn:WSQueryRequestMessage>
                               <Instance>$LoggedHost</Instance>
                                 </urn:WSQueryRequestMessage>
                           </soap:Body>
                        </soap:Envelope>
EOXML

                if (getBLDstatus("new", $bldxml, $bldurl, $usr, $pwd) eq 1)
                {
                        print "DEBUG: BLD Web service called successfully , admin tenant id is $tenant_id \n";

                }
                else
                {
                        print "DEBUG: BLD Web service failure, processing with default admin tenant id $tenant_id !! \n";
                }


		# temporary patch for dc16 hostgroups

		if ( $hostgroup =~ /DC16/ )
		{

		 $tenant_id = "000000000740165466" ;

		 print "DBUG: Processing with DC16 tenant, $tenant_id\n";

		}

if (-s $fullFileName)
{
   ################################ Alert exists ############################################################## 

		print "\n DEBUG: $fullFileName File Exists! \n";

                open (F1, $fullFileName) || die "problem opening $fullFileName\n";
                $oldincidentid = <F1>;

                print "\n DEBUG: Need to check if $oldincidentid is still open! \n";

                my $xml = <<EOXML;
                        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                           <soap:Header/>
                           <soap:Body>
                                  <urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                                         <IT_CONTEXT_PROVIDER>
                                                <item>
                                                   <PROVIDER_ID>/SAP/ABAP/HealthCheck/CheckContextProvider</PROVIDER_ID>
                                                   <CONTEXT_TYPE>5</CONTEXT_TYPE>
                                                   <CONTENT>$encoded</CONTENT>
                                                </item>
                                                <item>
                                                   <PROVIDER_ID>/SAP/BYDMS/River/SplunkAttachment</PROVIDER_ID>
                                                   <CONTEXT_TYPE>1</CONTEXT_TYPE>
                                                   <CONTENT>$fileencode</CONTENT>
                                                </item>
                                         </IT_CONTEXT_PROVIDER>
                                         <IV_CHECK_GROUP>$data{checkgroup}</IV_CHECK_GROUP>
                                         <IV_CHECK_ID>$data{checkid}</IV_CHECK_ID>
					 <IV_EVENT_KEY>$data{checkgroup}$data{checkid}01</IV_EVENT_KEY>
                                         <IV_DESCRIPTION>$data{description}</IV_DESCRIPTION>
                                         <IV_DETAIL_LINK></IV_DETAIL_LINK>
                                         <IV_INCIDENT_PROCESS>SYSTEM INCIDENT</IV_INCIDENT_PROCESS>
					 <IV_ISSUE_CATEGORY>30107</IV_ISSUE_CATEGORY>
                                         <IV_PRIORITY>$data{priority}</IV_PRIORITY>
					 <IV_PROCESS>32</IV_PROCESS>
                                         <IV_PROFILE></IV_PROFILE>
                                         <IV_REFERENCE_ID></IV_REFERENCE_ID>
                                         <IV_SUBJECT>$searchTerms</IV_SUBJECT>
                                         <IV_SYSTEM_ID></IV_SYSTEM_ID>
                                         <IV_TENANT_ID>$tenant_id</IV_TENANT_ID>
                                </urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                           </soap:Body>
                        </soap:Envelope>
EOXML

		print "DEBUG : Value of xml is $xml", "\n";

		$updateRC = sendUpdate("empty");
		print "DEBUG : Value of updateRC is $updateRC";

	
                if ( $updateRC eq 1 )
		{
                        print "\n DEBUG: Incident $oldincidentid is still open! \n";
                        # SMR Check if Zabbix event state and SPC event state is PROBLEM
                        $vdate = `date`;
                        print "\n DEBUG: Time Stamp $vdate \n";

                      if ( $zabbixEventState ne "OK" )
                      {

                       print "\n DEBUG: Zabbix event state: $zabbixEventState\n";

                        # SMR Check if zabbix priority changed and update spc incident comment with new priority details

                       open (FILE, "$fullFileName") || die "problem opening $fullFileName\n";
                       $x = <FILE>;
                       $y = <FILE>;
                       $z = <FILE>;
                       $p= <FILE>;
                       
                       print "\n DEBUG: Priority of $oldincidentid in SPC is $p \n";
                       print "\n DEBUG: Priority of Zabbix alert is $data{priority} \n";            
                       
                       if ( $p != $data{priority} )
                       {
                                 close(FILE); 
				 # Update old incident with incidentid of new incident and new priority
                        
				print "\n DEBUG:  now updating the original id: $oldincidentid in SPC \n";        
				sendUpdate("new");
                                print "\n DEBUG: Updated old incident: $oldincidentid, now exit \n";
				
                                	print "\n DEBUG: Done everything, see you next time around! \n";

                                        $vdate = `date`;
                                        print "\n DEBUG: Time Stamp $vdate \n";

                                 # update file with new SPC incident details

                         $counter = '1';
                         open (FILE1, "> $fullFileName") || die "problem opening $fullFileName\n";
                         print FILE1 $oldincidentid;
                         print FILE1 "\n";
                         print FILE1 $timestamp;
                         print FILE1 "\n";
                         print FILE1 $counter;
                         print FILE1 "\n";
                         print FILE1 $data{priority};
                         print FILE1 "\n";
                         close(FILE1);
      

                      }
                      else
                      {
                      print "\n DEBUG: No change in priority, exit \n";
                      close(FILE);

                      }
                   }
                   else
                   {
                   print "\n DEBUG: Event State Mismatched, Zabbix : $zabbixEventState\n";
                 #  close (FILE3);
                  
                 # SMR Auto closure for Zabbix OK alert

                 #`sleep 6`;
                 # print "\n DEBUG: Slept for 6s\n";
                 # open (F2, $fullFileName) || die "problem opening $fullFileName\n";
                 # $oldincidentid = <F2>;
                   
                    if (sendClose("new") eq 1)
                                {
                                        print "\n DEBUG: Auto Closed SPC incident: $oldincidentid \n";
                                        print "\n DEBUG: Done everything, Bye Bye! \n";
                                        $vdate = `date`;
                                        print "\n DEBUG: Time Stamp $vdate \n";

                                }
                                else
                                {
                                        print "DEBUG: Auto Closing  SPC incident $oldincidentid in SPC, FAILED !!! \n"
                                } 
                  #  close(F2);  
                   }

                }
                else 
                {


                      if ( $zabbixEventState ne "OK" )
                      {         

                        print "\n DEBUG: Old incident $oldincidentid is closed in SPC, hence creating a new one \n";



			$IV_SUB = xml_encode($searchTerms);
			print "\n value of IV-SUB is $IV_SUB";



	
       		        my $xml = <<EOXML;
                        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                           <soap:Header/>
                           <soap:Body>
                                  <urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                                         <IT_CONTEXT_PROVIDER>
                                                <item>
                                                   <PROVIDER_ID>/SAP/ABAP/HealthCheck/CheckContextProvider</PROVIDER_ID>
                                                   <CONTEXT_TYPE>5</CONTEXT_TYPE>
                                                   <CONTENT>$encoded</CONTENT>
                                                </item>
                                                <item>
                                                   <PROVIDER_ID>/SAP/BYDMS/River/SplunkAttachment</PROVIDER_ID>
                                                   <CONTEXT_TYPE>1</CONTEXT_TYPE>
                                                   <CONTENT>$fileencode</CONTENT>
                                                </item>
                                         </IT_CONTEXT_PROVIDER>
                                         <IV_CHECK_GROUP>$data{checkgroup}</IV_CHECK_GROUP>
                                         <IV_CHECK_ID>$data{checkid}</IV_CHECK_ID>
                                         <IV_EVENT_KEY>$data{checkgroup}$data{checkid}01</IV_EVENT_KEY>
                                         <IV_DESCRIPTION>$data{description}  Incident on the same issue : $oldincidentid</IV_DESCRIPTION>
                                         <IV_DETAIL_LINK></IV_DETAIL_LINK>
                                         <IV_INCIDENT_PROCESS>SYSTEM INCIDENT</IV_INCIDENT_PROCESS>
					 <IV_ISSUE_CATEGORY>30107</IV_ISSUE_CATEGORY>
                                         <IV_PRIORITY>$data{priority}</IV_PRIORITY>
					 <IV_PROCESS>32</IV_PROCESS>
                                         <IV_PROFILE></IV_PROFILE>
                                         <IV_REFERENCE_ID></IV_REFERENCE_ID>
                                         <IV_SUBJECT>$IV_SUB</IV_SUBJECT>
                                         <IV_SYSTEM_ID></IV_SYSTEM_ID>
                                         <IV_TENANT_ID>$tenant_id</IV_TENANT_ID>
                                </urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                           </soap:Body>
                        </soap:Envelope>
EOXML
			#print "I am here";

			#my $tt="/home/zabbix/spc_queue/create/$application-$LoggedHost-$alertTypeForFileName-$xlandscape";
			#print "value of tt is $tt";

			#open(CRF,"> $tt");
			#print CRF "$xml";
			#close(CRF);

                        $vdate = `date`;
                        print "\n DEBUG: Time Stamp $vdate \n";   

			if (sendCreate("new", $xml, $url, $usr, $pwd) eq 1)
			{
				print "\n DEBUG: Created a new Incident in SPC \n";
                                $vdate = `date`;
                                print "\n DEBUG: Time Stamp $vdate \n";


			}
			else
			{
				print "\n DEBUG: Create Incident in SPC FAILED !!  \n";
			}
                 } 
                 elsif ( $updateRC eq 2 && $zabbixEventState eq "OK" )	
			{

			$queueclose1="/home/zabbix/spc_queue/close/$oldincidentid";

                	print "Queue file name is $queueclose1";

                	if (-s $queueclose1)
                	{
                        	print "Queue file exists";
                	}
                	else
                	{
                        	print "Queue file not present";
                        	open (QCF, "> $queueclose1");
                        	print QCF "queue ok file\n";
                        	close(QCF);
                	}	
	}		
			}
		 
}
else
{
                ###############
                # new alert!
                ###############
              if ( $zabbixEventState ne "OK" )
              { 

                  print "\n DEBUG: There are no old incidents for this type, hence creating new one! \n";


		$IV_SUB = xml_encode($searchTerms);
		print "DEBUG: Value of IV-SUB is $IV_SUB \n";


	
                my $xml = <<EOXML;
                        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                           <soap:Header/>
                           <soap:Body>
                                  <urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                                         <IT_CONTEXT_PROVIDER>
                                                <item>
                                                   <PROVIDER_ID>/SAP/ABAP/HealthCheck/CheckContextProvider</PROVIDER_ID>
                                                   <CONTEXT_TYPE>5</CONTEXT_TYPE>
                                                   <CONTENT>$encoded</CONTENT>
                                                </item>
                                                <item>
                                                   <PROVIDER_ID>/SAP/BYDMS/River/SplunkAttachment</PROVIDER_ID>
                                                   <CONTEXT_TYPE>1</CONTEXT_TYPE>
                                                   <CONTENT>$fileencode</CONTENT>
                                                </item>
                                         </IT_CONTEXT_PROVIDER>
                                         <IV_CHECK_GROUP>$data{checkgroup}</IV_CHECK_GROUP>
                                         <IV_CHECK_ID>$data{checkid}</IV_CHECK_ID>
					 <IV_EVENT_KEY>$data{checkgroup}$data{checkid}01</IV_EVENT_KEY>
                                         <IV_DESCRIPTION>$data{description}</IV_DESCRIPTION>
                                         <IV_DETAIL_LINK></IV_DETAIL_LINK>
                                         <IV_INCIDENT_PROCESS>SYSTEM INCIDENT</IV_INCIDENT_PROCESS>
					 <IV_ISSUE_CATEGORY>30107</IV_ISSUE_CATEGORY>
                                         <IV_PRIORITY>$data{priority}</IV_PRIORITY>
					 <IV_PROCESS>32</IV_PROCESS>
                                         <IV_PROFILE></IV_PROFILE>
                                         <IV_REFERENCE_ID></IV_REFERENCE_ID>
                                         <IV_SUBJECT>$IV_SUB</IV_SUBJECT>
                                         <IV_SYSTEM_ID></IV_SYSTEM_ID>
                                         <IV_TENANT_ID>$tenant_id</IV_TENANT_ID>
                                </urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                           </soap:Body>
                        </soap:Envelope>
EOXML
	
		#my $tt="/home/zabbix/spc_queue/create/$application-$LoggedHost-$alertTypeForFileName-$xlandscape";
		#print "value of tt is $tt"; 
		#open(CRF,"> $tt");
                #        print CRF "$xml";
                #        close(CRF);
	
		if (sendCreate("new", $xml, $url, $usr, $pwd) eq 1)
		{
			  print "DEBUG: Created Incident in SPC \n";
                          $vdate = `date`;
                          print "\n DEBUG: Time Stamp $vdate \n";


	 	}
		else
		{
			print "DEBUG: Create Incident in SPC FAILED !! \n";
		}
        }
}

#open (MYFILE, ">> $fullFileName") || die "problem opening $fullFileName\n";
#print MYFILE "$incidentid";
#close (MYFILE);

#open (MYFILESIM, ">> $simfullFileName") || die "problem opening $simfullFileName\n";
#print MYFILESIM "$MessageResult";
#close (MYFILESIM);
close(LOGFILE);


######################################### Function Definitions #############################################################

sub xml_encode {
    my ($str) = @_;
    $str =~ s/([&<>"])/$ESCAPES{$1}/ge;
    return $str;
}







############## Webservice function for SPC ####################

sub do_webservice
{
   my ( $url, $usr, $password, $xml ) = @_;

   open (FH1, ">> $logfile") || die "problem opening $logfile\n";

   print FH1 "\nXML: \n$xml\n";
   print FH1 "\nURL: \n$url\n";

   my $ua = LWP::UserAgent->new();
   my $r = HTTP::Request->new( "POST", $url );
   $r->header( "Content-Type" => "application/soap+xml;charset=UTF-8", "SOAPAction" => "", "user-agent" => "Hyperic" );
   $r->authorization_basic( $usr, $password );
   $r->content($xml);
   my $response = $ua->request($r);
   print FH1 "DEBUG: Response is $response \n";
   return $response;
   close(FH1); 

}

############## Webservice function for SIM ####################

sub do_webservice_sim
{
   my ( $simurl, $simusr, $simpwd, $simxml ) = @_;
   print "\nSIM XML: \n$simxml\n";
   print "\nSIM URL: \n$simurl\n";

   my $ua = LWP::UserAgent->new();
   my $r = HTTP::Request->new( "POST", $simurl );
   $r->header( "Content-Type" => "text/xml;charset=UTF-8", "SOAPAction" => "http://realtech.com/SendMessageAM2Node", "user-agent" => "Hyperic" );
   $r->authorization_basic( $simusr, $simpwd );
   $r->content($simxml);
   my $responsesim = $ua->request($r);
   print "DEBUG: Response of SIM from do_webservice_sim function is $responsesim \n";
   return $responsesim;
}

############## Send e-mail function ####################

sub do_sendmail
{
   my ($from,
       $to,
       $subject,
       $body) = @_;

   print "DEBUG: do_sendmail $body";
   open (MAIL, "|/usr/lib/sendmail -f $from $to");
   print MAIL "From: $from\n",
              "To: $to\n",
              "Subject: $subject\n",
              "\n",
              "$body";
   close (MAIL);
}

############## Update incident in SPC funtion #############

sub sendUpdate
{
	my $updatemode = $_[0];
	my $updatedescription = <<EODESCRIPTION;
         	Alert Description: $ALERT_DESCRIPTION
         	Alert Condition: $ALERT_CONDITION
         	Alert Time: $con_alert_time
EODESCRIPTION

	#open (LOGFILE, ">> $logfile") || die "problem opening $logfile\n";
	print LOGFILE "Update Mode: $updatemode \n";
        #close(LOGFILE);

	my $updatexml = '';
	my $returnvalue;

	switch($updatemode)
	{
        	case "empty"
		{
			$oldincidentid =~ s/^\s+//;
			$oldincidentid =~ s/\s+$//;

			$updatexml = <<EOXML;
				<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
   				<soap:Header/>
   				<soap:Body>
      				<urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
         				<IV_INCIDENT_ID>$oldincidentid</IV_INCIDENT_ID>
         				<IV_NEW_COMMENT></IV_NEW_COMMENT>
         				<IV_PRIORITY></IV_PRIORITY>
      				</urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
   				</soap:Body>
				</soap:Envelope>
EOXML
        	}
        	case "new"
		{
			$updatexml = <<EOXML;
				<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
   				<soap:Header/>
   				<soap:Body>
      				<urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
         				<IV_INCIDENT_ID>$oldincidentid</IV_INCIDENT_ID>
         				<IV_NEW_COMMENT>Zabbix Severity changed at $alertTime, New severity is $splitAlert[0] </IV_NEW_COMMENT>
         				<IV_PRIORITY></IV_PRIORITY>
      				</urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
   				</soap:Body>
				</soap:Envelope>
EOXML
        	}
        	else
		{
			$updatexml = <<EOXML;
				<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
 				<soap:Header/>
   				<soap:Body>
      				<urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
         				<IV_INCIDENT_ID>$oldincidentid</IV_INCIDENT_ID>
         				<IV_NEW_COMMENT>$updatedescription</IV_NEW_COMMENT>
         				<IV_PRIORITY>$data{priority}</IV_PRIORITY>
      				</urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
   				</soap:Body>
				</soap:Envelope>
EOXML
        	}
	}

        my $xmlParser = new XML::Simple();
	print "DEBUG : Calling do_webservice1 function";
	my $response = do_webservice( $url, $usr, $pwd, $updatexml );

	print"\n DEBUG: about to call WS \n";
	$r_content = $response->content;
	$r_code = $response->code;
	$r_message = $response->message;

	print "\n DEBUG: Message we got is ==> $r_message \n URL is $url \n Content is $r_content \n";

	$r_all = <<EORESPONSE;
		HTTP Code: $r_code
		HTTP Message: $r_message
		HTTP Content: $r_content
EORESPONSE

	if ($r_code eq '200')
	{
                my $mess = $xmlParser->XMLin($r_content);

                # Check Response Content for Update Success Msg
                $incidentid = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"EV_OK"};

		if ($incidentid =~ m/HASH/)
		{
			$incidentid = '';
        	}
        	else
		{
        	}

        	if(($response->is_success) && ($incidentid eq "true" ))
		{
			open (FH2, ">> $logfile") || die "problem opening $logfile\n";
                	print FH2 "# SUCCESS # Alert Update Sent at $date \n";
                	print FH2 "Alert Time: $alertTime \n";
                	print FH2 "$r_all \n";
                	print FH2 "Update Success: $incidentid \n";
                	print FH2 "# ENDOFALERT # \n";
                        close(FH2);

                	if($updatemode ne "empty")
			{
                		$counter = '1';
                        	open (FH10, "> $fullFileName") || die "problem opening $fullFileName\n";
                        	print FH10 $oldincidentid;
                        	print FH10 "\n";
                        	print FH10 $timestamp;
                        	print FH10 "\n";
                        	print FH10 $counter;
                        	print FH10 "\n";
                        	print FH10 $data{priority};
                        	print FH10 "\n";
                        	close(FH10);
			}
		$returnvalue = 1;
        	}
        	else
		{
			open (FH3, ">> $logfile") || die "problem opening $logfile\n";
                	print FH3 "# ERROR # Alert Update NOT Sent at $date", "\n";
                	print FH3 "Alert Time: $alertTime \n";
                	print FH3 "$r_all \n";
                	print FH3 "# SOAP Request XML #", "\n";
                	print FH3 "$updatexml \n";

    #            	$responsetype = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"ET_MESSAGES"}{"item"}{"TYPE"};
    #            	print "\n DEBUG: Response type: $responsetype \n";

    #            	if ($responsetype eq 'E')
#			{
#                        	$responseno = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"ET_MESSAGES"}{"item"}{"NUMBER"};
#                        	$responsemsg = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"ET_MESSAGES"}{"item"}{"MESSAGE"};
#                        	print FH3 "Message No: $responseno \n";
#                        	print FH3 "Message: $responsemsg \n";
#                        	print "\n DEBUG: Response No & Message: $responseno $responsemsg  \n";
#                	}
        
	        # System in Downtime should not be an issue in update WS API
                # 014 - System in Downtime
                # 015 - Incident already completed
#                	if ($responseno ne '014' && $responseno ne '015' )
#			{
#                		my $emailContent = "SPC WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n";
#                        	do_sendmail($from, $to_list, "SPC Webservice failure", $emailContent );
#                	}
	
			print FH3 "# ENDOFALERT #", "\n";
        		$returnvalue = 0;
                        close(FH3);
        	}
	}
	else 
	{
		#r_code ne 200
                open (FH4, ">> $logfile") || die "problem opening $logfile\n";

        	print FH4 "# ERROR # Alert NOT Updated at $date", "\n";
        	print FH4 "Alert Time: $alertTime \n";
        	print FH4 "$r_all \n";
        	print FH4 "# SOAP Request XML #", "\n";
        	print FH4 "$xml \n";
        	my $emailContent = "SPC WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n ";
        	print "DEBUG: Email content is $emailContent", "\n";
        	do_sendmail($from, $to_list, "SPC Webservice failure", $emailContent );
        	print FH4 "# ENDOFALERT #", "\n";
        	$returnvalue = 2;
                close(FH4);  
	}
	return $returnvalue;
}

############## Create incident in SPC funtion #############

sub sendCreate
{
	my $createmode = $_[0];
	my $passedXml = $_[1];
	my $url = $_[2];
	my $usr = $_[3];
	my $pwd = $_[4];

#	if ($createmode eq "new")
#	{
#        	my $description = <<EODESC;
#        		Alert Name: $searchName
#        		Alert Description: $searchQuery
#        		Alert Condition: $searchTerms
#        		Server Impacted: $LoggedHost
#        		Summary: $alertTime. $searchName. $searchTerms
#EODESC

#        	$data{description} = $description;
#        	my $alerttype = $searchName;

#        	print "DEBUG: alerttype $alerttype searchName $searchName \n";
#	}

	my $returnvalue;
	my $xmlParser = new XML::Simple();
	print "DEBUG : Calling do_webservice2 function";
       $vdate = `date`;
       print "\n DEBUG: Time Stamp $vdate \n";
	my $response = do_webservice( $url, $usr, $pwd, $passedXml );
	print "DEBUG: Executed do_webservice function \n";
	print "DEBUG: Response from the webservice call is $response \n";
	#print "DEBUG: Response from the webservice call is $responsesim \n";

	$r_content = $response->content;
	$r_code = $response->code;
	$r_message = $response->message;

	print "DEBUG: Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";
	$r_all = <<EORESPONSE;
		HTTP Code: $r_code
		HTTP Message: $r_message
		HTTP Content: $r_content
EORESPONSE

	open (FH5, ">> $logfile") || die "problem opening $logfile\n";
	print FH5 "Alert Time: $alertTime \n";
	print FH5 "$r_all \n";
        close(FH5);

	if ($r_code eq '200')
	{
                my $mess = $xmlParser->XMLin($r_content);
                print "Message is $mess", "\n";
                print "xmlParser is $xmlParser", "\n";
                print "Content is $r_content", "\n";

                $incidentid = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CREATIONResponse"}{"EV_INCIDENT_ID"};
                print "INCIDENT ID is $incidentid", "\n";

                if ($incidentid =~ m/HASH/)
		{
                        $incidentid = '';
                }
                else
		{
                }

                if(($response->is_success) && ($incidentid ne ''))
		{
                        open (FH6, ">> $logfile") || die "problem opening $logfile\n";
                        print FH6 "# SUCCESS # Alert Sent at $date \n";
                        print FH6 "Alert Time: $alertTime \n";
                        print FH6 "$r_all \n";
                        print FH6 "INCIDENT ID: $incidentid \n";
                        print FH6 "# ENDOFALERT # \n";
                        close(FH6);
                        $counter = '1';
                        open (FH9, "> $fullFileName") || die "problem opening $fullFileName\n";
                        print FH9 $incidentid;
                        print FH9 "\n";
                        print FH9 $timestamp;
                        print FH9 "\n";
                        print FH9 $counter;
                        print FH9 "\n";
                        print FH9 $data{priority};
                        print FH9 "\n";
                        close(FH9);
                        $returnvalue = 1;
            	}
                else
		{

                        open (FH7, ">> $logfile") || die "problem opening $logfile\n";
                        print FH7 "# ERROR # Alert Close NOT Sent at $date", "\n";
                        print FH7 "Alert Time: $alertTime \n";
                        print FH7 "$r_all \n";
                        print FH7 "# SOAP Request XML #", "\n";
                        print FH7 "$xml \n";

                        $responsetype = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CREATIONResponse"}{"ET_MESSAGES"}{"item"}{"TYPE"};

                        if ($responsetype eq 'E')
			{
                                $responseno = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CREATIONResponse"}{"ET_MESSAGES"}{"item"}{"NUMBER"};
                                $responsemsg = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CREATIONResponse"}{"ET_MESSAGES"}{"item"}{"MESSAGE"};
                                print FH7 "Message No: $responseno \n";
                                print FH7 "Message: $responsemsg \n";
                        }
                        
			if ($responseno ne '014')
			{
                        	my $emailContent = "WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n ";
                                do_sendmail($from, $to_list, "Webservice failure", $emailContent );
                        }

                        print FH7 "# ENDOFALERT #", "\n";
                        $returnvalue = 0;
                        close(FH7);
                }
        }
        else
	{
                #r_code ne 200
                open (FH8, ">> $logfile") || die "problem opening $logfile\n";
		print FH8 "# ERROR # Alert NOT Sent at $date", "\n";
                print FH8 "Alert Time: $alertTime \n";
                print FH8 "$r_all \n";
                print FH8 "# SOAP Request XML #", "\n";
                print FH8 "$xml \n";
                my $emailContent = "WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n ";
                do_sendmail($from, $to_list, "Webservice failure", $emailContent );
                print FH8 "# ENDOFALERT #", "\n";
                $returnvalue = 0;
                close(FH8);
        }
        return $returnvalue;
}


############## Get status of an incident in SPC function #############

sub getStatus
{
	#my $createmode = $_[0];
	#my $passedXml = $_[1];
	my $url = $_[2];
	my $usr = $_[3];
	my $pwd = $_[4];

	my $returnvalue;

	my $getxml = '';
	$getxml = <<EOXML;
		<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
   		<soap:Header/>
   		<soap:Body>
      		<urn:_-A1SSPC_-GET_INCIDENT_STATUS>
         		<IV_INCIDENT_ID>1000147121</IV_INCIDENT_ID>
         		<IV_REFERENCE_ID></IV_REFERENCE_ID>
      		</urn:_-A1SSPC_-GET_INCIDENT_STATUS>
   		</soap:Body>
		</soap:Envelope>
EOXML

	my $xmlParser = new XML::Simple();
	print "DEBUG : Calling do_webservice2 function";

	my $response = do_webservice( $url, $usr, $pwd, $getxml );

	print "DEBUG: Executed do_webservice function \n";
	print "DEBUG: Response from the webservice call is $response \n";

	$r_content = $response->content;
	$r_code = $response->code;
	$r_message = $response->message;

	print "DEBUG: SPC Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";

	$r_all = <<EORESPONSE;
		HTTP Code: $r_code
		HTTP Message: $r_message
		HTTP Content: $r_content
EORESPONSE

	open (LOGFILE, ">> $logfile") || die "problem opening $logfile\n";
	print LOGFILE "Alert Time: $alertTime \n";
	print LOGFILE "$r_all \n";

	if (($r_code eq '200'))
	{
                my $mess = $xmlParser->XMLin($r_content);
		my $messtest = $xmlParser->XMLin($r_content);

                print "Message is $mess", "\n";
                print "xmlParser is $xmlParser", "\n";
                print "Content is $r_content", "\n";
		print "Mess test is $messtest", "\n";

                # Check Response Content for Incident ID

                my $evstatuscode = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_STATUSResponse"}{"EV_STATUS_CODE"};
                print "EV status code is $evstatuscode", "\n";
		
		my $evstatusdescription = $messtest->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_STATUSResponse"}{"EV_STATUS_DESCRIPTION"};	
		print "EV status Description is $evstatusdescription", "\n";		


                if ($evstatuscode =~ m/HASH/)
		{
                        $evstatuscode = '';
                }
                else
		{
                }

		if(($response->is_success) && ($evstatuscode ne ''))
		{
                        open (LOGFILE, ">> $logfile") || die "problem opening $logfile\n";
                        print LOGFILE "# SUCCESS # Alert Sent at $date \n";
                        print LOGFILE "Alert Time: $alertTime \n";
                        print LOGFILE "$r_all \n";
                        print LOGFILE "INCIDENT ID: $incidentid \n";
                        print LOGFILE "# ENDOFALERT # \n";
                        $counter = '1';
                        open (FILE, "> $fullFileName") || die "problem opening $fullFileName\n";
                        print FILE $incidentid;
                        print FILE "\n";
                        print FILE $timestamp;
                        print FILE "\n";
                        print FILE $counter;
                        print FILE "\n";
                        print FILE $data{priority};
                        print FILE "\n";
                        close(FILE);
                        $returnvalue = 1;
            	}
                else
		{
                        print LOGFILE "# ERROR # Alert Close NOT Sent at $date", "\n";
                        print LOGFILE "Alert Time: $alertTime \n";
                        print LOGFILE "$r_all \n";
                        print LOGFILE "# SOAP Request XML #", "\n";
                        print LOGFILE "$xml \n";

                        $responsetype = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_STATUSResponse"}{"ET_MESSAGES"}{"item"}{"TYPE"};

                        if ($responsetype eq 'E')
			{
                                $responseno = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_STATUSResponse"}{"ET_MESSAGES"}{"item"}{"NUMBER"};
                                $responsemsg = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_STATUSResponse"}{"ET_MESSAGES"}{"item"}{"MESSAGE"};
                                
				print LOGFILE "Message No: $responseno \n";
                                print LOGFILE "Message: $responsemsg \n";
                        }
                        #No Error Mail in case of system is in downtime
                        
			if ($responseno ne '014')
			{
                        	my $emailContent = "SPC WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n ";
                                do_sendmail($from, $to_list, "Webservice failure", $emailContent );
                        }

                        print LOGFILE "# ENDOFALERT #", "\n";
                        
			$returnvalue = 0;
                }
        }
	else
	{
                #r_code ne 200
		print LOGFILE "# ERROR # Alert NOT Sent at $date", "\n";
                print LOGFILE "Alert Time: $alertTime \n";
                print LOGFILE "$r_all \n";
                print LOGFILE "# SOAP Request XML #", "\n";
                print LOGFILE "$xml \n";
                my $emailContent = "SPC WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n ";
                do_sendmail($from, $to_list, "SPC Webservice failure", $emailContent );
                print LOGFILE "# ENDOFALERT #", "\n";
                $returnvalue = 0;
        }
        return $returnvalue;
}


############## BLD Getstatus function ####################

sub getBLDstatus
{
        my $createmode = $_[0];
        my $passedXml = $_[1];
        my $url = $_[2];
        my $usr = $_[3];
        my $pwd = $_[4];



        my $returnvalue;
        my $xmlParser = new XML::Simple();
        print "DEBUG : Calling do_webservice function";

        my $response = do_webservice( $url, $usr, $pwd, $passedXml );
        print "DEBUG: Executed do_webservice function \n";
        print "DEBUG: Response from the webservice call is $response \n";

        $r_content = $response->content;
        $r_code = $response->code;
        $r_message = $response->message;

        print "DEBUG: Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";
        $r_all = <<EORESPONSE;
                HTTP Code: $r_code
                HTTP Message: $r_message
                HTTP Content: $r_content
EORESPONSE


        print LOGFILE "$r_all \n";

	 if ($r_code eq '200')
        {
                my $mess = $xmlParser->XMLin($r_content);
                print "Message is $mess", "\n";
                print "xmlParser is $xmlParser", "\n";
                print "Content is $r_content", "\n";

            
                 my $tenant_id1 = $mess->{"env:Body"} {"n0:WSQueryResponseMessage"} {"SystemDetails"} {"AdminTenantId"} || "NULL";
	#	my $tenant_id1 = "$mess->{env:Body}{n0:WSQueryResponseMessage}{SystemDetails}[0]{AdminTenantId}" || "NULL";
		print "DEBUG: WS tenantid value is $tenant_id1 \n";

                if ($tenant_id1 eq "NULL")
                {
                        
                        print "DEBUG: Unknown host in BLD \n";
		}
                else
                {
                   $tenant_id = $tenant_id1;
		   print "DEBUG: Data present in BLD \n";
                }

                $returnvalue = 1;

        }
        else
        {
                #r_code ne 200
                print LOGFILE "BLD ERROR response code $r_code", "\n";
                print LOGFILE "$r_all \n";
                $returnvalue = 0;
        }
        return $returnvalue;
}







############## Close incident in SPC function #############

sub sendClose
{
	my $closemode = $_[0];
	my $returnvalue;
	my $closexml = '';
	my $queueclose;

        my $reason = "Auto closing of incident due to recovery of alert in Zabbix ";
	$closexml = <<EOXML;
		<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
   		<soap:Header/>
   		<soap:Body>
      		<urn:_-A1SSPC_-SPC_INCIDENT_CLOSE>
         		<IV_INCIDENT_ID>$oldincidentid</IV_INCIDENT_ID>
         		<IV_REASON>$reason</IV_REASON>
      		</urn:_-A1SSPC_-SPC_INCIDENT_CLOSE>
   		</soap:Body>
		</soap:Envelope>
EOXML

        my $xmlParser = new XML::Simple();

	my $response = do_webservice( $url, $usr, $pwd, $closexml );

	$r_content = $response->content;
	$r_code = $response->code;
	$r_message = $response->message;

	$r_all = <<EORESPONSE;
		HTTP Code: $r_code
		HTTP Message: $r_message
		HTTP Content: $r_content
EORESPONSE

	print "DEBUG : Inside sendClose function and the values of r_content r_code r_message are $r_all \n";

	if ($r_code eq '200')
	{
                my $mess = $xmlParser->XMLin($r_content);

                $incidentid = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CLOSEResponse"}{"EV_SUCCESS_FLAG"};

                if ($incidentid =~ m/HASH/)
		{
                        $incidentid = '';
                }
                else
		{
                }

                if(($response->is_success) && ($incidentid ne ''))
		{
                        print LOGFILE "# SUCCESS # Alert Close Sent at $date \n";
                        print LOGFILE "Alert Time: $alertTime \n";
                        print LOGFILE "$r_all \n";
                        print LOGFILE "Close Success: $incidentid \n";
                        print LOGFILE "# ENDOFALERT # \n";
                        if($closemode ne "new")
			{
                                        $counter = '1';
                                        open (FILE, "> $fullFileName") || die "problem opening $fullFileName\n";
                                        close(FILE);
                        }
                        $returnvalue = 1;
                        open (CF, "> $closurefile");
                        print CF "ok file\n";
                        close(CF);

			# code to remove incident file once OK alert is recieved

			unlink ($fullFileName);

            	}
                else
		{
                        print LOGFILE "# ERROR # Alert Close NOT Sent at $date", "\n";
                        print LOGFILE "Alert Time: $alertTime \n";
                        print LOGFILE "$r_all \n";
                        print LOGFILE "# SOAP Request XML #", "\n";
                        print LOGFILE "$xml \n";

                        $responsetype = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CLOSEResponse"}{"ET_MESSAGES"}{"item"}{"TYPE"};

                        if ($responsetype eq 'E')
			{
                                $responseno = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CLOSEResponse"}{"ET_MESSAGES"}{"item"}{"NUMBER"};
                                $responsemsg = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CLOSEResponse"}{"ET_MESSAGES"}{"item"}{"MESSAGE"};
                                print LOGFILE "Message No: $responseno \n";
                                print LOGFILE "Message: $responsemsg \n";
                        }
                        #Send error mail - exception 013 for incident is already finished
                        #System in Downtime (014) is not be an issue in close WS API
                       
			if ($responseno ne '013')
			{
                        	my $emailContent = "SPC WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n ";
                                do_sendmail($from, $to_list, "Webservice failure", $emailContent );
                        }

                        print LOGFILE "# ENDOFALERT #", "\n";
                        $returnvalue = 0;
                }
        }
        else
	{
                #r_code ne 200
        	print LOGFILE "# ERROR # Alert NOT Sent at $date", "\n";
                print LOGFILE "Alert Time: $alertTime \n";
                print LOGFILE "$r_all \n";
                print LOGFILE "# SOAP Request XML #", "\n";
                print LOGFILE "$xml \n";
                
		my $emailContent = "WS call failed with responseNumber: $responseno, response_message: $r_message, response_code: $r_code \n Alert detail: $searchName - $xlandscape \n ";
                do_sendmail($from, $to_list, "SPC Incident Close Webservice failure", $emailContent );
                
		print LOGFILE "# ENDOFALERT #", "\n";
                $returnvalue = 0;

		$queueclose="/home/zabbix/spc_queue/close/$oldincidentid";

		print LOGFILE "Queue file name is $queueclose";

		if (-s $queueclose)
		{
			print LOGFILE "Queue file exists";
		}
		else
		{
			print LOGFILE "Queue file not present";
			open (QCF, "> $queueclose");
	       		print QCF "queue ok file\n";
	        	close(QCF);
			unlink ($fullFileName);
		}




        }

        return $returnvalue;
}

print "\n \n DEBUG: SPC Incident Number is $incidentid \n";






