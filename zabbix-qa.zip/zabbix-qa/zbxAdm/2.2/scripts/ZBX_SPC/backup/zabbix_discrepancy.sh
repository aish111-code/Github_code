#!/bin/bash

#######################################################
# Author : Sandeep M.R (C5182416)
# Date   : 11th Dec 2013
# Purpose : Script to generate Zabbix discrepancy report
#######################################################


MASTER_DB_USER='root'
MASTER_DB_PASSWD='L3tm31n'
MASTER_DB_PORT=3306
MASTER_DB_HOST='10.4.196.90'
MASTER_DB_NAME='zabbix'

#TO_EMAIL="s.renuka@sap.com"

TO_EMAIL="s.renuka@sap.com surekha.pattnaik@sap.com,jaffer.ali.mohamed.maideen@sap.com,monitoring@successfactors.com,patrick.presto@sap.com,christopher.hunt@sap.com"
#TO_EMAIL="patrick.presto@sap.com MChen@successfactors.com jaffer.ali.mohamed.maideen@sap.com monitoring@successfactors.com s.renuka@sap.com surekha.pattnaik@sap.com"

cd /home/zabbix/bin

mysql -t -u$MASTER_DB_USER -p$MASTER_DB_PASSWD -P$MASTER_DB_PORT -h$MASTER_DB_HOST -D$MASTER_DB_NAME <  zabbix_queue.sql > queue_items.txt

mysql -t -u$MASTER_DB_USER -p$MASTER_DB_PASSWD -P$MASTER_DB_PORT -h$MASTER_DB_HOST -D$MASTER_DB_NAME <  zabbix_not_templated_items.sql > not_templated_items.txt

mysql -t -u$MASTER_DB_USER -p$MASTER_DB_PASSWD -P$MASTER_DB_PORT -h$MASTER_DB_HOST -D$MASTER_DB_NAME <  zabbix_duplicateDNS.sql > duplicateDNS.txt

mysql -t -u$MASTER_DB_USER -p$MASTER_DB_PASSWD -P$MASTER_DB_PORT -h$MASTER_DB_HOST -D$MASTER_DB_NAME <  zabbix_agentversion.sql > agentversion.txt

mysql -t -u$MASTER_DB_USER -p$MASTER_DB_PASSWD -P$MASTER_DB_PORT -h$MASTER_DB_HOST -D$MASTER_DB_NAME <  zabbix_duplicateIP.sql > duplicateIP.txt

mysql -t -u$MASTER_DB_USER -p$MASTER_DB_PASSWD -P$MASTER_DB_PORT -h$MASTER_DB_HOST -D$MASTER_DB_NAME <  zabbix_duplicatename.sql > duplicatename.txt

mysql -t -u$MASTER_DB_USER -p$MASTER_DB_PASSWD -P$MASTER_DB_PORT -h$MASTER_DB_HOST -D$MASTER_DB_NAME <  zabbix_itemlessthan60s.sql > itemlessthan60s.txt


Q_COUNT1=`wc -l queue_items.txt | awk '{print $1}'`
Q_COUNT=`expr $Q_COUNT1 - 4`

T_COUNT1=`wc -l not_templated_items.txt | awk '{print $1}'`
T_COUNT=`expr $T_COUNT1 - 4`

D_COUNT1=`wc -l duplicateDNS.txt | awk '{print $1}'`
D_COUNT=`expr $D_COUNT1 - 4`

A_COUNT1=`wc -l agentversion.txt | awk '{print $1}'`
A_COUNT=`expr $A_COUNT1 - 4`

I_COUNT1=`wc -l duplicateIP.txt | awk '{print $1}'`
I_COUNT=`expr $I_COUNT1 - 4`

N_COUNT1=`wc -l duplicatename.txt | awk '{print $1}'`
N_COUNT=`expr $N_COUNT1 - 4`

SIX_COUNT1=`wc -l itemlessthan60s.txt | awk '{print $1}'`
SIX_COUNT=`expr $SIX_COUNT1 - 4`


echo -e "\t\t\t ZABBIX House Keeping Report\n\n" > /home/zabbix/bin/message.txt
echo -e "\t\t\t Queue Items:\t\t $Q_COUNT\n" >> /home/zabbix/bin/message.txt
echo -e "\t\t\t Not Templated Items:  $T_COUNT \n" >> /home/zabbix/bin/message.txt
echo -e "\t\t\t Duplicate DNS:\t\t $D_COUNT \n" >> /home/zabbix/bin/message.txt
echo -e "\t\t\t Lower agent version:  $A_COUNT \n"  >> /home/zabbix/bin/message.txt
echo -e "\t\t\t Duplicate IP:  $I_COUNT \n"  >> /home/zabbix/bin/message.txt
echo -e "\t\t\t Duplicate hostname:  $N_COUNT \n"  >> /home/zabbix/bin/message.txt
echo -e "\t\t\t Items with interval less than 60s:  $SIX_COUNT \n"  >> /home/zabbix/bin/message.txt


mutt -a queue_items.txt -a not_templated_items.txt -a duplicateDNS.txt -a agentversion.txt -a duplicateIP.txt -a duplicatename.txt -a itemlessthan60s.txt -s "ZABBIX House Keeping Report" $TO_EMAIL < /home/zabbix/bin/message.txt


