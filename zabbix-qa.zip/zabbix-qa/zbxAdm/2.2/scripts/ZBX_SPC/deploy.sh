#!/bin/bash

# Deployment script for zabbix to spc integration
# Author: Sandeep M.R

mv /usr/local/share/zabbix/alertScripts/SPC_Notification_Wrapper_1.0.sh /usr/local/share/zabbix/alertScripts/SPC_Notification_Wrapper_1.0.sh_20150413
mv /usr/local/share/zabbix/alertScripts/SPC_Notification_Wrapper_1.0_new.sh /usr/local/share/zabbix/alertScripts/SPC_Notification_Wrapper_1.0.sh


mv /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/SPC_SIM_Notification.pl /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/SPC_SIM_Notification.pl_20150413
mv /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/SPC_SIM_Notification.pl_new /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/SPC_SIM_Notification.pl


mv /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/Product_Host_Map.config /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/Product_Host_Map.config_20150413
mv /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/Product_Host_Map.config_latest /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/Product_Host_Map.config

mv /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/*Mapp*.config /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/old

cp /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf/new/*.config /usr/local/etc/zbxAdm/2.2/scripts/ZBX_SPC/spcConf
