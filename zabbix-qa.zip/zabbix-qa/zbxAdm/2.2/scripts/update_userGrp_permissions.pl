#!/usr/bin/perl

##################################################################
# Author        : Sandeep M.R
# Purpose       : Zabbix 2.2 reporting script
# Reviewer      : Patrick Presto
# Version       : Jan 20th 2015 - Initial code
#               : Jan 26th 2015 - Added report.pm,-hostinventory option
#               : May 6th 2015 - Added -item_status function (Vikky Omkar)
#		: Sep 11th 2015 - Added TriggerReport function (Vikky Omkar)
####################################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';
use lib '/usr/local/etc/zbxAdm/2.2/lib';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use Getopt::Long;
use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Data::Dumper;

# Local variable declaration

my @hostname;

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLDs qw(pfail);


# Detect running env and set the connection variables

my $email='s.renuka@sap.com,pradip.kumar.k@sap.com';
open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>) {
    chomp $line;
    if ($line ne "" and $line =~ m/lab/ ){ 	
        $env = 'qa';
    }
    else { 
        $env = 'prod' ; 
    }
}	

# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


#=pod

# Connect to Zabbix API and write authid to /tmp/hostname.tmp
	
my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

my $logFile = "/tmp/update_userGrp_permissions.log";
open FH, ">", $logFile or die "Could not open log file $logFile:$!\n";
#my @userGrps = qw( sapsf_readonly_adauth  sapsf_readonly_internalauth  sapsf_admin_adauth sapsf_superadmin_adauth sapsf_superadmin_internalauth );
my @userGrps = ( 
                 { 'grpName' => 'sapsf_readonly_adauth', 'permission' => 2  },
                 { 'grpName' => 'sapsf_readonly_internalauth', 'permission' => 2  },
                 { 'grpName' => 'sapsf_admin_adauth', 'permission' => 2 }, 
                 { 'grpName' => 'sapsf_superadmin_adauth', 'permission' => 3 },
                 { 'grpName' => 'sapsf_superadmin_internalauth', 'permission' => 3}
               ); ##2=>read-only, 3=> read-write

foreach my $each_record( @userGrps ) {
    my $grpName = $each_record->{grpName};
    my $permsission = $each_record->{permission};

    my $userGrpId = getUserGrpIdByName($zabbix, $grpName);
    if( ! $userGrpId ) {
        print FH "Can not retrieve group Id of the given user group: $grpName \n";
        next;
    }

    # Get Hostgroup object
    my $hgroupRef;
    $hgroupRef = getHostGrpIds($zabbix );
    #print Dumper $hgroupRef;
    if( updateUserGrp($zabbix, $userGrpId, $permsission, $hgroupRef ) ) {
        print FH "Succesfully updated usergroup $grpName \n";
    }
    else{
        print FH "Failed to update usergroup $grpName \n";
    }

}
close(FH);
my $mailCmd = qq~ cat  $logFile | mailx -r "ZBX-PLT\@sap.com" -s "User Group Management Report " $email ~;
system($mailCmd);






#####subs
sub getUserGrpIdByName {
    my ( $zabbix, $grpName) = @_;

    #my %output = ('output' => 'extend' );

    my %filter = ( 'name' => $grpName );

    #my $params = { %output};
    my $params = { %filter };
    my $api_result = $zabbix->raw('usergroup', 'getobjects', $params);

    my $grpId = $api_result->{usrgrpid};

    return $grpId;
}


sub getHostGrpIds {
    my ($zabbix, $grpName) = @_;
    
    my %output = ('output' => 'extend' );

    my @listOfGrpIds=();
    my $params;
    if( $grpName ) {
        my %filter = ( 'name' => $grpName );
        $params = {%output, %filter };

    }
    else{
        $params = {%output};

    }

    my $api_result = $zabbix->raw('hostgroup','getobjects', $params);

    if( ref $api_result eq 'ARRAY' ) {
        foreach my $grpRef ( @$api_result ) {
            push @listOfGrpIds, $grpRef->{groupid};
        }
    }
    else{
        push @listOfGrpIds, $api_result->{groupid};
    }

    return \@listOfGrpIds;
}

sub updateUserGrp {
    my ( $zabbix, $userGrpId, $permission, $hostGroupListRef ) = @_;

    my @permissionArr;
    foreach my $hostGrpId ( @$hostGroupListRef ) {
         push @permissionArr, { 'permission' => $permission, 'id' => $hostGrpId };
    }
    # @permissionArr=();
    #@permissionArr = { 'permission' => 2, 'id' => 3161 };
    my $params = { 'usrgrpids' => [ $userGrpId ], 'rights' => [ @permissionArr ] };

    my $api_result = $zabbix->raw('usergroup','massupdate',$params);

    print FH Dumper $api_result;
    return 1 if ( $api_result->{usrgrpids} );
}


