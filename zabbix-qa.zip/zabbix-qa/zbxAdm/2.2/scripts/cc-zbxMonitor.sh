#!/bin/bash

##############################################
# Purpose :Monitor zabbix server service
# Author  : Sandeep M.R
# Date    : 12/9/2014
# Modified: Jibin Sunny
# Date    : 20/6/2022
##############################################

email_to="jibin.sunny@sap.com,sindhu.madicherla@sap.com,vidya.nandjha@sap.com,anusha.mandadi@sap.com,nagapavan.kalgur@sap.com"
#Logfile Location
logfile=/var/log/zabbix/zbx_failure.txt
date=`date`
#Check App server connection


telnet $2 10051 > /var/log/zabbix/zbxserverstatus.txt

servercount=`grep "Connected to" /var/log/zabbix/zbxserverstatus.txt | wc -l`

if [ $servercount -eq 0 ]
then

restartcheck=`find /var/log/zabbix/ -type f -name zbxrestart.txt -mmin -30 | wc -l`

       if [ $restartcheck -eq 0 ]
       then
                # zabbix server is not restarted in last 30 minutes, go for restart
                 printf "$date: ZABBIX server process is down.\n" >>$logfile
               ##echo "Alert - Zabbix server not responding. Manual restart required" | mailx -s "Action Required:$1 - Zabbix server down" -r saasopsps@successfactors.com $email_to
               echo "Alert - Zabbix server not responding. Manual restart required" | mailx -s "Action Required:$1 - Zabbix server down" -r ZBX@sapsf.com $email_to

               x=`date +%Y_%m_%d`
               backuplog="/var/log/zabbix/zabbix_server_${x}"
               cp /var/log/zabbix/zabbix_server.log  ${backuplog}

               touch /var/log/zabbix/zbxrestart.txt
       fi

rm /var/log/zabbix/zbxserverstatus.txt

fi
