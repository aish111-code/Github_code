#!/usr/bin/python
##
##input to this script is host_discovered group and monsoon group
##loop through the hosts
import sys
sys.path.append('/usr/local/etc/zbxAdm/2.2/lib/zbxpylib')
from zabbix_api import ZabbixAPI
from RSM import parseConfig
import re
from pprint import pprint
import subprocess
import errno
import os
import shlex
import json
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#import logging

ZABBIX_CONF_FILE='/usr/local/etc/zbxAdm/2.2/conf/zbx%s.conf'
ANSIBLE_AGENT_HOST_FILENAME='/etc/ansible/agent/inventory/hosts_agentansiblerun.txt'
ANSIBLE_AGENT_FAILEDHOST_FILENAME='/tmp/hosts_agentfailedrun.txt'
ZABBIX_NOTICE_FILENAME='/tmp/zbx_automation_notice.txt'
MAIL_FROM = 'ZBX-PLT<ZBX-PLT@sap.com>'
MAIL_TO = ["s.renuka@sap.com","sreekanth.kp@sap.com","kartik.gupta@sap.com","jibin.sunny@sap.com","ayush.jain@sap.com","rajwin.victor.jesudason@sap.com","v.manepalli@sap.com","sindhu.madicherla@sap.com","bikramjit.sengupta@sap.com","vivek.sivakumar@sap.com","e.wise@sap.com"]
#MAIL_TO = ["ganesan.karuppasamy@sap.com"]

# Datacenter
DATACENTER_HOSTNAME_FILE='/etc/hostname'
DATACENTER_HOSTS_FILE='/etc/hosts'
DATACENTER_PATTERN=r"[a-z]{2}([0-9]{1,2})[a-z]+"

HOST_REGISTRATION_MAIL_SUBJECT='Automated zabbix host registration status'
ANSIBLE_AGENT_MAIL_SUBJECT='Automated zabbix host agent deployment status'

if len(sys.argv) < 2:
    print("Usage: %s <host group e.g. host_discovered or monsoon> [ optional dc number e.g. DC23 ]" % (sys.argv[0]))
    sys.exit()

def main():
    inp_host_group = sys.argv[1]

    env = find_env_details('env')
    #configFile = find_env_details('config')
    datacenter = find_datacenter()

    ## Cleanup ansible host file
    if os.path.isfile(ANSIBLE_AGENT_HOST_FILENAME):
        os.unlink(ANSIBLE_AGENT_HOST_FILENAME)



##just checking if user explicitly passed dc number. If passed used that config file
    if len(sys.argv) > 2:
        configFile = ZABBIX_CONF_FILE % (sys.argv[2].upper())
    else:
        configFile = ZABBIX_CONF_FILE % (datacenter)
        if not os.path.isfile(configFile):
            configFile = ZABBIX_CONF_FILE % ('')

    print("configFile to use %s" % (configFile) )
    config = parseConfig(configFile)

    failed_grp = 'failed_automation'
#failed_grp_id = 4833
#logging.basicConfig(filename='/var/log/zabbix/automated_zabbix_registration.log',level=logging.DEBUG)
#logging.basicConfig(filename='automated_zabbix_registration.log',level=logging.DEBUG)
#logging.debug('This message should go to the log file')



    """
    ##logic to check if host is already in failed hostgroup
    #1 Check host name is duplicate
    #2 Check IP is duplicate
    #3 Check latest data already collected.

    #if none of above failed then autoregister
    #else Add to failed hostgroup

    """



    zabbix = init_zabbix_object(config)

    failed_grp_id = get_hostGrp_id(zabbix,failed_grp)

    host_inventory = get_host_inventory(zabbix)
    #print(host_inventory)
    #pprint(host_inventory)
    hosts_ips_from_discovered_grp = get_hosts_from_grp(zabbix, inp_host_group)
    #hosts = ['Test.ams2.sf.priv']
    #print(hosts)
    discoveryHostStatus = []
    failedHosts = []
    autoRegisterLogs = []
    for data in hosts_ips_from_discovered_grp:
        discovered_host = data['name']
        discovered_ip = data['ip']
        #discovered_host_id = get_host_id(zabbix,discovered_host)
        discovered_host_id = data['hostid']
        #print(host_id)
        #is_in_failedgrp = check_host_in_failedgroup(zabbix, host_id)
        #is_in_failedgrp = check_host_in_failedgroup(zabbix, 123)
        if check_host_in_failedgroup(zabbix,discovered_host_id):
            print("Host %s is in failed group" % (discovered_host) )
            #logging.warning("Host %s is in failed group" % (discovered_host) )
            ##do nothing
            status = "FAILEDGRP"
            failedHosts.append(discovered_host)
        #check host in duplicate
        elif host_inventory[discovered_host] > 1 or host_inventory[discovered_ip] > 1:
            print("%s is a duplicate " % (discovered_host))
            #logging.warning("%s is a duplicate " % (discovered_host))
            ##add it to failed host group
            status = "DUPLICATE"
            add_to_failed_grp(zabbix, discovered_host_id)
            failedHosts.append(discovered_host)
        elif get_item_sytem_uname_sync(zabbix, discovered_host_id):
                print("Calling autoregistration script")
                #cmd = "/usr/local/etc/zbxAdm/2.2/scripts/autoregister.pl -updatehost %s -addmaintenance" % (discovered_host)
                cmd = "/usr/local/etc/zbxAdm/2.2/scripts/autoregister_v2.pl -updatehost %s -addmaintenance -dc %s" % (discovered_host, datacenter)
                #cmd = "/usr/local/etc/zbxAdm/2.2/scripts/autoregister.pl -updatehost xxyytteesstt -addmaintenance"
                print(cmd)
                args = shlex.split(cmd)
                p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                out,err = p.communicate()
                autoRegisterLogs.append(out.strip())
                if out.find('Regex not found') > 0:
                    print("Autoregistration failed")
                    #logging.warning("Autoregistration failed")
                    print("Regex for the host %s id not found" % (discovered_host))
                    status = "NOREGEX"
                    #logging.warning("Regex for the host %s id not found" % (discovered_host))
                    add_to_failed_grp(zabbix, discovered_host_id)
                    #notify_failures.append(discovered_host)
                    failedHosts.append(discovered_host)
                    ##add to failed group
                elif out.find('Host is not valid') > 0:
                    print("Autoregistration failed")
                    #logging.warning("Autoregistration failed")
                    print("Invalid host in zabbix" % (discovered_host))
                    status = "INVALIDHOST"
                    #logging.warning("Regex for the host %s id not found" % (discovered_host))
                    add_to_failed_grp(zabbix, discovered_host_id)
                    #notify_failures.append(discovered_host)
                    failedHosts.append(discovered_host)
                    ##add to failed group
                elif p.returncode != 0:
                    print("Autoregistration failed")
                    print(out + err)
                    status = "FAILED"
                    #logging.warning("Autoregistration failed")
                    #logging.warning(out + err)
                    #notify_failures.append(discovered_host)
                    failedHosts.append(discovered_host)
                    ##add to failed group
                else:
                    status = "SUCCESS"
                ##add host to failed grp
                ##call autoregister
        else:
            if no_os_base_template_present(zabbix, discovered_host_id):
               print("%s doesn't have t_os_base template" % (discovered_host))
               status = "NO_OS_BASE_TEMPLATE"
            else:
                 print("Host %s is waiting for sync of system.uname" % (discovered_host))
                 status = "UNSYNC"
        discoveryHostStatus.append("%s - %s" % (discovered_host, status))
    if failedHosts:
        write_file(ZABBIX_NOTICE_FILENAME, '\n'.join(failedHosts))
    if discoveryHostStatus:
        mail_notification('\n'.join(discoveryHostStatus), subject='%s: %s' % (datacenter, HOST_REGISTRATION_MAIL_SUBJECT), logs= '\n'.join(autoRegisterLogs) if autoRegisterLogs else None)
    if os.path.isfile(ANSIBLE_AGENT_HOST_FILENAME):
        hostlist = read_file(ANSIBLE_AGENT_HOST_FILENAME)
        if hostlist.strip() <> '':
            os.environ['ANSIBLE_STDOUT_CALLBACK'] = 'json'
            cmd = '/usr/bin/ansible-playbook -i %s /etc/ansible/agent/zabbix.yml' % ANSIBLE_AGENT_HOST_FILENAME
            args = shlex.split(cmd)
            p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out,err = p.communicate()
            if out and out.find("{") >= 0:
                stats = json.loads(out[out.find("{"):])
                if stats.has_key('stats'):
                    failedHosts = []
                    ansibleHostStatus = []
                    for statHost in stats['stats']:
                        if stats['stats'][statHost]['failures'] > 0 or stats['stats'][statHost]['unreachable'] > 0:
                            failedHosts.append(statHost)
                            status = 'FAILED'
                        else:
                            status = 'SUCCESS'
                        ansibleHostStatus.append("%s - %s" % (statHost, status))
                    if failedHosts:
                        failedHosts = '\n'.join(failedHosts)
                        write_file(ANSIBLE_AGENT_FAILEDHOST_FILENAME, failedHosts)
                    if ansibleHostStatus:
                        mail_notification('\n'.join(ansibleHostStatus), subject='%s: %s' % (datacenter, ANSIBLE_AGENT_MAIL_SUBJECT), logs=out)
            del os.environ['ANSIBLE_STDOUT_CALLBACK']

def read_file(filename):
    data = ''
    try:
        with open(filename, 'r') as read_file:
            data = read_file.read()
    except IOError as ioe:
        if ioe.errno <> errno.ENOENT:
            print(str(ioe))
    return data

def write_file(filename, content):
    try:
        with open(filename, 'w') as outFile:
            outFile.write(content)
    except IOError as ioe:
        print(str(ioe))

def mail_notification(body, subject=None, fromAddress=MAIL_FROM, toAddress=MAIL_TO, logs=None):
    msg = MIMEMultipart()
    msg['From'] = fromAddress
    msg['To'] = ','.join(toAddress)
    msg['Subject'] = subject
    msg.attach(MIMEText(body))
    if logs:
        attachment = MIMEText(logs, 'plain')
        attachment.add_header('Content-Disposition', 'attachment', filename='logs.txt')
        msg.attach(attachment)
    mailServer = None
    try:
        mailServer = SMTP('localhost')
        mailServer.sendmail(fromAddress, toAddress, msg.as_string())
    except Exception as e:
        print(str(e))
    finally:
        if mailServer <> None:
            mailServer.quit()

def get_host_inventory(zabbix):
    inventory = {} ##declare empty dictionary
    #options = { 'output' : [ 'name','host', 'hostid' ] }
    options = { 'output' : 'extend', 'selectInterfaces': [ 'ip', 'port' ] }
    zabbix.timeout = 30
    result = zabbix.host.get(options)
    for record in result:
        name = record['name']
        hostid = record['hostid']
        ip = record['interfaces'][0]['ip']
        try:
            inventory[name] += 1
        except:
            inventory[name] = 1
        try:
            inventory[ip] += 1
        except:
            inventory[ip] = 1

    return inventory

def check_host_in_failedgroup(zabbix, host_id):

    failed_grp = 'failed_automation'
    failed_grp_id = get_hostGrp_id(zabbix,failed_grp)
    options = { 'output' : 'hostid', 'groupids': failed_grp_id, 'hostids': host_id }
    result = zabbix.host.get(options)
    print(failed_grp_id,result)
    try:
        return True if result[0]['hostid'] == host_id else False
    except:
        return False

def add_to_failed_grp(zabbix, host_id):

    failed_grp = 'failed_automation'
    failed_grp_id = get_hostGrp_id(zabbix,failed_grp)
    #options = { 'hostid' : host_id, 'groups': [ {'groupid': failed_grp_id } ], 'hosts': [ {'hostid': host_id} ] }
    options = { 'hostid' : host_id, 'groups': [ {'groupid': failed_grp_id } ] }
    result = zabbix.host.update(options)

    print("Host %d is added to failed group" % (int(host_id)) )
    #print(result)

def init_zabbix_object(config):
    with open('/etc/hosts','r') as fh:
        env = ''

        for line in fh:
            if line != "" and re.search('lab', line):
                env = 'qa'
                break
        else:
            env = 'prod'


        url    = config.get(env,'url')
        user   = config.get(env,'user')
        passwd = config.get(env,'password')

        print(url)
        zabbix = ZabbixAPI(server=url)
        zabbix.login(user,passwd)
        print("Connected to Zabbix API Version %s" % zabbix.api_version())

    return zabbix



def get_hosts_from_grp(zabbix, host_group):
    try:
        hgrpId = get_hostGrp_id(zabbix, host_group)
        options = {'output' : 'extend', 'groupids' : [hgrpId], 'selectInterfaces': [ 'ip', 'port' ] };
        results = zabbix.host.get(options)
        #print(results)

        hosts_and_ips = [ {'name':results[i]['name'], 'hostid': results[i]['hostid'], 'ip':results[i]['interfaces'][0]['ip']} for i in xrange(len(results))]
        #hosts = [ name for name in results[i]['name'] for i in xrange(len(results))]
        return hosts_and_ips
    except Exception as e:
        print(e)

def get_hostGrp_id(zabbix,hostGrp):
    options = {'output': 'extend', 'filter': { 'name':hostGrp } }
    results = zabbix.hostgroup.get(options)

    try:
        return results[0]['groupid']
    except (IndexError,KeyError) as e:
        print("Group Id not found for group %s" % (hostGrp))


def get_host_id(zabbix,host):
    options = {'output': 'extend', 'filter': {'name':host} }
    results = zabbix.host.get(options)

    try:
        return results[0]['hostid']
    except (IndexError,KeyError) as e:
        print("Host Id not found for host %s" % (host))

def no_os_base_template_present(zabbix,hostid):
   options = {'output': ['hostid'],'selectParentTemplates': ['name'],'hostids': hostid}
   results = zabbix.host.get(options)
   try:
        templates=results[0]['parentTemplates']
        no_basetemplate_present=True
        for temp in templates:
            template=temp['name']
            Result = template.lower() == "T_OS_BASE".lower()
            if Result == True:
                print ("base template found")
                no_basetemplate_present=False
        return no_basetemplate_present
   except (IndexError,KeyError) as e:
        print("os base template search failed  %s" % (host))
def get_item_sytem_uname_sync(zabbix,hostid):
    if no_os_base_template_present(zabbix, hostid):
        return False
    options = {'output': 'extend', 'hostids': [ hostid ], 'filter': {'key_':'system.uname'} }
    results = zabbix.item.get(options)

    try:
        if len(results) > 0:
            if results[0].get('lastvalue', "0") <> "0":
                return True
            elif results[0].get('lastvalue', "0") <> "0":
                return True
        return False
    except (IndexError,KeyError) as e:
        print("Item Id not found for host %s" % (host))

def _find_datacenterNumber(content):
    if content:
        content = content.strip()
        match = re.search(DATACENTER_PATTERN, content)
        if match:
            return 'DC%s' % int(match.group(1))
        if content.find('lab'):
            return 'DC%s' % 13
    return None

def find_datacenter():
    datacenter = _find_datacenterNumber(read_file(DATACENTER_HOSTNAME_FILE))
    if not datacenter:
        content = read_file(DATACENTER_HOSTS_FILE).strip()
        hosts = content.split("\n")
        for line in hosts:
            host = line.strip()
            if len(host) > 0 and host.find("#") != 0:
                datacenter = _find_datacenterNumber(host)
                if datacenter:
                    return datacenter
    return datacenter

def find_env_details(inp):
    with open( '/etc/hosts', 'r') as f:
        env = None
        configFile = None

        if inp == 'env':
            for line in f:
                if re.search(r'lab',line):
                    env = 'qa'
                else:
                    env = 'prod' ;
            return env;
        elif inp == 'config':
            for line in f:
                if re.search(r'mg4zbxserver01',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf'
                elif re.search(r'pc23',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf'
                elif re.search(r'pc22',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC22.conf'
                elif re.search(r'ss42',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf'
            return configFile;


if __name__ == '__main__':
    main()

