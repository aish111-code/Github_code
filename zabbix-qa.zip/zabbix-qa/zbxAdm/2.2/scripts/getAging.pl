#!/usr/bin/perl

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
#use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

my @hostid;
my $os_template;

# Add Modules and functions into local scope

	use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
	use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
	use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
	use TLDs qw(pfail);

	use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os);
	use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
	use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
	use SFSF::Log qw(addtoLogfile);
	use SFSF::Trigger qw(get_triggerobj gettriggerobj_val);

# Detect running env and set the connection variables

	open(my $fh,'< /etc/hosts');
	my $env;

	while (my $line = <$fh>)
	{
   		chomp $line;
   		if ($line ne "" and $line =~ m/lab/ )
        	{	
        		$env = 'qa';
        	}
    		else { $env = 'prod' ; }
	}	

# Load API properites file

	my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
  	pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
  	pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
  	pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp
	
	my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


			# Get hostid

			#my %hfilter = ('name' => $h);
			#my @hostobj = get_hostobj($zabbix,\%hfilter);
			#@hostid = get_hostobj_val(\@hostobj,"hostid");
  
			#my %hfilter1 = ('host' => $h,'selectgroups' => 'extend');	
			#my @hostobj1 = get_hostobj($zabbix,\%hfilter1);
			#print Dumper(@hostobj1);

			#my %tfilter = ('active' => 1, 'monitored' => 1, 'skipDependent' => 1, 'filter' => ( 'value' => 1), 'output' => 'extend');
			#my %tfilter = ('value' => 1, 'output' => 'extend','templateid' => '10036');

			#my @tobj = get_triggerobj($zabbix,\%tfilter);
		        #print Dumper(@tobj);	

# working option with hostgroup filter

#my $options = {'active' => 1, 'groupids' => '1084', 'monitored' => 1, 'expandDescription' => 1,'skipDependent' => 1, 'filter' => { 'value' => 1}, 'output' => 'extend'};

# list of triggers from a template

=pod
my $options = {'templateids' => '10336','expandDescription' => 1,'output' => 'extend'};

my $triggers = $zabbix->raw('trigger','get', $options);


#print Dumper($triggers);

foreach my $trigger (@{$triggers} ) 
{

   if ( $trigger->{'value'} == 1)
	{
    
	print "Trigger id - $trigger->{'triggerid'} Hostid - $trigger->{'hostid'} $trigger->{'description'}\n"; 

	}

}

# list of problem events

=cut

#my $options = {'output' => 'extend','triggerids' => '10342329','filter' => {'value' => '1'},'expandDescription' => 1 };
my $options = {'output' => 'extend','expandDescription' => 1,'filter' => {'value' => '1'}};

my $triggers = $zabbix->raw('trigger','get', $options);


print Dumper($triggers);

=pod
foreach my $trigger (@{$triggers} )
{

   if ( $trigger->{'value'} == 1)
        {

        print "Trigger id - $trigger->{'triggerid'} Hostid - $trigger->{'hostid'} $trigger->{'description'}\n";

        }

}
=cut

=pod
foreach my $trigger (@{$triggers} ) {
#    print Dumper($trigger);

   my $options1 = {'output' => 'extend','objectids' => $trigger->{'triggerid'}};

   my $event = $zabbix->raw('event','get',$options1);

    #my $event = $zabbix->get('event', {'output' => 'extend', 'select_acknowledges' => 'extend', 'triggerids' => $trigger->{'triggerid'},'filter' => {'object' => '0', 'value' => '1'}, 'sortfield' => ['eventid'], 'sortorder' => 'DESC', 'limit' => '1'});

    print Dumper ($event);

}	

=cut


