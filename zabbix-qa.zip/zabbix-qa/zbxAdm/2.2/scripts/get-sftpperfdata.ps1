#########################################################################################
# FRR: 04/12/2016
# Contact: frank.roeder@sap.com
# eftpserverreport.ps1
#
# Version: 0.1
#
# polls the performance information from the eftp servers
# 
#########################################################################################


<#
.SYNOPSIS

.DESCRIPTION
This script is used to gather some of the performance information to collect them with the 
zabbix agent.

If you have questions or you found a bug write to frank.roeder@sap.com

.PARAMETER username
This parameter is used to provide a username which is used to connect to the EFTP Server

.PARAMETER password
Password for the user to connect to the server

.PARAMETER servername
The servername which has to be queried. If not provided "localhost" is used.

.PARAMETER currentconnectioncount
With this parameter set the script returns the active current sessions to the server

.PARAMETER uniqueusers
With this parameter the script gives you the count of the unique users back.
If one useraccount has multiple connections open then he will only counted once.

.PARAMETER topfiveusers
This parameter returns the top five users which are having the most connections open.
Not useful for zabbix but good for troubleshooting.

.PARAMETER currentuploads
This parameter returns the current running uploads on the server

.PARAMETER currentdownloads
This parameter returns the current running downloads on the server

.PARAMETER averagespeed
This parameter returns the current combined upload and download speed in MB/s

.EXAMPLE
Returns the current count of active connections
.\get-sftpperfdata -username Admin -password TopSecret!! -currentconnections

.EXAMPLE
Returns the current unique users
.\get-sftpperfdata -username Admin -password TopSecret!! -currentconnections

#>

[CmdletBinding()]
Param(
  [Parameter(Mandatory=$False,Position=1)]
   [STRING]$username,
   [Parameter(Mandatory=$True,Position=2)]
   [STRING]$password,
   [Parameter(Position=3)]
   [STRING]$servername = "localhost",
   [SWITCH]$currentconnectioncount,
   [SWITCH]$uniqueusers,
   [SWITCH]$topfiveusers,
   [SWITCH]$currentdownloads,
   [SWITCH]$currentuploads,
   [SWITCH]$averagespeed
)
#Create server object and connect to the server
try{
 $server = New-Object -comobject "SFTPCOMInterface.CIServer"
 $server.connect($servername,1100,$username,$password)
 $sites = $server.sites()
 #Because we only have one site i can select the first object in the array
 $site = $sites.item(0)
}
catch
{
 write-host "-2" -nonewline
}
##############################lets grab the info#########################################
if($currentconnectioncount){
    try
    {
        write-host "$($site.getconnectedcount())" -nonewline
    }
    catch
    {
        -2
    }
}
elseif($uniqueusers){
    
    
    $users = $site.getconnectedusers()
	
	if (!$users)
	{ 
	write-host "0" -nonewline 
	}
else	{
	write-host "$(($users | %{($_.split(" "))[1]} | Select-Object -Unique).count)" -nonewline
	}     
	}
	
	
elseif($topfiveusers){
    try
    {
        $users = $site.getconnectedusers()
        $users | %{($_.split(" "))[1]} | group-object -noelement | sort-object count -desc | select-object -first 5
    }
    catch
    {
        write-host "-2" -nonewline
    }
}
elseif($currentdownloads){
    try
    {
        write-host "$($site.getdownloadcount())" -nonewline
    }
    catch
    {
        write-host "-2" -nonewline
    }
}
elseif($currentuploads){
    try
    {
        write-host "$($site.getuploadcount())" -nonewline
    }
    catch
    {
        write-host "-2" -nonewline
    }
}
elseif($averagespeed){
    try
    {
        write-host "$("{0:0.00}" -f (($site.averagespeed) / 1024))" -nonewline
    }
    catch
    {
        write-host "-2" -nonewline
    }
}
