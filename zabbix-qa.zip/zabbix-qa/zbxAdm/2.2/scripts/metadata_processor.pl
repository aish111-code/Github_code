#!/usr/bin/perl 

####################################
# Program to process metadata for hosts and update visible name and create new metadata macro
# Author : Sandeep M.R & Patrick Presto
# Date   : May 13th 2015
#####################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
#use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;


# Local variable declaration

my @hostid;
my $os_template;

# Add Modules and functions into local scope

	use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
	use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
	use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
	use TLDs qw(pfail);

	use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
	use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
	use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
	use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables

	open(my $fh,'< /etc/hosts');
	my $env;

	while (my $line = <$fh>)
	{
   		chomp $line;
   		if ($line ne "" and $line =~ m/lab/ )
        	{	
        		$env = 'qa';
        	}
    		else { $env = 'prod' ; }
	}	

# Load API properites file

	my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
  	pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
  	pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
  	pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp
	
	my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


   	my %args;
	my @host;
	my @hostgroup;



my $dir = "/var/log/zabbix/METADATA/*";

my @files = glob( $dir );

my $count = @files;

if ( $count ne '0' )
{

	foreach (@files) 
	{

	# read host metadata values from each files

	open(F1, "< $_");	
	my ($line) = $_;
	while ($line = <F1> )
 	{
	my @linevalue = split(' ',$line);
	my $host=$linevalue[0];
	my $metadata=$linevalue[1];
 	print "$host $metadata\n";	
	 addtoLogfile("---------------------------------","");
         addtoLogfile("Starting Metadata Processing","");
         addtoLogfile("Hostname - $host ","");
         addtoLogfile("Metadata - $metadata ","");

			my %hfilter = ('name' => $host);
                        my @hostobj = get_hostobj($zabbix,\%hfilter);
                        my @hostid = get_hostobj_val(\@hostobj,"hostid");
         addtoLogfile("Hostid - $hostid[0] ","");
	 host_create_macro($zabbix,\@hostid,$metadata,'{$MY_METADATA}');
          my @updated_name = update_host_visible_name($zabbix,$hostid[0],$metadata);
         addtoLogfile("Visible name updated","");

         addtoLogfile("Ending Metadata Processing","");

  	}
	close (F1);
	unlink ("$_");

	}
}
