#!/usr/bin/python
##
##input to this script is host_discovered group and monsoon group
##loop through the hosts
import sys
sys.path.append('/usr/local/etc/zbxAdm/2.2/lib/zbxpylib')
from zabbix_api import ZabbixAPI
from RSM import parseConfig
import re
from pprint import pprint
import subprocess
import os
import shlex
#import logging

if len(sys.argv) < 2:
    print("Usage: %s <host group e.g. host_discovered or monsoon> [ optional dc number e.g. DC23 ]" % (sys.argv[0]))
    sys.exit()

def main():
    inp_host_group = sys.argv[1]

    env = find_env_details('env')
    configFile = find_env_details('config')



##just checking if user explicitly passed dc number. If passed used that config file
    try:
        dc = sys.argv[2]
        configFile = "/usr/local/etc/zbxAdm/2.2/conf/zbx" + dc + ".conf"
    except:
        configFile = configFile

    print("configFile to use %s" % (configFile) )
    config = parseConfig(configFile)

    failed_grp = 'failed_automation'
#failed_grp_id = 4833
#logging.basicConfig(filename='/var/log/zabbix/automated_zabbix_registration.log',level=logging.DEBUG)
#logging.basicConfig(filename='automated_zabbix_registration.log',level=logging.DEBUG)
#logging.debug('This message should go to the log file')



    """
    ##logic to check if host is already in failed hostgroup
    #1 Check host name is duplicate
    #2 Check IP is duplicate
    #3 Check latest data already collected.

    #if none of above failed then autoregister
    #else Add to failed hostgroup

    """



    zabbix = init_zabbix_object(config)

    failed_grp_id = get_hostGrp_id(zabbix,failed_grp)

    host_inventory = get_host_inventory(zabbix)
    #print(host_inventory)
    #pprint(host_inventory)
    hosts_ips_from_discovered_grp = get_hosts_from_grp(zabbix, inp_host_group)
    #hosts = ['Test.ams2.sf.priv']
    #print(hosts)

    for data in hosts_ips_from_discovered_grp:
        discovered_host = data['name']
        discovered_ip = data['ip']
        discovered_host_id = get_host_id(zabbix,discovered_host)
        #print(host_id)
        #is_in_failedgrp = check_host_in_failedgroup(zabbix, host_id)
        #is_in_failedgrp = check_host_in_failedgroup(zabbix, 123)
        if check_host_in_failedgroup(zabbix,discovered_host_id):
            print("Host %s is in failed group" % (discovered_host) )
            #logging.warning("Host %s is in failed group" % (discovered_host) )
            ##do nothing
            msgFileObj.write(discovered_host + "\n")
        else:
            #check host in duplicate
            if host_inventory[discovered_host] > 1 or host_inventory[discovered_ip] > 1:
                print("%s is a duplicate " % (discovered_host))
                #logging.warning("%s is a duplicate " % (discovered_host))
                ##add it to failed host group
                add_to_failed_grp(zabbix, discovered_host_id)
                msgFileObj.write(discovered_host + "\n")
            else:
                if get_item_sytem_uname_sync(zabbix, discovered_host):
                    print("Calling autoregistration script")
                    #cmd = "/usr/local/etc/zbxAdm/2.2/scripts/autoregister.pl -updatehost %s -addmaintenance" % (discovered_host)
                    cmd = "/usr/local/etc/zbxAdm/2.2/scripts/autoregister.pl -updatehost %s -addmaintenance" % (discovered_host)
                    #cmd = "/usr/local/etc/zbxAdm/2.2/scripts/autoregister.pl -updatehost xxyytteesstt -addmaintenance"
                    print(cmd)
                    args = shlex.split(cmd)
                    p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    out,err = p.communicate()
                    if out.startswith('Regex not found'):
                        print("Autoregistration failed")
                        #logging.warning("Autoregistration failed")
                        print("Regex for the host %s id not found" % (discovered_host))
                        #logging.warning("Regex for the host %s id not found" % (discovered_host))
                        add_to_failed_grp(zabbix, discovered_host_id)
                        #notify_failures.append(discovered_host)
                        msgFileObj.write(discovered_host + "\n")
                        ##add to failed group
                    elif out.startswith('Host is not valid'):
                        print("Autoregistration failed")
                        #logging.warning("Autoregistration failed")
                        print("Invalid host in zabbix" % (discovered_host))
                        #logging.warning("Regex for the host %s id not found" % (discovered_host))
                        add_to_failed_grp(zabbix, discovered_host_id)
                        #notify_failures.append(discovered_host)
                        msgFileObj.write(discovered_host + "\n")
                        ##add to failed group
                    elif p.returncode != 0:
                        print("Autoregistration failed")
                        print(out + err)
                        #logging.warning("Autoregistration failed")
                        #logging.warning(out + err)
                        #notify_failures.append(discovered_host)
                        msgFileObj.write(discovered_host + "\n")
                        ##add to failed group

                    ##add host to failed grp
                    ##call autoregister


def notify_failure():

    email = "pradip.kumar.k@sap.com,s.renuka@sap.com,sreekanth.kp@sap.com,nandhini.chander@sap.com,jibin.sunny@sap.com,rakhesh.ms@sap.com"

    mailCmd = """cat  %s | mailx -r "ZBX-PLT@sap.com" -s "Automated zabbix host registration failed" %s""" % (msgFile,email)

    os.system(mailCmd)

def get_host_inventory(zabbix):
    inventory = {} ##declare empty dictionary
    #options = { 'output' : [ 'name','host', 'hostid' ] }
    options = { 'output' : 'extend', 'selectInterfaces': [ 'ip', 'port' ] }
    zabbix.timeout = 30
    result = zabbix.host.get(options)
    for record in result:
        name = record['name']
        hostid = record['hostid']
        ip = record['interfaces'][0]['ip']
        try:
            inventory[name] += 1
        except:
            inventory[name] = 1
        try:
            inventory[ip] += 1
        except:
            inventory[ip] = 1

    return inventory

def check_host_in_failedgroup(zabbix, host_id):

    failed_grp = 'failed_automation'
    failed_grp_id = get_hostGrp_id(zabbix,failed_grp)
    options = { 'output' : 'hostid', 'groupids': failed_grp_id, 'hostids': host_id }
    result = zabbix.host.get(options)
    try:
        return True if result[0]['hostid'] == host_id else False
    except:
        return False

def add_to_failed_grp(zabbix, host_id):

    failed_grp = 'failed_automation'
    failed_grp_id = get_hostGrp_id(zabbix,failed_grp)
    #options = { 'hostid' : host_id, 'groups': [ {'groupid': failed_grp_id } ], 'hosts': [ {'hostid': host_id} ] }
    options = { 'hostid' : host_id, 'groups': [ {'groupid': failed_grp_id } ] }
    result = zabbix.host.update(options)

    print("Host %d is added to failed group" % (int(host_id)) )
    #print(result)

def init_zabbix_object(config):
    with open('/etc/hosts','r') as fh:
        env = ''

        for line in fh.readline():
            if line != "" and re.match('lab', line):
                env = 'qa'
                break
        else:
            env = 'prod'


        url    = config.get(env,'url')
        user   = config.get(env,'user')
        passwd = config.get(env,'password')

        zabbix = ZabbixAPI(server=url)
        zabbix.login(user,passwd)
        print("Connected to Zabbix API Version %s" % zabbix.api_version())

    return zabbix



def get_hosts_from_grp(zabbix, host_group):
    try:
        hgrpId = get_hostGrp_id(zabbix, host_group)
        options = {'output' : 'extend', 'groupids' : [hgrpId], 'selectInterfaces': [ 'ip', 'port' ] };
        results = zabbix.host.get(options)
        #print(results)

        hosts_and_ips = [ {'name':results[i]['name'], 'ip':results[i]['interfaces'][0]['ip']} for i in xrange(len(results))]
        #hosts = [ name for name in results[i]['name'] for i in xrange(len(results))]
        return hosts_and_ips
    except Exception as e:
        print(e)

def get_hostGrp_id(zabbix,hostGrp):
    options = {'output': 'extend', 'filter': { 'name':hostGrp } }
    results = zabbix.hostgroup.get(options)

    try:
        return results[0]['groupid']
    except (IndexError,KeyError) as e:
        print("Group Id not found for group %s" % (hostGrp))


def get_host_id(zabbix,host):
    options = {'output': 'extend', 'filter': {'name':host} }
    results = zabbix.host.get(options)

    try:
        return results[0]['hostid']
    except (IndexError,KeyError) as e:
        print("Host Id not found for host %s" % (host))

def get_item_sytem_uname_sync(zabbix,host):
    options = {'output': 'extend', 'host': host, 'filter': {'key_':'system.uname'} }
    results = zabbix.item.get(options)

    try:
        if len(results) > 0:
            if len(str(results[0].get('lastvalue', ''))) > 0:
                return True
            elif len(str(results[0].get('prevalue', ''))) > 0:
                return True
        return False
    except (IndexError,KeyError) as e:
        print("Item Id not found for host %s" % (host))

def find_env_details(inp):

    with open( '/etc/hosts', 'r') as f:
        env = None
        configFile = None

        if inp == 'env':
            for line in f:
                if re.search(r'lab',line):
                    env = 'qa'
                else:
                    env = 'prod' ;
            return env;
        elif inp == 'config':
            for line in f:
                if re.search(r'mg4zbxserver01',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf'
                elif re.search(r'pc23',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf'
                elif re.search(r'ss42',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf'
            return configFile;


if __name__ == '__main__':
    msgFile = "/tmp/zbx_automation_notice.txt"
    msgFileObj = open(msgFile,'w')
    main()
    msgFileObj.close()
    notify_failure()
