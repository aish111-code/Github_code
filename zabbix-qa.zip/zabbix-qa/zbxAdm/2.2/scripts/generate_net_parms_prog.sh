#!/bin/bash
# Version 0.1c
# Updated 2016-03-01
# Last updated 2016-03-06
# By Kevin Fu and KP, Sreekanth
# Updated to Puppet by Jayavardhan (C5176337)

BASEDIR=/root/network-tunning
LOGDIR=${BASEDIR}/log
ETCDIR=${BASEDIR}/etc
BINDIR=${BASEDIR}/bin

if [ ! -d ${BASEDIR} ]; then
    mkdir -p ${BASEDIR}
fi

if [ ! -d ${LOGDIR} ]; then
    mkdir -p ${LOGDIR}
fi

if [ ! -d ${ETCDIR} ]; then
    mkdir -p ${ETCDIR}
fi

if [ ! -d ${BINDIR} ]; then
    mkdir -p ${BINDIR}
fi

TIMESTAMP=`date +%Y%m%d%H%M%S`

cp /etc/sysctl.conf ${ETCDIR}/sysctl.conf.${TIMESTAMP}
sysctl -a |egrep "net.core|net.ipv4" > ${ETCDIR}/all_original_net_parms_${TIMESTAMP}.txt



for v in net.core.wmem_max net.core.rmem_max net.ipv4.tcp_rmem net.ipv4.tcp_wmem net.ipv4.tcp_mem net.core.netdev_max_backlog net.ipv4.tcp_max_syn_backlog net.ipv4.tcp_timestamps net.ipv4.tcp_synack_retries net.ipv4.tcp_keepalive_time net.ipv4.tcp_keepalive_probes net.ipv4.tcp_keepalive_intvl net.ipv4.tcp_fin_timeout net.core.somaxconn net.ipv4.tcp_synack_retries net.ipv4.tcp_retries2 net.ipv4.tcp_tw_recycle net.ipv4.tcp_tw_reuse net.ipv4.tcp_window_scaling
do
    sysctl $v >> ${ETCDIR}/relevant_original_net_parms_${TIMESTAMP}.txt
done

echo "#!/bin/bash" > ${BINDIR}/restore_parms_${TIMESTAMP}.sh
sed -e 's/ = /=/' -e 's/net./sysctl -w net./' ${ETCDIR}/relevant_original_net_parms_${TIMESTAMP}.txt >> ${BINDIR}/restore_parms_${TIMESTAMP}.sh
sed -i -e "s/tcp_wmem=/tcp_wmem='/" -e "s/tcp_rmem=/tcp_rmem='/" -e "s/tcp_mem=/tcp_mem='/" -e "/tcp_wmem/ s/$/'/" -e "/tcp_rmem/ s/$/'/" -e "/tcp_mem/ s/$/'/"  ${BINDIR}/restore_parms_${TIMESTAMP}.sh
echo "sed -i '/txqueuelen/d' /etc/rc.d/boot.local" >>  ${BINDIR}/restore_parms_${TIMESTAMP}.sh

echo "for i in \`ifconfig |grep "eth"|grep HWaddr|awk '{print \$1}'|cut -d":" -f1|sort|uniq\`" >> ${BINDIR}/restore_parms_${TIMESTAMP}.sh
echo "do" >> ${BINDIR}/restore_parms_${TIMESTAMP}.sh
echo "  ifconfig \$i txqueuelen 1000"  >> ${BINDIR}/restore_parms_${TIMESTAMP}.sh
echo "done" >> ${BINDIR}/restore_parms_${TIMESTAMP}.sh

for v in net.core.wmem_max net.core.rmem_max net.ipv4.tcp_rmem net.ipv4.tcp_wmem net.ipv4.tcp_mem net.core.netdev_max_backlog net.ipv4.tcp_max_syn_backlog net.ipv4.tcp_timestamps net.ipv4.tcp_synack_retries net.ipv4.tcp_keepalive_time net.ipv4.tcp_keepalive_probes net.ipv4.tcp_keepalive_intvl net.ipv4.tcp_fin_timeout net.core.somaxconn net.ipv4.tcp_synack_retries net.ipv4.tcp_retries2 net.ipv4.tcp_tw_recycle net.ipv4.tcp_tw_reuse net.ipv4.tcp_window_scaling
do
    echo "sed -i \"/$v/d\" /etc/sysctl.conf" >> ${BINDIR}/restore_parms_${TIMESTAMP}.sh
done
echo "sed -i '/set_parms.sh/d' /etc/sysctl.conf" >> ${BINDIR}/restore_parms_${TIMESTAMP}.sh

chmod u+x ${BINDIR}/restore_parms_${TIMESTAMP}.sh

echo "#!/bin/bash" > ${BINDIR}/set_parms.sh
for v in net.core.wmem_max net.core.rmem_max net.ipv4.tcp_rmem net.ipv4.tcp_wmem net.ipv4.tcp_mem net.core.netdev_max_backlog net.ipv4.tcp_max_syn_backlog net.ipv4.tcp_timestamps net.ipv4.tcp_synack_retries net.ipv4.tcp_keepalive_time net.ipv4.tcp_keepalive_probes net.ipv4.tcp_keepalive_intvl net.ipv4.tcp_fin_timeout net.core.somaxconn net.ipv4.tcp_synack_retries net.ipv4.tcp_retries2 net.ipv4.tcp_tw_recycle net.ipv4.tcp_tw_reuse net.ipv4.tcp_window_scaling
do
    echo "sed -i \"/$v/d\" /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
done
echo "sed -i '/set_parms.sh/d' /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"#Added by script ${BINDIR}/set_parms.sh\"  >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.core.wmem_max=134217728\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.core.rmem_max=134217728\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_rmem=4096 87380 67108864\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_wmem=4096 65536 67108864\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_mem=67108864 67108864 67108864\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.core.netdev_max_backlog=16384\" >> /etc/sysctl.conf"   >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_max_syn_backlog=8192\" >> /etc/sysctl.conf"  >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_timestamps=0\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_synack_retries=3\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_keepalive_time=1000\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_keepalive_probes=4\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_keepalive_intvl=20\" >> /etc/sysctl.conf"    >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_fin_timeout=30\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.core.somaxconn=512\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_synack_retries=3\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_retries2=6\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_tw_recycle=0\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_tw_reuse=0\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "echo \"net.ipv4.tcp_window_scaling=1\" >> /etc/sysctl.conf" >> ${BINDIR}/set_parms.sh
echo "sysctl -p" >> ${BINDIR}/set_parms.sh
echo "sed -i '/^ifconfig .*txqueuelen.*/ d' /etc/rc.d/boot.local" >> ${BINDIR}/set_parms.sh
echo "for i in \`ifconfig |grep "eth"|grep HWaddr|awk '{print \$1}'|cut -d":" -f1|sort|uniq\`" >> ${BINDIR}/set_parms.sh
echo "do" >> ${BINDIR}/set_parms.sh
echo "  ifconfig \$i txqueuelen 10000"  >> ${BINDIR}/set_parms.sh
echo "  echo \"ifconfig \$i txqueuelen 10000\" >> /etc/rc.d/boot.local" >> ${BINDIR}/set_parms.sh
echo "  echo -n \"\$i : \" " >> ${BINDIR}/set_parms.sh
echo "  ifconfig \$i |grep txqueuelen|awk '{print \$2}' " >> ${BINDIR}/set_parms.sh
echo "done" >> ${BINDIR}/set_parms.sh

chmod u+x ${BINDIR}/set_parms.sh

if [ ! -f ${BINDIR}/$0 ]; then
    cp $0 ${BINDIR}/$0
    chmod u+x ${BINDIR}/$0
fi

diff $0 ${BINDIR}/$0 > /dev/null
if [ $? -eq 1 ]; then
    cp ${BINDIR}/$0 ${BINDIR}/$0.${TIMESTAMP}
    cp $0 ${BINDIR}/$0
    chmod u+x ${BINDIR}/$0
fi

echo "This is a master script."
echo "Run ${BINDIR}/set_parms.sh for setting parameters."
echo "Run ${BINDIR}/restore_parms_${TIMESTAMP}.sh if you want to restore"
echo "If you want to restore to any previous time stamp, check values in ${ETCDIR} and run curresponding script in ${BINDIR}"


