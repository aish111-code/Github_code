#!/usr/bin/perl

##################################################################
# Author        : Vikky Omkar
# Purpose       : Zabbix Admin tasks
# Reviewer      : Sandeep M.R
# Version       : Oct 20th 2015 - Initial code
#
####################################################################


use strict;
use warnings;

my $solarwinds_home  = "/usr/local/etc/zbxAdm/2.2/scripts/solarwinds_api/";

# Build @INC to point to relative ./lib for modules

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;

# Local variable declaration

my @hostname;

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);
use SFSF::Host  qw(host_maintenance changestatus updatefqdn gethostnames_fromHostgroup gettechnames_fromHostgroup get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val build_host_template_list host_update search_cfg_Templates get_host_ip host_create_macro host_create_jmxinterface host_check_jmxinterface getHostnames_fromHostgroup build_config_mapping get_host_os check_temp_exists update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata host_metadatamacro hostcreate);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Item qw(getLocalItems deletelocalitems getLocalItemsByHostId);
use SFSF::Web qw(getlocalwebmonitoring deletelocalwebmonitoring getLocalWebScenarioByHostId);
use SFSF::Discovery qw(getlocaldiscoveryrule deletelocaldiscoveryrule getLocalDRuleByHostId);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Trigger qw(getlocaltriggers deletelocaltriggers get_triggerobj gettriggerobj_val);
use SFSF::Log qw(addtoLogfile);


# Detect running env and set the connection variables

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';


#=pod
my %args;
my @alertname;

GetOptions(\%args,
                        "DecommissionHost",
                        "LookupSlrGroup",
                        "LookupSlrRecord",
			"Maintenance=s",
                        "LookupMonitorStat",
                        "DecommissionGroup",
			"EnableHost=s",
                        "EnableGroup=s",
                        "DisableHost=s",
                        "DisableGroup=s",
                        "dc=s"
           )
           or die "Invalid arguments ! Required Param: $0 -UpdateFqdnName <Present_Name> \n";
if( ! scalar keys %args ) {
    die "Missing options -
                -LookupSlrGroup <groupname OR all>
                -LookupSlrRecord <all OR PlayerName OR NoPlayer>
		-Maintenance <Host> <add/remove>
                -DecommissionHost  <Host_Name>
                -DecommissionGroup  <File Containing Hosts>
                -LookupMonitorStat <MonitorName>
		-EnableHost <Host name>
                -EnableGroup <File with hosts>
                -DisableHost <Host name>
                -DisableGroup <File with hosts>
                -dc <DC22|DC23>\n";
}

if ( exists $args{dc} && $args{dc} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{dc} && uc $args{dc} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}
my $config = get_rsm_config($configFile);
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};

my $username = $ENV{LOGNAME} || $ENV{USER} || getpwuid($<);
##precaution from running from rundeck. Remove the optionname if it doesn't have a value
if( ! $args{EnableHost} ) {
    delete $args{EnableHost};
}
if( ! $args{DisableHost} ) {
    delete $args{DisableHost};
}
my @key = keys (%args);
# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

switch ($key[0]){

        case "LookupMonitorStat" {
                                     chomp(my $monitorName = $ARGV[0]);
                                     my $output =`/usr/local/etc/zbxAdm/2.2/scripts/solarwinds_api/scripts/solarwinds.sh "LookupMonitorStat" "$monitorName"`;
                                     print "$output";
                                 }

	case  "Maintenance"      {
                                     my @host = values (%args);
                                     my $status = $ARGV[0];

                                     #API call to get hostid
                                     my $hostid = get_hostid($zabbix,$host[0]);
                                     die "No hosts found" unless defined $host[0];

                                     my $maintenance = host_maintenance($zabbix,$hostid,$status);
                                     die "No hostid found" unless defined $hostid;
                                 }


         case "LookupSlrGroup"   { 

                                     chomp(my $group_Name = $ARGV[0]);
                                     my $output =`/usr/local/etc/zbxAdm/2.2/scripts/solarwinds_api/scripts/solarwinds.sh "LookupSlrGroup"  "$group_Name"`;
                                     print "$output";

                                 }

        case "LookupSlrRecord"   {
                                     chomp(my $group_Name = $ARGV[0]);
                                     my $output =`/usr/local/etc/zbxAdm/2.2/scripts/solarwinds_api/scripts/solarwinds.sh "LookupSlrRecord"  "$group_Name"`;
                                     print "$output";
                                 }

        case "DecommissionHost"  {
                                     chomp(my $hostName = $ARGV[0]);
                                     $hostName = strip($hostName);

                                     if( decomHost($hostName) ) {
                                          print "Decom Host failed for $hostName .  Aborting......\n";
                                          addtoLogfile("Decom Host failed for $hostName .  Aborting......\n","");
                                     }

                                     deleteSolarwindsMonitor($hostName);
                                 }
        case  "DecommissionGroup" {

                                     chomp(my $fileName= $ARGV[0]);

                                     open my $FH, $fileName or die "Could not open file $fileName :$! ";
                                     while ( my $hostName = <$FH> ) {
                                         chomp($hostName) ;
                                         $hostName = strip($hostName);
                                         decomHost($hostName);

                                         deleteSolarwindsMonitor($hostName);
                                     }
                                 }
	case  "EnableHost" {
                                     chomp(my $hostName = $args{EnableHost});
                                     $hostName = strip($hostName);
                                     my @hostNames = split /,/, $hostName;

                                     if ( $args{EnableHost} ) {
                                         enableHost(\@hostNames); ####run if hostname is passed after EnableHost option
          
                                         remanageSolarwindsMonitor(\@hostNames);
                                     }
        }
        case "EnableGroup" {
                                     chomp(my $fileName= $args{EnableGroup});

                                     open my $FH, $fileName or die "Could not open file $fileName :$! ";
                                     while ( my $hostName = <$FH> ) {
                                         chomp($hostName) ;
                                         $hostName = strip($hostName);
                                         enableHost([$hostName]);

                                         remanageSolarwindsMonitor([$hostName]);
                                     }
                                     close($FH);
        }
        case  "DisableHost" {
                                     chomp(my $hostName = $args{DisableHost});
                                     $hostName = strip($hostName);
                                     my @hostNames = split /,/, $hostName;

                                     if( $args{DisableHost} ) {
                                         disableHost(\@hostNames);  ##run if hostname is passed after DisableHost option

                                         unmanageSolarwindsMonitor(\@hostNames);
                                     }
        }
        case "DisableGroup" {
                                     chomp(my $fileName= $args{DisableGroup});

                                     open my $FH, $fileName or die "Could not open file $fileName :$! ";
                                     while ( my $hostName = <$FH> ) {
                                         chomp($hostName) ;
                                         $hostName = strip($hostName);
                                         disableHost([$hostName]);

                                         unmanageSolarwindsMonitor([$hostName]);
                                     }
                                     close($FH);
        }

}

############################################################################
##name:   deleteLocalItems 
##Desc:   Deletes local items, triggers, Drules, web scenarios etc.
##Author: Pradip Kumar K
##Modified by: 
##Date:   March 11 2016
############################################################################
sub deleteLocalItems {
    my ( $zabbix, $hostId ) = @_;

    if( ! defined $zabbix || ! defined $hostId ) {
        print "No zabbix object or hostname as input parameter to deleteLocalItems function \n";
        return 1;
    }
    #######################################################################################
    ############delete local items ########################################################
    #######################################################################################
    my $myresult = getLocalItemsByHostId($zabbix,$hostId);
    if( defined $myresult ) {
        my @itemNames = ();
    	my @itemIds = ();
    	if( ref $myresult eq 'ARRAY' ) {
    	    foreach my $itemData ( @$myresult ) {
                if( $itemData->{itemid} && $itemData->{name} ) {
    		    push @itemIds, $itemData->{itemid};
                    push @itemNames, $itemData->{name};
                }
    	    }
    	}
    	else{
            if( $myresult->{itemid} && $myresult->{name} ) {
                push @itemIds, $myresult->{itemid};
                push @itemNames, $myresult->{name};
            }
    	}
        if( scalar @itemIds && scalar @itemNames ) {
    	    deletelocalitems($zabbix,\@itemIds);
            print "Deleted local items: " . (join ",", @itemNames) . "\n";
            addtoLogfile("Deleted local items: " . (join ",", @itemNames) . "\n", "");
        }
    }

}

sub deleteLocalWebScenario {
    my ( $zabbix, $hostId ) = @_;
    #######################################################################################
    ############delete local web scenarios ################################################
    #######################################################################################
    my $myresult = getLocalWebScenarioByHostId($zabbix,$hostId);
    #print "Local web scenarios",  Dumper $myresult;
    
    if( defined $myresult ) {
    	my @webIds= ();
    	my @webNamess= ();
    	if( ref $myresult eq 'ARRAY' ) {
    	    foreach my $webData( @$myresult ) {
                if( $webData->{httptestid} && $webData->{name} ) {
    	            push @webIds, $webData->{httptestid};
                    push @webNamess, $webData->{name};
                }
    	    }
    	}
    	else{
            if( $myresult->{httptestid} && $myresult->{name} ) { 
    	        push @webIds, $myresult->{httptestid};
    	        push @webNamess, $myresult->{name};
            }
    	}
        if( scalar @webIds && scalar @webNamess ) {
    	    deletelocalwebmonitoring($zabbix,\@webIds);
            print "Deleted web scenarios: " . (join ",", @webNamess) . "\n";
            addtoLogfile("Deleted web scenarios: " . (join ",", @webNamess) . "\n", "");
        }
    }
    
}

sub deleteLocalTriggers {
    my ( $zabbix, $hostId) = @_;
    
    #######################################################################################
    ############delete local triggers ######################################################
    #######################################################################################
    my $myresult = getLocalTriggersByHostId($zabbix,$hostId);
    #print  "Local triggers", Dumper $myresult;
    if( defined $myresult ) {
    	my @triggerIds= ();
    	my @triggerNames= ();
    	if( ref $myresult eq 'ARRAY' ) {
    	    foreach my $triggerData( @$myresult ) {
                if( $triggerData->{triggerid} && $triggerData->{description} ) {
                     push @triggerIds, $triggerData->{triggerid};
                     push @triggerNames, $triggerData->{description};
                }
    	    }
    	}
    	elsif( ref $myresult eq 'HASH' ) {
            if( $myresult->{triggerid} && $myresult->{description} ) {
                push @triggerIds, $myresult->{triggerid}; 
                push @triggerNames, $myresult->{description};
            }
    	}
        else{
            print "No triggers found to delete\n";
            addtoLogfile("No triggers found to delete\n", "");
        }
        if( scalar @triggerIds && scalar @triggerNames ) {
            deleteLocalTriggersByIds($zabbix,\@triggerIds);
            print "Deleted triggers: " . (join ",", @triggerNames) . "\n";
            addtoLogfile("Deleted triggers: " . (join ",", @triggerNames) . "\n", "");
        }
    }
    
}

sub deleteLocalDRules {
    my ( $zabbix, $hostId ) = @_;
    #######################################################################################
    ############delete local drules  ######################################################
    #######################################################################################
    my $myresult = getLocalDRuleByHostId($zabbix,$hostId);
    #print  "Local discovery rules", Dumper $myresult;
    if( defined $myresult ) {
    	my @discoveryRules = ();
    	my @dRuleNames = ();
    	if( ref $myresult eq 'ARRAY' ) {
    	    foreach my $discoveryData( @$myresult ) {
                if( $discoveryData->{itemid} && $discoveryData->{name} ) {
                    push @discoveryRules, $discoveryData->{itemid};
                    push @dRuleNames, $discoveryData->{name};
                }
    	    }
    	}
    	else{
            if( $myresult->{itemid} && $myresult->{name} ) {
    	        push @discoveryRules, $myresult->{itemid};
    	        push @dRuleNames, $myresult->{name};
            }
    	}
        if( scalar @discoveryRules && scalar @dRuleNames ) {
            deletelocaldiscoveryrule($zabbix,\@discoveryRules);
            print "Deleted discovery rules: " . (join ",", @dRuleNames) . "\n";
            addtoLogfile("Deleted discovery rules: " . (join ",", @dRuleNames) . "\n", "");
        }
    }
}


########################################
##call solarwinds delete monitor script

sub deleteSolarwindsMonitor {
    my ( $hostName ) = @_;

    my ($monitorName, $dc) = getDCName($hostName);
    print("Started Deleteing Solarwinds monitoring - $monitorName\n","");
    addtoLogfile("Started Deleteing Solarwinds monitoring - $monitorName\n","");
    if( ! -f "$solarwinds_home/recordings/$monitorName.recording" ) {
        print "No Recording found for monitor $monitorName. Skipping solarwinds decommission. \n";
        addtoLogfile("No Recording found for monitor $monitorName. Skipping solarwinds decommission. \n","");
        return ;
    }
    my $solarwindsScript = $solarwinds_home . "scripts/solarwinds.sh";
    my $deleteMonitCmd;
    if( $dc ) {
        $deleteMonitCmd = qq~ $solarwindsScript DeleteMonitor $monitorName DataCenter $dc ~;
    }
    else{
        $deleteMonitCmd = qq~ $solarwindsScript DeleteMonitor $monitorName ~;
    }
 
    my $result = qx($deleteMonitCmd);
    if( $result =~ /Monitor is deleted/ ){
        print "Solarwinds monitor deleted for $monitorName \n";
        addtoLogfile("Solarwinds monitor deleted for $monitorName \n","");
    }
    else{
        print "Unable to delete monitor $monitorName \n";
            print "$result\n";
        addtoLogfile("Unable to delete monitor $monitorName \n","");
    }

    return;
}

sub remanageSolarwindsMonitor {
    my ( $hostNameArrRef ) = @_;

    foreach my $hostName ( @$hostNameArrRef ) {
        my ($monitorName, $dc) = getDCName($hostName);
        print("Started Remanaging Solarwinds monitoring - $monitorName\n","");
        addtoLogfile("Started Remanaging Solarwinds monitoring - $monitorName\n","");
        if( ! -f "$solarwinds_home/recordings/$monitorName.recording" ) {
            print "No Recording found for monitor $monitorName. Skipping solarwinds remanage. \n";
            addtoLogfile("No Recording found for monitor $monitorName. Skipping solarwinds remanage. \n","");
            return ;
        }
    
        my $solarwindsScript = $solarwinds_home . "scripts/solarwinds.sh";
        my $remanageMonitCmd;
        if( $dc ) {
            $remanageMonitCmd = qq~ $solarwindsScript RemanageMonitor $monitorName DataCenter $dc ~;
        }
        else{
            $remanageMonitCmd = qq~ $solarwindsScript RemanageMonitor $monitorName ~;
        }
        my $result = qx($remanageMonitCmd);
        if( $result =~ /Monitor is enabled/i ){
            print "Solarwinds monitor is enabled/remanaged for $monitorName \n";
            addtoLogfile("Solarwinds monitor is enabled/remanaged for $monitorName \n","");
        }
        else{
            print "$result\n";
            print "Unable to enable/remanage monitor $monitorName \n";
            addtoLogfile("Unable to enable/remanage monitor $monitorName \n","");
        }
    }
    return;

}

sub unmanageSolarwindsMonitor {
    my ( $hostNameArrRef ) = @_;

    foreach my $hostName ( @$hostNameArrRef ) {   
        my ($monitorName, $dc) = getDCName($hostName);
        print("Started Unmanaging Solarwinds monitoring - $monitorName\n","");
        addtoLogfile("Started Unmanaging Solarwinds monitoring - $monitorName\n","");
        if( ! -f "$solarwinds_home/recordings/$monitorName.recording" ) {
            print "No Recording found for monitor $monitorName. Skipping solarwinds Unmanage. \n";
            addtoLogfile("No Recording found for monitor $monitorName. Skipping solarwinds Unmanage. \n","");
            return ;
        }
    
        my $solarwindsScript = $solarwinds_home . "scripts/solarwinds.sh";
        my $unmanageMonitCmd;
        if( $dc ) { 
            $unmanageMonitCmd = qq~ $solarwindsScript UnmanageMonitor $monitorName Duration 180 DataCenter $dc ~;  ##Hardcoding for 6 months to disable
        }
        else{
            $unmanageMonitCmd = qq~ $solarwindsScript UnmanageMonitor $monitorName Duration 180 ~;
        }
        my $result = qx($unmanageMonitCmd);
        if( $result =~ /Monitor is disabled/i ){
            print "Solarwinds monitor is disabled/unmanaged for $monitorName for 180 days\n";
            addtoLogfile("Solarwinds monitor is disabled/unmanaged for $monitorName for 180 days\n","");
        }
        else{
            print "$result\n";
            print "Unable to disable/unmanage monitor $monitorName \n";
            addtoLogfile("Unable to disable/unmanage monitor $monitorName \n","");
        }

    }
    return;
}
sub deleteLocalTriggersByIds {
    my $zabbix = $_[0];
    my @triggerIds= @{$_[1]};

    my $result;
    if ( scalar @triggerIds ){
        $result = $zabbix->raw('trigger','delete',\@triggerIds);
    }

    return $result;
}

sub decomHost {
    my ( $hostName ) = @_;

    $hostName = strip($hostName);
    addtoLogfile("-------------------------------------------","");
    addtoLogfile("Started decommissioning of Host - $hostName","");
    print ("-------------------------------------------\n","");
    print ("Started decommissioning of Host - $hostName\n","");
    
    # Get Hostid
    my $options = {'output'=>'extend','filter' =>{'name' => $hostName}};
    my $result  = $zabbix->raw('host','get',$options);
    my $hostid  = $result->{'hostid'};
    
    if ( ! defined $hostid ) {
        print "Host id not found for $hostName \n";
        addtoLogfile("Host id not found for $hostName \n","");
        return 1;
    }
    addtoLogfile("Hostid - $hostid","");
    
    $options = [ $hostid ]; 
    $result = $zabbix->raw('host','delete',$options);
    if( ref $result eq 'HASH' && ${$result->{hostids}}[0] == $hostid ) {
        print("Host - $hostName is decommissioned(deleted) from ZABBIX\n","");
        addtoLogfile("Host - $hostName is decommissioned(deleted) from ZABBIX","");
    }
    else{
        print("Failed to delete host $hostName\n","");
        addtoLogfile("Failed to delete host $hostName","");
    }
    print ("-------------------------------------------\n","");

    return;
}

sub strip {
    my ( $input ) = @_;

    $input =~ s/^\s//g;
    $input =~ s/\s$//g;

    return $input;
}

sub getLocalTriggersByHostId {
    my  $zabbix = $_[0];
    my $hostId = $_[1];
    ##hash_status = ('0' => 'Enabled','1'=>'Disabled');
    #my %hash_temp = ('0' => 'LocalTrigger','1'=>'TemplateItem');
    my $options = {'output' =>'extend','hostids' =>$hostId, 'inherited' => '0' };
    my $myresult = $zabbix->raw('trigger','get',$options);

    return $myresult;

}

sub enableHost {

    my ( $hostNamesRef ) = @_;

    foreach my $hostName ( @$hostNamesRef ) {
    # Get Hostid

        my $options = {'output'=>'extend','filter' =>{'name' => $hostName}};
        my $result  = $zabbix->raw('host','get',$options);
        my $hostid  = $result->{'hostid'};

        if ( ! defined $hostid ) {
            print "Host id not found for $hostName \n";
            addtoLogfile("Host id not found for $hostName \n","");
            next;
        }

        $options = {'output'=>'extend','status' => 0, 'hostid' => $hostid};
        $result = $zabbix->raw('host','update',$options);

        my $date = localtime();
        print("$hostName has been Enabled\n","");
        addtoLogfile("$hostName has been Enabled on $date by $username\n","");
    }
    return;

}

sub disableHost {

    my ( $hostNamesRef ) = @_;

    foreach my $hostName ( @$hostNamesRef ) {
    # Get Hostid

        my $options = {'output'=>'extend','filter' =>{'name' => $hostName}};
        my $result  = $zabbix->raw('host','get',$options);
        my $hostid  = $result->{'hostid'};

        if ( ! defined $hostid ) {
            print "Host id not found for $hostName \n";
            addtoLogfile("Host id not found for $hostName \n","");
            next;
        }

        $options = {'output'=>'extend','status' => 1, 'hostid' => $hostid};
        $result = $zabbix->raw('host','update',$options);

        my $date = localtime();
        print("$hostName has been Disabled\n","");
        addtoLogfile("$hostName has been Disabled on $date by $username\n","");
    }
    return;

}

sub getDCName {
    my ( $hostName ) = @_;

    my ($monitorName, @domains) = split /\./, $hostName;

    my $domain = join '\.', @domains;

    open FH, "<", "/usr/local/etc/zbxAdm/2.2/scripts/solarwinds_api/conf/players.conf" or die "Can not open players.conf file\n";
 
    while(my $line=<FH>) {
        chomp($line);
        my @fields = split '\|', $line;
        my $dc = $fields[0];
        my $domainStr = $fields[1];
        if ( $domainStr =~ /$domain/i ) {
            return ($monitorName,$dc);
        }
    }
   
    return ($monitorName,undef);
}
