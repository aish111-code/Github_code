#!/bin/bash

##############################################
# Purpose : Monitor for zabbix server service
# Author  : Jibin
# Date    : 2/7/2018
##############################################

email_to="prajwal.arunachala@sap.com,n.chander@sap.com,ayush.jain@sap.com,rajwin.victor.jesudason@sap.com,sreekanth.kp@sap.com,vnr.sridhar.manepalli@sap.com,vishwas.mohan@sap.com,rijash.patel@sap.com,d.raj@sap.com,s.renuka@sap.com,bikramjit.sengupta@sap.com,vivek.sivakumar@sap.com,jibin.sunny@sap.com,e.wise@sap.com,karthikeyan.rajamani@sap.com,manojkumar.venkatesan@sap.com,sainadh.vadlamudi@sap.com,arunkumar.velmurugan@sap.com"

#email_to="jibin.sunny@sap.com"

#Logfile Location
logfile=/var/log/zabbix/zbx_failure.txt
date=`date`

# Check DB connection

#curl -X POST -H 'Content-Type:application/json' -d'{"jsonrpc": "2.0","method":"user.login","params": {"user":"noc","password":"zabbix123"},"id":0}' 10.4.196.100/zabbix/api_jsonrpc.php -o /var/log/zabbix/zbxloginresult.txt


#grep "result" /var/log/zabbix/zbxloginresult.txt


#if [ $? -eq 1 ]
#then
#               printf "$date: Unable to connect to ZABBIX Database.\n" >>$logfile
#                       echo "Alert - Zabbix login failed,Unable to connect to Database" | mailx -s "Action Required - Unable to connect to Zabbix DB port" $email_to

#fi


#Check App server connection


telnet 10.169.136.57 10051 > /var/log/zabbix/zbxserverstatus.txt

servercount=`grep "Connected to" /var/log/zabbix/zbxserverstatus.txt | wc -l`

if [ $servercount -eq 0 ]
then

restartcheck=`find /var/log/zabbix/ -type f -name zbxrestart.txt -mmin -30 | wc -l`

       if [ $restartcheck -eq 0 ]
       then
                # zabbix server is not restarted in last 30 minutes, go for restart
                 printf "$date: ZABBIX server process is down.\n" >>$logfile
                echo "Alert - Zabbix server not responding. Manual restart required" | mailx -s "Action Required - Azure(DC42)Zabbix server down" -r ZBX@sap.com $email_to


               x=`date +%Y_%m_%d`
               backuplog="/var/log/zabbixs/zabbix-server_${x}"
               cp /var/log/zabbixs/zabbix-server.log  ${backuplog}

                #/etc/init.d/zabbix-server stop

               #sleep 30

                #/etc/init.d/zabbix-server start

               touch /var/log/zabbix/zbxrestart.txt
       fi

rm /var/log/zabbix/zbxserverstatus.txt

fi
