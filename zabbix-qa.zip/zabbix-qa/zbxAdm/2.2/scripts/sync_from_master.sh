
#!/bin/bash
cd /usr/local/etc/GITHUB_MIRROR/zabbix
git pull https://sapsfsdotoolsandutils:d492de81fa6ceac186617446cb11b684ce318231@github.cld.ondemand.com/sdo-toolsandutilities/zabbix.git master > /tmp/github.clone 2> /dev/null
Flag=`cat /tmp/github.clone|grep Merge|wc -l`

email='sreekanth.kp@sap.com,s.renuka@sap.com,nandhini.chander@sap.com,pradip.kumar.k@sap.com,vnr.sridhar.manepalli@sap.com,rakhesh.ms@sap.com,bikramjit.sengupta@sap.com,jibin.sunny@sap.com,sainadh.vadlamudi@sap.com'

if [ "$Flag" == "0" ]
then
        cat /tmp/github.clone
        exit
else
        cat /tmp/github.clone| mail -r GITZBX@sap.com -s "GitHub To Ansible Zabbix agent folder Sync Completed - `hostname`" $email
        rsync -a zbxAdm/ /usr/local/etc/zbxAdm/
        rsync -a agentconf/scripts/* /etc/ansible/agent/roles/zabbix-agent/files/zabbix_agentd_custom_scripts
        rsync -a  agentconf/conf/*  /etc/ansible/agent/roles/zabbix-agent/files/zabbix_agentd.conf.d
        chown -R zabbix:zabbix /usr/local/etc/zbxAdm
        chmod -R 755 /usr/local/etc/zbxAdm
fi
