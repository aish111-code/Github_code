#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################

#{HOST.NAME} Centrifydc process is not running
#{HOST.NAME} - CentrifyDC Status is showing as not connected.
#{HOST.HOST} ntpd process is not running

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

my @hostid;
my $os_template;
my $slr_host;
my $slr_hostgrp;
my $slr_template;
# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Host;

# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
    chomp $line;
    if ($line ne "" and $line =~ m/lab/ )
    {
        $env = 'qa';
    }
    else { $env = 'prod' ; }
}

# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

my %args;


GetOptions(\%args,
                        "Host=s",
                        "HostFile=s",
                        "Trigger=s",
                        "TriggerFile=s",
                        "Action=s"
           );

if( ! scalar keys %args ) {
    usage();
}

sub usage {
    print "$0
    -Host <Host Name>                                   - Host to disable/enable trigger
          OR
    -HostFile <Host File>                               - Filename with list of hosts to disable/enable trigger
    -Trigger < Trigger Name >                           - trigger name to disable/enable
          OR
    -TriggerFile < Trigger File >                       - Filename with list of triggers to disable/enable
    -Action  <enable|disable>

    Example: $0 -Host sc2bagy01.ams2.sf.priv -Trigger trigger1 -Action enable
               OR
             $0 -HostFile filename1 -TriggerFile triggerfile1 -Action disable
    \n";

    exit 1;
}

my $inp_status;
if ( $args{Action} eq 'enable' ) {
    $inp_status = 0;
}
else{
    $inp_status = 1;
}
my @triggersToManage;
if( exists $args{Trigger} ) {
    @triggersToManage = $args{Trigger};
}
else{
    if ( -e $args{TriggerFile} ) {
        open TFH, $args{TriggerFile} or die "Can not open TriggerFile: $args{TriggerFile} \n";
        while (my $line = <TFH>){
            chomp($line);
            push @triggersToManage, $line;
        }
        close(TFH);
    }
}

my @hosts;
if( exists $args{Host} ) {
    push @hosts, $args{Host};
}
else{
    if ( -e $args{HostFile} ) {
        open FH, "$args{HostFile}" or die "Can not open Hostfile : $args{HostFile} \n";
        while (my $line = <FH>){
            chomp($line);
	    push @hosts, $line;
        }
        close(FH);
    }
}

disableTriggers($zabbix, \@hosts);

sub disableTriggers {
    my ( $zabbix, $hostRef ) = @_;
    
    
    foreach my $hostName ( @{$hostRef} ) {
        print "host = ##########################$hostName######################################\n";
        my $hostId = SFSF::Host::get_hostid($zabbix,$hostName);
        if( ! defined $hostId ) {
             print "No host found for hostname $hostName \n";
             next;
        }
        foreach my $triggerName ( @triggersToManage ) {
            get_triggers($zabbix, $hostId, $hostName, $triggerName);
        }
    }
}

sub get_triggers {
    my ( $zabbix, $inp_hostid, $inp_hostname, $inp_description ) = @_;
  
    my %output = ('output' => [ 'triggerid', 'description', 'priority' ], 'hostids' => [ $inp_hostid ], 'search' => { 'description' => $inp_description }  );
    my $params;
    $params = {%output};
    my $api_result = $zabbix->raw('trigger','get', $params);

    if( ref $api_result eq 'HASH' ) {
        if( ! exists $api_result->{triggerid} ) {
            print "No trigger found for host $inp_hostname \n";
            return;
        }
        my $triggerid = $api_result->{triggerid};
        my $priority = $api_result->{priority};
        %output = ( 'output' => [ 'triggerid','description','status' ], 'triggerids' => $triggerid );
        $api_result = $zabbix->raw('trigger','get', \%output);
#print Dumper $api_result;
#print "\n";

        if( defined $api_result && exists $api_result->{status} && $triggerid == $api_result->{triggerid} ) {
            %output = ( 'triggerid' => $triggerid , 'status' => $inp_status );
            $api_result = $zabbix->raw('trigger','update', \%output);
            print Dumper $api_result;
            print "Trigger id $triggerid => '$inp_description' is $args{Action}" . "d" . " for host $inp_hostname ($inp_hostid) \n";
            #print "$inp_hostname\t\t $triggerid \t$inp_description \t$args{Action}\n";
        }

    }
    elsif ( ref $api_result eq 'ARRAY' ) {
   
        foreach my $res ( @$api_result ) {
            my $triggerid = $res->{triggerid};
            my $priority = $res->{priority};
            %output = ( 'output' => [ 'triggerid','description','status' ], 'triggerids' => $triggerid );
            $api_result = $zabbix->raw('trigger','get', \%output);
    
            ##disable trigger only when it is enabled ( status = 0 )
            if( defined $api_result && exists $api_result->{status} && $triggerid == $api_result->{triggerid} ) {
                %output = ( 'triggerid' => $triggerid , 'status' => $inp_status );
                $api_result = $zabbix->raw('trigger','update', \%output);
                print Dumper $api_result;
                print "Trigger id $triggerid => '$inp_description' is $args{Action}" . "d" . " for host $inp_hostname ($inp_hostid) \n";
                #print "$inp_hostname\t\t $triggerid \t$inp_description \t$args{Action} \n";
            }
      
        }
    }
    else {
        print "No trigger found for host $inp_hostname\n";
        return;
    }

}
