#!/usr/bin/perl


use strict;

#my $cmd = qq~ cat /tmp/zbxDumpFile.csv  | awk -F"," '{print \$1}' | awk -F"." '{print \$1}' | sort | uniq -d > /tmp/wrongConfigHosts.txt ~;
#system($cmd);


open FH, "<", "/tmp/zbxDumpFile.csv" or die "Can't open file /tmp/zbxDumpFile.csv:$!\n";

open WFH, ">", "/tmp/wrongConfigHosts.txt" or die "Can not open file:$!\n";
my %hashWithDups;
while(my $line=<FH>) {
    chomp($line);
    my $cmd = qq~echo $line | awk -F"," '{print \$1}' ~;
    my $hostFQDN = `$cmd`;
    chomp($hostFQDN);
    $hostFQDN = lc $hostFQDN;
    $cmd = qq~echo $hostFQDN | awk -F"." '{print \$1}' ~;
    #my $FQDN = `$cmd`;
    my $host     = `$cmd`;
    chomp($host);
    $host = lc $host;

    if( exists $hashWithDups{$host} && $hashWithDups{$host} eq $hostFQDN ) {
        print WFH "$host is duplicate host. May be different IPs\n";
    }
    if( exists $hashWithDups{$host} && ($hostFQDN eq $host || $hashWithDups{$host}  eq $host) ) {
        print WFH "$host is configured with both FQDN ($hostFQDN) and without it\n";
    }
    else{
        $hashWithDups{$host} = $hostFQDN;
    }

}
close(WFH);
close(FH);

#my $mails = q~ pradip.kumar.k@sap.com ~;
my $mails = q~ s.renuka@sap.com, pradip.kumar.k@sap.com, nandhini.chander@sap.com, rakhesh.ms@sap.com, sreekanth.kp@sap.com,jibin.sunny@sap.com ~;
my $mailCmd = qq~ echo "Wrongly configured hosts" | mailx -s "Hosts that are incorrectly configured" -a '/tmp/wrongConfigHosts.txt' -r "sapsfplatformmonitoring\@sap.com" $mails ~;
system($mailCmd);
