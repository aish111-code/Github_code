#!/usr/bin/perl

############################################################################
# Author        : Pradip Kumar, Nandhini Chander
# Purpose       : Zabbix 2.4 Audit script to find hosts, missing OS templates 
# Reviewer      : Sandeep M.R 
# Version       : 30th May 2016 - Initial code
############################################################################
# Modified the script on 227-Dec-2017 to exclude the Product specific OS
# Templates and few VIP host groups in the checks - Nandhini
############################################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

# Local variable declaration

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLDs qw(pfail);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
    chomp $line;
   if ($line ne "" and $line =~ m/lab/ )
   {	
       $env = 'qa';
   }
   else { 
      $env = 'prod' ; 
   }
}	

# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


my $hostsNoOSTemplates = "/var/log/zabbix/no_os_templates.txt";
open my $fg, ">", $hostsNoOSTemplates or die "Can not open $hostsNoOSTemplates to write:$! \n";

#Exclude the mentioned host groups
#my @excludeGrps = qw( All-STORAGE-NETAPP Hypervisors hosts-manual monsoon hosts-decommissioned hosts-discovered hosts-unknown pc2mgt_UCS pc4mgt_UCS 
#                      pc8mgt_UCS pc10mgt_UCS pc4mgt_IPAM ps2_BizX_A_SRCH-Cluster ps4_BizX_A_SRCH-Cluster ps8_BizX_A_SRCH-Cluster pc2_BizX_A_SCHDDB 
#                      pc4_BizX_A_SCHDDB pc8_BizX_A_SCHDDB pc8_BizX_A_SCHDDB pc10_BizX_A_SCHDDB pc12_BizX_A_SCHDDB pc15_BizX_A_SCHDDB pc16_BizX_A_SCHDDB 
#                      pc17_BizX_A_SCHDDB pc18_BizX_A_SCHDDB pc2mgt_NETWORK pc4mgt_NETWORK pc8mgt_NETWORK pc10mgt_NETWORK pc12mgt_NETWORK pc2mgt_MAIL_IRONPORT 
#                      pc4mgt_MAIL_IRONPORT pc8mgt_MAIL_IRONPORT pc10mgt_MAIL_IRONPORT pc12mgt_MAIL_IRONPORT pc15mgt_MAIL_IRONPORT pc16mgt_MAIL_IRONPORT pc17mgt_MAIL_IRONPORT 
#                      pc18mgt_MAIL_IRONPORT pc4_BizX_A_SRCH-Cluster pc12_BizX_A_SRCH-Cluster pc17_BizX_A_SRCH-Cluster sc2_BizX_A_SRCH-Cluster sc4_BizX_A_SRCH-Cluster 
#		      sc8_BizX_A_SRCH-Cluster sc10_BizX_A_SRCH-Cluster sc12_BizX_A_SRCH-Cluster sc2_BizX_A_SCHDDB sc4_BizX_A_SCHDDB sc8_BizX_A_SCHDDB sc10_BizX_A_SCHDDB sc12_BizX_A_SCHDDB sc17_BizX_A_SCHDDB sc18_BizX_A_SCHDDB 
#		      pc2_BizX_A_JobS2-Cluster pc4_BizX_A_JobS2-Cluster pc8_BizX_A_JobS2-Cluster pc10_BizX_A_JobS2-Cluster pc12_BizX_A_JobS2-Cluster pc15_BizX_A_JobS2-Cluster pc16_BizX_A_JobS2-Cluster pc17_BizX_A_JobS2-Cluster
#		      pc18_BizX_A_JobS2-Cluster sc10_BizX_A_JobS2-Cluster sc12_BizX_A_JobS2-Cluster sc17_BizX_A_JobS2-Cluster sc18_BizX_A_JobS2-Cluster pc12bosch_BizX_A_JobS2-Cluster pc12Bosch_BizX_A_SCHDDB "JAM Web Monitoring");
my @excludeGrps = ( 'All-STORAGE-NETAPP', 'Hypervisors', 'hosts-manual', 'monsoon', 'hosts-decommissioned', 'hosts-discovered', 'hosts-unknown', 'pc2mgt_UCS', 'pc4mgt_UCS',
                      'pc8mgt_UCS', 'pc10mgt_UCS', 'pc4mgt_IPAM', 'ps2_BizX_A_SRCH-Cluster', 'ps4_BizX_A_SRCH-Cluster', 'ps8_BizX_A_SRCH-Cluster', 'pc2_BizX_A_SCHDDB',
                      'pc4_BizX_A_SCHDDB', 'pc8_BizX_A_SCHDDB', 'pc8_BizX_A_SCHDDB', 'pc10_BizX_A_SCHDDB', 'pc12_BizX_A_SCHDDB', 'pc15_BizX_A_SCHDDB', 'pc16_BizX_A_SCHDDB',
                      'pc17_BizX_A_SCHDDB', 'pc18_BizX_A_SCHDDB', 'pc2mgt_NETWORK', 'pc4mgt_NETWORK', 'pc8mgt_NETWORK', 'pc10mgt_NETWORK', 'pc12mgt_NETWORK', 'pc2mgt_MAIL_IRONPORT',
                      'pc4mgt_MAIL_IRONPORT', 'pc8mgt_MAIL_IRONPORT', 'pc10mgt_MAIL_IRONPORT','pc12mgt_MAIL_IRONPORT', 'pc15mgt_MAIL_IRONPORT', 'pc16mgt_MAIL_IRONPORT',
                      'pc17mgt_MAIL_IRONPORT','pc18mgt_MAIL_IRONPORT','pc4_BizX_A_SRCH-Cluster', 'pc12_BizX_A_SRCH-Cluster', 'pc17_BizX_A_SRCH-Cluster', 'sc2_BizX_A_SRCH-Cluster',
                      'sc4_BizX_A_SRCH-Cluster','sc8_BizX_A_SRCH-Cluster', 'sc10_BizX_A_SRCH-Cluster', 'sc12_BizX_A_SRCH-Cluster', 'sc2_BizX_A_SCHDDB',
                      'sc4_BizX_A_SCHDDB', 'sc8_BizX_A_SCHDDB', 'sc10_BizX_A_SCHDDB', 'sc12_BizX_A_SCHDDB', 'sc17_BizX_A_SCHDDB', 'sc18_BizX_A_SCHDDB',
                      'pc2_BizX_A_JobS2-Cluster', 'pc4_BizX_A_JobS2-Cluster', 'pc8_BizX_A_JobS2-Cluster', 'pc10_BizX_A_JobS2-Cluster', 'pc12_BizX_A_JobS2-Cluster',
                      'pc15_BizX_A_JobS2-Cluster', 'pc16_BizX_A_JobS2-Cluster', 'pc17_BizX_A_JobS2-Cluster','pc18_BizX_A_JobS2-Cluster', 'sc10_BizX_A_JobS2-Cluster', 'sc12_BizX_A_JobS2-Cluster',
                      'sc17_BizX_A_JobS2-Cluster', 'sc18_BizX_A_JobS2-Cluster', 'pc12bosch_BizX_A_JobS2-Cluster', 'pc12Bosch_BizX_A_SCHDDB', 'JAM Web Monitoring', 'WFA Web Monitoring', 'All-BIZX-Sesn-Cluster',
                      'ALL-BIZX-DMS-Custom', 'All-BIZX-Email-Engine-Cluster', 'All-BIZX-AttachImage-Cluster', 'ALL-BIZX-BPE-Custom', 'All-BIZX-SRCH-VIP', 'All-OPTIER-JSEM-VIP', 'pc4mgt_OPTIER_DB-Scanner',
                      'pc10mgt_OPTIER_DB-Scanner', 'pc12mgt_OPTIER_DB-Scanner', 'pc15mgt_OPTIER_DB-Scanner', 'pc18mgt_OPTIER_DB-Scanner', 'pc17mgt_OPTIER_DB-Scanner', 'pc19mgt_OPTIER_DB-Scanner', 'All-JSEM-VIP' ,
		      'Zertificon_Appliances' , 'ALL-BIZX-DRS-VIP', 'All-BIZX-AVSCAN-VIP', 'All-BIZX-JobScheduler', 'All-MAIL-IRONPORT', 'All-DB-MSSQL', 'ALL-ADO-CERT', 'pc15mgt_ESXI', 'lms-hosts-discovered', 'failed_automation' );
my @excludeTemplates = qw( T_OS_Linux T_OS_Solaris T_OS_Windows T_LMS_Linux T_BizX_Linux T_OPTIER_Linux T_SPLUNK_Linux T_HANA_Linux T_WFA_Linux T_MOB_Linux T_JAM_Linux
                           T_J2W_Linux T_BOOMI_Linux T_APIGEE_Linux T_ZABBIX_Linux T_ELK_Linux );

my %excludeGrpHash;
my %excludeTmpltHash;
my $count = 0;

%excludeGrpHash = map { $_ => 1 } @excludeGrps;
%excludeTmpltHash = map { $_ => 1 } @excludeTemplates;
my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


##get all hosts that do not have OS templates
findNoOSTmpltHosts( $zabbix );

sub findNoOSTmpltHosts {
    my ( $zabbix ) = @_;

    
    my %tfilter = ( 'output' => ['hostid', 'name','status'], "selectGroups" => "extend", "selectParentTemplates" => [ 'templateid', 'name'] );
    
    my $params = {%tfilter};
    my $api_result = $zabbix->raw('host','get', $params);

    HOSTLOOP:
    foreach my $hashRef ( @$api_result ) {
        my @grpNames;
        my $name     = $hashRef->{name};
        my $id       = $hashRef->{hostid};
        my $stat     = $hashRef->{status};
	my $grpObj   = $hashRef->{groups};
        my $tmpltObj = $hashRef->{parentTemplates};
	foreach my $grpRef ( @$grpObj ) {
            my ($grpName, $grpId ) = ( $grpRef->{name}, $grpRef->{groupid} );   
            if(( exists $excludeGrpHash{$grpName}) or ( $name =~ /performancemanager/) ) {
                next HOSTLOOP;
            }
            else{
                push @grpNames, $grpName;
            }
        }

        my $flag = 0;
        foreach my $tmpltRef ( @$tmpltObj ) {
            my ( $tmpltName, $tmpltId ) = ( $tmpltRef->{name}, $tmpltRef->{templateid} );
            if( exists $excludeTmpltHash{$tmpltName} ) {
                $flag = 1;
                last;
            }  
        }
	my $enab;
	if ( $stat == 0 ) {
           $enab = "Enabled";
   	   }
	   else {
	     $enab = "Disabled";
	   }
			
        if( ! $flag ) {
            $count++;
            my $grpList = join ",", @grpNames;
            print $fg "Host name = $name, Status = $stat ($enab) , Groups=$grpList\n";
        }
    }

    return;
}

close($fg);

#Mail to the team
my $email='s.renuka@sap.com,rakhesh.ms@sap.com,jibin.sunny@sap.com,sreekanth.kp@sap.com,,n.chander@sap.com';
my $mailCmd = qq~ cat  $hostsNoOSTemplates | mailx -r "ZBX-PLT\@sap.com" -s "Zabbix Audit - Hosts Missing OS Templates - $count " $email ~;
system($mailCmd);
