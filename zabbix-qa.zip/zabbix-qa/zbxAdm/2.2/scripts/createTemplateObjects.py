#!/usr/bin/python
import sys
sys.path.append('/usr/local/etc/zbxAdm/2.2/lib/zbxpylib')
from zabbix_api import ZabbixAPI
from RSM import parseConfig
import re
import argparse

parser = argparse.ArgumentParser(description='Provide options')
parser.add_argument('--CreateWhat', metavar='(Trigger | Item)', help='Option to add a new Trigger or Item to a template.')
parser.add_argument('--InpExpression',help='Expression of the trigger')
parser.add_argument('--InpDescription',help='Description of the trigger')
parser.add_argument('--InpStatus',help='Status of the trigger. 0 or 1')
parser.add_argument('--InpPriority',help='Priority of the trigger. 0 to 5')
parser.add_argument('--InpType',help='Type of the trigger.Generally 0')
args = parser.parse_args()

config = parseConfig('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf')
def main():
        fh = open('/etc/hosts','r')
        env = ''

        for line in fh.readline():
            if line != "" and re.match('lab', line):
                env = 'qa'
                break
        else :
                env = 'prod'


        url    = config.get(env,'url')
        user   = config.get(env,'user')
        passwd = config.get(env,'password')

        zabbix = ZabbixAPI(server=url + "/api_jsonrpc.php")
        zabbix.login(user,passwd)

        
        inp_exp = args.InpExpression
   	inp_desc = args.InpDescription
        inp_status = args.InpStatus
  	inp_priority= args.InpPriority
	inp_type = args.InpType
        if args.CreateWhat == 'Trigger':
        	addTrigger(zabbix,inp_exp,inp_desc,inp_status,inp_priority,inp_type)
def addTrigger(zabbix, inp_exp, inp_desc, inp_status, inp_priority, inp_type):
	results = zabbix.trigger.create({'expression' : inp_exp,
					 'description' : inp_desc,
					 'status' : inp_status,
					 'priority' : inp_priority,
					 'type' : inp_type})


	print(results)

if __name__ == '__main__':
	main()
