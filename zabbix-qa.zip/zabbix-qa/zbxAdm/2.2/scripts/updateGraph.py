"""
#####update existing graph
"""

from pyzabbix import ZabbixAPI
from datetime import datetime
from pprint import pprint
import re
import sys

if len(sys.argv) < 3:
    print("Usage : {} graphId dc product".format(sys.argv[0]))
    sys.exit()

graphId = sys.argv[1]
dc = sys.argv[2]
dc = dc.upper()
product = sys.argv[3]
product = product.upper()

class Palette:
    last_idx = 0
    colors = ["C04000", "800000", "191970", "3EB489", "FFDB58", "000080",
              "CC7722", "808000", "FF7F00", "002147", "AEC6CF", "836953",
              "CFCFC4", "77DD77", "F49AC2", "FFB347", "FFD1DC", "B39EB5",
              "FF6961", "CB99C9", "FDFD96", "FFE5B4", "D1E231", "8E4585",
              "FF5A36", "701C1C", "FF7518", "69359C", "E30B5D", "826644",
              "FF0000", "414833", "65000B", "002366", "E0115F", "B7410E",
              "FF6700", "F4C430", "FF8C69", "C2B280", "967117", "ECD540",
              "082567"]
 
    def next(self):
        self.last_idx = (self.last_idx + 1) % len(self.colors)
        return self.colors[self.last_idx]

# The hostname at which the Zabbix web interface is available
ZABBIX_SERVER = 'http://10.4.196.101/zabbix/api_jsonrpc.php'

zapi = ZabbixAPI(ZABBIX_SERVER,user='ZABBIX_SFSF_API',password=<passvault>)

# Login to the Zabbix API


# Create a time range
# Query item's history (integer) data
output = zapi.host.get(filter={'host' : [ 'DC12SPLUNKJOB01.rot.od.sap.biz' ]},
                       selectItems='extend',        
                           output='extend',
                           limit='5000',
                           )



palette = Palette()
itemArr = list()
my_regex  = r'{} {}'.format(dc,product)
for res in output[0]['items']:
    itemId = res['itemid']
    itemName = res['name']

    if re.search(my_regex,itemName) :
        itemArr.append({'itemid':itemId, 'color': palette.next()})


# If nothing was found, try getting it from history (float) data


output2 = zapi.graph.update(graphid=graphId,
                            gitems=itemArr
                            )


pprint(output2)
