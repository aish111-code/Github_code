#!/usr/bin/python
import sys
sys.path.append('/usr/local/etc/zbxAdm/2.2/lib/zbxpylib')
from zabbix_api import ZabbixAPI
from RSM import parseConfig
import re
import argparse
import os
import json
from pprint import pprint
import logging


config = parseConfig('/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf')


parser = argparse.ArgumentParser(description='Provide options')
parser.add_argument('--template',metavar='<template name>',help='template to import/export')
parser.add_argument('--option',metavar='<import|export>', help='Option to pass a import or export')
parser.add_argument('--source',metavar='<source file>',help='source template file')
parser.add_argument('--destination',metavar='<destination file>',help='file to export to')
parser.add_argument('--frmat',metavar='<xml|json>',help='format type xml or json')
args = parser.parse_args()
if len(sys.argv) < 5:
    parser.print_help()
    sys.exit(0)

templateName = args.template
sourceFile = args.source
destinationFile = args.destination
option = args.option
frmat= args.frmat

tempalteRules = "/usr/local/etc/zbxAdm/2.2/conf/templateImportRules.conf"
importRule = {}
with open(tempalteRules, 'r') as tconfFH:
    for line in tconfFH:
        rules = line.split('|')
        category = rules[0]
        category = category.strip()
        action = rules[1]
        action = action.strip()
        actions = action.split(',')
        for actn in actions:
            try:
                importRule[category].append( { actn : "true" } )
            except:
                importRule[category] = { actn : "true" }

importRule = {
              'applications': {'createMissing': True } ,
              'discoveryRules': {'createMissing': True, 'updateExisting': True},
              'graphs': {'createMissing': True, 'updateExisting': True},
              'groups': {'createMissing': True },
              'items': {'createMissing': True, 'updateExisting': True},
              'templateLinkage': {'createMissing': True },
              'templateScreens': {'createMissing': True, 'updateExisting': True},
              'templates': {'createMissing': True, 'updateExisting': True},
              'triggers': {'createMissing': True, 'updateExisting': True}
            }

#importRule = {
#            "applications": [ { "createMissing"  :  True }, { "updateExisting" :  True } ],
#            "discoveryRules": [ { "createMissing"  :  True }, { "updateExisting" :  True } ],
#            "groups" :  [ { "createMissing"  :  True }, { "updateExisting" :  True } ],
#            "templates" :  [ { "createMissing"  :  True }, { "updateExisting" :  True } ],
#            "triggers"  :  [ { "createMissing"  :  True }, { "updateExisting" :  True } ],
#            "items"     : [ { "createMissing"  :  True }, { "updateExisting" :  True } ]
#          }
#importRule = {
#            "applications": { "createMissing"  :  True },
#            "discoveryRules": { "createMissing"  :  True },
#            "groups" :  { "createMissing"  :  True },
#            "templates" :  { "createMissing"  :  True },
#            "triggers"  :  { "createMissing"  :  True },
#            "items"     : { "createMissing"  :  True },
#            "graphs"     : { "createMissing"  :  True },
#            "templateLinkage"     : { "createMissing"  :  True },
#            "templateScreens"     : { "createMissing"  :  True }
#          }

# Detect running env and set the connection variables
env = 'prod'
url    = config.get(env,'url')
user   = config.get(env,'user')
passwd = config.get(env,'password')

zabbix = ZabbixAPI(server=url)
zabbix.login(user,passwd)
print("Connected to Zabbix API Version %s" % zabbix.api_version())



def main():

    if( option == 'import' ):
        importTemplate( zabbix, templateName, sourceFile, frmat )
    elif( option == 'export' ):
        exportTemplate( zabbix, templateName, destinationFile, frmat );
    else:
        print( "Unknown option : option \n")
        sys.exit(1)

def importTemplate(zabbix, templateName, sourceFile, frmat):
    with open(sourceFile, 'r') as fg:
        data = fg.read()
        options = {'format' : frmat, 'rules' : importRule, 'source': data }
        #pprint(options)
        results = zabbix.configuration.import_(options)
        pprint(results)

def exportTemplate( zabbix, templateName, destinationFile, frmat ):
    template_id = get_templateid(zabbix,templateName)
    options = { 'format' : frmat, 'options': { "templates" : [ template_id ] } }
    results = zabbix.configuration.export(options)

    with open(destinationFile, 'w') as wh:
        wh.write(results)

def get_templateid(zabbix, template):
    options = {'output' : ['templateid'], 'filter' : {'host' : template}}
    result = zabbix.template.get(options)
    pprint(result)
    return result[0]['templateid']



if __name__ == '__main__':
    main()

