#!/bin/sh

pwd='/usr/local/etc/zbxAdm/2.2/scripts'
echo "Taking backup of all conf files"
my_date=`date "+%m_%d_%y"`
echo $my_date
echo "Taking tar of conf folder"
cd $pwd
tar -cvf zbxAdm_conf_$my_date.tar ../conf
mv zbxAdm_conf_$my_date.tar /tmp/zbxAdm_conf_$my_date.tar
if [ -f /tmp/zbxAdm_conf_$my_date.tar ]
then
echo "conf folder backup taken for today $my_date" | mailx -s"zbxadm/2.2/conf backup taken for $my_date" surekha.pattnaik@sap.com
else
echo "Issue while taking backup for today $my_date" | mailx -s"zbxadm/2.2/conf backup NOT taken for $my_date" surekha.pattnaik@sap.com
fi
