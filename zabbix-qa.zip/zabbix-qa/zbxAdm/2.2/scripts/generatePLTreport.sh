#!/bin/bash

#################################################################
# Author : Sandeep M.R
# Purpose : Generate weekly report for platform services
# Date : July 14th 2015
#################################################################

systemrestartfile="/var/log/zabbix/zbx_systemrestarts.report"
lowswapfile="/var/log/zabbix/zbx_lowswap.report"
lowmemoryfile="/var/log/zabbix/zbx_lowmemory.report"
email="s.renuka@sap.com,patrick.presto@sap.com,amit.kumar15@sap.com,rinkesh.singh@sap.com,sajeesh.mohanan@sap.com,fiyas.ahamed@sap.com"
#email="s.renuka@sap.com"

cd /usr/local/etc/zbxAdm/2.2/scripts



/usr/local/etc/zbxAdm/2.2/scripts/report.pl -item_status 'all' 'system.uptime' | awk -F',' '{ if ( $4 != 0 && $4 < 604800 ) print $1,",",$2,",",$4,",",$6,",",$7,",",$8,",",$9,",",$10 }' > ${systemrestartfile} 


/usr/local/etc/zbxAdm/2.2/scripts/report.pl -item_status 'all' 'system.swap.size[,pused]' | awk -F',' '{ if ( $4 != 0 && $4 > 80 ) print $1,",",$2,",",$4,",",$6,",",$7,",",$8,",",$9,",",$10 }' > ${lowswapfile}


/usr/local/etc/zbxAdm/2.2/scripts/report.pl -item_status 'all' 'vm.memory.size[pavailable]' | awk -F',' '{ if ( $4 != 0 && $4 < 10 ) print $1,",",$2,",",$4,",",$6,",",$7,",",$8,",",$9,",",$10 }' > ${lowmemoryfile}

