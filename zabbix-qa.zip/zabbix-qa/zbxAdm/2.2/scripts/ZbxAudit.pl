#!/usr/bin/perl

##################################################################
# Author        : Vikky Omkar
# Purpose       : Zabbix 2.2 Auditing script
# Reviewer      : Patrick Presto
# Version       : June 2nd 2015 - Initial code
#               : Sep 28th 2015 - added function to update FQDN of a host
####################################################################
########
#######

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;

# Local variable declaration

my @hostname;

# Add Modules and functions into local scope

        use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
        use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
        use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
        use TLDs qw(pfail);
        use SFSF::Host  qw(gethostnames_fromHostgroup gettechnames_fromHostgroup get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val build_host_template_list host_update search_cfg_Templates get_host_ip host_create_macro host_create_jmxinterface host_check_jmxinterface getHostnames_fromHostgroup build_config_mapping get_host_os check_temp_exists update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata host_metadatamacro hostcreate updatefqdn);
        use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
	use SFSF::Item qw(getLocalItems deletelocalitems);
	use SFSF::Web qw(getlocalwebmonitoring deletelocalwebmonitoring);
	use SFSF::Discovery qw(getlocaldiscoveryrule deletelocaldiscoveryrule);
        use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
        use SFSF::Log qw(addtoLogfile);
        use SFSF::Trigger qw(getlocaltriggers deletelocaltriggers get_triggerobj gettriggerobj_val);
        

# Detect running env and set the connection variables

        open(my $fh,'< /etc/hosts');
        my $env;

        while (my $line = <$fh>)
        {
                chomp $line;
                if ($line ne "" and $line =~ m/lab/ )
                {
                        $env = 'qa';
                }
                else { $env = 'prod' ; }
        }

# Load API properites file

        my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
        pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
        pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
        pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


#=pod
my %args;
my @alertname;

        GetOptions(\%args,
                	"lookuplocalitems=s",
                	"lookuplocaldiscoveryrule=s",
                	"lookuplocalwebmonitoring=s",
                	"removelocalitems=s",
               	 	"removelocaldiscoveryrule=s",
                	"removelocalwebmonitoring=s",
			"lookuplocaltriggers=s",
			"removelocaltriggers=s",
			"lookupGroupForNonFqdn=s"	
                )
                or die "Invalid arguments ! Required Param: $0 -lookuplocalitems -removelocalitems -removelocaldiscoveryrule -removelocalwebmonitoring \n";
die "Missing options - 
 	        -lookuplocalitems  <hostgroup>  OR  -removelocalitems <hostgroup>
  		-lookuplocaldiscoveryrule  <hostgroup>  OR  -removelocaldiscoveryrule <hostgroup>
  		-lookuplocalwebmonitoring  <hostgroup>  OR  -removelocalwebmonitoring  <hostgroup>
		-lookuplocaltriggers  <hostgroup>  OR  -removelocaltriggers  <hostgroup>
		-lookupGroupForNonFqdn <hostgroup> \n" unless %args;

        my @key = keys (%args);
# Connect to Zabbix API and write authid to /tmp/hostname.tmp

        my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

        switch ($key[0]){

	#to get host without FQDN hostname in ZABBIX

        case "lookupGroupForNonFqdn" {
                                 my @h_group = values (%args);

                                 # Get Hostgroup object
                                my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                                die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                                # Get Array of Hash keys from hostgroup object that match regex

                                my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                                # Get hostnames from Hostgroup
                                my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                                die "No hosts found" unless defined $host[0];


                                foreach my $t(@host) {
                                                        chomp $t ;
                                                        #Get FQDN name of a host
                                                        my $fqdnname = `nslookup $t`;

                                                                if($fqdnname=~/$t/)
                                                                        {
                                                                                if($fqdnname=~/Name:\s*(.*?)\s/)
                                                                                        {
                                                                                                if($1 eq $t)
                                                                                                        { }
                                                                                                else
                                                                                                        { print "$t\n";}

                                                                                        }

                                                                        }
                                                        }
                                }



	case "lookuplocalitems" {
                         my @h_group = values (%args);
                         my %hash_status = ('0' => 'Enabled','1'=>'Disabled');
                         my %hash_temp = ('0' => 'LocalItem','1'=>'TemplateItem');
                        # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get last value of item
                        foreach my $t(@host) {
                        my $myresult = getLocalItems($zabbix,$t);
                        my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                        #print "$item_count\n";
                        if ( $item_count > 1 ){
                        foreach my  $h (@{$myresult}){
                        #print "$h->{'hostid'}\t$hash_temp{$h->{'templateid'}}\t$hash_status{$h->{'status'}}\t$h->{'itemid'}\t$h->{'key_'}\t$h->{'name'}\n";
                        print "$t\t$hash_status{$h->{'status'}}\t$h->{'itemid'}\t$h->{'key_'}\t$h->{'name'}\n";
                        } print "*******************************************\n";
                        }
                         else {
                                if($myresult->{'itemid'})
                                        {
                                        print "$myresult->{'hostid'}\t$hash_temp{$myresult->{'templateid'}}\t$hash_status{$myresult->{'status'}}\t$myresult->{'itemid'}\t$myresult->{'key_'}\t$myresult->{'name'}\n";
                        #                print "$myresult->{'host'}\t$hash_status{$myresult->{'status'}}\t$myresult->{'itemid'}\t$myresult->{'key_'}\t$myresult->{'name'}\n";
                                        print "********************************************\n";
                                        }
                              }
                #       print "********************************************\n";
                        }

                                            }
case "removelocalitems" {
                        my @localitemid;
                         my @h_group = values (%args);
#                        my $myresult = deletelocalitems($zabbix,$h_group[0]);
                          # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get last value of item
#print Dumper(@host);
                        foreach my $t(@host) {
                        my $myresult = getLocalItems($zabbix,$t);
#print Dumper($myresult);

                        my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                        #print "$item_count\n";
                        if ( $item_count > 1 ){
                        foreach my  $h (@{$myresult}){
                                push(@localitemid,$h->{'itemid'});
			addtoLogfile("$h->{'host'} : Deleted Item id - $h->{'itemid'}  Item Key - $h->{'key_'}","Audit");
                        }
                        }
                         else {
                                if($myresult->{'itemid'})
                                        {
                                                push(@localitemid,$myresult->{'itemid'});
						addtoLogfile("$myresult->{'host'} : Deleted Item id - $myresult->{'itemid'}  Item Key - $myresult->{'key_'}","Audit");
                                        }
                              }
                        }

#                       print "@localitemid";
                        my $result = deletelocalitems($zabbix,\@localitemid);
        #                print Dumper($result);
                        }

case "lookuplocaldiscoveryrule" {
                         my @h_group = values (%args);
                         my %hash_temp = ('0' => 'LocalItem','1'=>'TemplateItem');
                         my %hash_status = ('0' => 'Enabled','1'=>'Disabled');
                        # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get last value of item
                        foreach my $t(@host) {
                        my $myresult = getlocaldiscoveryrule($zabbix,$t);
                        my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                        #print Dumper($myresult);
                        if ( $item_count > 1 ){
                        foreach my $h (@{$myresult}){
#		addtoLogfile("================$h->{'itemid'}==============","audit");

                        print "$t\t$hash_temp{$h->{'templateid'}}\t$hash_status{$h->{'status'}}\t$h->{'itemid'}\t$h->{'key_'}\t\t\t$h->{'name'}\n";
                        }
                        print "**********************\n";
                        }

                         else{
                                if($myresult->{'itemid'})
                                        {
                                        print "$t\t$hash_temp{$myresult->{'templateid'}}\t$hash_status{$myresult->{'status'}}\t$myresult->{'itemid'}\t$myresult->{'key_'}\t$myresult->{'name'}\n";
                                        print "*************************************\n";
                                        }
                             }
                                             }
                              }
case "removelocaldiscoveryrule" {

                                my @h_group = values (%args);
                        my @localdiscoveryrulesid;
                        # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get last value of item
                        foreach my $t(@host) {
                        my $myresult = getlocaldiscoveryrule($zabbix,$t);
                        my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                        #print Dumper($myresult);
                        if ( $item_count > 1 ){
                        foreach my $h (@{$myresult}){
                        push(@localdiscoveryrulesid,$h->{'itemid'});
			addtoLogfile("$t : Deleted Item id - $h->{'itemid'}  Item Key - $h->{'key_'}","Audit");
                        }

                        }

                         else{
                                if($myresult->{'itemid'})
                                        {
                                        push(@localdiscoveryrulesid,$myresult->{'itemid'});
					addtoLogfile("$t : Deleted Item id - $myresult->{'itemid'}  Item Key - $myresult->{'key_'}","Audit");
                                        }
                             }
                                             }
                                my $result = deletelocaldiscoveryrule($zabbix,\@localdiscoveryrulesid);
                #               print "$result";

                              }




case "lookuplocalwebmonitoring" {
                         my @h_group = values (%args);
                        my $h;
                         my %hash_temp = ('0' => 'LocalItem','1'=>'TemplateItem');
                         my %hash_status = ('0' => 'Enabled','1'=>'Disabled');
                        # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get last value of item
                        foreach my $t(@host) {
                        my $myresult = getlocalwebmonitoring($zabbix,$t);
                        my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                        if ( $item_count > 1 ){
                        foreach  $h (@{$myresult}){
                        print "$t\t$hash_temp{$h->{'templateid'}}\t$hash_status{$h->{'status'}}\t\t$h->{'httptestid'}\t\t$h->{'name'}\n";
                        }
                        print "**********************\n";
                        }
                        else{
                                if($myresult->{'httptestid'}){
                                print "$t\t$hash_temp{$myresult->{'templateid'}}\t$hash_status{$myresult->{'status'}}\t\t$myresult->{'httptestid'}\t\t$myresult->{'name'}\n";
                                print "**********************\n";
                                      }  # print "$t: Local item is not present\n";
                        }
                                 }
                        }


case "removelocalwebmonitoring" {
                        my @h_group = values (%args);
                        my $h;
                        my @localwebmonitoringid;
                        # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get last value of item
                        foreach my $t(@host) {
                        my $myresult = getlocalwebmonitoring($zabbix,$t);
                        my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                        if ( $item_count > 1 ){
                        foreach  $h (@{$myresult}){
                        push(@localwebmonitoringid,$h->{'httptestid'});
			addtoLogfile("$t : Deleted Item id - $h->{'httptestid'}  Name - $h->{'name'}","Audit");
                        }

                        }
                        else{
                                if($myresult->{'httptestid'}){
                                push(@localwebmonitoringid,$myresult->{'httptestid'});
				addtoLogfile("$t : Deleted Item id - $myresult->{'httptestid'}  Name - $myresult->{'name'}","Audit");

                                      }
                        }
                                 }
                        my $result = deletelocalwebmonitoring($zabbix,\@localwebmonitoringid);
                #       print "$result";

        }

case "lookuplocaltriggers" {
                         my @h_group = values (%args);
                         
                        # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        #my @host = gethostnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get local triggers

                        foreach my $t(@host) {
                        		my $myresult = getlocaltriggers($zabbix,$t);
                        		#print Dumper($myresult);
                                                }
                        }

case "removelocaltriggers" {

			 my @h_group = values (%args);

                        # Get Hostgroup object
                        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        # Get hostnames from Hostgroup
                        my @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $host[0];
                        # Zabbix API call to get local triggers

                        foreach my $t(@host) {
				my $myresult = deletelocaltriggers($zabbix,$t);
						}
			}

 }



