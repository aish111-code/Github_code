#!/bin/sh

##################################################################
# Author        : Vikky Omkar
# Purpose       : command execution on remote host
# Reviewer      : Sandeep M.R
# Version       : July 21 2015 - Initial code
#
####################################################################

#get user inputs
printf "\nUserName:"
read id
printf "Password:"
stty -echo
read passwd
stty echo
echo
printf "Host Group Name:"
read hostgroup

#file locations
linuxhost=/var/log/zabbix/linuxhost.txt
puphost=/var/log/zabbix/puphost.txt
logfile=/var/log/zabbix/CustomCommand-run.txt

#get host ip
Host=`hostname`
if [ $Host == DC13ZBXPROXY02 ] || [ $Host == DC12ZABBIXPROXY01 ] ||  [ $Host == DC12ZABBIXPROXY02 ]
then
ip=`/sbin/ifconfig -a|grep -A 3 eth0: |grep "inet addr:" |awk '{print $2}'|cut -d: -f2`
else
ip=`/sbin/ifconfig eth0|grep "inet addr:" |awk '{print $2}'|cut -d: -f2`
fi



rm $linuxhost
rm $puphost

#function to get linux servers
Getallhost () {
                dc12allhost=`/usr/local/etc/zbxAdm/2.2/scripts/report.pl  -item_status $1 $2`
                printf "%s\n" "${dc12allhost[@]}" |grep -v Windows |awk '{print $5;}' | sed 1d >>$linuxhost

                }

#function to get puppet enabled servers
Getnpuphost (){
                dc12pupall=`/usr/local/etc/zbxAdm/2.2/scripts/report.pl  -item_status $1 $2`
                printf "%s\n" "${dc12pupall[@]}"  | awk '{if($13==1) print $5}' >>$puphost
                }

#function call
Getallhost $hostgroup  system.uname
Getnpuphost $hostgroup  vfs.file.exists[/var/lib/puppet/facts.yaml]

#file sorting
a=`sort $linuxhost`
b=`sort $puphost`

abc=`comm -23 $linuxhost $puphost`


#printf '%s\n'  ${abc[@]}

#loop to deploy custom command
        for number in ${abc[@]}
        do
                date=`date`
                logdata=`expect copycustcmd.exp $number $id $passwd $ip`
                        if [ $? -ne 0 ]
                                then
                                        printf "$date: Unable to ssh during Rsync of Zabbix Custom Scripts folder on $number\n\n" >>$logfile
                                else
                                        echo "$date" >>$logfile
                                        printf "%s\n"  "${logdata[@]}" |head -6 >>$logfile
                        fi
        done


