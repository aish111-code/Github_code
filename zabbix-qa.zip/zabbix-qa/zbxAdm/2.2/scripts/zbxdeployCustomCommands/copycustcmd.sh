#!/bin/sh
Zbxagent=zabbix-agentd

#get conf file path
ZbxConfPath=`ps -ef |grep zabbix |awk '{if($1=="zabbix") print$10;}'| head -1`

#get path to copy custom commands
ZbxDirPath=`cat /etc/zabbix/zabbix_agentd.conf |grep -i ^Include |cut -d= -f2`
if [ -d $ZbxDirPath ]
then

#sync  custom commands
      Sync=`rsync -avrl   -e  "ssh -o StrictHostKeyChecking=no"  $1@$2:/etc/zabbix/zabbix_agentd/  $ZbxDirPath`
        echo "$Sync\ndir present"
                 if [ -f /etc/init.d/zabbix.agentd ]
                 then
                        Zbxagent="zabbix.agentd"
                fi

#Restart Agent"
        echo " Restart Zabbix Agent"
        #`sudo su -`
        /etc/init.d/${Zbxagent} stop
        t=`/etc/init.d/${Zbxagent} start`
        if [ $? -ne 0 ]
        then
                echo "ERROR during Zabbix Agent Restart"
        else
                echo "Zabbix Agent Restarted Successfully"
        fi


else
        echo "Path to dir is not mentioned in conf file"
fi

