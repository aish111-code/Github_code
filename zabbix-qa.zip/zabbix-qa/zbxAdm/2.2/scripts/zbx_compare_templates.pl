#!/usr/bin/perl

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

# Local variable declaration

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLDs qw(pfail);
use SFSF::Log qw(addtoLogfile);

if( scalar @ARGV < 2 ) {
    die "$0 <source template> < target template > \n";
}

my $srcTmplt = $ARGV[0];
my $tgtTmplt = $ARGV[1];
# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
    chomp $line;
   if ($line ne "" and $line =~ m/lab/ )
   {
       $env = 'qa';
   }
   else {
      $env = 'prod' ;
   }
}


# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};
my $count = 0;
my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

compareTemplates($srcTmplt,$tgtTmplt);


sub compareTemplates { 
    my ( $srcTmpl, $tgtTmplt ) = @_;


    my $srcDataRef = createTemplateStructure( $srcTmpl );
    my $tgtDataRef = createTemplateStructure  ($tgtTmplt);

    foreach my $keyData ( keys %$srcDataRef ) {
        if( $keyData eq 'linkedTemplates' ) {
            foreach my $linkedTemplate ( keys %{$srcDataRef->{linkedTemplates}{name}} ) {
                if( ! exists $tgtDataRef->{linkedTemplates}{name}{$linkedTemplate} ) {
                    print "Linked template '$linkedTemplate' doesn't exist in the target File \n";
                }
                else{
                    #print "template $linkedTemplate exists in both source and target \n";
                }
            }
        }
        if( $keyData eq 'applications' ) {
            foreach my $application ( keys %{$srcDataRef->{applications}{name}} ) {
                if( ! exists $tgtDataRef->{applications}{name}{$application} ) {
                    print "Application '$application' doesn't exist in the target File \n";
                }
                else{
                }
            }
        }
        if( $keyData eq 'triggers' ) {
            foreach my $trigger ( keys %{$srcDataRef->{triggers}{name}} ) {
                if( ! exists $tgtDataRef->{triggers}{name}{$trigger} ) {
                    print "Trigger '$trigger' doesn't exist in the target File \n";
                }
                else{
                }
            }
        }
        if( $keyData eq 'graphs' ) {
            foreach my $graph ( keys %{$srcDataRef->{graphs}{name}} ) {
                if( ! exists $tgtDataRef->{graphs}{name}{$graph} ) {
                    print "Graph '$graph' doesn't exist in the target File \n";
                }
                else{
                }
            }
        }
        if( $keyData eq 'screens' ) {
            foreach my $screen ( keys %{$srcDataRef->{screens}{name}} ) {
                if( ! exists $tgtDataRef->{screens}{name}{$screen} ) {
                    print "Screen '$screen' doesn't exist in the target File \n";
                }
                else{
                }
            }
        }
    }

}
sub createTemplateStructure {
    my ( $filename ) = @_;
  

    my $json_text = do {
    open(my $json_fh, "<:encoding(UTF-8)", $filename)
      or die("Can't open \$filename\": $!\n");
       local $/;
      <$json_fh>
    };

   my $json = JSON->new;
   my $data = $json->decode($json_text);

   my %sourceDS;
   foreach my $zbxKey ( keys %{$data->{zabbix_export}} ) {
       if( $zbxKey eq 'triggers' ) {
            foreach my $triggerRef ( @{$data->{zabbix_export}{triggers}} ) {
                my $triggerName = $triggerRef->{name};
                my $triggerExpression = $triggerRef->{expression};
                $sourceDS{triggers}{name}{$triggerName} = 1;
                $sourceDS{triggers}{expression}{$triggerExpression} = 1; 
            }
            foreach my $graphRef ( @{$data->{zabbix_export}{graphs}} ) {
                my $graphName = $graphRef->{name};
                $sourceDS{graphs}{name}{$graphName} = 1;
            }
            foreach my $tmplRef ( @{$data->{zabbix_export}{templates}} ) {
                my $linkedTmplRef = $tmplRef->{templates};
                my $itemRef = $tmplRef->{items};
                my $discoveryRulesRef = $tmplRef->{discovery_rules};
                my $applicationsRef = $tmplRef->{applications};
                my $screensRef = $tmplRef->{screens};

                foreach my $linkedTmplts ( @$linkedTmplRef ) {
                    my $linkedTmplName = $linkedTmplts->{name};
                    $sourceDS{linkedTemplates}{name}{$linkedTmplName} = 1;
                }
                foreach my $items ( @$itemRef ) {
                    my $itemName = $items->{name};
                    my $itemKey = $items->{key};
                    $sourceDS{items}{name}{$itemName} = 1;
                    $sourceDS{items}{key}{$itemKey} = 1;
                }
                foreach my $drules ( @$discoveryRulesRef ) {
                    my $druleName = $drules->{name};
                    $sourceDS{discovery_rules}{name}{$druleName} = 1;
                }
                foreach my $applications ( @$applicationsRef ) {
                    my $appname = $applications->{name};
                    $sourceDS{applications}{name}{$appname} = 1;
                }
                foreach my $screens ( @$screensRef) {
                    my $screenName = $screens->{name};
                    $sourceDS{screens}{name}{$screenName} = 1;
                }
            }
       }
   }

    return \%sourceDS;
}
sub get_templateid {
    my $zabbix = shift;
    my $template_name = shift;
    my $options = {'output' => ['templateid'], 'filter' => {'host' => $template_name}};
    my $result = $zabbix->get('template', $options);
    my $template_id = $result->{templateid};
    return $template_id;

}

