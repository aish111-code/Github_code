#!/usr/bin/perl

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';
use lib dirname(abs_path $0) . '/../lib/myCorelib/lib/perl5';
use lib dirname(abs_path $0) . '/../lib/lib/perl5';
use lib dirname(abs_path $0) . '/../lib/myCorelib/lib/perl5/lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON::XS;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

my @hostid;

# Add Modules and functions into local scope

	use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
	use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
	use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
	use TLDs qw(pfail);

	use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os);
	use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
	use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
	use SFSF::Log qw(addtoLogfile);
	use SFSF::Trigger qw(get_triggerobj gettriggerobj_val);

# Detect running env and set the connection variables

	open(my $fh,'< /etc/hosts');
	my $env;

	while (my $line = <$fh>)
	{
   		chomp $line;
   		if ($line ne "" and $line =~ m/lab/ )
        	{	
        		$env = 'qa';
        	}
    		else { $env = 'prod' ; }
	}	

# Load API properites file

	my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
  	pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
  	pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
  	pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp
	
	my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});





my $options = {'output' => 'extend','selectHosts' => { '0' => 'name' },'webitems' => '1','preservekeys' => '1','status' => '2'};


my $items = $zabbix->raw('event','get', $options);

print Dumper($items);


=pod
my @triggerid;

foreach my $trigger (@{$triggers} )
{

push @triggerid,$trigger->{'triggerid'};

}

#print @triggerid;

foreach my $t (@{triggerid})
{

#print Dumper($t);

my $options1={'nodeids' => '0','triggerids' => $t,'output' => 'extend','selectHosts' => {'0' => 'itemid','1' => 'hostid','2' => 'key_','3' => 'name'},'selectDependencies' => 'extend','selectLastEvent' => '1','expandDescription' => '1','preservekeys' => '1'};

my $triggers1 = $zabbix->raw('trigger','get', $options1);

#print Dumper($triggers1);
#}
#=pod
foreach my $k (keys %$triggers1) {
    #print "key=$k";
    foreach my $h (@{$triggers1->{$k}{hosts}}) {
        print "$h->{name} \n" // 'not defined';
	#print Dumper($h);
    }
    #print "\nvalue=",$triggers1->{$k}{description} // 'not defined',"\n";
}
}
#=cut


#}

=cut
