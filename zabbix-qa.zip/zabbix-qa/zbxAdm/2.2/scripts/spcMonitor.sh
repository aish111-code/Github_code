#!/bin/bash

##############################################
# Purpose : Monitor for zabbix login
# Author  : Sandeep M.R
# Date    : 12/9/2014
##############################################

#email_to="s.renuka@sap.com,patrick.presto@sap.com,anoop.sivaraman@sap.com,amit.kumar15@sap.com,jayavardhan.jandhyala@sap.com,surekha.pattnaik@sap.com"
email_to="s.renuka@sap.com"

x=`date +%Y%m%d_%H`

count=`grep "DEBUG: Created Incident in SPC" /var/log/zabbix/SPC/*$x* | wc -l`

if [ $count -eq 0 ]
then
echo "Action required - Zabbix to SPC Integration is not creating new SPC incidents for last 30mins" | mailx -s "Action required - Zabbix to SPC Integration is not creating new SPC incidents" -r saasopsps@successfactors.com $email_to
fi

