import pypyodbc 
import re
import sys
import logging
import urllib
import urllib2
import base64
import ssl
import datetime
import os
import csv
import xml.etree.ElementTree as ET
import xml.dom.minidom
from xml.dom.minidom import parse
from xml.dom import minidom
from difflib import SequenceMatcher
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import wget
from csv import reader
import time

#Files attached to mail
in_mintenance_list = '/tmp/all_mssql_zbx_in_maintenance.csv'
out_maintenance_list = '/tmp/all_mssql_zbx_not_in_maintenance.csv'
mssql_not_in_zbx = '/tmp/servers_in_mssql_inventory_not_in_zbx.csv'


cnxn = pypyodbc.connect("Driver={ODBC Driver 17 for SQL Server};"
                      "Server=10.8.198.93;"
		      "uid=splunkjobuser;"
                      "pwd=b58KZNsdMWf8E5Yn;")


cursor = cnxn.cursor()
cursor.execute('SELECT * FROM [CMDB].[dbo].[VW_CMDB_COLLECTOR_LIST]')
with open('/tmp/mssql.csv', 'w') as mssql:
    #mssql.write("DC,Servers,Product,Environment\n")
    for row in cursor:
        DC = row[0]
        instance = row[1]
        server_list = 'Null'
        if row[8]:
            slist = []
            splitData = re.split('\]\s*;\s*\[', row[8])
            for v in splitData:
               #v1 = v.split('-')
               v1 = re.split('\s\-\s', v)
               slist.append(v1[0].replace('[', '').strip())
            server_list = '|'.join(slist)
        Product = row[9]
        Environment = row[10]
        if row[4] == 'Live' and server_list != 'Null':
            mssql.write("{},{},{},{}\n".format(DC, server_list, Product, Environment)) 
        #print('row = %r' % (row,))
cursor.close()
cnxn.close()


with open('/tmp/mssql.csv','r') as in_file, open('/tmp/mssql_inventory.csv','w') as out_file:
    seen = set() 
    for line in in_file:
        if line in seen: continue # skip duplicate

        seen.add(line)
        out_file.write(line)

#Download Zabbix Inventory
os.system("rm /tmp/all_zabbix_inventory_mssql.txt")
zabbix_inv_url = 'https://zabbix-inventory.cld.ondemand.com/Inventory.txt'
zabbix_inventory = wget.download(zabbix_inv_url, '/tmp/all_zabbix_inventory_mssql.txt')


zbxmssql = open('/tmp/servers_in_mssql_inventory_and_zbx.csv', 'w')
zbxmssql.write("MSSQL_DC,MSSQL_SERVER,MSSQL_PRODUCT,MSSQL_ENVIRONMENT,ZABBIX_VISIBLENAME,ZABBIX_STATUS,IPADDRESS,TEMPLATES,ZABBIX_GROUPS\n")
mssqlnotzbx = open('/tmp/servers_in_mssql_inventory_not_in_zbx.csv', 'w')
mssqlnotzbx.write("MSSQL_DC,MSSQL_SERVER,MSSQL_PRODUCT,MSSQL_ENVIRONMENT\n")

zbx = open('/tmp/all_zabbix_inventory_mssql.txt', 'r')
lines = zbx.readlines()


mssql = open('/tmp/mssql_inventory.csv', 'r')
mssql_inventory = csv.reader(mssql, delimiter=',')
mssql_servers = 0
ncount = 0
for row in mssql_inventory:
    found = 0
    slist = row[1].split("|")
    for i in range(len(slist)):
        #server = slist[i]
        mssql_servers = mssql_servers + 1
        dc =  row[0]
        product = row[2]
        env = row[3]
        for line in lines:
            fields = line.split('|')
            host_details = fields[0].split('.')
            host = host_details[0].strip().lower()
            vname_details = fields[1].split('.')
            vname = vname_details[0].strip().lower()
            zstatus = fields[2]
            ips = fields[3].replace(",", ";")
            ztemplates = fields[4].replace(",", ";")
            zgroups = fields[5].replace(",", ";")
            #if (mssql_server == vname or mssql_server == host):
            if re.search(slist[i],vname,re.IGNORECASE) or re.search(slist[i],host,re.IGNORECASE):
                found = 1
                zbxmssql.write("{},{},{},{},{},{},{},{},{}".format(dc,slist[i],product,env,vname,zstatus,ips,ztemplates,zgroups))
        if found == 0:
            ncount = ncount + 1
            mssqlnotzbx.write("{},{},{},{}\n".format(dc,slist[i],product,env))

all_mssql_maintenance = open('/tmp/all_mssql_zbx_in_maintenance.csv', 'w')
all_mssql_without_maintenance = open('/tmp/all_mssql_zbx_not_in_maintenance.csv', 'w')

#code to extract all mssql hosts which are in maintenance and not in maintenance mode.
myinv = open('/tmp/servers_in_mssql_inventory_and_zbx.csv', 'r')
#mssql_inv = csv.reader(myinv, delimiter=',')
all_mssql_maintenance.write("MSSQL_DC,MSSQL_SERVER,MSSQL_PRODUCT,MSSQL_ENVIRONMENT,ZABBIX_VISIBLENAME,ZABBIX_STATUS,IPADDRESS,TEMPLATES,ZABBIX_GROUPS\n")
maintenance = 0
out_of_maintenance = 0
for line in myinv:
    if re.search("All-NotLive-Hosts-Maintenance",str(line),re.IGNORECASE):
        all_mssql_maintenance.write(str(line))
        maintenance = maintenance + 1
    else:
        all_mssql_without_maintenance.write(str(line))
        out_of_maintenance = out_of_maintenance + 1


def mailFiles(report1,report2,report3):

    #mails = "v.manepalli@sap.com"
    mails = "v.manepalli@sap.com s.renuka@sap.com sindhu.madicherla@sap.com jibin.sunny@sap.com ayush.jain@sap.com sajeev.george@sap.com v.gandrakota@sap.com s.vadella@sap.com vineeth.nair01@sap.com"
    subject = "Zabbix Inventory vs MSSQL Host Audit report"
    printBody =  "Hi Team,\n\nThis report shows Zabbix montoring status of MSSQL Servers\n\n 1.No.of MSSQL servers(Live) in MSSQL Inventory:" + str(mssql_servers) + "\n\n2.No.of MSSQL Hosts(including SSD) out of maintenance in Zabbix(attached):" + str(out_of_maintenance-1) + "\n\n3.No.of MSSQL Hosts(Including SSD) in maintenance in Zabbix(attached):" + str(maintenance) + "\n\n4.Servers(Live) in MSSQL Inventory but not in Zabbix(attached):" + str(ncount) + "\n\nPlease do not reply to this email, it was automatically generated\n\nRegards,\nCloud Operations | Tools and Utilities"
    mailCmd = "echo '" + printBody + "' | mailx -s '" + subject + "' -a " + report1 + " -a " + report2 + " -a " + report3 + "  -r sapsfsdotoolsandutils@sap.com " + mails
    os.system(mailCmd)


all_mssql_maintenance.seek(0, os.SEEK_END)
size = all_mssql_maintenance.tell()

all_mssql_without_maintenance.seek(0, os.SEEK_END)
size = all_mssql_without_maintenance.tell()

mssqlnotzbx.seek(0, os.SEEK_END)
size = mssqlnotzbx.tell()

mailFiles(in_mintenance_list,out_maintenance_list,mssql_not_in_zbx)

