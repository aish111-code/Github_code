#!/usr/bin/python
import json
import requests
import csv
import re
import sys
import logging
import urllib
import urllib2
import base64
import ssl
import datetime
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
from xml.dom.minidom import parse
from xml.dom import minidom
from difflib import SequenceMatcher
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import wget
from csv import reader
import time

all_hana = open('/tmp/all_hana_zbx.txt', 'w')
all_hana_maintenance = open('/tmp/all_hana_zbx_maintenance.csv', 'w')
all_hana_without_maintenance = open('/tmp/all_hana_zbx_without_maintenance.csv', 'w')

itoa_url = 'https://itoahana.sapsf.com/sfsf//inventory/tools/inventory.xsodata/INVENTORY'
zabbix_inv_url = 'https://zabbix-inventory.cld.ondemand.com/Inventory.txt'

os.system("rm /tmp/zabbix_new_inventory.txt")
zabbix_inventory = wget.download(zabbix_inv_url, '/tmp/zabbix_new_inventory.txt')

#extract data from ITOA Inventory
r=requests.get(url=itoa_url,auth=('INVENTORY_USER_TOOLS','InventoryA12345'),headers={'Content-Type': 'application/json'}, verify=False)
root = ET.fromstring(r.content)
#print root

count = 0
with open('/tmp/itoa.csv', 'w') as itoa:
    #itoa.write("Hostname,Status\n")
    for child in root:
        #print child
        for entry in child.findall('{http://www.w3.org/2005/Atom}content'):
            for content in entry.findall('{http://schemas.microsoft.com/ado/2007/08/dataservices/metadata}properties'):
                virtual_host = content.find('{http://schemas.microsoft.com/ado/2007/08/dataservices}VIRTUAL_HOST').text
                physical_host  =  content.find('{http://schemas.microsoft.com/ado/2007/08/dataservices}PHYSICAL_HOST').text
                status = content.find('{http://schemas.microsoft.com/ado/2007/08/dataservices}HOST_STATUS').text
                cat = content.find('{http://schemas.microsoft.com/ado/2007/08/dataservices}CATEGORY').text
                dc = content.find('{http://schemas.microsoft.com/ado/2007/08/dataservices}DC').text
                if status == 'LIVE' and not physical_host == 'NA' and not cat == 'RESTORE_SYSTEM'  and not dc == 'DC16' and not dc == 'DC25':
                    count = count + 1
                    itoa.write("{},{},{},{}\n".format(virtual_host, physical_host, status, cat))



#Code the extract all hana hosts from Zabbix Inventory
zbx = open('/tmp/zabbix_new_inventory.txt', 'r')
lines = zbx.readlines()
for line in lines:
    if re.search('hana',line,re.IGNORECASE):
        all_hana.write(line)

#code to extract all hana hosts which are in All-NotLive-Hosts-Maintenance and not in maintenance mode.
all_hana_count = 0
all_hana_count_without = 0
all_hana = open('/tmp/all_hana_zbx.txt', 'r')
all_hana_maintenance.write("HOSTNAME,VISIBLENAME,STATUS,IPADDRESS,TEMPLATES,GROUPS\n")
for line in all_hana:
    if re.search('All-NotLive-Hosts-Maintenance',line,re.IGNORECASE):
        entries = line.split('|')
        ips = entries[3].replace(",", ";")
        templates = entries[4].replace(",", ";")
        zabbix_groups  = entries[5].replace(",", ";")
        all_hana_maintenance.write("{},{},{},{},{},{}".format(entries[0],entries[1],entries[2],ips,templates,zabbix_groups))
        all_hana_count = all_hana_count + 1
    else:
        all_hana_without_maintenance.write(line)
        all_hana_count_without = all_hana_count_without + 1




zbxitoa = open('/tmp/servers_in_itoa_and_zbx.csv', 'w')
zbxitoa.write("ITOA_VIRTUAL_HOST,ITOA_PHYSICAL_HOST,ITOA_STATUS,ZABBIX_VISIBLENAME,ZABBIX_STATUS,ZABBIX_GROUPS\n")
liveitoinmaintinzbx = open('/tmp/live_servers_in_itoa_in_maintenance_zbx.csv', 'w')
liveitoinmaintinzbx.write("ITOA_VIRTUAL_HOST,ITOA_PHYSICAL_HOST,ITOA_STATUS,ZABBIX_VISIBLENAME,ZABBIX_STATUS,ZABBIX_GROUPS\n")
itoanotzbx = open('/tmp/servers_in_itoa_not_in_zbx.csv', 'w')
itoanotzbx.write("VIRTUAL_HOST,PHYSICAL_HOST\n")

#Files attached to mail notification
initoainzbx = '/tmp/servers_in_itoa_and_zbx.csv'
hanainmait = '/tmp/all_hana_zbx_maintenance.csv'
initoanotinzbx = '/tmp/servers_in_itoa_not_in_zbx.csv' 
liveitoainmaintzbx = '/tmp/live_servers_in_itoa_in_maintenance_zbx.csv'


itoa = open('/tmp/itoa.csv', 'r')
itoa_inventory = csv.reader(itoa, delimiter=',')
zbx = open('/tmp/zabbix_new_inventory.txt', 'r')
lines = zbx.readlines()
live = 0
ncount = 0
for row in itoa_inventory:
    found = 0
    itoa_vhost = row[0].strip()
    itoa_phost = row[1].strip()
    itoa_status = row[2]
    #print itoa_host,itoa_status
    for line in lines:
        fields = line.split('|')
        host_details = fields[0].split('.')
        host = host_details[0].strip().lower()
        vname_details = fields[1].split('.')
        vname = vname_details[0].strip().lower()
        zstatus = fields[2]
        zgroups = fields[5].replace(",", ";")
        if (itoa_phost == vname or itoa_phost == host) or (itoa_vhost == vname or itoa_vhost == host):
            found = 1
            #print itoa_vhost,itoa_phost,itoa_status,vname,zstatus,zgroups
            zbxitoa.write("{},{},{},{},{},{}".format(itoa_vhost,itoa_phost,itoa_status,vname,zstatus,zgroups))
        if (re.search(itoa_phost,line,re.IGNORECASE) or re.search(itoa_vhost,line,re.IGNORECASE)) and re.search('All-NotLive-Hosts-Maintenance',line,re.IGNORECASE):
            live = live +1
            liveitoinmaintinzbx.write("{},{},{},{},{},{}".format(itoa_vhost,itoa_phost,itoa_status,vname,zstatus,zgroups))
    if found == 0:
        ncount = ncount + 1
        itoanotzbx.write("{},{}\n".format(itoa_vhost,itoa_phost))
 

def mailFiles(report1,report2,report3,report4):

    #mails = "v.manepalli@sap.com s.renuka@sap.com sindhu.madicherla@sap.com jibin.sunny@sap.com ayush.jain@sap.com SDO_CO_HANA_DB_Support@sap.com"
    mails = "v.manepalli@sap.com"
    subject = "Zabbix Host vs ITOA HANA Host Audit report"
    printBody =  "Hi Team,\n\nThis report shows Zabbix montoring status of servers in ITOA\n\n 1.No.of Live hosts in ITOA(except NA,DC16,DC25 and Restore Systems):" + str(count) + "\n\n2.No.of HANA Hosts out of maintenance in Zabbix:" + str(all_hana_count_without) + "\n\n3.No.of HANA Hosts in maintenance in Zabbix(attached):" + str(all_hana_count) + "\n\n4.No.of ITOA Live Hosts in maintenance in Zabbix(attached):" + str(live) + "\n\n5.Servers(Live) in ITOA but not in Zabbix(attached):" + str(ncount) + "\n\nPlease do not reply to this email, it was automatically generated\n\nRegards,\nCloud Operations | Tools and Utilities"
    mailCmd = "echo '" + printBody + "' | mailx -s '" + subject + "' -a " + report1 + " -a " + report2 + " -a " + report3 + " -a " + report4 + " -r sapsfsdotoolsandutils@sap.com " + mails
    os.system(mailCmd)


itoanotzbx.seek(0, os.SEEK_END)
size = itoanotzbx.tell()
liveitoinmaintinzbx.seek(0, os.SEEK_END)
size = liveitoinmaintinzbx.tell()
mailFiles(initoainzbx,hanainmait,liveitoainmaintzbx,initoanotinzbx)
