import pypyodbc
import requests
import csv
import re
import sys
import logging
import urllib
import urllib2
import base64
import ssl
import datetime
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
from xml.dom.minidom import parse
from xml.dom import minidom
from difflib import SequenceMatcher
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import wget
from csv import reader
import time

all_mysql_maintenance = open('/tmp/all_mysql_zbx_in_maintenance.csv', 'w')
all_mysql_without_maintenance = open('/tmp/all_mysql_zbx_not_in_maintenance.csv', 'w')

#Files attached to mail
in_mintenance_list = '/tmp/all_mysql_zbx_in_maintenance.csv'
out_maintenance_list = '/tmp/all_mysql_zbx_not_in_maintenance.csv'
mysql_not_in_zbx = '/tmp/servers_in_mysql_inventory_not_in_zbx.csv'

cnxn = pypyodbc.connect("Driver={mysqlodbcdriver};"
                      "Server=10.8.199.144;"
		      "uid=splunkjobuser;"
                      "pwd=qNBVzMAEt4Gjzuzw;"
                      "Trusted_Connection=yes;")


cursor = cnxn.cursor()
cursor.execute('SELECT * FROM cmdb.VW_DBAI_MYSQL_SERVER_LIST')




with open('/tmp/mysql_inventory.csv', 'w') as mysql:
    #mysql.write("DC,Server,Product,Environment\n")
    mysql_servers = 0
    for row in cursor:
        dc = row[0]
        server = row[1].lower()
        product = row[5]
        env = row[6]
        status = row[7]
        if status == 'Live':
            mysql.write("{},{},{},{}\n".format(dc, server, product, env))
            mysql_servers = mysql_servers + 1

cursor.close()
cnxn.close()

#Download Zabbix Inventory
os.system("rm /tmp/all_zabbix_inventory.txt")
zabbix_inv_url = 'https://zabbix-inventory.cld.ondemand.com/Inventory.txt'
zabbix_inventory = wget.download(zabbix_inv_url, '/tmp/all_zabbix_inventory.txt')

zbxmysql = open('/tmp/servers_in_mysql_inventory_and_zbx.csv', 'w')
zbxmysql.write("MYSQL_DC,MYSQL_SERVER,MYSQL_PRODUCT,MYSQL_ENVIRONMENT,ZABBIX_VISIBLENAME,ZABBIX_STATUS,IPADDRESS,TEMPLATES,ZABBIX_GROUPS\n")
mysqlnotzbx = open('/tmp/servers_in_mysql_inventory_not_in_zbx.csv', 'w')
mysqlnotzbx.write("MYSQL_DC,MYSQL_SERVER,MYSQL_PRODUCT,MYSQL_ENVIRONMENT\n")

mysql = open('/tmp/mysql_inventory.csv', 'r')
mysql_inventory = csv.reader(mysql, delimiter=',')
zbx = open('/tmp/all_zabbix_inventory.txt', 'r')
lines = zbx.readlines()
ncount = 0
for row in mysql_inventory:
    found = 0
    mysql_dc = row[0]
    mysql_server_details = row[1].split('.')
    mysql_server = mysql_server_details[0].strip().lower()
    mysql_product = row[2]
    mysql_env = row[3]
    for line in lines:
        fields = line.split('|')
        host_details = fields[0].split('.')
        host = host_details[0].strip().lower()
        vname_details = fields[1].split('.')
        vname = vname_details[0].strip().lower()
        zstatus = fields[2]
        ips = fields[3].replace(",", ";")
        ztemplates = fields[4].replace(",", ";")
        zgroups = fields[5].replace(",", ";")
        #if (mysql_server == vname or mysql_server == host):
        if re.search(mysql_server,vname,re.IGNORECASE) or re.search(mysql_server,host,re.IGNORECASE):
            found = 1
            zbxmysql.write("{},{},{},{},{},{},{},{},{}".format(mysql_dc,mysql_server,mysql_product,mysql_env,vname,zstatus,ips,ztemplates,zgroups))
    if found == 0:
        ncount = ncount + 1
        mysqlnotzbx.write("{},{},{},{}\n".format(mysql_dc,mysql_server,mysql_product,mysql_env))

zbxmysql.close()

#code to extract all mysql hosts which are in maintenance and not in maintenance mode.
myinv = open('/tmp/servers_in_mysql_inventory_and_zbx.csv', 'r')
#mysql_inv = csv.reader(myinv, delimiter=',')
all_mysql_maintenance.write("MYSQL_DC,MYSQL_SERVER,MYSQL_PRODUCT,MYSQL_ENVIRONMENT,ZABBIX_VISIBLENAME,ZABBIX_STATUS,IPADDRESS,TEMPLATES,ZABBIX_GROUPS\n")
maintenance = 0
out_of_maintenance = 0
for line in myinv:
    if re.search("All-NotLive-Hosts-Maintenance",str(line),re.IGNORECASE):
        all_mysql_maintenance.write(str(line))
        maintenance = maintenance + 1
    else:
        all_mysql_without_maintenance.write(str(line))
        out_of_maintenance = out_of_maintenance + 1
       

def mailFiles(report1,report2,report3):

    #mails = "v.manepalli@sap.com"
    mails = "v.manepalli@sap.com s.renuka@sap.com sindhu.madicherla@sap.com jibin.sunny@sap.com ayush.jain@sap.com dl_hcm_mysql_db_support@sap.com sajeev.george@sap.com"
    subject = "Zabbix Inventory vs MySQL Host Audit report"
    printBody =  "Hi Team,\n\nThis report shows Zabbix montoring status of MySQL Servers\n\n 1.No.of MySQL servers in MySQL Inventory:" + str(mysql_servers) + "\n\n2.No.of MySQL Hosts out of maintenance in Zabbix(attached):" + str(out_of_maintenance-1) + "\n\n3.No.of MySQL Hosts in maintenance in Zabbix(attached):" + str(maintenance) + "\n\n4.Servers(Live) in MySQL Inventory but not in Zabbix(attached):" + str(ncount) + "\n\nPlease do not reply to this email, it was automatically generated\n\nRegards,\nCloud Operations | Tools and Utilities"
    mailCmd = "echo '" + printBody + "' | mailx -s '" + subject + "' -a " + report1 + " -a " + report2 + " -a " + report3 + "  -r sapsfsdotoolsandutils@sap.com " + mails
    os.system(mailCmd)


all_mysql_maintenance.seek(0, os.SEEK_END)
size = all_mysql_maintenance.tell()

all_mysql_without_maintenance.seek(0, os.SEEK_END)
size = all_mysql_without_maintenance.tell()

mysqlnotzbx.seek(0, os.SEEK_END)
size = mysqlnotzbx.tell()

mailFiles(in_mintenance_list,out_maintenance_list,mysql_not_in_zbx)
