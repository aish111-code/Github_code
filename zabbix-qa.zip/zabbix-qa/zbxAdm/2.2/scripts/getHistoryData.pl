#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration


use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
                chomp $line;
                if ($line ne "" and $line =~ m/lab/ )
                {
                        $env = 'qa';
                }
                else { $env = 'prod' ; }
}

# Load API properites file

        my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
        pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
        pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
        pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my %metricNameDataTypeMap = ( 'system.cpu.load' => 0, 'system.cpu.load[,avg5]' => 0, 'vm.memory.size[pavailable]' => 0, 'jmx["java.lang:type=Memory",HeapMemoryUsage.used]' => 3, 'jmx["java.lang:type=Memory",HeapMemoryUsage.max]' => 3, 'jmx["java.lang:type=MemoryPool,name=CMS Old Gen",Usage.used]' => 3 );
my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


my %args;

GetOptions(\%args,
                        "hostGroup=s",
                        "metricName=s",
                        "period=s",
                        "timeUnit=s"
           );


if( ! scalar keys %args ) {
    usage();
}

    #-metricName < metric name >			        - options: system.cpu.load or system.cpu.load[,avg5] or vm.memory.size[pavailable] or jmx[\"java.lang:type=Memory\",HeapMemoryUsage.used] or jmx[\"java.lang:type=Memory\",HeapMemoryUsage.max]
sub usage {

    my $options = join " | " , keys %metricNameDataTypeMap;
    $options = '( ' . $options . ' )';
    printf("%s 
    -period < n >  		                        - Time in days to get metrics data
    -timeUnit < days | hours | mins >   	        - Unit of Time . Any of the mentioned options
    -hostGroup < Host Group Name(s) >			- Comma separated list of Host Group names
    -metricName < metric name >                         - options: %s 

    Example: %s -hostGroup  pc4_BizX_A_SFAPI -period 30 -timeUnit hours -metricName 'system.cpu.load' \n", $0, $options, $0  ) ;

    exit 1;
}

##Zabbix web host is in Eastern time......so convert all time time EDT
$ENV{TZ} = 'US/Eastern';
my $hostGroup = $args{hostGroup};
my @hostGroups=();
if( $hostGroup =~ /,/ ) {
    @hostGroups = split /,/, $hostGroup;
}
else{
    push @hostGroups, $hostGroup;
}
my $timeUnit = $args{timeUnit};
my $timeDuration = $args{period};
if( $timeDuration > 30 && $timeUnit eq 'days' ) {
    die "Time period is restricted to maximum 30 days due to performance load to the DB\n";
}
my $metricName = $args{metricName};

if ( ! exists $metricNameDataTypeMap{$metricName} ) {
    print "==============================================================================================================\n";
    print "Only Below metrics names are allowed to execute. You may contact the Admin to Add more metrics, if required. \n";
    print Dumper \%metricNameDataTypeMap;
    usage();
}
getHistory($zabbix, \@hostGroups, $timeDuration, $timeUnit, $metricName);


sub getHistory {
    my ( $zabbix, $hostGroupRef, $timeDuration, $timeUnit, $metricName ) = @_;

    if( ! defined $zabbix || ! $timeDuration || ! $timeUnit || ! $hostGroupRef ) {
        print "Some input parameters are not provided :" .  usage() . "\n";
        exit 1;
    }

    my ( @hostIds, @itemIds );
    my $hostDetails; 
    my $histDataType=0; 
    if( $hostGroupRef ) {
        $hostDetails = _getHostDataByGroup($zabbix,$hostGroupRef,$metricName);
        if( ! scalar keys %$hostDetails )  {
            print "No host details found for host group @$hostGroupRef \n";
            print "Possibly no metric defined for the given hosts/hostgroups\n";
            exit 1;
        }
        else{
            @itemIds = keys %$hostDetails;
            my $itemId = $itemIds[0];
            $histDataType = $hostDetails->{$itemId}{dataType};
        }
    }
    
    my $currentTimeStamp = `date +%s`;
    chomp($currentTimeStamp);
    my $currentDate = `date -d\@$currentTimeStamp +%Y%m%d:%H%M%S`;
    chomp($currentDate);
    


    my $timeperiod_type = 0;   ##0=daily
    my $currentHour = `date +%H`;
    chomp($currentHour);
    my $currentMin = `date +%M`;
    chomp($currentMin);

    my $now = ($currentHour * 60 *60 ) + ( $currentMin * 60 );

    if ( $timeUnit eq 'days' ) {
        $timeDuration = $timeDuration * 24 * 60 * 60;
    }
    elsif( $timeUnit eq 'hours' ) {
        $timeDuration = $timeDuration * 60 * 60;
    }
    elsif( $timeUnit eq 'mins' ) {
        $timeDuration = $timeDuration * 60;
    }
    else {
        die "Invalid time unit";
    }
    my $pastTimeStamp = $currentTimeStamp - $timeDuration;
    my $pastDate = `date -d\@$pastTimeStamp +%Y%m%d:%H%M%S`;
    chomp($pastDate);

#print "currentTimeStamp=$currentDate | $currentTimeStamp, pastTimeStamp=$pastDate | $pastTimeStamp\n";
#$histDataType = 3;
    my %params = ( 
                   'output' => 'extend',
                   'time_from' => $pastTimeStamp,
                   'time_till' => $currentTimeStamp,
                   'itemids' => [@itemIds] ,
                   'history' => $histDataType,
                   'sortfield' => 'clock',
                   'sortorder' => 'DESC',
                 );

    my $result = $zabbix->raw('history','get',\%params);
    #print "Recieved Time,Host Name,Host Group, Metric Name,Value\n";
    foreach my $data ( @$result ) {
        my $itemid = $data->{itemid};
        my $hostName = $hostDetails->{$itemid}{hostname};
        my $hostGroup = $hostDetails->{$itemid}{hostGroup};
        my $value = $data->{value};
        my $recievedTime = $data->{clock};
        $recievedTime = `date -d\@$recievedTime +%Y%m%d%H%M%S`;
        chomp($recievedTime);
#        print "recievedTime=$recievedTime,hostName=$hostName,hostGroup=$hostGroup,metricName=$metricName,value=$value\n";
        print "$recievedTime $hostName $hostGroup $metricName $value\n";
    }
#print Dumper $result;


}


sub _getHostIdByName {
    my ( $zabbix, $hostName ) = @_;

    return SFSF::Host::get_hostid($zabbix,$hostName);
}

sub _getHostDataByGroup {
    my ($zabbix,$hGrpNameRef,$metricName) = @_;

    return {} if ( ! $zabbix || ! $hGrpNameRef );
    my %hostDetails = ();

    foreach my $hGrpName ( @$hGrpNameRef ) {
        my $options = {'output' => 'groupid','filter' => {'name' => $hGrpName }};
        my $myresult = $zabbix->raw('hostgroup','get',$options);
    
        my $hostGrpId = $myresult->{groupid};
    
        $options = {'output' => ['hostid','name','status'], 'groupids' => $hostGrpId };
        $myresult = $zabbix->raw('host','get',$options);
        #print Dumper $myresult;
        if ( ref($myresult) eq 'ARRAY' ){
            foreach my $h (@{$myresult}){
                my $hId = $h->{hostid};
                my $hName = $h->{name};
                my $status = $h->{'status'};
                if( $status == 0 ){  ##only active hosts
                    my $itemDataRef = _getItemId($zabbix, $hId,$metricName);
                    if ( ! defined $itemDataRef ) {
                        print("Could not find a metric data for $hName and $metricName combination. Most likely this metric is not present for the host $hName\n");
                        print("Please check in Zabbix for more details\n");
                        next;
                    }
                    my $itemId = $itemDataRef->{'item'}{itemid};
                    my $dataType = $itemDataRef->{'item'}{itemDataType};
                    $hostDetails{$itemId} = { 'hostname' => $hName, 'hostid' => $hId, 'hostGroup' => $hGrpName, 'dataType' => $dataType };
                }
            }
        } else{
            my $hostid = $myresult->{hostid};
            my $hostName= $myresult->{name};
            my $status = $myresult->{'status'};
            if( $status == 0 ){
                my $itemDataRef = _getItemId($zabbix, $hostid,$metricName);
                my $itemId = $itemDataRef->{'item'}{itemid};
                my $dataType = $itemDataRef->{'item'}{itemDataType};
                $hostDetails{$itemId} = { 'hostname' => $hostName, 'hostid' => $hostid, 'hostGroup' => $hGrpName, 'dataType' => $dataType };
            }
        }
    }
    return \%hostDetails;
}

sub _getItemId {
    my ( $zabbix,$hId, $key) = @_;

    my %itemData;
    my $options = {'output' => ['key_','itemid','value_type'], 'hostids' => $hId, "search" => { "key_" => $key }};
    my $myresult = $zabbix->raw('item','get',$options);
    if ( ref($myresult) eq 'ARRAY' ){
        foreach my $res ( @$myresult ) {
            if (lc $res->{'key_'} eq lc $key ) {
                 $itemData{'item'} = { itemid => $res->{'itemid'}, itemDataType => $res->{'value_type'} };
                 return \%itemData;
            }
        }
    }
    else{
        if ( lc $myresult->{'key_'} eq lc $key ) {
            $itemData{'item'} = { itemid => $myresult->{'itemid'}, itemDataType => $myresult->{'value_type'} };
            return \%itemData;
        }
    }
    
    return undef;
}
