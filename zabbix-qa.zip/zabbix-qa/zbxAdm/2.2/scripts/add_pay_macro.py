import requests
import json
import re
import sys
import smtplib
import getpass
import getopt
import datetime
import csv
import subprocess

def gettoken(api):
        user = "ZABBIX_SFSF_API"
        password = <passvault>
        data='{"jsonrpc":"2.0","method":"user.login","params":{"user":"%s","password":"%s"},"id":1,"auth":null}' %(user,password)
        r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
        r=r.json()
        #print r
        if 'result' not in r :
                print('Invalid Credentials')
                exit()
        token = r["result"]
        return token

def get_host_map():
	input_file = 'Payroll_Zabbix_SID.csv'
# Upload file to DC4 SFTP
        ftp_cmd_p = """
#!/bin/sh
sftp toolsandutil@sftp4.successfactors.com <<EOF
get {input_file}
EOF
"""
        subprocess.call(ftp_cmd_p.format(input_file=input_file),shell=True, stdout=sys.stdout, stderr=sys.stderr)
	payroll_file = '/usr/local/etc/zbxAdm/2.2/scripts/Payroll_Zabbix_SID.csv'
	payroll_map = {}
	ZH_Map = {'ZH421':'Prod',
		  'ZH527':'Dev',
		  'ZH526':'Test',
		  'OS002' : 'Stock',
		  'OS003' : 'Stock',
		  'ZH301':'PartnerDemo',
		  'ZH101':'SalesDemo'}	
	with open(payroll_file,'r') as data:
		for line in data.readlines()[1:]:
				split = line.split(',')
				tenantcode = split[2].split('\n')[0]
				payroll_map[split[0].split(".")[0].lower() ]= ZH_Map.get(tenantcode,'None')
#	for k in payroll_map.keys()[:4]:
#		print(k)
#		print(payroll_map[k])	
	return payroll_map
			

def add_macros(payroll_map,env) :
	print("Went in")
        envmatrix = {'emea':'https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php',
                'azure':'https://zabbix-azure.sapsf.com/api_jsonrpc.php',
                'apac':'http://10.10.198.22/api_jsonrpc.php',
                'americas':'http://10.8.196.207/api_jsonrpc.php',
                'americas_primary':'https://zabbix-americas-primary.cld.ondemand.com/api_jsonrpc.php',
                'qa-25':'https://zabbix-qa.cld.ondemand.com/api_jsonrpc.php',
		'dc55':'https://zabbix-dc55.cld.ondemand.com/api_jsonrpc.php',
		'dc60':'https://zabbix-dc60.cld.ondemand.com/api_jsonrpc.php',
		'dc62':'https://zabbix-dc62.cld.ondemand.com/api_jsonrpc.php',
		'dc64':'https://zabbix-dc64.cld.ondemand.com/api_jsonrpc.php',
		'dc66':'https://zabbix-dc66.cld.ondemand.com/api_jsonrpc.php',
		'dc68':'https://zabbix-dc68.cld.ondemand.com/api_jsonrpc.php',
		'dc70':'https://zabbix-dc70.cld.ondemand.com/api_jsonrpc.php',
		'dc57':'https://zabbix-dc57.cld.ondemand.com/api_jsonrpc.php',
		'dc30':'https://zabbix-dc30.cld.ondemand.com/api_jsonrpc.php',
		'dc33':'https://zabbix-dc33.cld.ondemand.com/api_jsonrpc.php'}

        api = envmatrix[env]
        token = gettoken(api)
        res = ''
        #print "went in"
	hostids = []
        data='{"jsonrpc":"2.0","method":"template.get","params":{"selectHosts":["host","key_","name"],"filter": {"host": "T_PAYROLL_Linux"} },"id":2,"auth": "%s"}' %(token)
	r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
        r=r.json()
        if 'result' not in r :
                return 'The template T_PAYROLL_LINUX is invalid'
                exit()
        else :
                if r['result']==[]:
                        return 'The template T_PAYROLL_LINUX is invalid'
                else :
                        hosts = r['result'][0]['hosts']
                        for host in hosts :
                                hostids.append(host['hostid'])
                        data = {"jsonrpc":"2.0","method":"host.get","params":{"hostids":hostids,"selectMacros":"extend"},"id":1, "auth":token }
                        r= requests.post(api, data=json.dumps(data), headers={'Content-Type': 'application/json'})
                        hosts = r.json()['result']
                        for host in hosts :
				name = host['host'].split(".")[0].lower()
                                if name in payroll_map.keys() :
					if payroll_map[name] == 'None' :
						print(name+ " Env is None")
		                	found=0
                                	macros = host['macros']
                                	for macro in macros :
                                        	if str(macro['macro']) == '{$PAYROLL_ENV}' :
							if str(macro['value']) == payroll_map[name] and payroll_map[name]!="None":
								print(name + ' The macro is present and is correct')
								found = 1
							else :
								print(name + ' The macro is present, but is wrong ******')
								print(payroll_map[name])
								if payroll_map[name]!='None' :
									print('Changing the macro')
									data = {"jsonrpc":"2.0","method":"usermacro.delete","params":[macro['hostmacroid']],"id":1, "auth":token}
                                                			r = requests.post(api, data=json.dumps(data), headers={'Content-Type': 'application/json'})
								
                                	if found==0 and payroll_map[name]!="None":
                                        	print(name +  ' Adding macro' )
						print(payroll_map[name])
                                        #res = res+"\n Adding macro " + value_mapping[dc]
                                        	data={"jsonrpc":"2.0","method":"usermacro.create","params":{"hostid":host['hostid'],"macro":"{$PAYROLL_ENV}","value":payroll_map[name]},"id":1, "auth":token }
                                        	r= requests.post(api, data=json.dumps(data), headers={'Content-Type': 'application/json'})
                                       # print r.json()
                                        	res = res+" \n" + str(r.json())
				else :
					print(name+ " is  not present")
#        return res
	#print res
	f=open("/usr/local/etc/zbxAdm/2.2/scripts/pay_macro_result.txt",'w')
	f.write(res)
	f.close()



def main():
	argv=sys.argv[1:]
	opts,args=getopt.getopt(argv,"e:",["env="])
	opts=dict(opts)
	env = opts['--env']

	payroll_map = get_host_map()
	add_macros(payroll_map,env)
	
if __name__ == "__main__":
        main()

