#!/bin/bash


# Script to generate aging alerts for Platform services Team
# Author : Sandeep M.R
# Date : 5/25/2015

email="s.renuka@sap.com,patrick.presto@sap.com,amit.kumar15@sap.com,rinkesh.singh@sap.com,sajeesh.mohanan@sap.com,fiyas.ahamed@sap.com"

cd /usr/local/etc/zbxAdm/2.2/scripts

/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'All-SFTP' > /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'All-AD' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'All-MAIL-IRONPORT' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc2mgt_MAIL_SENDMAIL' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc4mgt_MAIL_SENDMAIL' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc8mgt_MAIL_SENDMAIL' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc12mgt_MAIL_SENDMAIL' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pf8mgt_MAIL_SENDMAIL' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'All-SPLUNK-INDEXERS' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc2mgt_SPLUNK_DEP' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc2mgt_SPLUNK_JOB' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc2mgt_SPLUNK_LOG' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc2mgt_SPLUNK_SRCH' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc4mgt_SPLUNK_DEP' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc4mgt_SPLUNK_JOB' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc4mgt_SPLUNK_LOG' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc4mgt_SPLUNK_SRCH' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc8mgt_SPLUNK_DEP' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc8mgt_SPLUNK_JOB' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc8mgt_SPLUNK_LOG' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc8mgt_SPLUNK_SRCH' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc10mgt_SPLUNK_DEP' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc10mgt_SPLUNK_JOB' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc10mgt_SPLUNK_LOG' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc10mgt_SPLUNK_SRCH' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc12mgt_SPLUNK_DEP' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc12mgt_SPLUNK_JOB' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc12mgt_SPLUNK_LOG' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc12mgt_SPLUNK_SRCH' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc16mgt_SPLUNK_DEP' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc16mgt_SPLUNK_JOB' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc16mgt_SPLUNK_LOG' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pc16mgt_SPLUNK_SRCH' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pf8mgt_SPLUNK_JOB' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'pf8mgt_SPLUNK_SRCH' >> /var/log/zabbix/plt-aging.txt
/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging '' >> /var/log/zabbix/plt-aging.txt

c=`wc -l /var/log/zabbix/plt-aging.txt | awk '{print $1}'`
cat  /var/log/zabbix/plt-aging.txt | mailx -r "ZBX-PLT@sap.com" -s "Plaftom Services Aging Alerts Report - $c aging alerts" $email 
