##################################################################
# Author        : Sreekanth K P
# Purpose       : Wrapper script for creating alert log
# Version       : 20/12/2016 - Initial code 1
#
####################################################################

#!/bin/bash

#Main group list
HG="pc2 ps2 pc2mgt sc2 sc2mgt pc4 ps4 pd4 pc4mgt sc4 sc4mgt pc8 ps8 pf8 pc8mgt sc8 sc8mgt pc10 ps10 pc10mgt sc10 sc10mgt pc12 ps12 pc12Bosch pc12Siemens pc12SiemensExternal pc12SiemensInternal sc12 sc12mgt pc15 pc15mgt sc15 sc15mgt pc16 pc16mgt ps16 sc16 sc16mgt pc17 pc17mgt ps17 ps17mgt sc17 sc17mgt pc18 pc18mgt ps18 ps18mgt sc18 sc18mgt pc19 pc19mgt ps19 ps19mgt sc19 sc19mgt"
>/var/log/zabbix/zabbix_event.log
to=`date +%s`
from=`expr $to - 28800`
for i in $HG
do
#perl /usr/local/etc/zbxAdm/2.2/scripts/getEvents.pl -hostGroup $i -time_from $from -time_till $to |awk -F"|" '{print $6","$1","$2","$3","$4","$5}' |grep -v "Alert Generated Time,Host Name, Host Groups , Alert Name, Current Status, Priority"  >> /var/log/zabbix/zabbix_event.log
perl /usr/local/etc/zbxAdm/2.2/scripts/getEvents.pl -hostGroup $i -time_from $from -time_till $to |awk -F"|" '{print $6"|"$1"|"$2"|"$3"|"$4"|"$5}' |grep -v "Alert Generated Time|Host Name| Host Groups | Alert Name| Current Status| Priority"  >> /var/log/zabbix/zabbix_event.log
done

