#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

my @hostid;
my $os_template;
my $slr_host;
my $slr_hostgrp;
my $slr_template;
# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);

# Detect running env and set the connection variables

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

my %args;


GetOptions(\%args,
                        "Product=s",
                        "Environment=s",
                        "Trigger=s",
                        "dc=s"
           );

if( ! scalar keys %args ) {
    usage();
}

# Load API properites file
if ( exists $args{dc} && $args{dc} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{dc} && uc $args{dc} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}
my $config = get_rsm_config($configFile);


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

my %DCToHostGroup = ( 
                      'BIZX' =>  {
                                'DC2' => [ "sc2_bizx","ps2_bizx","pc2_bizx" ], 
                                'DC4' => [ "sc4_bizx","ps4_bizx","pc4_bizx" ],
                                'DC8' => [ "sc8_bizx","ps8_bizx","pc8_bizx" ],
                                'DC10' => [ "sc10_bizx","pc10_bizx" ],
                                'DC12' => [ "sc12_bizx","pc12_bizx" ],
                                'DC15' => [ "pc15_bizx" ],
                                'DC16' => [ "pc16_bizx" ],
                                'DC17' => [ "sc17_bizx","pc17_bizx" ],
                                'DC18' => [ "sc18_bizx","pc18_bizx" ],
                       },
                       'LMS' => {
                                'DC2' => [ "sc2_LMS","ps2_LMS","pc2_LMS" ], 
                                'DC4' => [ "sc4_LMS","ps4_LMS","pc4_LMS" ],
                                'DC8' => [ "sc8_LMS","ps8_LMS","pc8_LMS" ],
                                'DC10' => [ "sc10_LMS","pc10_LMS" ],
                                'DC12' => [ "sc12_LMS","pc12_LMS" ],
                                'DC15' => [ "sc15_LMS","pc15_LMS" ],
                                'DC16' => [ "sc16_LMS","ps16_LMS","pc16_LMS" ],
                                'DC17' => [ "sc17_LMS","ps17_LMS","pc17_LMS" ],
                                'DC18' => [ "sc18_LMS","ps18_LMS","pc18_LMS" ],
                       }
                    );




sub usage {
    print "$0
    -Product < BIZX|LMS >                               - Product Name like Bizx or LMS
    -Environment < DCn >                                - Optional Datacentre environment. For example DC2
    -Trigger < Trigger Name >                           - Optional trigger name to disable
    -dc < datacenter >                                  - Optional argument DC if running from different datacenter

    Example: $0 -Product BIZX -Environment DC4 
               OR
             $0 -Product BIZX -Environment DC4 -Trigger '{HOST.HOST} /local Space Low (Total={ITEM.VALUE1}, %Used={ITEM.VALUE3}, Avail={ITEM.VALUE4})'
    \n";

    exit 1;
}

open my $FH, ">", "/tmp/triggerToDisable.txt" or die "Cant open file to write:$! \n";
print $FH "Host Name ,\t\t Trigger ID, \tTrigger Name \n";
my %triggersToDisable = ( 
                           'BIZX' => [ 
                                       '{HOST.HOST} /local Space Low (Total={ITEM.VALUE1}, %Used={ITEM.VALUE2})',
                                       '{HOST.HOST} /local Space Low (Total={ITEM.VALUE1}, %Used={ITEM.VALUE2}, avail={ITEM.VALUE3})',
                                       '{HOST.HOST} /local Space Low (Total={ITEM.VALUE1}, %Used={ITEM.VALUE3}, Avail={ITEM.VALUE4})'
                                     ],
                           'LMS' =>  [ 
                                       '{HOST.HOST} /usr/local Space Low (Total={ITEM.VALUE1}, %Used={ITEM.VALUE2})',
                                       '{HOST.HOST} /usr/local Space Low (Total={ITEM.VALUE1}, %Used={ITEM.VALUE2}, avail={ITEM.VALUE3})',
                                       '{HOST.HOST} /usr/local Space Low (Total={ITEM.VALUE1}, %Used={ITEM.VALUE3}, Avail={ITEM.VALUE4})'
                                     ]
                        );

my $product = $args{Product};
my $dcName = $args{Environment};

my @triggersToDisable;
if( $args{Trigger} ) {
    @triggersToDisable = $args{Trigger};
}
else{
    @triggersToDisable = @{$triggersToDisable{$product}};
}


my @allDCs;
if( ! $dcName ) {
    @allDCs = keys %{$DCToHostGroup{uc $product}};
}
else{
    @allDCs = ( $dcName );
}
foreach my $dcToUse ( @allDCs ) {
    my @hostGroups = @{$DCToHostGroup{uc $product}{uc $dcToUse} };

    disableTriggers($zabbix, \@hostGroups);
}

sub disableTriggers {
    my ( $zabbix, $hostGrpRef ) = @_;
    
    foreach my $hostGroup ( @{$hostGrpRef} ) {
        my %filter = ( 'output' => 'extend' , 'filter' => { 'name' => [ $hostGroup ] }, 'selectHosts' => ['hostid', 'name'] );

        my $api_result = $zabbix->raw('hostgroup', 'get', \%filter);

        foreach my $triggerName ( @triggersToDisable ) {
            foreach my $record ( @{$api_result->{hosts}} ) {
                print "$record->{hostid} => $record->{name} \n";
                my $hostId = $record->{hostid};
                my $hostName = $record->{name};
                get_triggers($zabbix, $hostId, $hostName, $triggerName);
            }
        }
    }
}

sub get_triggers {
    my ( $zabbix, $inp_hostid, $inp_hostname, $inp_description ) = @_;
  
    my %output = ('output' => [ 'triggerid', 'description', 'priority' ], 'hostids' => [ $inp_hostid ], 'search' => { 'description' => $inp_description }  );
    my $params;
    $params = {%output};
    my $api_result = $zabbix->raw('trigger','get', $params);
    if( ! defined $api_result || ref $api_result ne 'ARRAY' ) {
        print "No trigger found for host $inp_hostname\n";
        return;
    }

    foreach my $res ( @$api_result ) {
        my $triggerid = $res->{triggerid};
        my $priority = $res->{priority};
        %output = ( 'output' => [ 'triggerid','description','status' ], 'triggerids' => $triggerid , 'filter' => { 'status' => 0 } );
        $api_result = $zabbix->raw('trigger','get', \%output);

        ##disable trigger only when it is enabled ( status = 0 )
        if( defined $api_result && exists $api_result->{status} && $triggerid == $api_result->{triggerid} && $api_result->{status} == 0 ) {
            %output = ( 'triggerid' => $triggerid , 'status' => 1 );
            $api_result = $zabbix->raw('trigger','update', \%output);
            #print Dumper $api_result;
            print "Trigger id $triggerid => $inp_description will be disabled for host $inp_hostname ($inp_hostid) \n";
            print $FH "$inp_hostname,\t\t $triggerid, \t$inp_description \n";
        }
  
    }

}

my $email = 'pradip.kumar.k@sap.com,s.renuka@sap.com';
my $mailCmd = qq~ cat  "/tmp/triggerToDisable.txt" | mailx -r "monitoring\@sap.com" -s "Filesystem trigger disable Report" $email ~;
system($mailCmd);
