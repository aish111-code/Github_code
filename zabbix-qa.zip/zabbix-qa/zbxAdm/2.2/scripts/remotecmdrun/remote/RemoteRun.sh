#######
##################################################################
# Author        : Sreekanth K P
# Purpose       : Wrapper script for updating Zabbix
# Reviewer      : Sandeep M.R
# Version       : 22/02/2016 - Initial code, 21/12/2016 - Latest version
#
####################################################################


#!/bin/bash
#LOGFILE=Log-`date +%s`.txt
>Log_Valid.txt
remoteconn() {
IFS=$'\n'
for i in `cat $1`
do
echo "****" > Log_Valid.txt
echo "-----------------------"
echo  "$i "
#echo -n "Running on $i .."
Server=`echo $i|awk '{print $1}'`
IP=`echo $i|awk '{print $1}'`
SHORTNAME=`echo $Server|awk -F"." '{print $1}'`
#echo -n " -- $Server ($IP) -- "
expect scp_valid.exp $IP $user $password  $2 2> /dev/null

expect remoterun.exp $IP $user $password "sh /tmp/$2 > /tmp/Log_Valid.txt 2>&1"

expect scpdownload.exp $IP $user $password Log_Valid.txt 2> /dev/null
cat Log_Valid.txt
done
echo "-----------------------"
}


#Enter user
#echo -n "User:"
read -p "User: " user
#Enter Password
echo -n "Password:"
read -s password

#Enter serverlist file
printf "\n"
echo -n "Location of serverlist file:"
read ServerLFile

if [ ! -f $ServerLFile ]
then
        echo "ServerLFile does not exist. Please exist a valid file"
        exit
fi
echo "Please select one option from below... "
echo "Remote command            : 1"
echo "Multiple commands/script  : 2"

read "option"



case $option in

        1) echo -n "Enter the command : "
           read command
           for IP in `cat $ServerLFile`
           do
                   expect remoterun.exp $IP $user $password "$command"
           done
                ;;
        2) echo -n "Enter the command file location  : "
           read script
           cp $script temp_script.sh
           remoteconn $ServerLFile temp_script.sh  ;;
        *) echo "Please enter some option from the above list"
esac

