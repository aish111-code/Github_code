##################################################################
# Author        : Sreekanth K P
# Purpose       : Wrapper script for updating Zabbix
# Reviewer      : Sandeep M.R
# Version       : 22/02/2016 - Initial code, 21/12/2016 - Latest version
#
####################################################################


#!/bin/bash
echo "killing splunk.."
killall -9 splunkd
echo "current running splunk process `ps -ef|grep -v grep|grep splunkd|wc -l`"
echo "restarting splunk...."
/etc/init.d/splunk restart

