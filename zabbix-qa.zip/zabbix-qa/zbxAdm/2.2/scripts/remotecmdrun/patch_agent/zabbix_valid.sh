#hostname --alsoforroot > /tmp/Log_Valid.txt
#echo "Installed zabbix version: `zypper se -s zabbix-agent |grep \"^i\"|awk -F\"|\" '{print $4}'|sort|uniq`" > /tmp/Log_Valid.txt
#zypper se -s zabbix-agent |grep "2.4.6-20.1" >> /tmp/Log_Valid.txt
#ps -ef|grep zabbix|wc -l >> /tmp/Log_Valid.txt
#/etc/init.d/puppet stop >> /tmp/Log_Valid.txt
#zypper -n rm zabbix-agent >> /tmp/Log_Valid.txt
#zypper -n in --repo SLES11-SP1-CUSTOM-SF zabbix-agent >> /tmp/Log_Valid.txt
#echo "Number of running zabbix processes = `ps -ef|grep zabbix|grep -v "grep"|wc -l`" >> /tmp/Log_Valid.txt
#echo "Hostname updated in zabbix agent conf file: `grep Hostname /etc/zabbix/zabbix_agentd.conf|grep -v \"#\"|grep -v \"^$\"|awk -F\"=\" '{print $2}'`" >> /tmp/Log_Valid.txt
#grep dc12puppetstage.rot.od.sap.biz /etc/puppet/puppet.conf > /tmp/Log_Valid.txt
which nfsiostat > /tmp/Log_Valid.txt 2>&1
ls -l /usr/sbin/nfsiostat >> /tmp/Log_Valid.txt 2>&1
rpm -qa|grep nfs-client >> /tmp/Log_Valid.txt
