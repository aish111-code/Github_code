#!/usr/bin/perl

##################################################################
# Author        : Vikky Omkar
# Purpose       : command execution on remote host
# Reviewer      : Sandeep M.R
# Version       : July 21 2015 - Initial code
#
####################################################################

#user inputs
print "User Name:";
chomp($user=<STDIN>);
print "Password:";
system('stty','-echo');
chomp($password=<STDIN>);
system('stty','echo');
print "\nServer File:";
chomp($serverlist=<STDIN>);
print "Command to execute:";
chomp($command=<STDIN>);

my $date = `date`;
chomp($date);


#open logfile
open W1,">/var/log/zabbix/zabbixcmdexecution.txt"  or die "cant open file to log\n";

#open serverlist file to read server names
open F,"$serverlist" or die "cant open file\n";
        while(<F>){
                chomp $_;
                @temp=split(/\t+|\s+/,$_);
                $server=$temp[0];
                @out='';

                @out=`expect remoteCommand.exp $server $user $password $command`;
#print "@out\n";
                   if ($? != 0)
                        {
                                print "$date: Unbale to SSH $server for execution of the command\n\n================================================================================================================\n\n";
                                print W1 "$date:\n Unbale to SSH $server for execution of the command\n\n================================================================================================================\n\n";
                        }
                    else {
                                @out1 = splice @out,0,-6;
                                print W1 "$date:\n @out1\n================================================================================================================\n\n";
                                print "$date:\n @out1\n================================================================================================================\n\n";
                     }
                 }
#close the file handlers
close F;
close W;

#print logfile location
print "\n\nLogfile Location : /var/log/zabbix/zabbixcmdexecution.txt\n";
