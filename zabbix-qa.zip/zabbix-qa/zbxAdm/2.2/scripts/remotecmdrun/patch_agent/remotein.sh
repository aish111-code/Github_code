hostname --alsoforroot > /tmp/Log_Valid.txt
zypper -n rm zabbix-agent >> /tmp/Log_Valid.txt
zypper -n in --repo SLES11-SP1-CUSTOM-SF zabbix-agent >> /tmp/Log_Valid.txt
echo "Number of running zabbix processes = `ps -ef|grep zabbix|grep -v "grep"|wc -l`" >> /tmp/Log_Valid.txt
echo "Hostname updated in zabbix agent conf file: `grep Hostname /etc/zabbix/zabbix_agentd.conf|grep -v \"#\"|grep -v \"^$\"|awk -F\"=\" '{print $2}'`" >> /tmp/Log_Valid.txt
