##
##################################################################
# Author        : Sreekanth K P
# Purpose       : Wrapper script for updating Zabbix
# Reviewer      : Sandeep M.R
# Version       : 22/02/2016 - Initial code
#
####################################################################


#!/bin/bash
LOGFILE=Log-`date +%s`.txt
#Enter user
#echo -n "User:"
read -p "User: " user
#Enter Password
echo -n "Password:" 
read -s password

#Enter serverlist file
printf "\n"
echo -n "Server File:"
read ServerLFile

if [ ! -f $ServerLFile ]
then
	echo "ServerLFile does not exist. Please exist a valid file"
	exit
fi
IFS=$'\n'
for i in `cat $ServerLFile`
do
echo "****" > Log_Valid.txt
echo "-----------------------"
echo  "$i "
#echo -n "Running on $i .."
Server=`echo $i|awk '{print $1}'`
IP=`echo $i|awk '{print $1}'`
SHORTNAME=`echo $Server|awk -F"." '{print $1}'`
#echo -n " -- $Server ($IP) -- "  
expect scp_valid.exp $IP $user $password zabbix_valid.sh 2> /dev/null

expect remoterun.exp $IP $user $password "sh /tmp/zabbix_valid.sh" > /dev/null 2>&1

expect scpdownload.exp $IP $user $password Log_Valid.txt 2> /dev/null
cat Log_Valid.txt
done 
echo "-----------------------"
