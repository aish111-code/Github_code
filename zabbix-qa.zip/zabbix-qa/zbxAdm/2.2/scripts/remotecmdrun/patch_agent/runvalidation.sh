echo "server hostname: `hostname --alsoforroot`" > /tmp/Log_Valid.txt
IV=`rpm -qa|grep zabbix-agent`
if [[ $IV =~ ^"zabbix-agent-" ]]
then
echo "Installed zabbix version: $IV"  >> /tmp/Log_Valid.txt
else
echo "Cannot recognize any zabbix installation." >> /tmp/Log_Valid.txt
echo $IV >> /tmp/Log_Valid.txt
fi


Latest=`zypper se -s zabbix-agent|grep "zabbix-agent "|grep ^v|sort -k 7|tail -1|awk  '{print $7"("$11 ")" }'`
#if [[ $LV =~ ^"2." ]]
#then
#echo "Latest Available version: $LV" >> /tmp/Log_Valid.txt
#else
#echo "There is some problem fetching latest version details" >> /tmp/Log_Valid.txt
#echo $IV >> /tmp/Log_Valid.txt
#fi
IV=`echo "$IV" |sed 's/zabbix-agent-//g'`
LV=`echo "$LV"|awk -F"(" '{print $1}' `
if [ $LV > $IV ]
then
echo "Latest version $Latest is available" >> /tmp/Log_Valid.txt
else
echo "No Latest version available" >> /tmp/Log_Valid.txt
fi


#zypper se -s zabbix-agent |grep "2.4.6-20.1" >> /tmp/Log_Valid.txt
#ps -ef|grep zabbix|wc -l >> /tmp/Log_Valid.txt
#/etc/init.d/puppet stop >> /tmp/Log_Valid.txt
#zypper -n rm zabbix-agent >> /tmp/Log_Valid.txt
#zypper -n in --repo SLES11-SP1-CUSTOM-SF zabbix-agent >> /tmp/Log_Valid.txt
echo "Number of running zabbix processes = `ps -ef|grep zabbix|grep -v "grep"|wc -l`" >> /tmp/Log_Valid.txt
echo "Hostname updated in zabbix agent conf file: `grep Hostname /etc/zabbix/zabbix_agentd.conf|grep -v \"#\"|grep -v \"^$\"|awk -F\"=\" '{print $2}'`" >> /tmp/Log_Valid.txt
#grep dc12puppetstage.rot.od.sap.biz /etc/puppet/puppet.conf > /tmp/Log_Valid.txt
