##################################################################
# Author        : Sreekanth K P
# Purpose       : script to update zabbix agent
# Reviewer      : Sandeep M.R
# Version       : 22/02/2016 - Initial code
#
####################################################################
#!/bin/bash
#current OS version

VERSION=`cat /etc/SuSE-release |grep VERSION|awk  '{print $3}'`
#current patch level
PLEVEL=`cat /etc/SuSE-release |grep LEVEL|awk '{print $3}'`
#Host=`/usr/bin/hostname --alsoforroot`
#if [ $? == 0 ]
#then
#       if [ "$Host" == "" ]
#       then
#               Host=`hostname`
#       fi
#else
hostname > /tmp/Log_Valid.txt
#fi


#updating repo function
checkrepo () {
        out=`zypper lr -u|grep $1|grep Yes`
        if [ "$out" = "" ]
        then
                echo "No repo configured" >> /tmp/Log_Valid.txt
                zypper ar $1 $2 >> /tmp/Log_Valid.txt
                zypper mr -e $2 >> /tmp/Log_Valid.txt
                zypper mr -r $2 >> /tmp/Log_Valid.txt
                zypper --gpg-auto-import-keys -n  refresh >> /tmp/Log_Valid.txt
        else
                echo "Repo $1 has configured" >> /tmp/Log_Valid.txt
                zypper mr -e $2 >> /tmp/Log_Valid.txt
                zypper mr -r $2 >> /tmp/Log_Valid.txt
        fi
}

checkrepo http://yum.`dnsdomainname`/hcm/platform/yum/SLES/$VERSION.$PLEVEL SLES$VERSION-SP$PLEVEL-new

