
##################################################################
# Author        : Sreekanth K P
# Purpose       : Wrapper script for updating Zabbix
# Reviewer      : Sandeep M.R
# Version       : 22/02/2016 - Initial code
#
####################################################################


#!/bin/bash
#LOGFILE=Log-`date +%s`.txt

remoteconn() {
IFS=$'\n'
for i in `cat $1`
do
echo "****" > Log_Valid.txt
echo "-----------------------"
echo  "$i "
#echo -n "Running on $i .."
Server=`echo $i|awk '{print $1}'`
IP=`echo $i|awk '{print $1}'`
SHORTNAME=`echo $Server|awk -F"." '{print $1}'`
#echo -n " -- $Server ($IP) -- "  
expect scp_valid.exp $IP $user $password  $2 

expect remoterun.exp $IP $user $password "sh /tmp/$2" 

expect scpdownload.exp $IP $user $password Log_Valid.txt 
cat Log_Valid.txt
done 
echo "-----------------------"
}


#Enter user
#echo -n "User:"
read -p "User: " user
#Enter Password
echo -n "Password:" 
read -s password

#Enter serverlist file
printf "\n"
echo -n "Server File:"
read ServerLFile

if [ ! -f $ServerLFile ]
then
	echo "ServerLFile does not exist. Please exist a valid file"
	exit
fi
echo "Please select one option from below"
echo "Validation	: 1"
echo "Update repo 	: 2"
echo "Updt zbx agt	: 3"
echo "Update FQDN:	: 4"
echo "Which option you want to execute? "
read "option"



case $option in 
	
	1) remoteconn $ServerLFile runvalidation.sh ;;
	2) remoteconn $ServerLFile updaterepo.sh ;;
	3) remoteconn $ServerLFile remotein.sh ;;
	4) IFS=$'\n'
for i in `cat $1`
do
echo "****" > Log_Valid.txt
echo "-----------------------"
echo "$i"
Server=`echo $i|awk '{print $1}'`
SHORTNAME=`echo $Server|awk -F"." '{print $1}'`

perl /usr/local/etc/zbxAdm/2.2/scripts/remoteCommand_fixAgent.pl -UpdateFqdnName $SHORTNAME 
if [ $? == 0 ]
        then
                echo "Success" >> $LOGFILE
        else
                echo "Fail" >> $LOGFILE
fi
echo "-----------------------"
done
;;
	*) echo "Please enter some option from the above list"
esac
 
