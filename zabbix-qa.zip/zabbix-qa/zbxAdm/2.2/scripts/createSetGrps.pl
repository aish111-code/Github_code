#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration


use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

my %args;

GetOptions(\%args,"hostName=s","hostGroup=s","product=s", "DEBUG=s", "dc_override=s" );
if( ! scalar keys %args ) {
    print "Missing options -
                -hostName <Host name>
                        OR
                -hostGroup <Host Group>
                -product <LMS|BIZX|All> [ optional parameter - default all products ]
                -debug 1 [ To display debug information ]
                -dc_override DC23 [ Provide this only when running from different datacenter ]\n";
    print "Example: $0 -hostName pc2bseb03.ams2.sf.priv
                        OR
                    $0 -hostGroup pc2_BIZX_A -product LMS
                        OR
                    $0 -hostGroup All -product All -debug 1
                        OR
                    $0 -hostGroup All -product All -debug 1 dc_override DC23 \n";
    exit -1;
}

if ( exists $args{dc_override}  && uc $args{dc_override} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{dc_override} && uc $args{dc_override} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}

my $config = get_rsm_config($configFile);


my $DEBUG = 0;

# Load API properites file


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

# Decrypting Password
my $private_key_file = "/etc/zabbix/custom/zabbix_private_key.pem";

# Specify the path to the encrypted data file
my $encrypted_data_file = "/etc/zabbix/custom/zabbix_autoregister_password_enc.dat";

# Run the OpenSSL command to decrypt the data
#my $openssl_command = "openssl rsautl -decrypt -inkey $private_key_file -in $encrypted_data_file";
#my $decrypted_password = `$openssl_command`;

# Remove trailing newline characters
#chomp($decrypted_password);
my $output_file = "/tmp/decrypted_password.txt";
my $openssl_command = "openssl pkeyutl -decrypt -inkey $private_key_file -in $encrypted_data_file -out $output_file";
system($openssl_command) == 0 or die "Failed to run openssl pkeyutl";

open(my $pfh, "<", $output_file) or die "Cannot open decrypted password file";
my $decrypted_password = <$pfh>;
close($pfh);
chomp($decrypted_password);
unlink($output_file);


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

#my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});
my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $decrypted_password});


#my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

my @masterGrpToUseForSplitLMS = qw( pc2_LMS_A sc2_LMS_A ps2_LMS_A pd2_LMS_A
                                 pc4_LMS_A sc4_LMS_A ps4_LMS_A pd4_LMS_A
                                 pc8_LMS_A sc8_LMS_A ps8_LMS_A pd8_LMS_A
                                 pc10_LMS_A sc10_LMS_A ps10_LMS_A pd10_LMS_A
                                 pc12_LMS_A sc12_LMS_A ps12_LMS_A pd12_LMS_A
                                 pc15_LMS_A sc15_LMS_A ps15_LMS_A pd15_LMS_A
                                 pc16_LMS_A sc16_LMS_A ps16_LMS_A pd16_LMS_A
                                 pc17_LMS_A sc17_LMS_A ps17_LMS_A pd17_LMS_A
                                 pc18_LMS_A sc18_LMS_A ps18_LMS_A pd18_LMS_A
                                 pc19_LMS_A sc19_LMS_A ps19_LMS_A pd19_LMS_A
                                 );
my @masterGrpToUseForSplitBIZX = qw(
                                 pc2_BIZX_A sc2_BIZX_A ps2_BIZX_A 
                                 pc4_BIZX_A sc4_BIZX_A ps4_BIZX_A 
                                 pc8_BIZX_A sc8_BIZX_A ps8_BIZX_A 
                                 pc10_BIZX_A sc10_BIZX_A ps10_BIZX_A 
                                 pc12_BIZX_A sc12_BIZX_A ps12_BIZX_A 
                                 pc15_BIZX_A sc15_BIZX_A ps15_BIZX_A 
                                 pc16_BIZX_A sc16_BIZX_A ps16_BIZX_A 
                                 pc17_BIZX_A sc17_BIZX_A ps17_BIZX_A 
                                 pc18_BIZX_A sc18_BIZX_A ps18_BIZX_A 
                                 pc19_BIZX_A sc19_BIZX_A ps19_BIZX_A 
                               );
                                 

$DEBUG = 1 if ( exists $args{debug} && $args{debug} == 1 );
my $inp_grpName = $args{hostGroup};
my $inp_hostName = $args{hostName};
my $productToUse;
my @masterGrpToUseForSplit;
if( exists $args{product} ) {
    $productToUse = $args{product};
print "productToUse = $productToUse \n";
    if( $productToUse eq 'LMS' ) {
        @masterGrpToUseForSplit = @masterGrpToUseForSplitLMS;
    }
    elsif( $productToUse eq 'BIZX' ) {
        @masterGrpToUseForSplit = @masterGrpToUseForSplitBIZX;
    }
    else{
        @masterGrpToUseForSplit = ( @masterGrpToUseForSplitLMS, @masterGrpToUseForSplitBIZX );
    }
}
else{
    $productToUse = 'All';
    @masterGrpToUseForSplit = ( @masterGrpToUseForSplitLMS, @masterGrpToUseForSplitBIZX );
}

#print Dumper \@masterGrpToUseForSplit;
if( $inp_hostName ) {

     my $hostName = $inp_hostName;
     my $hostId = _getHostIdByName($zabbix, $hostName);

     my @existingGrpNamesOfHost;
     my $groupDetailsARef = _getExistingGroupsOfTheHost($zabbix, $inp_hostName);
     if( ! defined $groupDetailsARef ) {
         print "This host $inp_hostName can not be added to setA/B group.\n";
         exit 1;
     }
     else{
         foreach my $keyData ( @$groupDetailsARef ) {
             push @existingGrpNamesOfHost, $keyData->{name};
         }
     }

     ##reverse lookup for finding host group like pc2_LMS_A
     ##if we get such group , we will create pc2_LMS_A_setA or setB groups, if not already exists
     my $grpExistsInMaster = 0;
     foreach my $grpname ( @existingGrpNamesOfHost ) {
         if( grep { /^$grpname$/i } @masterGrpToUseForSplit ) {
              createNewGroups($zabbix,$grpname, { $hostId => $hostName } );
              $grpExistsInMaster = 1;
         }
     }
     if( ! $grpExistsInMaster ) {
         if( $DEBUG ) {
             print "None of the host Groups is in master list. Can not proceed further \n";
             print "Existing Groups = ", Dumper \@existingGrpNamesOfHost;
             print "Master list contains = ", Dumper \@masterGrpToUseForSplit;
         }
         exit 1;
     }
}
elsif ( $inp_grpName eq 'All' ) {

    my $options = {'output' => ['name','groupid']};
    my $myresult = $zabbix->raw('hostgroup','get',$options);
    foreach my $grpData ( @$myresult ) {
    
        my $grpname = $grpData->{name};
        my $grpid = $grpData->{groupid};

        if( grep { /^$grpname$/i } @masterGrpToUseForSplit ) {
            createNewGroups($zabbix,$grpname);
            #print "group $grpname is matched to create new grp \n";
        }
    }
}
else { 
    if( grep { /^$inp_grpName$/i } @masterGrpToUseForSplit ) {
        createNewGroups($zabbix,$inp_grpName);
    }
    else{
        print "This group $inp_grpName can not be splitted. Please check the master list \n";
        print Dumper \@masterGrpToUseForSplit;
        print "\n";
        exit;
    }
}

sub _getHostsByGroup {
    my ($zabbix,$hGrpName) = @_;

    return {} if ( ! $zabbix || ! $hGrpName );
    my %hostDetails;

    my $options = {'output' => 'extend','filter' => {'name' => $hGrpName }};
    my $myresult = $zabbix->raw('hostgroup','get',$options);

    my $hostGrpId = $myresult->{groupid};

    $options = {'output' => 'extend', 'groupids' => $hostGrpId };
    $myresult = $zabbix->raw('host','get',$options);
    if ( ref($myresult) eq 'ARRAY' ){
        foreach my $h (@{$myresult}){
            my $hId = $h->{hostid};
            my $hostName = $h->{'name'};
            $hostDetails{$hId} = $hostName if( defined $hId && defined $hostName );
        }
    } else{
        $hostDetails{$myresult->{hostid}} = $myresult->{'name'} if( defined $myresult->{hostid} && defined $myresult->{'name'} );
    }
    return \%hostDetails;
}

sub createNewGroups {
    my ( $zabbix, $grpname, $hostDetails ) = @_;

    if( grep { /^$grpname$/i } @masterGrpToUseForSplit ) {
        my $newNameA = "${grpname}_setA";
        my $newNameB = "${grpname}_setB";
        my $newGrpIdA = _createIfNotExists($zabbix,$newNameA);
        my $newGrpIdB = _createIfNotExists($zabbix,$newNameB);

        print "For Grp name $grpname new groups $newNameA and $newNameB will be created, if not exists \n";
        ##For hostnames the hostDetails hash will be passed with details
        if( ! scalar keys %$hostDetails ) {
            $hostDetails = _getHostsByGroup($zabbix,$grpname);
        }
        
        foreach my $hostId ( keys %$hostDetails ) {
            my $hostName = $hostDetails->{$hostId};
            if ( $grpname =~ /LMS/ ) {
                ##Check for app host of type u,b,r,c for LMS only
                if( ! _isHostAnAppHost($hostName) ) {
                     print "Host $hostName is not an App host of type u,b,r,c. Not doing anything.\n";
                     next;
                }
                else{
                     print "Host $hostName is an App host, will process with this. \n" if ( $DEBUG );
                     #next;
                }
            }

            my $hostInitial = (split /\./, $hostName)[0];

            my $lastNum;
            my %existingGrpsOfHost;
            if ( $hostInitial =~ /^\w+(\d)[a-zA-Z]*$/ ) {
                $lastNum = $1;
                print "Running for $hostName and hostinitial $hostInitial \n" if ( $DEBUG );
                my @existingGrpIdsOfHost;
                my $groupDetailsARef = _getExistingGroupsOfTheHost($zabbix, $hostName);
                if( ! defined $groupDetailsARef ) {
                    print "This host $hostName can not be added to setA/B group.\n";
                    next;
                }
                else{
                    foreach my $keyData ( @$groupDetailsARef ) {
                        push @existingGrpIdsOfHost, $keyData->{id};
                        $existingGrpsOfHost{$keyData->{id}} = 1;
                    }
                }

                my $newGrpId;
                my $newGrpName;
                if( $lastNum % 2 ) {
                     #print "$hostName  will be pushed to setA\n";
                     $newGrpId = $newGrpIdA;
                     $newGrpName = $newNameA;
                } 
                else{
                     #print "$hostName  will be pushed to setB\n";
                     $newGrpId = $newGrpIdB;
                     $newGrpName = $newNameB;
                } 

                if( exists $existingGrpsOfHost{$newGrpId} ) {
                    print "Grp $newGrpName already exists on host $hostName. No action will be performed\n";
                    next;
                }
                else{
                    if ( hostMassAdd($zabbix,$hostId, $newGrpId) ) {
                         print "Hostgroup $newGrpName successfully added to host $hostName \n" if ( $DEBUG );
                    }
                    else{
                         print "Failed to add Hostgroup $newGrpName to host $hostName \n" if ( $DEBUG );
                         next;
                    }
                }
            }
            else{
                print "$hostName is not in proper format to identify odd or even \n" if ( $DEBUG );
                next;
            }
        }
    }
}


sub _grpAlreadyExists {
   my ( $zabbix, $grpName ) = @_;

    my $options = {'output' => ['groupid'],'filter' => {'name' => $grpName }};
    my $myresult = $zabbix->raw('hostgroup','get',$options);
    if( ref($myresult) eq 'HASH' && exists $myresult->{groupid} ) {
        return $myresult->{groupid};
    }

    return 0;
}

sub _getExistingGroupsOfTheHost {
    my ( $zabbix, $hostName) = @_;

    my @groupDetails;
    my $options = {'output' => 'extend', 'selectGroups' => 'extend', 'filter' => { 'name' => [ $hostName ] }};
    my $result = $zabbix->raw('host','get',$options);
    
    if( ref($result) eq 'ARRAY' ) {
        print "Duplicate host name found. This host sc12bbipub01.rot.od.sap.biz can not be added to setA/B groups. Please do it manually, if required";
        return undef;
    }
    else{
        if( defined $result ) {
            foreach my $arr ( @{$result->{groups}} ) {
                push @groupDetails, { 'name' => $arr->{name}, 'id' => $arr->{groupid} };
            } 
        }
    }
    return \@groupDetails;

}
sub _createIfNotExists {
    my ( $zabbix, $grpName ) = @_;
    my $newGrpId = _grpAlreadyExists($zabbix, $grpName) ;
    if( ! $newGrpId ) {
        my $myresult = SFSF::Hostgroups::createHostgroup($grpName);
        my @resArr = @{$myresult->{content}{result}{groupids}};
        $newGrpId = $resArr[0];
    }
        
    return $newGrpId;
}


sub _getHostIdByName {
    my ( $zabbix, $hostName ) = @_;

    return SFSF::Host::get_hostid($zabbix,$hostName);
}

sub _isHostAnAppHost {
    my ( $hostName ) = @_;

    my $hostInitial = (split /\./, $hostName)[0];
    if ( $hostInitial =~ /^\w+?([a-zA-Z])\d+[a-zA-Z]*$/ ) {
        my $appInitial = $1;
        if( $appInitial =~ /[ubrc]/ ) {
             return 1; ##this is an app host
        }
    }

    return 0;
}

sub hostMassAdd {
    my ( $zabbix,$hostId,$hostGrpId) = @_;

    my $options = { 'output' => 'extend','hosts' => { 'hostid' => $hostId }, 'groups' => { 'groupid' => $hostGrpId } };
    my $myresult = $zabbix->raw('host', 'massadd', $options);
    print Dumper $myresult if ( $DEBUG );
    if( ref ($myresult) eq 'HASH' && exists $myresult->{hostids}  ) {
        return 1;
    }
    return 0;
}

