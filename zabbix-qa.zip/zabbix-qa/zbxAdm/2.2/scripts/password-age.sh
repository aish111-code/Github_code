#!/bin/bash

#**this script is scheduled as a reminder to rest service account users after 1 year***
#define last password modified date here#
ZABBIX_SFSF_API=2022-12-02

email_to="jibin.sunny@sap.com,vidya.nandjha@sap.com,sindhu.madicherla@sap.com,jose.ortiz@sap.com,nagapavan.kalgur@sap.com"
diff_date=$(((($(date  "+%s") - $(date -d "${ZABBIX_SFSF_API}" "+%s"))) / 86400))
if [ $diff_date -gt 365 ]
then
  echo "ZABBIX_SFSF_API user password is older than $diff_date days ,password should be changed after 1 year as per security policy"| mailx -s "`hostname`:Action Required - change zabbix service account password" -r ZBX@sap.com $email_to
fi
