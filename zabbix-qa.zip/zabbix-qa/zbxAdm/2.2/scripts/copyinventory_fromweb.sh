#!/bin/bash

#########################################
# Author : Sandeep M.R
# Purpose : Copy zabbix inventory from web server to proxy
##########################################


rm /var/log/zabbix/zbxInventory.txt
curl -o /var/log/zabbix/zbxInventory.txt http://10.4.196.100/zabbix/cops/zbxInventory.txt
