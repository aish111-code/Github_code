#!/usr/bin/perl
use strict;
use warnings;
use HTTP::Request;
use LWP::UserAgent;
use Data::Dumper;
use JSON;
use MIME::Base64;
use Net::SSL;

BEGIN {
    $ENV{PERL_NET_HTTPS_SSL_SOCKET_CLASS}="Net::SSL";
#    $ENV{HTTPS_PROXY} = 'http://proxy-tco:8080';
}

my $g_baseURL = $ARGV[0] ;#|| 'https://qacand.sflab.ondemand.com';
my $g_clientId = $ARGV[1] ;#|| 'successfactors';
my $g_clientSecret = $ARGV[2];# || 'a0c37455e1c04db3bdc7c0e1038a844044af902d6b3c417c998c3002de92c958';
my $g_companyId = $ARGV[3] ;#|| 'PLTDMSBOX2';
my $g_userId = $ARGV[4] ;#|| 'v4admin';  #user id for the target company
my $g_resourceType = $ARGV[5] ;# || 'successfactors';   ##successfactors for Bizx non-provisioning access

if( !$g_baseURL || !$g_clientId || !$g_clientSecret || !$g_companyId || !$g_userId || !$g_resourceType ) {
    print "Some input parameters missing\n";
    print "Usage: $0 <baseURL> <clientId> <clientSecret> <companyId> <userId> <resourceType> \n";
    exit 1;
}

my $accessToken = getoauthToken($g_userId,$g_companyId,$g_resourceType);
#print "Access Token recieved = $accessToken\n";

checkDMSService($accessToken, $g_companyId);

sub getoauthToken {
    my (  $userId, $companyId, $resourceType ) = @_;

    my $scope =  "userId=$userId,companyId=$companyId,resourceType=$resourceType";
    my %data = (
        grant_type => 'client_credentials',
        scope => $scope
    );

    # Encode the data structure to JSON
    my $encodedData = encode_json(\%data);

    my $oauthUrl = qq~$g_baseURL/api/oauth/rest/v1/token~;

    ##convert credetial to base64 encoded format
    my $credentials = encode_base64($g_clientId .':'. $g_clientSecret,'');

    # Create the user agent and make the request
    my $ua = LWP::UserAgent->new(ssl_opts =>{ verify_hostname => 0 });
    my $response = $ua->post($oauthUrl,
                         'Content' => $encodedData,
                         'Content-Type' => 'application/json',
                         'Authorization' => "Basic $credentials");



    if ($response->is_success) {
        my $rc = $response->code;
        my $jsonData = decode_json($response->content);
        my $accesstoken = $jsonData->{"access_token"};
        return $accesstoken;
    }
    else{
        print STDERR "Failed to get Access Token\n";
        print STDERR $response->status_line , "\n";
        exit 1;
    }

    return;
}

sub checkDMSService {
    my ($token, $companyId ) = @_;

#chop($token);
    my $serviceUrl = qq~$g_baseURL/api/dms/healthcheck/$companyId~;

    my $ua = LWP::UserAgent->new(ssl_opts =>{ verify_hostname => 0 });
    my $res = $ua->get($serviceUrl,
                        'Content-Type' => 'application/json',
                        'Authorization' => "Bearer $token");

    my $rc = $res->code;
    if ($res->is_success) {
        my ($category,$vendorId,@msg);
        my $jsonData = decode_json($res->content);
        $category = $jsonData->{result}{category} || "";
        $vendorId = $jsonData->{result}{vendorId} || "";
        @msg = @{$jsonData->{result}{msg}};
        print "status:$rc category:$category vendorId:$vendorId msg:@msg\n";
    }
    else {
        #print STDERR "Error retrieving data: $rc.\n";
        print STDERR $res->status_line, "\n";
        if( $res->content_type eq 'application/json' ) {
            #print STDERR $res->decoded_content;
            my ($category,$vendorId,@msg);
            my $jsonData = decode_json($res->content);
            $category = $jsonData->{result}{category} || "";
            $vendorId = $jsonData->{result}{vendorId} || "";
            @msg = @{$jsonData->{result}{msg}};
            print STDERR "status:$rc category:$category vendorId:$vendorId msg:@msg\n";
        }
        exit(1);
    }

}
