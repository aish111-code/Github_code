##################################################################
# Author        : Sreekanth K P
# Purpose       : Wrapper script for creating alert log
# Version       : 20/12/2016 - Initial code
#
####################################################################

#!/bin/bash

#Main group list
HG="pc2 ps2 pc2mgt sc2 sc2mgt pc4 ps4 pd4 pc4mgt sc4 sc4mgt pc8 ps8 pf8 pc8mgt sc8 sc8mgt pc10 ps10 pc10mgt sc10 sc10mgt pc12 ps12 pc12Bosch pc12Siemens pc12SiemensExternal pc12SiemensInternal sc12 sc12mgt pc15 pc15mgt sc15 sc15mgt pc16 pc16mgt ps16 sc16 sc16mgt pc17 pc17mgt ps17 ps17mgt sc17 sc17mgt pc18 pc18mgt ps18 ps18mgt sc18 sc18mgt pc19 pc19mgt ps19 ps19mgt sc19 sc19mgt"

cd /usr/local/etc/zbxAdm/2.2/scripts
> report.txt
for i in $HG
do
./report.pl -item_status $i vfs.file.exists[/usr/sbin/updatezbx] 2> /dev/null |grep -v "HostGroup  |  Item_Key  |  Hostname  |  Host_tech_Name  |  Item_status  | Item_state  |  Item_Last_Value" >> report.txt
done
Total=`cat report.txt|grep -v "^$"|wc -l`
Latest_count=`cat report.txt|grep -v "^$"|grep "| 1"|wc -l`
Old_count=`cat report.txt|grep -v "^$"|grep "| 0"|wc -l`
cat report.txt|grep -v "^$"|grep "| 0"|awk -F"|" '{print $3}'|sed 's/ //g' > /tmp/old_servers.txt
echo "Total $Latest_count servers where latest package installed."
echo "Total $Old_count servers where old package installed."
Percent=`expr $Latest_count \* 100 / $Total`
echo "Compliance percentage is $Percent %"
echo "Please find the file /tmp/old_servers.txt to get complete list of servers with old zabbix package"

