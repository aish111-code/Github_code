#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

my @hostid;
my $os_template;
my $slr_host;
my $slr_hostgrp;
my $slr_template;
# Add Modules and functions into local scope

        use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
        use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
        use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
        use TLDs qw(pfail);

        use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
        use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
        use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
        use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';


my %args;

GetOptions(\%args,
                        "Hostname=s",
                        "Hostgroup=s",
                        "dc=s",
           );


if( ! scalar keys %args ) {
    usage();
}

if ( exists $args{dc} && $args{dc} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{dc} && uc $args{dc} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}
my $config = get_rsm_config($configFile);

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

if( $args{Hostname} && $args{Hostgroup} ) {
    print "Options Hostname and Hostgroup are mutually exclusive. Please provide only one option.\n";
    usage();
}

sub usage {
    print "$0 
    -Hostname < host name>                              - Single host or comma separated hosts to remove from maintenance
                                           OR
    -Hostgroup < Host Group Name >			- Single group or comma separated groups to remove from maintenance
    -dc < dc number >			                - like DC23 - optional argument

    Note: option -Hostname or -Hostgroup are mutually exclusive. Please provide only one option.

    Example: $0 -Hostname dc4zbxproxy01.phx.sf.priv
                         OR
    Example: $0 -Hostgroup PC2_LMS_A_U,PC2_LMS_A_R
    \n";

    exit 1;
}

if( exists $args{Hostname} && $args{Hostname} !~ /^0$/  ) {
    foreach my $hostName ( split /,/, $args{Hostname} ) {
        deleteMaintenance($zabbix, $hostName);
    }
}
elsif( exists $args{Hostgroup} && $args{Hostgroup} !~ /^0$/ ) {
    foreach my $hostGrp ( split /,/, $args{Hostgroup} ) {
        deleteMaintenance($zabbix, undef, $hostGrp);
    }
}



sub deleteMaintenance{
    my ( $zabbix, $hostName, $hostGroup ) = @_;

    if( ! defined $zabbix || ( ! $hostName && ! $hostGroup ) ) {
        print "Some input parameters are not provided :" .  usage() . "\n";
        exit 1;
    }

    my ( $hostId, $hostGrpId, $entityName );
    if( $hostName ) {
        $hostName =~ s/^\s*//;
        $hostName =~ s/\s*$//;
        $hostId = _getHostIdByName($zabbix, $hostName);
        if( ! $hostId ) {
            print "No host Id found for $hostName \n";
            exit 1;
        }
        $entityName = $hostName;
    }
    elsif( $hostGroup ) {
        $hostGroup =~ s/^\s*//;
        $hostGroup =~ s/\s*$//;
        $hostGrpId = _getHostGrpIdByName($zabbix,$hostGroup);
        if( ! $hostGrpId )  {
            print "No group id found for host group $hostGrpId \n";
            exit 1;
        }
        $entityName = $hostGroup;
    }
    

    my %params = ( 
                   "output" => "extend"
                 );

    if( $hostId ) {
        $params{hostids} = [ $hostId ];
    }
    elsif( $hostGrpId ) {
        $params{groupids} = [ $hostGrpId ];
    }
  


    my $result =  $zabbix->raw('maintenance','get',\%params);

    if ( ref($result) eq 'HASH' && defined $result->{maintenanceid} ) {
        my $maintenanceid = $result->{maintenanceid};
        my $maintenanceName = $result->{name};
        my $resultDelete =  $zabbix->raw('maintenance','delete', [ $maintenanceid ]);
        print Dumper $resultDelete;
        print "Maintenance $maintenanceName deleted for $entityName\n";
    }
    elsif ( ref($result) eq 'ARRAY' ) {
        foreach my $maintData ( @$result ) {
            my $maintenanceid = $maintData->{maintenanceid};
            my $maintenanceName = $maintData->{name};
            if (! $maintenanceid ) {
                print "Couldn't find maintenance Id for $maintenanceName\n";
                next;
            }
            if($maintenanceName =~ /^Platform_MW_/ ) {  ##only remove windows created by this tool
                my $resultDelete =  $zabbix->raw('maintenance','delete', [ $maintenanceid ]);
                print Dumper $resultDelete;
                print "Maintenance $maintenanceName deleted for $entityName\n";
            }
        }

    }
    else{
        print "No active maintenance window defined for $entityName\n";
        return;
    }
        	
}


sub _getHostIdByName {
    my ( $zabbix, $hostName ) = @_;

    return SFSF::Host::get_hostid($zabbix,$hostName);
}

sub _getHostGrpIdByName {
    my ( $zabbix, $grpName ) = @_;

    my $options = {'filter' =>{'name' => $grpName } };

    my $result = $zabbix->raw('hostgroup', 'get', $options );
    my $grpId = $result->{groupid};

    return $grpId;
}

