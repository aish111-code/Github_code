#!/usr/bin/perl

##################################################################
# Author        : Sandeep M.R
# Purpose       : Zabbix 2.2 reporting script
# Reviewer      : Patrick Presto
# Version       : Jan 20th 2015 - Initial code
#               : Jan 26th 2015 - Added report.pm,-hostinventory option
#               : May 6th 2015 - Added -item_status function (Vikky Omkar)
#               : Sep 11th 2015 - Added TriggerReport function (Vikky Omkar)
####################################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';


use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

my $reportScript = "/usr/local/etc/zbxAdm/2.2/scripts/report.pl";
my $outputFile   = "/var/log/zabbix/plt-aging.txt";
#my $email='s.renuka@sap.com,patrick.presto@sap.com,rinkesh.singh@sap.com,sajeesh.mohanan.adiyodi.chettayil@sap.com,fiyas.ahamed@sap.com,vipin.v.morais@sap.com,haiou.fu@sap.com,chris.hunt@sap.com,monitoring@successfactors.com,frank.roeder@sap.com,natalia.pyalling@sap.com,adrian.johnson@sap.com,frank.guerra@sap.com,vishwas.mohan@sap.com,vivekananda.dv@sap.com,vallimuthu.k@sap.com';
my $email='s.renuka@sap.com,sajeesh.mohanan.adiyodi.chettayil@sap.com,fiyas.ahamed@sap.com,vipin.v.morais@sap.com,haiou.fu@sap.com,vishwas.mohan@sap.com,vivekananda.dv@sap.com,vallimuthu.k@sap.com,santosh.tej@sap.com,michael.eugenio@sap.com';
# Local variable declaration

my @hostname;

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);

use SFSF::Host qw(gettechnames_fromHostgroup get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os);
use SFSF::Report qw(getTrigger gethostInventory  getgroupsInventory getHistory get_Item_Last_Value get_host_name getAging getevents);
use RSM qw(get_rsm_config);

# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
	chomp $line;
	if ($line ne "" and $line =~ m/lab/ )
	{
		$env = 'qa';
	}
	else { $env = 'prod' ; }
}

# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


#=pod

# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});



my @hostGrpPatterns = ( 'All-MAIL-IRONPORT',     'All-SFTP',             'All-AD',
                        'All-SPLUNK-INDEXERS',   '*_SPLUNK_DEP',         '*_SPLUNK_JOB',
                        '*_SPLUNK_LOG',          '*_SPLUNK_SRCH',        '*_AVSCAN', 
                        '*_SOLARWINDS_PLAYER',   '*_SOLARWINDS_SERVER',  '*_SOLARWINDS_WEB',
                        '*_SOLARWINDS_DATABASE', '*_OPTIER_BTM',         '*_OPTIER_DB',
                        '*_OPTIER_EM' ,          '*_ZABBIX',             '*_MAIL_SENDMAIL');


##making sure we are creating this file first
if( -e $outputFile ) {
    system("rm -f $outputFile");
}
open my $OFH, ">", $outputFile or die "Can not open file $outputFile to write report:$! \n";
print $OFH "=============================REPORT OF ALERTS AGING FOR MORE THAN 2 WEEKS=======================================\n";
print $OFH "\n";
print $OFH "\n";
my $count = 0;
foreach my $pattern ( @hostGrpPatterns ) {
    my $hostGrpRef = getHostgroupsByPattern($zabbix, $pattern);
    foreach my $hgName ( @$hostGrpRef ) {
       next if ( ! $hgName ); ##skip if empty groupname
       my $cmd = qq($reportScript -getAging '$hgName');       
       my @output = qx($cmd);
       my $tmpCnt = scalar @output;
       if( @output ) {
           print $OFH "*************************** Host Group: $hgName ***************************\n";
           print $OFH (@output), "\n";
           $count = $count + $tmpCnt;
       }
    }
}

my $mailCmd = qq~ cat  $outputFile | mailx -r "ZBX-PLT\@sap.com" -s "Plaftom Services Aging Alerts Report - $count aging alerts" $email ~;
system($mailCmd);



sub getHostgroupsByPattern {
    my ($zabbix,$pattern) = @_ ;

    my @hostGrpNames = ();
    my %output = ('output' => 'extend');
    my $params;
    #my %tfilter = ('filter' => $_[1], 'searchWildcardsEnabled' => 1);
    my %tfilter = ( 'search' => {
                                'name' => [
                                              $pattern
                                          ]
                              },
                     'searchWildcardsEnabled' => 1
                  );
    $params = {%output, %tfilter};
    my $api_result = $zabbix->raw('hostgroup','get', $params);
    if ( ref($api_result) eq 'ARRAY' ){
         foreach my $hgObj ( @$api_result ) {
             push @hostGrpNames, $hgObj->{name};
         }
    }
    else{
        push @hostGrpNames, $api_result->{name};
    }

    return \@hostGrpNames;
}

