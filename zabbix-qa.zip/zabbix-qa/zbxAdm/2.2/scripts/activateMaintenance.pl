#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

my @hostid;
my $os_template;
my $slr_host;
my $slr_hostgrp;
my $slr_template;
# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config ); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

my %args;

GetOptions(\%args,
                        "Hostname=s",
                        "Hostgroup=s",
                        "MaintenancePeriod=s",
                        "dc=s"
           );

if( ! scalar keys %args ) {
    usage();
}

if ( exists $args{dc} && $args{dc} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{dc} && $args{dc} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}

my $config = get_rsm_config($configFile);

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


if( $args{Hostname} && $args{Hostgroup} ) {
    print "Options Hostname and Hostgroup are mutually exclusive. Please provide only one option.\n";
    usage();
}

sub usage {
    print "
    ************************************************************************************************************************************************
    WARNING: IF YOU ARE EXECUTING THIS SCRIPT FROM ONE DC AND INTEND TO CONNECT TO OTHER DC, THEN YOU MUST PROVIDE THAT DETAILS IN THE 'dc' PARAMETER
    ************************************************************************************************************************************************
    $0 
    -MaintenancePeriod  < n >  				- Time in Hours to activate the maintenance window
    -Hostname < host name>                              - Single host or Comma separated Host Names to put into maintenance window
                                           OR
    -Hostgroup < Host Group Name >			- Single group or Comma separated Host Group names to put into maintenance window
    -dc < new DC name>			                - Use only if you are connecting to different DC url. e.g. DC23

    Note: option -Hostname or -Hostgroup are mutually exclusive. Please provide only one option.

    Example: $0 -MaintenancePeriod 1 -Hostname dc4zbxproxy01.phx.sf.priv
                                    OR
    Example: $0 -MaintenancePeriod 8 -Hostgroup pc2_bizx_a_u,pc2_bizx_a_r -dc DC23
    \n";

    exit 1;
}

$ENV{TZ} = 'US/Eastern';
if ( exists $args{Hostname} && $args{Hostname} !~ /^0$/ ) {
    foreach my $hostName ( split /,/, $args{Hostname} ) {
        activateMaintenance($zabbix, $args{MaintenancePeriod}, $hostName );
    }
}
elsif ( exists $args{Hostgroup} && $args{Hostgroup} !~ /^0$/ ) {
    foreach my $hostGrp ( split /,/, $args{Hostgroup} ) {
        activateMaintenance($zabbix, $args{MaintenancePeriod}, undef, $hostGrp );
    }
}


##Zabbix web host is in Eastern time......so convert all time time EDT
#activateMaintenance($zabbix, $args{MaintenancePeriod}, $args{Hostname}, $args{Hostgroup} );


sub activateMaintenance {
    my ( $zabbix, $maintPeriod, $hostName, $hostGroup ) = @_;

    if( ! defined $zabbix || ! $maintPeriod || ( ! $hostName && ! $hostGroup ) ) {
        print "Some input parameters are not provided :" .  usage() . "\n";
        exit 1;
    }

    my $entityName = $hostName;
    $entityName =~ s/^\s*//;
    $entityName =~ s/\s*$//;
    my ( $hostId, $hostGrpId );
    if( $hostName ) {
        $entityName = $hostName;
        $entityName =~ s/^\s*//;
        $entityName =~ s/\s*$//;
        $hostId = _getHostIdByName($zabbix, $entityName);
        if( ! $hostId ) {
            print "No host Id found for $entityName\n";
            exit 1;
        }
    }
    elsif( $hostGroup ) {
        $entityName = $hostGroup;
        $entityName =~ s/^\s*//;
        $entityName =~ s/\s*$//;
        $hostGrpId = _getHostGrpIdByName($zabbix,$entityName);
        if( ! $hostGrpId )  {
            print "No group id found for host group $entityName\n";
            exit 1;
        }
    }
    
    my $currentTimeStamp = `date +%s`;
    chomp($currentTimeStamp);
    my $currentDate = `date -d\@$currentTimeStamp +%Y%m%d:%H%M%S`;
    chomp($currentDate);
    


    my $timeperiod_type = 0;   ##0=daily
    my $currentHour = `date +%H`;
    chomp($currentHour);
    my $currentMin = `date +%M`;
    chomp($currentMin);

    my $now = ($currentHour * 60 *60 ) + ( $currentMin * 60 );
    
    my $period = $maintPeriod * 60 * 60; ##1 hour

    my $futureTimeStamp = $currentTimeStamp + $period;
    my $futureDate = `date -d\@$futureTimeStamp +%Y%m%d:%H%M%S`;
    chomp($futureDate);

    my $mainName = "Platform_MW_${currentDate}_${futureDate}_${entityName}";

    my %params = ( 
                   'name' => $mainName,
                   'active_since' => $currentTimeStamp,
                   'active_till' => $futureTimeStamp,
                   timeperiods => [ { 'timeperiod_type' => $timeperiod_type, 'start_time' => $now, 'period' => $period } ] 
                 );

    if( $hostId ) {
        $params{hostids} = [ $hostId ];
    }
    elsif( $hostGrpId ) {
        $params{groupids} = [ $hostGrpId ];
    }
  


    print "\n";
    print "Creating maintenance name '$mainName' for $entityName\n";
    my $result =  $zabbix->raw('maintenance','create',\%params);

    print Dumper $result;
    print "Host or Group added to maintenance. \n" if ( ref($result) eq 'HASH' && defined $result->{maintenanceids} );           
        	
}


sub _getHostIdByName {
    my ( $zabbix, $hostName ) = @_;

    return SFSF::Host::get_hostid($zabbix,$hostName);
}

sub _getHostGrpIdByName {
    my ( $zabbix, $grpName ) = @_;

    my $options = {'filter' =>{'name' => $grpName } };

    my $result = $zabbix->raw('hostgroup', 'get', $options );
    my $grpId = $result->{groupid};

    return $grpId;
}

