#!/bin/bash

##################################################################
# Author: Sandeep M.R, Platform Services
# Purpose: Wrapper script to copy zabbix host inventory to apache docroot
# Date   : July 13th 2015
##################################################################

email="s.renuka@sap.com,patrick.presto@sap.com,surekha.pattnaik@sap.com"

mv /var/log/zabbix/zbxInventory.txt  /nfs/web_content/prod/zabbix/zabbix/cops/

lines=`wc -l /nfs/web_content/prod/zabbix/zabbix/cops/zbxInventory.txt | awk '{print $1}'`

if [ $lines -gt 6000 ]
then
echo "SFSF Zabbix Inventory Generation Succesful - No of Hosts $lines" | mailx -r "ZBX@sap.com" -s "Zabbix Inventory Generation Successful" $email 
else
echo "SFSF Zabbix Inventory Generation Failed - No of hosts found $lines" | mailx -r "ZBX@sap.com" -s "Zabbix Inventory Generation Failed" $email

fi

