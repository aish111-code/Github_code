#!/usr/bin/env python3
##
##input to this script is host_discovered group and monsoon group
##loop through the hosts
import sys
sys.path.append('/usr/local/etc/zbxAdm/2.2/lib/zbxpylib')
from zabbix_api import ZabbixAPI
from RSM import parseConfig
import configparser
import re
from pprint import pprint
import subprocess
import errno
import os
import shlex
import json
import subprocess
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#import logging

ZABBIX_CONF_FILE='/usr/local/etc/zbxAdm/2.2/conf/zbx%s.conf'
ANSIBLE_AGENT_HOST_FILENAME='/etc/ansible/agent/inventory/hosts_agentansiblerun.txt'
ANSIBLE_AGENT_FAILEDHOST_FILENAME='/tmp/hosts_agentfailedrun.txt'
ZABBIX_NOTICE_FILENAME='/tmp/zbx_automation_notice.txt'
MAIL_FROM = 'ZBX-PLT<ZBX-PLT@sap.com>'
MAIL_TO = ["jibin.sunny@sap.com","vidya.nandjha@sap.com"]
#MAIL_TO = ["ganesan.karuppasamy@sap.com"]

# Datacenter
DATACENTER_HOSTNAME_FILE='/etc/hostname'
DATACENTER_HOSTS_FILE='/etc/hosts'
DATACENTER_PATTERN=r"[a-z]{2}([0-9]{1,2})[a-z]+"

HOST_REGISTRATION_MAIL_SUBJECT='Automated zabbix host registration status'
ANSIBLE_AGENT_MAIL_SUBJECT='Automated zabbix host agent deployment status'

if len(sys.argv) < 2:
    print("Usage: %s <host group e.g. host_discovered or monsoon> [ optional dc number e.g. DC23 ]" % (sys.argv[0]))
    sys.exit()

def main():
    inp_host_group = sys.argv[1]

    env = find_env_details('env')
    #configFile = find_env_details('config')
    datacenter = find_datacenter()

    ## Cleanup ansible host file
    if os.path.isfile(ANSIBLE_AGENT_HOST_FILENAME):
        os.unlink(ANSIBLE_AGENT_HOST_FILENAME)

##just checking if user explicitly passed dc number. If passed used that config file
    if len(sys.argv) > 2:
        configFile = ZABBIX_CONF_FILE % (sys.argv[2].upper())
    else:
        configFile = ZABBIX_CONF_FILE % (datacenter)
        if not os.path.isfile(configFile):
            configFile = ZABBIX_CONF_FILE % ('')

    print("configFile to use %s" % (configFile) )
    config = parseConfig(configFile)

    failed_grp = 'failed_automation'
#failed_grp_id = 4833
#logging.basicConfig(filename='/var/log/zabbix/automated_zabbix_registration.log',level=logging.DEBUG)
#logging.basicConfig(filename='automated_zabbix_registration.log',level=logging.DEBUG)
#logging.debug('This message should go to the log file')

    """
    ##logic to check if host is already in failed hostgroup
    #1 Check host name is duplicate
    #2 Check IP is duplicate
    #3 Check latest data already collected.

    #if none of above failed then autoregister
    #else Add to failed hostgroup

    """

    zabbix = init_zabbix_object(config)

    failed_grp_id = get_hostGrp_id(zabbix,failed_grp)

    host_inventory = get_host_inventory(zabbix)
    hosts_ips_from_discovered_grp = get_hosts_from_grp(zabbix, inp_host_group)
    discoveryHostStatus = []
    failedHosts = []
    autoRegisterLogs = []
    for data in hosts_ips_from_discovered_grp:
        discovered_host = data['name']
        discovered_ip = data['ip']
        discovered_host_id = data['hostid']
        
        if check_host_in_failedgroup(zabbix,discovered_host_id):
            print(f"Host {discovered_host} is in failed group")
            status = "FAILEDGRP"
            failedHosts.append(discovered_host)
        elif host_inventory.get(discovered_host, 0) > 1 or host_inventory.get(discovered_ip, 0) > 1:
            print(f"{discovered_host} is a duplicate")
            status = "DUPLICATE"
            add_to_failed_grp(zabbix, discovered_host_id)
            failedHosts.append(discovered_host)
        elif get_item_sytem_uname_sync(zabbix, discovered_host_id):
                print("Calling autoregistration script")
                cmd = f"/usr/local/etc/zbxAdm/2.2/scripts/autoregister_v2.pl -updatehost {discovered_host} -addmaintenance -dc {datacenter}"
                print(cmd)
                args = shlex.split(cmd)
                p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                out,err = p.communicate()
                autoRegisterLogs.append(out.strip().decode('utf-8'))
                
                if b'Regex not found' in out:
                    print(f"Autoregistration failed")
                    print(f"Regex for the host {discovered_host} id not found")
                    status = "NOREGEX"
                    add_to_failed_grp(zabbix, discovered_host_id)
                    failedHosts.append(discovered_host)
                elif b'Host is not valid' in out:
                    print(f"Autoregistration failed")
                    print(f"Invalid host in zabbix {discovered_host}")
                    status = "INVALIDHOST"
                    add_to_failed_grp(zabbix, discovered_host_id)
                    failedHosts.append(discovered_host)
                elif p.returncode != 0:
                    print(f"Autoregistration failed")
                    print(out.decode('utf-8') + err.decode('utf-8'))
                    status = "FAILED"
                    failedHosts.append(discovered_host)
                else:
                    status = "SUCCESS"
        else:
            if no_os_base_template_present(zabbix, discovered_host_id):
               print(f"{discovered_host} doesn't have t_os_base template")
               status = "NO_OS_BASE_TEMPLATE"
            else:
                 print(f"Host {discovered_host} is waiting for sync of system.uname")
                 status = "UNSYNC"
        discoveryHostStatus.append(f"{discovered_host} - {status}")

    if failedHosts:
        write_file(ZABBIX_NOTICE_FILENAME, '\n'.join(failedHosts))
    if discoveryHostStatus:
        mail_notification('\n'.join(discoveryHostStatus), 
                         subject='%s: %s' % (datacenter, HOST_REGISTRATION_MAIL_SUBJECT), 
                         logs='\n'.join(autoRegisterLogs) if autoRegisterLogs else None)

def read_file(filename):
    data = ''
    try:
        with open(filename, 'r', encoding='utf-8') as read_file:
            data = read_file.read()
    except IOError as ioe:
        if ioe.errno != errno.ENOENT:
            print(str(ioe))
    return data

def write_file(filename, content):
    try:
        with open(filename, 'w', encoding='utf-8') as outFile:
            outFile.write(content)
    except IOError as ioe:
        print(str(ioe))

def mail_notification(body, subject=None, fromAddress=MAIL_FROM, toAddress=MAIL_TO, logs=None):
    msg = MIMEMultipart()
    msg['From'] = fromAddress
    msg['To'] = ','.join(toAddress)
    msg['Subject'] = subject
    msg.attach(MIMEText(body))
    if logs:
        attachment = MIMEText(logs, 'plain')
        attachment.add_header('Content-Disposition', 'attachment', filename='logs.txt')
        msg.attach(attachment)
    mailServer = None
    try:
        mailServer = SMTP('localhost')
        mailServer.sendmail(fromAddress, toAddress, msg.as_string())
    except Exception as e:
        print(str(e))
    finally:
        if mailServer is not None:
            mailServer.quit()

def get_host_inventory(zabbix):
    inventory = {} 
    options = {'output': 'extend', 'selectInterfaces': ['ip', 'port']}
    zabbix.timeout = 30
    result = zabbix.host.get(options)
    for record in result:
        name = record['name']
        hostid = record['hostid']
        ip = record['interfaces'][0]['ip']
        try:
            inventory[name] += 1
        except KeyError:
            inventory[name] = 1
        try:
            inventory[ip] += 1
        except KeyError:
            inventory[ip] = 1

    return inventory

def check_host_in_failedgroup(zabbix, host_id):
    failed_grp = 'failed_automation'
    failed_grp_id = get_hostGrp_id(zabbix, failed_grp)
    options = {'output': 'hostid', 'groupids': failed_grp_id, 'hostids': host_id}
    result = zabbix.host.get(options)
    print(failed_grp_id, result)
    try:
        return True if result[0]['hostid'] == host_id else False
    except (IndexError, KeyError):
        return False

def add_to_failed_grp(zabbix, host_id):
    failed_grp = 'failed_automation'
    failed_grp_id = get_hostGrp_id(zabbix, failed_grp)
    options = {'hostid': host_id, 'groups': [{'groupid': failed_grp_id}]}
    result = zabbix.host.update(options)
    print(f"Host {int(host_id)} is added to failed group")

def init_zabbix_object(config):
    with open('/etc/hosts','r') as fh:
        env = ''

        for line in fh:
            if line != "" and re.search('lab', line):
                env = 'qa'
                break
        else:
            env = 'prod'

        url = config.get(env,'url')
        user = config.get(env,'user')

        private_key_file = "/etc/zabbix/custom/zabbix_private_key.pem"
        encrypted_data_file = "/etc/zabbix/custom/zabbix_autoregister_password_enc.dat"
        cmd = f"openssl rsautl -decrypt -inkey {private_key_file} -in {encrypted_data_file}"
        print(cmd)
        args = shlex.split(cmd)
        p = subprocess.Popen(args,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out,err = p.communicate()
        passwd = out.rstrip().decode('utf-8')

        print(url)
        zabbix = ZabbixAPI(server=url)
        zabbix.login(user,passwd)
        print(f"Connected to Zabbix API Version {zabbix.api_version()}")

    return zabbix

def get_hosts_from_grp(zabbix, host_group):
    try:
        hgrpId = get_hostGrp_id(zabbix, host_group)
        options = {'output': 'extend', 'groupids': [hgrpId], 'selectInterfaces': ['ip', 'port']}
        results = zabbix.host.get(options)
        hosts_and_ips = [{'name':results[i]['name'], 'hostid': results[i]['hostid'], 'ip':results[i]['interfaces'][0]['ip']} 
                        for i in range(len(results))]
        return hosts_and_ips
    except Exception as e:
        print(e)

def get_hostGrp_id(zabbix,hostGrp):
    options = {'output': 'extend', 'filter': {'name':hostGrp}}
    results = zabbix.hostgroup.get(options)
    try:
        return results[0]['groupid']
    except (IndexError,KeyError) as e:
        print(f"Group Id not found for group {hostGrp}")
        return None

def get_host_id(zabbix,host):
    options = {'output': 'extend', 'filter': {'name':host}}
    results = zabbix.host.get(options)
    try:
        return results[0]['hostid']
    except (IndexError,KeyError) as e:
        print(f"Host Id not found for host {host}")
        return None

def no_os_base_template_present(zabbix,hostid):
    options = {'output': ['hostid'],'selectParentTemplates': ['name'],'hostids': hostid}
    results = zabbix.host.get(options)
    try:
        templates=results[0]['parentTemplates']
        no_basetemplate_present=True
        for temp in templates:
            template=temp['name']
            Result = template.lower() == "T_OS_BASE".lower()
            if Result == True:
                print("base template found")
                no_basetemplate_present=False
        return no_basetemplate_present
    except (IndexError,KeyError) as e:
        print(f"os base template search failed {host}")
        return True

def get_item_sytem_uname_sync(zabbix,hostid):
    if no_os_base_template_present(zabbix, hostid):
        return False
    options = {'output': 'extend', 'hostids': [hostid], 'filter': {'key_':'system.uname'}}
    results = zabbix.item.get(options)
    try:
        if len(results) > 0:
            if len(str(results[0].get('lastvalue', ''))) > 0:
                return True
            elif len(str(results[0].get('prevalue', ''))) > 0:
                return True
        return False
    except (IndexError,KeyError) as e:
        print(f"Item Id not found for host {host}")
        return False

def _find_datacenterNumber(content):
    if content:
        content = content.strip()
        match = re.search(DATACENTER_PATTERN, content)
        if match:
            return f'DC{int(match.group(1))}'
        if 'lab' in content:
            return 'DC13'
    return None

def find_datacenter():
    datacenter = _find_datacenterNumber(read_file(DATACENTER_HOSTNAME_FILE))
    if not datacenter:
        content = read_file(DATACENTER_HOSTS_FILE).strip()
        hosts = content.split("\n")
        for line in hosts:
            host = line.strip()
            if len(host) > 0 and not host.startswith("#"):
                datacenter = _find_datacenterNumber(host)
                if datacenter:
                    return datacenter
    print(datacenter)
    return datacenter

def find_env_details(inp):
    with open('/etc/hosts', 'r') as f:
        env = None
        configFile = None

        if inp == 'env':
            for line in f:
                if re.search(r'lab',line):
                    env = 'qa'
                else:
                    env = 'prod'
            return env
        elif inp == 'config':
            for line in f:
                if re.search(r'ss01zbx',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC01.conf'
                elif re.search(r'pc23',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf'
                elif re.search(r'pc22',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC22.conf'
                elif re.search(r'ss42',line):
                    configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf'
            return configFile

if __name__ == '__main__':
     main()
