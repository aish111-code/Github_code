#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);
use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
    chomp $line;
    if ($line ne "" and $line =~ m/lab/ )
    {
        $env = 'qa';
    }
    else { $env = 'prod' ; }
}

# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


my %args;

GetOptions(\%args, "hostGroup=s", "hostGrpFile=s") or die "Invalid arguments \n";
if ( ! %args  || ! ( $args{hostGroup} || $args{hostGrpFile} ) ) { ###if nothing passed or something other than accepted parameters
    die "Missing options -
                -hostGrpFile <file containing host groups - newline separated>
                   OR
                -hostGroup <group name> \n" ;
} 

# Get hostgroup from commandline
my @inp_hostGrps = ();
if ( exists $args{hostGroup} ) {
    push @inp_hostGrps, $args{hostGroup};
}
elsif( exists $args{hostGrpFile} ) {
    open GFH, $args{hostGrpFile} or die "Can not open input file $args{hostGrpFile} : $! \n";
    while(<GFH>){
        chomp;
        next if $_ =~ /^$/;
        push @inp_hostGrps, $_;
    }
}
else{
    print "No hostgroup provided to work on. Exiting ..... \n";
    exit 1;
}

foreach my $hGrp ( @inp_hostGrps ) {
    my $result_api = get_triggers($zabbix, $hGrp);

    displayResults($result_api);
}

sub displayResults {
    my ( $result_api ) = @_;


    print "=======================================================================================================================================================================================================\n";
    print "\tHost Name \t\t\t HostGroups \t\t\t\t\t Time Stamp \t\t\t\tTrigger Expression \n";
    print "=======================================================================================================================================================================================================\n";
    print "\n";
    foreach my $data ( @$result_api ) {
        my $hostName = ${$data->{hosts}}[0]->{name};
        my $timeStamp = $data->{lastchange};
        my $time      = convertTimeStamp($timeStamp);
        my $trgName   = $data->{description};
        my @hostGrps;
        foreach my $grpData( @{$data->{groups}} ) {
             push @hostGrps, $grpData->{name};
        }
        print "$hostName | [ @hostGrps \] | $time | $trgName \n";   
    }
}

sub get_triggers {
  my ( $zabbix, $inp_hGrp ) = @_;
  my %params = ('output' => 'extend', 'selectHosts' => 'extend', 'selectGroups' => ['groupid','name'], 'expandDescription' => 1, 'min_severity' => 2, 'monitored' => 1, 'skipDependent' => 1, 'sortfield' => 'priority', 'group' => $inp_hGrp, 'filter' => { 'value' => 1  } );
  my $api_result = $zabbix->raw('trigger','get', \%params);

  return $api_result;
}

sub convertTimeStamp {
    my ( $time ) =  @_ ;
    

    my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
    my ($sec, $min, $hour, $day,$month,$year) = (gmtime($time - 14400))[0,1,2,3,4,5];
    # You can use 'gmtime' for GMT/UTC dates instead of 'localtime'
    my $convertedTime = ($year+1900) ."-". ($month + 1) ."-". $day ." ". $hour.":".$min.":".$sec;

    return $convertedTime;
}
