#!/usr/bin/perl -w

###########################################################
# Author  : Pradip Kumar
# Purpose : 
# Date    : Aug 2017
############################################################
# Modified - Nandhini on 27-Dec-2017
# Purpose - Added Products specific host group details
############################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration


use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf'; 

my %args;

GetOptions(\%args,"hostName=s","hostGroup=s","product=s", "dc_override=s" );
if( ! scalar keys %args  || (scalar keys %args < 2)) {
    usage();
    exit 1;
}
# Load API properites file
if ( exists $args{dc_override}  && $args{dc_override} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{dc_override} && $args{dc_override} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}

my $config = get_rsm_config($configFile);


pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

my %validProducts = ( 'WFA' => 'T_WFA_Linux', 'HANA' => 'T_HANA_Linux', 'J2W' => 'T_J2W_Linux', 'MOB' => 'T_MOB_Linux', 'OPTIER' => 'T_OPTIER_Linux', 'JAM' => 'T_JAM_Linux', 'SPLUNK' => 'T_SPLUNK_Linux', 'LMS' => 'T_LMS_Linux', 'BIZX' => 'T_BizX_Linux', 'BOOMI' => 'T_BOOMI_Linux', 'APIGEE' => 'T_APIGEE_Linux', 'BIZX-DB' => 'T_HANA_Linux', 'LMS-DB' => 'T_HANA_Linux' );  ##this will grow later
#my @masterGrpToUseLMS = qw( pc2_LMS sc2_LMS ps2_LMS pd2_LMS
#                                 pc4_LMS sc4_LMS ps4_LMS pd4_LMS
#                                 pc8_LMS sc8_LMS ps8_LMS pd8_LMS
#                                 pc10_LMS sc10_LMS ps10_LMS pd10_LMS
#                                 pc12_LMS sc12_LMS ps12_LMS pd12_LMS
#                                 pc15_LMS sc15_LMS ps15_LMS pd15_LMS
#                                 pc16_LMS sc16_LMS ps16_LMS pd16_LMS
#                                 pc17_LMS sc17_LMS ps17_LMS pd17_LMS
#                                 pc18_LMS sc18_LMS ps18_LMS pd18_LMS
#                                 pc19_LMS sc19_LMS ps19_LMS pd19_LMS
#                        );
my @masterGrpToUseLMS = qw( sc8_LMS_A_B sc8_LMS_A_C sc8_LMS_A_R
                            sc8_LMS_A_SHIB sc8_LMS_A_SHIB_SP sc8_LMS_A_U
                            sc8_LMS_W sc2_LMS_A sc2_LMS_W sc4_LMS_A sc4_LMS_W 
                            sc10_LMS_A sc10_LMS_W sc12_LMS_A sc12_LMS_W 
                            sc15_LMS_A sc15_LMS_W sf8_LMS_A_B sf8_LMS_A_U sc16_LMS_A sc16_LMS_W  
                            sc17_LMS_W sc17_LMS_A sc18_LMS_A sc18_LMS_W sc19_LMS_A        sc19_LMS_W pc15_LMS_A pc15_LMS_W pc16_LMS_A
                            pc16_LMS_W pc17_LMS_A pc17_LMS_W pc18_LMS_A pc18_LMS_W pc19_LMS_A pc19_LMS_W pc10_LMS_A pc10_LMS_W pc8_LMS_W
                            pc8_LMS_A ps8_LMS_A ps8_LMS_W pd4_LMS pc4_LMS_A pc4_LMS_W pc2_LMS_A pc2_LMS_W pd2_LMS ps2_LMS pd12_LMS 
                            pc12_LMS_A pc12_LMS_W pc2_LMS_DB pc4_LMS_DB pc8_LMS_DB pc10_LMS_DB pc12_LMS_DB pc15_LMS_DB pc19_LMS_DB pf8_LMS_DB 
                            sc8_LMS_DB sc12_LMS_DB sc19_LMS_DB sf8_LMS_DB);
#my @masterGrpToUseBIZX = qw();
my @masterGrpToUseBIZX = qw{
                                 ps19_BIZX sc10_BizX_A_CF sc10_BizX_A_CF-TOMCAT sc10_BizX_W_CF sc10_BizX sc19_BizX sc4_BizX_A sc4_BizX_W ps4_BizX_W ps4_BizX_A
                            pd4_BizX pd8_BizX pd2_BizX pd12_BizX sc2_BizX_W sc2_BizX_A ps2_BizX_A ps2_BizX_W sc12_BizX_W sc8_BizX_W sc8_BizX_A ps8_BizX_W 
                                ps8_BizX_A sc12_BizX_A pc16_BizX pc15_BizX pc2_BizX_W pc2_BizX_A pc4_BizX_A pc4_BizX_W pc8_BizX_A pc8_BizX_W pc8_BizX_DB pc12_BizX
                              pc12Bosch_BizX_A pc12Bosch_BizX_W pc12Siemens_BizX_W pc12Siemens_BizX_A pc12SiemensExternal pc12SiemensInternal pc2SiemensPS 
                             pc2SiemensPen    
                           };

my @masterGrpToUseBOOMI = qw{ sc2_BOOMI sc4_BOOMI sc8_BOOMI
                              sc10_BOOMI sc12_BOOMI sc15_BOOMI
                              sc16_BOOMI sc17_BOOMI sc18_BOOMI
                              sc19_BOOMI pc2_BOOMI pc4_BOOMI
                              pc8_BOOMI pc10_BOOMI pc12_BOOMI
                              pc15_BOOMI pc16_BOOMI pc17_BOOMI
                              pc18_BOOMI pc19_BOOMI ps8_BOOMI
                            };

my @masterGrpToUseAPIGEE = qw{ pc2_APIGEE pc4_APIGEE pc8_APIGEE
                               pc10_APIGEE pc12_APIGEE pc17_APIGEE 
                               pc18_APIGEE pc19_APIGEE sc12_APIGEE 
                               sc17_APIGEE sc18_APIGEE sc19_APIGEE 
                             };
my @masterGrpToUseSPLUNK = qw{ pc2mgt_SPLUNK pc4mgt_SPLUNK pc8mgt_SPLUNK pc10mgt_SPLUNK pc12mgt_SPLUNK 
                                pc15mgt_SPLUNK pc16mgt_SPLUNK pc18mgt_SPLUNK pc19mgt_SPLUNK pc17mgt_SPLUNK pf8mgt_SPLUNK
                             };
my @masterGrpToUseWFA = qw{ ps2_WFA_A_WEB pc2_WFA_A_WEB sc2_WFA_A_WEB pd2_WFA_A_WEB pc4_WFA_A_WEB sc4_WFA_A_WEB pc8_WFA_A_WEB sc8_WFA_A_WEB pc10_WFA_A_WEB
                                sc10_WFA_A_WEB pc12_WFA_A_WEB sc12_WFA_A_WEB pc15_WFA_A_WEB pc17_WFA_A_WEB sc17_WFA_A_WEB pc18_WFA_A_WEB sc18_WFA_A_WEB
                                ps8_WFA_A_WEB pc19_WFA_A_WEB sc19_WFA_A_WEB pf8_WFA_A_WEB
                             };
my @masterGrpToUseJAM = qw{ ps4_JAM ps8_JAM pc19_JAM pc18_JAM pc17_JAM pc15_JAM pc10_JAM pc2_JAM pc4_JAM pc8_JAM pc12_JAM
                             };
my @masterGrpToUseOPTIER = qw{ pf8mgt_OPTIER pc19mgt_OPTIER pc18mgt_OPTIER pc17mgt_OPTIER pc16mgt_OPTIER pc15mgt_OPTIER pc12mgt_OPTIER pc10mgt_OPTIER 
                                pc8mgt_OPTIER pc4mgt_OPTIER pc2mgt_OPTIER
                             };
my @masterGrpToUseJ2W = qw{ pc8_J2W sc8_J2W pc10_J2W sc10_J2W pc12_J2W sc12_J2W pc19_J2W sc19_J2W pcchicago_J2W sc17_J2W
                             };
my @masterGrpToUseHANA = qw{ pc8_DB_HANACELL pc2_DB_HANACELL sc2_WFA_HanaDB sc4_WFA_HanaDB sc8_WFA_HanaDB sc10_WFA_HanaDB sc12_WFA_HanaDB sc17_WFA_HanaDB
                                sc18_WFA_HanaDB sc19_WFA_HanaDB pd2_WFA_HanaDB ps2_WFA_HanaDB ps4_WFA_HanaDB ps8_WFA_HanaDB pc18_WFA_HanaDB pc19_WFA_HanaDB
                                pc17_WFA_HanaDB pc15_WFA_HanaDB pc19_DB_HANACELL pc18_DB_HANACELL pc17_DB_HANACELL sc19_DB_HANACELL sc18_BizXDB_HANACELL
                                sc17_DB_HANACELL sc10_DB_HANACELL sc4_BizX_HANACELL sc4_WFA-DB_HANACELL sc8_BizXDB_HANACELL sc2_DB_HANACELL sc12_WFA-DB_HANACELL
                                sc12_BizXDB_HANACELL sc10_DB_HANACELL sc10_WFA-DB_HANACELL sc2_DB_HANACELL ps2_WFA-DB_HANACELL ps4_WFA-DB_HANACELL sc8_BizXDB_HANACELL
                                pc4_WFA-DB_HANACELL pc8_BizXDB_HANACELL pc8_WFA-DB_HANACELL pc18_DB_HANACELL pc12_BizXDB_HANACELL pc10_WFA-DB_HANACELL pc10_DB_HANACELL
                                pc8_DB_HANACELL pc4_BizXDB_HANACELL pc4_DB_HANACELL sc8_DB_HANACELL pc8_BizX-DB_HANACELL
                             };
my @masterGrpToUseMOB = qw{ pc2_MOB ps2_MOB pc4_MOB pc8_MOB pc10_MOB pc12_MOB pc15_MOB pc17_MOB pc18_MOB pc19_MOB ps4_MOB ps8_MOB pc12Bosch_MOB sc2_MOB sc4_MOB
                                sc8_MOB sc10_MOB sc12_MOB sc15_MOB sc17_MOB sc18_MOB sc19_MOB
			     };

my $inp_grpName = $args{hostGroup};
my $inp_hostName = $args{hostName};
my $productToUse;
my @masterGrpToUse;
if( exists $args{product} ) {
    $productToUse = $args{product};
    if( $productToUse eq 'LMS' ) {
        @masterGrpToUse = @masterGrpToUseLMS;
    }
    elsif( $productToUse eq 'BIZX' ) {
        @masterGrpToUse = @masterGrpToUseBIZX;
    }
    elsif( $productToUse eq 'BOOMI' ) {
        @masterGrpToUse = @masterGrpToUseBOOMI;
    }
    elsif( $productToUse eq 'APIGEE' ) {
        @masterGrpToUse = @masterGrpToUseAPIGEE;
    }
   elsif( $productToUse eq 'SPLUNK' ) {
        @masterGrpToUse = @masterGrpToUseSPLUNK;
    }
    elsif( $productToUse eq 'OPTIER' ) {
        @masterGrpToUse = @masterGrpToUseOPTIER;
    }
    elsif( $productToUse eq 'J2W' ) {
        @masterGrpToUse = @masterGrpToUseJ2W;
    }
    elsif( $productToUse eq 'WFA' ) {
        @masterGrpToUse = @masterGrpToUseWFA;
    }
    elsif( $productToUse eq 'HANA' ) {
        @masterGrpToUse = @masterGrpToUseHANA;
    }
    elsif( $productToUse eq 'MOB' ) {
        @masterGrpToUse = @masterGrpToUseMOB;
    }
    elsif( $productToUse eq 'JAM' ) {
        @masterGrpToUse = @masterGrpToUseJAM;
    }
    elsif( $productToUse eq 'BIZX-DB' ) {
        @masterGrpToUse = @masterGrpToUseHANA;
    }
    elsif( $productToUse eq 'LMS-DB' ) {
        @masterGrpToUse = @masterGrpToUseHANA;
    }
    else{
        @masterGrpToUse = ();
    }
}
else{
    #@masterGrpToUse = ( @masterGrpToUseLMS, @masterGrpToUseBIZX );
    usage();
    exit 1;
}

if( $inp_hostName ) {
    if( exists $validProducts{$productToUse} ) {
        if( addTemplates($zabbix, $inp_hostName) ) {
             print "Add template process failed for host $inp_hostName\n";
             exit 1;
        }
    }
    else{
        print "Not a valid product. List of products currently supported are \n" , Dumper keys %validProducts;
        exit 1;
    }
}
elsif ( $inp_grpName eq 'ALL' ) {
    my $options = {'output' => ['name','groupid']};
    my $myresult = $zabbix->raw('hostgroup','get',$options);
    foreach my $grpData ( @$myresult ) {

        my $grpname = $grpData->{name};
        my $grpid = $grpData->{groupid};

        if( ! scalar @masterGrpToUse ) {
            print "No Group names found for product $productToUse \n";
            exit 1;
        }
        elsif( grep { /^$grpname$/i } @masterGrpToUse) {
            my $hostDetails = _getHostsByGroup($zabbix,$grpname);
            next if (! scalar keys %$hostDetails);
            foreach my $hostName ( values %$hostDetails ) {
                if( addTemplates($zabbix, $hostName) ) {
                     print "Add template process failed for host $hostName. Trying next host in the list  \n";
                }
            }
        }
    }

}
else {
    if( grep { /^$inp_grpName$/i } @masterGrpToUse) {
        my $hostDetails = _getHostsByGroup($zabbix,$inp_grpName);
        next if (! scalar keys %$hostDetails);
        foreach my $hostName ( values %$hostDetails ) {
            if( addTemplates($zabbix, $hostName) ) {
                print "Add template process failed for host $hostName. Trying next host in the list  \n";
            }
        }
    }
    else{
        print "This group $inp_grpName can not be used. Please check the master list \n";
        print Dumper \@masterGrpToUse;
        print "\n";
        exit;
    }

}



sub _getHostIdByName {
    my ( $zabbix, $hostName ) = @_;

    my $hostId = SFSF::Host::get_hostid($zabbix,$hostName);
    if( $hostId ) {
        return $hostId;
    }
    else{
        return undef;
    }
}

sub getExistingTemplates {
    my ( $zabbix, $hostId ) = @_;
    my $attached = get_host_templates($zabbix,$hostId);
    my %templateData;
    if(ref($attached) eq 'HASH' ) {
        my $templateId = $attached->{templateid};
        my $templateName = $attached->{host};
        $templateData{$templateId} = $templateName;
    }
    elsif(ref($attached) eq 'ARRAY'){
        foreach my $res ( @{$attached} ) {
            my $templateId = $res->{templateid};
            my $templateName = $res->{host};
            $templateData{$templateId} = $templateName;
        }
    }
    else{
        print "Can not get existing templates for host $hostId \n";
        exit 1;
    }

    return \%templateData;
}
sub _getTemplateId {
    my ( $zabbix, $templateName) = @_;

    my %options = ( 'output' => [ 'templateid','host' ], 'filter' => { 'host' => $templateName } );
    my $result = $zabbix->raw('template','get',\%options);
    if( ref($result) eq 'HASH' ) {
        my $templateid = $result->{templateid};
        return $templateid;
    }
    else{
        print "Can not get template id of template: $templateName \n";
        exit 1;
    }

    
}

sub addTemplates {
    my ( $zabbix, $arg_hostName ) = @_;
    my $hostId = _getHostIdByName($zabbix, $arg_hostName);
    if( ! $hostId ) {
        print "Can not find host id of $arg_hostName.\n";
        return 1;
    }
    my $templateDataRef = getExistingTemplates($zabbix, $hostId);
    print "Existing templates in the host $arg_hostName ",Dumper $templateDataRef;
    print "\n";
    my $productSpecificTemplate = $validProducts{$productToUse};
    my $productSpecificTemplateId = _getTemplateId($zabbix, $productSpecificTemplate); 
    if( exists $templateDataRef->{$productSpecificTemplateId} ) {
         print "Template $templateDataRef->{$productSpecificTemplateId} already exists on this host $arg_hostName. Nothing to be done \n";
         return 0;
    }

    my @uniqueremoveTemplateids = (); 
    foreach my $templateId ( keys %{$templateDataRef} ) {
         my $templateName = $templateDataRef->{$templateId};
         if( $templateName =~ /^(T_OS_Linux)$/ ) {
             ##do nothing
             push @uniqueremoveTemplateids, $templateId;
             last;
         }
    }
    
    if( scalar @uniqueremoveTemplateids < 1 ) {
        print "No templates to be removed for host $arg_hostName.\n";
    }
    else {
        print "Templates to be removed : @uniqueremoveTemplateids\n";
        ###remove all templates from the host
        my $removeresponse = host_remove_template($zabbix,[$hostId],\@uniqueremoveTemplateids);   
        if( $removeresponse eq  'success' ) {
            print "templates removed successfully: @uniqueremoveTemplateids\n " ;
            #print "templates removed successfully: " , Dumper (values %{$templateDataRef}); 
            print "\n";
        }
        else{
            print "Can not remove existing templates for host $arg_hostName.\n";
            return 1;
        }
    }
       ##Re add the newly created template list
    print "Template to add : $productSpecificTemplate => $productSpecificTemplateId\n";
    #my @results = host_update($zabbix,[$hostId] ,"templates","templateid",\@templatesToReadd);
    if( templateMassAdd($zabbix,$hostId, $productSpecificTemplateId) ) {
        print "Template $productSpecificTemplate added successfully\n" ; 
    }
    else{
        print "Could not add template to host $arg_hostName \n";
        return 1;
    }
    return 0;
}


sub _getHostsByGroup {
    my ($zabbix,$hGrpName) = @_;

    return {} if ( ! $zabbix || ! $hGrpName );
    my %hostDetails;

    my $options = {'output' => 'extend','filter' => {'name' => $hGrpName }};
    my $myresult = $zabbix->raw('hostgroup','get',$options);

    my $hostGrpId = $myresult->{groupid};

    $options = {'output' => 'extend', 'groupids' => $hostGrpId };
    $myresult = $zabbix->raw('host','get',$options);
    if ( ref($myresult) eq 'ARRAY' ){
        foreach my $h (@{$myresult}){
            my $hId = $h->{hostid};
            my $hostName = $h->{'name'};
            $hostDetails{$hId} = $hostName if( defined $hId && defined $hostName );
        }
    } else{
        $hostDetails{$myresult->{hostid}} = $myresult->{'name'} if( defined $myresult->{hostid} && defined $myresult->{'name'} );
    }
    return \%hostDetails;
}

sub usage {
    print "
           *********************************************************************************************************************************************************
           WARNING: IF YOU ARE EXECUTING THIS SCRIPT FROM ONE DC AND INTEND TO CONNECT TO OTHER DC, THEN YOU MUST PROVIDE THAT DETAILS IN THE 'dc_override' PARAMETER
           *********************************************************************************************************************************************************  
           Missing options -
                -hostName <Host name>
                        OR
                -hostGroup <Host Group|ALL>
                -product <LMS|BIZX|BOOMI|APIGEE|ALL> 
                [ -dc_override DC23 ] \n";
    print "Example: $0 -hostName pc2bseb03.ams2.sf.priv -product LMS
                        OR
                    $0 -hostGroup pc2_LMS -product LMS  -dc_override DC23 
                        OR
                    $0 -hostGroup ALL -product LMS \n";
    exit -1;
}

sub templateMassAdd {
    my ( $zabbix,$hostId,$templateId) = @_;

    my $options = { 'output' => 'extend','hosts' => { 'hostid' => $hostId }, 'templates' => { 'templateid' => $templateId } };
#print Dumper $options;
#print"+++++++++++++++++++++++++++++++++++++\n";
    my $myresult = $zabbix->raw('template', 'massadd', $options);
    print Dumper $myresult;
    if( ref ($myresult) eq 'HASH' && exists $myresult->{templateids}  ) {
        return 1;
    }
    return 0;
}
