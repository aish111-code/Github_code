#!/bin/bash
email='jibin.sunny@sap.com,s.renuka@sap.com'

python /usr/local/etc/scripts/weekly_inventory.py > /usr/local/etc/scripts/temp/weekly_inventory.txt
echo "[all]" >/etc/ansible/agent/inventory/zabbix_agent_weekly.txt
#grep -E '_Linux|_Solaris' /usr/local/etc/scripts/temp/weekly_inventory.txt|awk -F '|' '{print $1}' >>/etc/ansible/agent/inventory/zabbix_agent_weekly.txt
grep -E '_Linux|_Solaris' /usr/local/etc/scripts/temp/weekly_inventory.txt|awk -F '|' '{print $1}'|head -5 >>/etc/ansible/agent/inventory/zabbix_agent_weekly.txt
/usr/bin/ansible-playbook -i /etc/ansible/agent/inventory/zabbix_agent_weekly.txt /etc/ansible/agent/zabbix.yml >/usr/local/etc/scripts/temp/zabbix_agent_weekly_ansible.log 2>&1

cat /usr/local/etc/scripts/temp/zabbix_agent_weekly_ansible.log |awk '/PLAY RECAP/,0'|mail -r ZBX@sap.com -s "Weekly zabbix agent congiuration Deployment status from Ansible - `hostname`" $email
#nodecont=`cat /etc/ansible/agent/inventory/zabbix_agent_weekly.txt|wc -l`
#playcont=`cat /usr/local/etc/scripts/temp/zabbix_agent_weekly_ansible.log|awk '/PLAY RECAP/,0'|wc -l`
#if [ $nodecont -ne $playcont ]
#then
#echo "count is not machineg"
#fi
