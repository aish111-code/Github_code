#!/bin/bash

zabbixdb="zabbix"
dumpdir="/mysqlbackup/dbdumps"
workdir="work"
days_to_keep=3
starttime=$(date "+%Y-%m-%d_%H.%M.%S")
statfile=config_restore_stats

#zabbixserver=127.0.0.1
#zabbixhost="Zabbix server"
#zabbixtroubleitemkey=dr_database_restore_problems
#zabbixokitemkey=dr_database_restore_ping
zabbixsender="/usr/local/bin/zabbix_sender"

fail() {
        echo -e "\n$1"
        $zabbixsender -z $zabbixserver -s "$zabbixhost" -p 10051 -k $zabbixtroubleitemkey -o "$1"
        exit 1
}

timing() {
        case "$1" in
                start)
                        let START_$2=$(date +%s)
                        ;;
                stop)
                        let TOTALTIME=$(date +%s)-START_$2
                        if [ "$3" == "short" ]; then
                                echo $TOTALTIME
                                return
                        fi
                        let TOTALMINUTES=TOTALTIME/60
                        let TOTALSECONDS=TOTALTIME%60
                        echo "$TOTALMINUTES:$TOTALSECONDS"
                        ;;
                esac
}

# ToDo rsync commands
#rsync -a --rsh=ssh zabbix-rsync@<Zabbix_DR_IP>:/<path_to_dump>/dumps/ /<path_to_dump>/dumps/ > /dev/null 2>&1

# copy last file to work directory
lastfile=$(ls /mysqlbackup/dbdumps/zabbix_configuration-*.bz2 | tail -n 1)
cp "$lastfile" /mysqlbackup/dbdumps/work/
lastdumpfile=`echo $lastfile | sed 's/.bz2//'`
lastdumpfilebase=`basename $lastdumpfile`

# unzip last dump
bzip2 -d /mysqlbackup/dbdumps/work/zabbix_configuration-*.sql.bz2 || fail "can't unzip config dump"

# restore dump
timing start db_restore
mysql "$zabbixdb" <  /mysqlbackup/dbdumps/work/$lastdumpfilebase || fail "can't restore config dump"
time_spent=$(timing stop db_restore)

echo "$starttime $time_spent" >> $statfile

rm /mysqlbackup/dbdumps/work/zabbix_configuration-*.sql || fail "can't remove old config dump"

find "$dumpdir" -type f -mtime +"$days_to_keep" -exec rm {} \; || fail "can't remove previous config dumps"

# by now we assume that all was ok and ping zabbix server on that, too


