#!/bin/bash

zabbixdb="zabbix"
dumpdir="/mysqlbackup/dbdumps"
days_to_keep=3
starttime=$(date "+%Y-%m-%d_%H.%M.%S")
statfile=config_dump_stats

#zabbixserver=127.0.0.1
#zabbixhost="Zabbix server"
#zabbixtroubleitemkey=dr_database_dump_problems
#zabbixokitemkey=dr_database_dump_ping
#zabbixsender="/usr/local/bin/zabbix_sender"

config_tables=(actions
applications
application_template
conditions
config
dbversion
dchecks
dhosts
drules
dservices
expressions
functions
globalmacro
globalvars
graph_discovery
graph_theme
graphs
graphs_items
groups
group_discovery
group_prototype
host_inventory
hostmacro
hosts
hosts_groups
hosts_templates
host_discovery
httpstep
httpstepitem
httptest
httptestitem
icon_map
icon_mapping
images
interface
interface_discovery
item_discovery
items
items_applications
maintenances
maintenances_groups
maintenances_hosts
maintenances_windows
mappings
media
media_type
opcommand
opcommand_grp
opcommand_hst
opconditions
operations
opgroup
opmessage
opmessage_grp
opmessage_usr
optemplate
profiles
regexps
rights
screens
screens_items
scripts
services
services_links
services_times
slides
slideshows
sysmap_element_url
sysmap_url
sysmaps
sysmaps_elements
sysmaps_link_triggers
sysmaps_links
timeperiods
trigger_depends
trigger_discovery
triggers
users
users_groups
usrgrp
valuemaps)

fail() {
        echo -e "\n$1"
        $zabbixsender -z $zabbixserver -s "$zabbixhost" -k $zabbixtroubleitemkey -o "$1"
        exit 1
}

timing() {
        case "$1" in
                start)
                        let START_$2=$(date +%s)
                        ;;
                stop)
                        let TOTALTIME=$(date +%s)-START_$2
                        if [ "$3" == "short" ]; then
                                echo $TOTALTIME
                                return
                        fi
                        let TOTALMINUTES=TOTALTIME/60
                        let TOTALSECONDS=TOTALTIME%60
                        echo "$TOTALMINUTES:$TOTALSECONDS"
                        ;;
                esac
}

dumpfile="$dumpdir"/zabbix_configuration-${starttime}.sql.bz2

timing start db_dump
mysqldump "$zabbixdb" --extended-insert --single-transaction --tables "${config_tables[@]}" | bzip2 -9 > "$dumpfile" || fail "can't create config table dump"
time_spent=$(timing stop db_dump)

filesize=$(stat -c "%s" "$dumpfile") || fail "can't obtain dump file size"

echo "$starttime $filesize $time_spent" >> $statfile

find "$dumpdir" -type f -mtime +"$days_to_keep" -exec rm {} \; || fail "can't remove previous config dumps"

# by now we assume that all was ok and ping zabbix server on that, too

#$zabbixsender -z $zabbixserver -s "$zabbixhost" -k $zabbixokitemkey -o "1"

