#!/usr/bin/python
##
##input to this script is host_discovered group and monsoon group
##loop through the hosts
import sys
sys.path.append('/usr/local/etc/zbxAdm/2.2/lib/zbxpylib')
from zabbix_api import ZabbixAPI
from pprint import pprint
from RSM import parseConfig
import re
import datetime
#import logging

if len(sys.argv) < 2:
    print("Provide datacenter to remove maintenance windows")
    sys.exit()



def main():
    configFile = "/usr/local/etc/zbxAdm/2.2/conf/zbx.conf"
    try:
        dc = sys.argv[1].upper()
        if dc == 'DC4':
            configFile = configFile
        else:
            configFile = "/usr/local/etc/zbxAdm/2.2/conf/zbx" + dc + ".conf"
    except:
        configFile = configFile

    print("configFile to use %s" % (configFile) )
    config = parseConfig(configFile)


    dt = datetime.datetime.now()
    current_timestamp = dt.strftime("%s")
    zabbix = init_zabbix_object(config)
    options = { 'output' : 'extend', 'selectTimeperiods': 'extend' }
    result = zabbix.maintenance.get(options)
    #pprint(result)
    #sys.exit()
    for rowno, each_maintenance in enumerate(result):
        print(each_maintenance['maintenanceid'],each_maintenance['name'],each_maintenance['active_since'],each_maintenance['active_till'])
        #if rowno == 1000:
        #     break
        if ( current_timestamp > each_maintenance['active_till'] ) :
            #print("maintenance window %s will be removed" % (each_maintenance['name']))
            options = [ each_maintenance['maintenanceid'] ]
            try:
            #if each_maintenance['name'].startswith('Rundeck_'):
               zabbix.maintenance.delete(options)
            except AttributeError:
               assert "Could not remove maintenance window %s" % (each_maintenance['name'])



def init_zabbix_object(config):
    with open('/etc/hosts','r') as fh:
        env = ''

        for line in fh.readline():
            if line != "" and re.match('lab', line):
                env = 'qa'
                break
        else:
            env = 'prod'


        url    = config.get(env,'url')
        user   = config.get(env,'user')
        passwd = config.get(env,'password')

        zabbix = ZabbixAPI(server=url)
        zabbix.login(user,passwd)
        print("Connected to Zabbix API Version %s" % zabbix.api_version())

    return zabbix



if __name__ == '__main__':
    main()
