#!/bin/bash

##############################################################
# Script to generate report of host not responding alerts for Platform services Team
# Author : Sandeep M.R
# Date : 5/25/2015
##############################################################

#email="s.renuka@sap.com,patrick.presto@sap.com,amit.kumar15@sap.com,rinkesh.singh@sap.com,sajeesh.mohanan@sap.com,fiyas.ahamed@sap.com"
#email="s.renuka@sap.com"
email="amiya.krishna@sap.com,sandeep.roger.binny@sap.com,harsha.raju.b.c@sap.com,abhijit.sabhapandit@sap.com,s.renuka@sap.com,patrick.presto@sap.com,amit.kumar15@sap.com,rinkesh.singh@sap.com,fiyas.ahamed@sap.com,sajeesh.mohanan.adiyodi.chettayil@sap.com,chris.hunt@sap.com,haiou.fu@sap.com,csaba.seres@sap.com,ferenc.kuhlburger@sap.com,jayavardhan.jandhyala@sap.com,monitoring@sap.com"

cd /usr/local/etc/zbxAdm/2.2/scripts

#/usr/local/etc/zbxAdm/2.2/scripts/report.pl -getAging 'All-SFTP' > /var/log/zabbix/plt-aging.txt

/usr/local/etc/zbxAdm/2.2/scripts/report.pl -trigger 'System {HOST.NAME} is not responding' | grep -v "hosts-decommissioned" > /var/log/zabbix/plt-hostnotresponding.txt

c=`wc -l /var/log/zabbix/plt-hostnotresponding.txt | awk '{print $1}'`
cat  /var/log/zabbix/plt-hostnotresponding.txt | mailx -r "monitoring@sap.com" -s "ACTION REQUIRED : HCM - Host Not Responding Alerts Report - $c alerts" $email 
