#!/usr/bin/perl

############################################################################
# Author        : Pradip Kumar, Nandhini Chander
# Purpose       : Zabbix 2.4 Audit script to find hosts, missing OS templates 
# Reviewer      : Sandeep M.R 
# Version       : 30th May 2016 - Initial code
############################################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

# Local variable declaration

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLDs qw(pfail);
use SFSF::Log qw(addtoLogfile);
use SFSF::Trigger qw(getlocaltriggers deletelocaltriggers get_triggerobj gettriggerobj_val);
use SFSF::Item qw(getLocalItems deletelocalitems);
use SFSF::Web qw(getlocalwebmonitoring deletelocalwebmonitoring);
use SFSF::Discovery qw(getlocaldiscoveryrule deletelocaldiscoveryrule);
use SFSF::Host  qw(gethostnames_fromHostgroup gettechnames_fromHostgroup);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);


# Detect running env and set the connection variables

open(my $fh,'< /etc/hosts');
my $env;

while (my $line = <$fh>)
{
    chomp $line;
   if ($line ne "" and $line =~ m/lab/ )
   {	
       $env = 'qa';
   }
   else { 
      $env = 'prod' ; 
   }
}	

# Load API properites file

my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


my $localObjectsReport = "/tmp/localObjectsReport.txt";
open FG, ">", $localObjectsReport or die "Can not open $localObjectsReport to write:$! \n";

select(FG);
my @excludeGrps = ( 'hosts-decommissioned' );

my %excludeGrpHash;
my %excludeTmpltHash;
my $count = 0;

%excludeGrpHash = map { $_ => 1 } @excludeGrps;
my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

my %args;

GetOptions(\%args, "localItems", "localTriggers","localDiscoverRules","localWebMonitoring","hostGroup=s",) or die "Invalid arguments \n";
die "Missing options -
                -localItems  
                   OR/AND
                -localTriggers 
                   OR/AND
                -localDiscoverRules 
                   OR/AND
                -localWebMonitoring 
                   AND
                -hostGroup 'all' OR <group name> \n" unless %args;

##get all hosts that do not have OS templates
findLocalObjects( $zabbix, $args{hostGroup} );

sub findLocalObjects {
    my ( $zabbix, $hostGroup ) = @_;

    
    my @hosts;
    if( $hostGroup && $hostGroup ne 'all' ) {    
        my  @hgroup = get_hostgroup_obj($zabbix,{'name' => [$hostGroup]});
        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };
        # Get Array of Hash keys from hostgroup object that match regex

        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
        # Get hostnames from Hostgroup
        my @hostsOnly = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
        die "No hosts found" unless defined $hostsOnly[0];
        foreach my $name ( @hostsOnly ) {
            push @hosts, { 'host' => $name, 'group' => $hostGroup };
        }

    }
    else{
        my %tfilter = ( 'output' => ['hostid', 'name','status'], "selectGroups" => "extend", "selectParentTemplates" => [ 'templateid', 'name'] );
        my $params = {%tfilter};
        my $api_result = $zabbix->raw('host','get', $params);
        HOSTLOOP:
        foreach my $hashRef ( @$api_result ) {
            my $name     = $hashRef->{name};
            my $status   = $hashRef->{status};  ###0=enabled 1=disabled host
            next HOSTLOOP if ( $status == 1 );
            my @hostGroupsArr = @{$hashRef->{groups}};
            my $childGrpname = $hostGroupsArr[-1]->{name};
            foreach my $hGrpRef ( @{$hashRef->{groups}} ) {
                my $hGrpname = $hGrpRef->{name};
                ###If host is part of exclude groups ( e.g. hosts-decommissioned ) then skip that host
                if ( exists $excludeGrpHash{$hGrpname} ) {
                     next HOSTLOOP;
                }
                
            }
            push @hosts, { 'host' => $name, 'group' => $childGrpname };
        }
    }

    my %resultsDS;
    my $myresult;
    


    HOSTLOOP:
    foreach my $hostData ( @hosts) {

        my $host = $hostData->{host};
        my $hostGroup = $hostData->{group};
        if( exists $args{"localItems"} ) {
            $myresult = SFSF::Item::getLocalItems($zabbix,$host);
            createResultantDS($host, $hostGroup, $myresult, 'localItems', \%resultsDS);
        }

        if( exists $args{"localTriggers"} ) {
            $myresult = getLocalTriggers($zabbix,$host);
            createResultantDS($host, $hostGroup, $myresult, 'localTriggers', \%resultsDS);
        }

        if( exists $args{"localDiscoverRules"} ) {
            $myresult = SFSF::Discovery::getlocaldiscoveryrule($zabbix,$host);
            createResultantDS($host, $hostGroup, $myresult, 'localDR', \%resultsDS);
        }

        if( exists $args{"localWebMonitoring"} ) {
            $myresult = SFSF::Web::getlocalwebmonitoring($zabbix,$host);
            createResultantDS($host, $hostGroup, $myresult, 'localWM', \%resultsDS);
        }
        
    }

    no warnings; ##suppress warnings if some local objects are not found
    if( exists $resultsDS{localItems} && scalar @{$resultsDS{localItems}} ) {
        format ITEM_HEADER =
==================================================================================================================================================================================================
    Report for Local Items
==================================================================================================================================================================================================
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @>>>>>>>>>>>>  @>>>>>>>>>>  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        "|HOST|", "|HOSTGROUP_NAME|", "|STATUS|", "|ITEMID|", "|KEY|", "|NAME|"
.
        $~ = 'ITEM_HEADER';
        write ;
    
        $~ = 'REPORT_ITEMS';
        foreach my $localItem ( @{$resultsDS{localItems}} ) {
            format REPORT_ITEMS =
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @>>>>>>>>>>>>  @>>>>>>>>>>  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
            @$localItem;
.
            write ;
        }
    }

 
    if( exists $resultsDS{localTriggers} && scalar @{$resultsDS{localTriggers}} ) {
        format TRIGGER_HEADER =
==================================================================================================================================================================================================
    Report for Local Triggers
==================================================================================================================================================================================================
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @<<<<<<<<<<<<  @<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        "|HOST|", "|HOSTGROUP_NAME|", "|STATUS|", "|TRIGGERID|", "|DESCRIPTION|"
.
        $~ = 'TRIGGER_HEADER';
        write ;
    
        $~ = 'REPORT_TRIGGERS';
        foreach my $localTrigger ( @{$resultsDS{localTriggers}} ) {
            format REPORT_TRIGGERS =
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @<<<<<<<<<<<<  @<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
            @$localTrigger;
.
            write ;
        }
    }

    if( exists $resultsDS{localDR} && scalar @{$resultsDS{localDR}} ) {
        format DR_HEADER =
==================================================================================================================================================================================================
    Report for Local Discovery Rules
==================================================================================================================================================================================================
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @>>>>>>>>>>>>  @>>>>>>>>>>  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        "|HOST|", "|HOSTGROUP_NAME|", "|STATUS|", "|ITEMID|", "|KEY|", "|NAME|"
.
        $~ = 'DR_HEADER';
        write ;
    
        $~ = 'REPORT_DR';
        foreach my $localDRules ( @{$resultsDS{localDR}} ) {
            format REPORT_DR =
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @>>>>>>>>>>>>  @>>>>>>>>>>  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
             @$localDRules;
.
             write ;
        }
    }


    if( exists $resultsDS{localWM} && scalar @{$resultsDS{localWM}} ) {
        format WM_HEADER =
==================================================================================================================================================================================================
    Report for Local Web Scenarios
==================================================================================================================================================================================================
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @>>>>>>>>>>>>  @>>>>>>>>>>  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        "|HOST|", "|HOSTGROUP_NAME|", "|STATUS|", "|ITEMID|", "|KEY|", "|NAME|"
.
        $~ = 'WM_HEADER';
        write ;
    
        $~ = 'REPORT_WM';
        foreach my $localWMonitors ( @{$resultsDS{localWM}} ) {
            format REPORT_WM =
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<< @>>>>>>>>>>>>  @>>>>>>>>>>  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
             @$localWMonitors;
.
             write ;
        }
    }
    return;
}

close(FG);

sub createResultantDS {
    my ( $host, $hostGroup, $myresult, $objectType, $resultsDSRef ) = @_;

    my %hash_status = ('0' => 'Enabled','1'=>'Disabled');
    my %hash_temp = ('0' => 'LocalItem','1'=>'TemplateItem');

    if( ref $myresult eq 'HASH' && ! scalar keys %$myresult ) {
        return;
    }
    elsif( ref $myresult eq 'HASH' && scalar keys %$myresult ) {
        if( $objectType eq 'localItems' ) {
            push @{$resultsDSRef->{localItems}}, [ $host, $hostGroup, $hash_status{$myresult->{'status'}},$myresult->{'itemid'},$myresult->{'key_'},$myresult->{'name'} ];
        }
        elsif( $objectType eq 'localTriggers' ) {
            push @{$resultsDSRef->{localTriggers}}, [ $host, $hostGroup, $hash_status{$myresult->{'status'}},$myresult->{'triggerid'},$myresult->{'description'},$myresult->{'Expression'} ];
        }
        elsif( $objectType eq 'localDR' ) {
            push @{$resultsDSRef->{localDR}}, [ $host, $hostGroup, $hash_status{$myresult->{'status'}},$myresult->{'itemid'},$myresult->{'key_'},$myresult->{'name'} ];
        }
        elsif( $objectType eq 'localWM' ) {
            push @{$resultsDSRef->{localWM}}, [ $host, $hostGroup, $hash_status{$myresult->{'status'}},$myresult->{'itemid'},$myresult->{'key_'},$myresult->{'name'} ];
        }
    }
    elsif( ref $myresult eq 'ARRAY' ) {
        foreach my $res ( @{$myresult} ) {
            if( $objectType eq 'localItems' ) {
                push @{$resultsDSRef->{localItems}}, [ $host, $hostGroup, $hash_status{$res->{'status'}},$res->{'itemid'},$res->{'key_'},$res->{'name'} ];
            }
            elsif( $objectType eq 'localTriggers' ) {
                push @{$resultsDSRef->{localTriggers}}, [ $host, $hostGroup, $hash_status{$res->{'status'}},$res->{'triggerid'},$res->{'description'},$res->{'Expression'} ];
            }
            elsif( $objectType eq 'localDR' ) {
                push @{$resultsDSRef->{localDR}}, [ $host, $hostGroup, $hash_status{$res->{'status'}},$res->{'itemid'},$res->{'key_'},$res->{'name'} ];
            }  
            elsif( $objectType eq 'localWM' ) {
                push @{$resultsDSRef->{localWM}}, [ $host, $hostGroup, $hash_status{$res->{'status'}},$res->{'itemid'},$res->{'key_'},$res->{'name'} ];
            }
        }
    }
    
    return; 
}


sub getLocalTriggers {
    my ( $zabbix, $host ) = @_;

    my $options = {'output' =>'extend','host' =>$host, 'inherited' => '0','filter' =>{'flags' => '0'}};
    my $myresult = $zabbix->raw('trigger','get',$options);

    return $myresult;
}

