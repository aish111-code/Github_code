#!/usr/bin/perl
#####
##################################################################
# Author        : Sandeep M.R
# Purpose       : Zabbix 2.2 reporting script
# Reviewer      : Patrick Presto
# Version       : Jan 20th 2015 - Initial code
#               : Jan 26th 2015 - Added report.pm,-hostinventory option
#               : May 6th 2015 - Added -item_status function (Vikky Omkar)
#		: Sep 11th 2015 - Added TriggerReport function (Vikky Omkar)
####################################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

# Local variable declaration

my @hostname;

# Add Modules and functions into local scope

	use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
	use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
	use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
	use TLDs qw(pfail);

	use SFSF::Host qw(gettechnames_fromHostgroup get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os);
	use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
	use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
	use SFSF::Log qw(addtoLogfile);
	use SFSF::Trigger qw(get_triggerobj gettriggerobj_val);
	use SFSF::Report qw(getTrigger gethostInventory  getgroupsInventory getHistory get_Item_Last_Value get_host_name getAging getevents);

# Detect running env and set the connection variables

	open(my $fh,'< /etc/hosts');
	my $env;

	while (my $line = <$fh>)
	{
   		chomp $line;
   		if ($line ne "" and $line =~ m/lab/ )
        	{	
        		$env = 'qa';
        	}
    		else { $env = 'prod' ; }
	}	

# Load API properites file

	my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
  	pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
  	pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
  	pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


#=pod
my %args;
my @alertname;

        GetOptions(\%args,"trigger=s","hostinventory","groupsinventory","history=s","item_status=s","getAging=s","TriggerReport","discovery_item_status=s") or die "Invalid arguments ! Required Param: $0 -trigger -hostinventory -groupsinventory -history -item_status -getAging  -TriggerReport \n";
        die "Missing options :-
			-trigger <TriggerName> 
			-hostinventory 
			-groupsinventory 
			-history < HostGroup >  < Key >  < TimeFrom >  < TimeTill >
			-item_status < HostGroup >  < Item Key >
			-getAging  < HostGroup >
			-TriggerReport nd (n->No. of days)
                        -discovery_item_status < HostGroup > < Item Key >\n" unless %args;

	my @key = keys (%args);

# Connect to Zabbix API and write authid to /tmp/hostname.tmp
	
	my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

	switch ($key[0]){
	
	case "trigger"   {

			 @alertname = values (%args);
			 getTrigger($zabbix,$alertname[0]);   # call getTrigger function to list all active alerts

			}

	case "hostinventory" {


			gethostInventory($zabbix);


			 }

	case "getAging"   {

                        my @groupname = values (%args);
                        getAging($zabbix,$groupname[0]);

                        }


	case "groupsinventory" {

			getgroupsInventory($zabbix);
				}

	case "TriggerReport" {
                        my $days = $ARGV[0];
                        chop($days);
                        my $date = `date`;
                        my $starttime = str2time($date);
                        my $endtime = ($starttime -(24*60*60*$days));

                         # Get Hostgroup object
                        my @hgroup = get_hostgroup_obj($zabbix);
                        die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };

                        # Get Array of Hash keys from hostgroup object that match regex

                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');
                        #print Dumper(@hgroup_id);

                        getevents($zabbix,$starttime,$endtime,\@hgroup_id);

                                }


	case "history"  {

			my @historyvalues = values (%args);
		#	print @historyvalues;
			my $h_group = $historyvalues[0];
			my $h_key = $ARGV[0];
		        my $h_timefrom = $ARGV[1];
			my $h_timetill = $ARGV[2];

			#print "\n group $h_group key $h_key from $h_timefrom till $h_timetill\n";
			
			getHistory($zabbix,$h_group,$h_key,$h_timefrom,$h_timetill);

			}

	case "item_status" {
                         my @h_group = values (%args);
                         my @item_name = $ARGV[0];
                         my @lastvalue;
                         my @status;
                         my @state;
                         my @hostid;
                         my @host_name;
                         my @host_techname;
                         my @hgroup;
                         my @host;
                         my @active_hostid;
                         my %allhgroup1;
                         my %allhgroup2;
                         my %allhgroup3;
                         my %allhgroup4;
                         my %allhgroup5;

                         my %hash_status = ('0' => 'enabled','1'=>'Disabled');
                         my %hash_state = ('0' => 'SUPPORTED','1'=>'NOTSUPPORTED');
                        # Get Hostgroup object
                            if("$h_group[0]" eq "all")
                                {
                                   @host = gettechnames_fromHostgroup($zabbix);
                                   die "No hosts found" unless defined $host[0];
                                }

                             else
                                {
                                   # Get Hostgroup object
                                   @hgroup = get_hostgroup_obj($zabbix,{'name' => \@h_group});
                                   die "No Hostgroups Found Matching @hgroup" unless %{ $hgroup[0] };

                                    # Get Array of Hash keys from hostgroup object that match regex

                                    my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');

                                    # Get hostnames from Hostgroup
                                    @host = gettechnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
                                    die "No hosts found" unless defined $host[0];
                                }

                        # Zabbix API call to get last value of item
                        my $value = get_Item_Last_Value($zabbix,\@host,$item_name[0]);
                        if(ref $value eq 'HASH' && ! scalar keys %$value ) {
                             print "No data found for item key $item_name[0] \n";
                             exit 1;
                        }
                         

                        my $value_count = ref $value eq 'HASH' || scalar @$value;

                        my @hash_arr;

                                if ( $value_count > 1 )
                                        {
                                           @hash_arr=@{$value};
                                                foreach my $href(@hash_arr)
                                                   {
                                                        my %hash = %$href;
                                                        push(@lastvalue,$hash{'lastvalue'});
                                                        push(@status,$hash{'status'});
                                                        push(@hostid,$hash{'hostid'});
                                                        push(@state,$hash{'state'});
                                                   }
                                        }
                                else
                                        {

                                        push(@lastvalue,$value->{'lastvalue'});
                                        push(@status,$value->{'status'});
                                        push(@hostid,$value->{'hostid'});
                                        push(@state,$value->{'state'});

                                        }

                        my $host_name = get_host_name($zabbix,\@hostid);
                        my %host_name_hash;
                        #print Dumper($host_name);
                        my @unsortednonall;
                        my @unsortedall;
                        my %host_techname_hash;
                        my $host_count = ref $host_name eq 'HASH' || scalar @$host_name;
                        my @host_name_arr;
                           if ( $host_count > 1 )
                                 {
                                     @host_name_arr=@{$host_name};

                                      foreach my $href(@host_name_arr)
                                           {
                                                  my %hash_2 = %$href;
                                                  @unsortednonall = ();
                                                  @unsortedall = ();
                                                  my $groupcount = @{$hash_2{'groups'}};
                                                        foreach my $g (@{$hash_2{'groups'}})
                                                                {
                                                                        if($g->{'name'}!~/All|all/)
                                                                                {
                                                                                        push(@unsortednonall,$g->{'name'});
                                                                                        #if(  $groupcount eq 1 ) { push(@unsortedarray,$g->{'name'});}
                                                                                }
                                                                        else {
                                                                                push (@unsortedall,$g->{'name'});
                                                                                }
                                                                }
                                                        my @sortednonall =();
                                                         my @sortedall =();
                                                        @sortednonall = sort { length $a <=> length $b } @unsortednonall;
                                                        @sortedall = sort { length $a <=> length $b } @unsortedall;

                                                        my @sortedarray = (@sortednonall,@sortedall);
                                                        my $gcount = @sortedarray;
                                                        my $i='0';
                                                        my $lastgroupname;

                                                        foreach my $g (@sortedarray)
                                                                {
                                                                        $i++;

                                                                         if ( $i eq $gcount ) { $lastgroupname=$g; }

                                                                }

                                                        while ( $gcount lt '5' )
                                                                {

                                                                        push (@sortedarray,$lastgroupname);
                                                                        $gcount++;

                                                                }
#print " @sortedarray\n";



                                                  $allhgroup1{$hash_2{'hostid'}}=$sortedarray[0];
                                                  $allhgroup2{$hash_2{'hostid'}}=$sortedarray[1];
                                                  $allhgroup3{$hash_2{'hostid'}}=$sortedarray[2];
                                                  $allhgroup4{$hash_2{'hostid'}}=$sortedarray[3];
                                                  $allhgroup5{$hash_2{'hostid'}}=$sortedarray[4];
                                                  $host_name_hash{$hash_2{'hostid'}}=$hash_2{'name'};
                                                  push(@host_name,$hash_2{'name'});
                                                  $host_techname_hash{$hash_2{'hostid'}}=$hash_2{'host'};
                                                  push(@host_techname,$hash_2{'host'});
                                           }

                                 }

                           else
                                {
                                     $host_name_hash{$host_name->{'hostid'}}=$host_name->{'name'};
                                     push(@host_name,$host_name->{'name'});
                                     $host_techname_hash{$host_name->{'hostid'}}=$host_name->{'host'};
                                     push(@host_techname,$host_name->{'host'});

                                }

                        if("$h_group[0]" eq "all")
                                { print "Calendar_date,HOSTNAME,Itemkey,Itemvalue,Itemstate,Hostgroup1,Hostgroup2,Hostgroup3,Hostgroup4,Hostgroup5 \n";
                                }

                        else
                                {
                                print " HostGroup  |  Item_Key  |  Hostname  |  Host_tech_Name  |  Item_status  | Item_state  |  Item_Last_Value \n";
                                }


			my $calendardate=`date +"%Y_CW-%V"`;
                        chomp($calendardate);
                         for my $i(0..$#host_techname)
                                 {  if($host_name_hash{$hostid[$i]})
                                                {
                                                        if("$h_group[0]" eq "all")
                                                                {
                                                                         print "$calendardate,$host_name_hash{$hostid[$i]},$item_name[0],$lastvalue[$i],$hash_state{$state[$i]},$allhgroup1{$hostid[$i]},$allhgroup2{$hostid[$i]},$allhgroup3{$hostid[$i]},$allhgroup4{$hostid[$i]},$allhgroup5{$hostid[$i]}\n";
                                                                }
                                                        else {
                                                                        print "$h_group[0] | $item_name[0] | $host_name_hash{$hostid[$i]} | $host_techname_hash{$hostid[$i]} | $hash_status{$status[$i]} | $hash_state{$state[$i]} | $lastvalue[$i]\n";
                                                                }
                                                }
                                  }

                                        print "\n";

                    }
            case "discovery_item_status" {
                        print " HostGroup  |  Item_Key  |  Hostname  |  Host_tech_Name  |  Item_status  | Item_state  \n";
                        my $h_group = $args{'discovery_item_status'};
                        my $item_name = $ARGV[0];

                        my %hash_status = ('0' => 'enabled','1'=>'Disabled');
                        my %hash_state = ('0' => 'SUPPORTED','1'=>'NOTSUPPORTED');
                        # Get Hostgroup object
                        my @hgroup = get_hostgroup_obj($zabbix,{'name' => [ $h_group ]} );
                        die "No Hostgroups Found Matching $h_group" if ( ! @hgroup && ! defined $hgroup[0] );

                        # Get Array of Hash keys from hostgroup object that match regex
                        my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');

                        # Get hostnames from Hostgroup
                        my @hostObjs = getHostsData($zabbix,$hgroup_id[0]{'groupid'});
                        die "No hosts found" unless defined $hostObjs[0];
                        foreach my $hostObj ( @hostObjs ) {
                            my $hostId = $hostObj->{hostId};
                            my $hostTechName = $hostObj->{techname};
                            my $hostName = $hostObj->{hostname};
                            my $value = get_discovery_data($zabbix,[$hostId],$item_name);
                            next if ( ! defined $value || ! scalar keys %$value);
                            if ( ref $value eq 'ARRAY' ) {
                                foreach my $href(@$value) {
                                    print "$h_group | $item_name | $hostName | $hostTechName | $hash_status{$href->{'status'}} | $hash_state{$href->{'state'}} \n";
                                }
                            }
                            else {
                                print "$h_group | $item_name | $hostName | $hostTechName | $hash_status{$value->{'status'}} | $hash_state{$value->{'state'}} \n";
                            }
                        }
                    }

   }

sub get_discovery_data {

    my $zabbix = $_[0];
    my @hostId = @{$_[1]};
    my $item = $_[2];
    my $options = {'output' => 'extend', 'hostids' => \@hostId, 'search' => {'key_' => $item } };
    my $my_result = $zabbix->raw('discoveryrule','get',$options);
    return $my_result;

}


sub getHostsData{
    my $zabbix = $_[0];
    my $hg_id = $_[1];

    my @hostObj;
    my $options = {'output' => 'extend', 'groupids' => [$hg_id],'filter' => {'status' => '0'} };
    my $myresult = $zabbix->raw('host','get',$options);
    if ( ref($myresult) eq 'ARRAY' ){
        foreach my $h (@{$myresult}){
            push @hostObj,{ 'hostId' => $h->{'hostid'}, 'techname' => $h->{'host'}, 'hostname' => $h->{name} };
        }
    } else{
        push @hostObj, { 'hostId' => $myresult->{hostid}, 'techname' => $myresult->{'host'}, 'hostname' => $myresult->{'name'} };
    }
    return @hostObj;

}
