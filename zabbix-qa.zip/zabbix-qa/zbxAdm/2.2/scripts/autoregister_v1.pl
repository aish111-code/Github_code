#!/usr/bin/perl -w

###########################################################
# Author  : Patrick Presto, Sandeep M.R
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2015
############################################################
##

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration

my @hostid;
my $os_template;
my $slr_host;
my $slr_hostgrp;
my $slr_template;
my $solarwinds_home  = "/usr/local/etc/zbxAdm/2.2/scripts/solarwinds_api/";
# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

# Load API properites file

#my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');

# Get hostgroup from commandline

my @products= qw(BIZX-DB BIZX LMS APIGEE BOOMI SPLUNK OPTIER JAM J2W MOB HANA WFA );
my $product_templates={
'BIZX-DB' => 'T_HANA_Linux',
'BIZX' => 'T_BizX_Linux',
'LMS' => 'T_LMS_Linux',
'APIGEE' => 'T_APIGEE_Linux',
'BOOMI' => 'T_BOOMI_Linux',
'SPLUNK' => 'T_SPLUNK_Linux',
'OPTIER' => 'T_OPTIER_Linux',
'JAM' => 'T_JAM_Linux',
'J2W' => 'T_J2W_Linux',
'MOB' => 'T_MOB_Linux',
'HANA' => 'T_HANA_Linux',
'WFA' => 'T_WFA_Linux'
};
my %args;
my @host;
my @hostgroup;
my $maintenance_host_groupid = 4405;  #'All-Hosts-Maintenance';

GetOptions(\%args,"validategroup=s","updategroup=s","validatehost=s","updatehost=s","update_visible_name=s", "disable", "addmaintenance", "deletemaintenance", "dc=s") or die "Invalid arguments ! Required Param: $0 -validategroup or -updategroup <hostgroup> or -validatehost <host> <-disable> or updatehost <host> <-disable> or -update_visible_name  <hostname|visiblename>\n";
        die "
             ************************************************************************************************************************************************
             WARNING: IF YOU ARE EXECUTING THIS SCRIPT FROM ONE DC AND INTEND TO CONNECT TO OTHER DC, THEN YOU MUST PROVIDE THAT DETAILS IN THE 'dc' PARAMETER
             ************************************************************************************************************************************************

             Missing options :-
                        -validategroup <hostgroup> (OR) -updategroup <hostgroup> [ -disable | -addmaintenance | -deletemaintenance ] [ -dc DC22 ]
                        -validatehost  <host> (OR) -updatehost  <host> [ -disable | -addmaintenance | -deletemaintenance ] [ -dc DC22 ]
                        -update_visible_name  <hostname|visiblename>

                        Example: $0 -updatehost hostA
                               OR
                        $0 -updatehost hostA -disable
                               OR
                        $0 -updatehost hostA -disable -dc DC22
                               OR
                        $0 -updatehost hostA -addmaintenance \n" unless %args;

        #my @hostgroup = $args{validategroup};


if ( exists $args{dc} && ( uc $args{dc} eq 'DC23' or uc $args{dc} eq 'DC22' or uc $args{dc} eq 'DC42' or uc $args{dc} eq 'DC44' or uc $args{dc} eq 'DC11' or uc $args{dc} eq 'DC48' or uc $args{dc} eq 'DC47' or uc $args{dc} eq 'DC8' or uc $args{dc} eq 'DC10' or uc $args{dc} eq 'DC41' or uc $args{dc} eq 'DC25' )) {
    my $dc = uc $args{dc};
    $configFile = "/usr/local/etc/zbxAdm/2.2/conf/zbx$dc.conf";
}

my $config = get_rsm_config($configFile);
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};

# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

if ( exists $args{validategroup} || exists $args{updategroup} ) {
    @hostgroup = $args{validategroup} || $args{updategroup};

    # Get Hostgroup object
    my @hgroup = get_hostgroup_obj($zabbix,{'name' => \@hostgroup});
    die "No Hostgroups Found Matching @hostgroup" unless %{ $hgroup[0] };

    # Get Array of Hash keys from hostgroup object that match regex

    my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');

    # Get hostnames from Hostgroup
    @host = getHostnames_fromHostgroup($zabbix,$hgroup_id[0]{'groupid'});
    die "No hosts found" unless defined $host[0];

}
elsif ( exists $args{validatehost} || exists $args{updatehost} ){
    @host = $args{validatehost} || $args{updatehost};
}


# Cache names of all existing templates in zabbix

my $file = $config->{'sap'}->{'hostcfg'};

my @templateobj = get_templateobj($zabbix);

my @existingTemplates = get_templateobj_val(\@templateobj,"host");

#print @existingTemplates;


#my @host = values (%args);
#my @host = 'dc13mgtrund01.lab.od.sap.biz';

# Start of regex validation

my @foundTemplates;
my @notfoundTemplates;
my @updatehosts;    # stores hosts that match regex and has all required templates to be mapped existing in zabbix

foreach (@host) {
    my ( $rc, $msg) = check_valid_host($zabbix,$_, $config);
    if( $rc ) {
        print "\n\t$_ $msg\n";
        next;
    }

    my @cgroups = searchHostCfg($_,'','');
    my @templatelist = build_host_template_list($_);
    my ($duplicatePtrn, @hostGrps) = checkDupRegex($_, $config);


    if( $duplicatePtrn ) {
        print "Regex validation failed. Multiple matches found: @hostGrps \n";
        print "Aborting.......\n";
        addtoLogfile("Regex validation failed. Multiple matches found: @hostGrps \n","");
        addtoLogfile("Aborting.......\n","");
        exit 1;
    }

    if (!@templatelist){
        if ( exists $args{validategroup} || exists $args{validatehost} ) {
            @templatelist = "NOMATCH";
            print "\n\t$_ , @cgroups, @templatelist\n";
        }
    }
    else {
        # Code for generating templates matching childgroup_*

        my @childgroup = split ('_',$cgroups[0]);
        my $first = shift @childgroup;
        unshift @childgroup, 'T';
        my $childtemplate = join('_',@childgroup);
        my $childtemplate1 = $childtemplate."_";

        my @found1 = grep(/$childtemplate1/, @existingTemplates );

        #print "\n _ templates found  @found1 \n";

        if (@found1) {
            foreach my $t1 (@found1) {
                push @templatelist,$t1;
            }
        }

        my $dctemplate = 'T_'.$cgroups[0];

        my @found2 = grep(/$dctemplate/, @existingTemplates );

        if (@found2) {
            foreach my $t2 (@found2){
                push @templatelist,$t2;
            }
        }

        # Check if generated template list exists in existingTemplates

        #print @templatelist;


        my $flag = '0';

        foreach my $t1 (@templatelist) {
            if ( $t1 eq 'notemplate' )  {
                $flag = '1';
            }
        }

        if ( $flag eq '0' ) {
            foreach my $t (@templatelist) {
                if ( my @found = grep { $_ eq $t } @existingTemplates ) {
                    push @foundTemplates, $t;
                }
                else {
                    push @notfoundTemplates, $t;
                }
            }
        }

                        # remove template with name notemplate from notfoundTemplates array



        print "\n\tRegex Matched - \t";
        my @uniquefound = uniq(@foundTemplates);
        print "$_ , @cgroups, @uniquefound\n";
        push @updatehosts,$_;


        @foundTemplates = ();
        @notfoundTemplates = ();
        @uniquefound = ();

    }
    @templatelist = ();
}



#=pod
#my @updatehosts="DC13QAAUTOCANDSFAPI01";
#my @updatehosts="DC13BIZX2CFAPP01";
#my @updatehosts="dc13mgtrund01.lab.od.sap.biz";

# Process hosts in updatehosts for updatehost option

if ( exists $args{updategroup} || exists $args{updatehost} ) {
    addHostInAnsibleAgentRun("[all]");
    foreach my $h (@updatehosts) {
        addtoLogfile("---------------------------------","");
        addtoLogfile("Starting AutoRegistration Process","");
        addtoLogfile("Hostname - $h ","");
        $slr_host =0;
        $slr_host = $h;
        # Get hostid

        my %hfilter = ('name' => $h);
        my @hostobj = get_hostobj($zabbix,\%hfilter);
        my @hostid = get_hostobj_val(\@hostobj,"hostid");
        if( ! scalar @hostid ) {
            print "Host Id not found for $h\n";
            addtoLogfile("Host Id not found for $h","");
            next;
        }
        #my %hfilter1 = ('host' => $h,'selectgroups' => 'extend');
        #my @hostobj1 = get_hostobj($zabbix,\%hfilter1);
        #       print Dumper(@hostobj1);

        foreach (@hostid){
            addtoLogfile("Host id - $_ ","");
        }


        if ( exists $args{deletemaintenance} ) {
             if ( is_already_in_maintenance($zabbix, $hostid[0]) ) {
                 delete_from_maintenance($zabbix,$hostid[0]);
             }
             else {
                 print("Host $h not in maintenance\n");
             }
             next;
        }
        # Get Host IP

        my $ip = get_host_ip($zabbix,$hostid[0]);
        addtoLogfile("IP - $ip","");

        # Create IP user macro

        host_create_macro($zabbix,\@hostid,$ip,'{$MY_IP}');
        addtoLogfile("Created MY_IP macro ","");


        # Get OS Type and add OS Template

        my $hostos = get_host_os($zabbix,$hostid[0]);

        my $osflag = '0';

        if ( $hostos =~ qr/Linux/i ){
            $os_template = "T_OS_Linux";
            addtoLogfile("OS - Linux","");
            addHostInAnsibleAgentRun($h);
            $osflag = '1';
        }
        elsif ( $hostos =~ qr/Windows/i ){
            $os_template = "T_OS_Windows";
            addtoLogfile("OS - Windows","");
            $osflag = '1';
        }
        elsif ( $hostos =~ qr/Sun/i ){
            $os_template = "T_OS_Solaris";
            addtoLogfile("OS - Solaris","");
            $osflag = '1';
        }
        else {
            $hostos = "NoOS";
            addtoLogfile("Warning - OS Template Not Added","");
        }


        # Get  matching childgroups

        my @cgroups = searchHostCfg($h,$hostid[0],$ip);
        #print "Child Hostgroups - @cgroups";
        addtoLogfile("Child Hostgroups - @cgroups","");

        $slr_hostgrp =0;
        $slr_hostgrp = $cgroups[0];

        # Generate full list of Hostgroups

        my @getGroups = buildParentHostgroups(@cgroups);
        #print "\nGenerated host groups - @getGroups \n";
        addtoLogfile("Generated host groups - @getGroups","");
        my $hGrp = join(', ', @getGroups);
        my $product;
        TOPLOOP:
        foreach my $tmpProd( @products ) {
            #foreach my $hGrp ( @getGroups ) {
                #if( $hGrp =~ /_(LMS|BOOMI|APIGEE|BIZX|JAM)/ ) {
            if( $hGrp =~ /_${tmpProd}/i ) {
                if ( $os_template eq "T_OS_Linux" ) {
                    if ( $hGrp =~ /hana/i ) {
                       $os_template = $product_templates->{'HANA'};
                    } else {
                       $os_template = $product_templates->{$tmpProd};
                    }
                }
                $product = $tmpProd;
                last TOPLOOP;
            }
            else{
                $product = 'unknown';
            }
            #}
        }



        # Check if hostgroup exists; if not create

        foreach my $hostgroup (@getGroups) {
            if (checkHostgroupExistance($hostgroup) eq "false"){
                createHostgroup($hostgroup);
            }
        }

        # Get list of hostgroup ids

        my @gid = getHostgroupID(@getGroups);
        #print "Group ids - @gid\n";
        addtoLogfile("Group ids - @gid","");


        # Update Host with hostgroupids

        updateHost($zabbix,\@hostid,\@gid);


        # Check JMX Interface; if required, jmxport will have the port details, else will have the value false

        my $jmxport = check_JMX(\@getGroups,$config->{'sap'}->{'jmxcfg'});

        if ( $jmxport eq 'false' ) {
            addtoLogfile("JMX Interface Not required","");
        }
        else{
            #addtoLogfile("JMX Port is $jmxport");
            # create JMX interface
            my $result = host_check_jmxinterface($zabbix,$hostid[0],$ip,$jmxport);
            if ( $result eq "false" ) {
                host_create_jmxinterface($zabbix,$result,$hostid[0],$ip,$jmxport);
                addtoLogfile("JMX Interface added - Port $jmxport","");
            }
            else {
                addtoLogfile("JMX Interface Not required","");
            }
        }

        # Generate template list

        my @templatelist = build_host_template_list($h);

        my $tflag = '0';

        foreach my $t2 (@templatelist){
            if ( $t2 eq 'notemplate' )  {
                $tflag = '1';
            }
        }

        if ( $tflag eq '1' && $osflag eq '1' ) {
            @templatelist = ();
            if ( $hostos ne "NoOS" ) {
                push @templatelist, $os_template;
            }
        }
        else{
            if ( $hostos ne "NoOS" ) {
                push @templatelist, $os_template;
            }
        }


        #addtoLogfile("Generated Templates - @templatelist");

        # code to add _ templates

        my @childgroup = split ('_',$cgroups[0]);
        my $first = shift @childgroup;
        unshift @childgroup, 'T';
        my $childtemplate = join('_',@childgroup);
        my $childtemplate1 = $childtemplate."_";

        my @found1 = grep(/$childtemplate1/, @existingTemplates );

        #print "\n _ templates found  @found1 \n";

        if (@found1) {
            foreach my $t1 (@found1) {
                push @templatelist,$t1;
            }
        }

        my $dctemplate = 'T_'.$cgroups[0];

        my @found2 = grep(/$dctemplate/, @existingTemplates );

        if (@found2) {
            foreach my $t2 (@found2) {
                push @templatelist,$t2;
            }
        }

        # bug fix for OS 5/18



        if ( my @found5 = grep { $_ eq 'notemplate' } @templatelist ) {
            @templatelist = ();
            push @templatelist,$os_template;
            goto END;
        }

        END:
        # code added on 3/18 by sandeep to get only existing templates

        my @foundTemplates;

        foreach my $t (@templatelist) {
            if ( my @found = grep { $_ eq $t } @existingTemplates ){
                push @foundTemplates, $t;
            }
        }

        my @uniquefound = uniq(@foundTemplates);

        addtoLogfile("Generated Templates List via regex rules - @uniquefound","");

        #code to get slrwinds template
        my @solr_uniquefound = ();
        @solr_uniquefound =  @uniquefound;
        foreach my $tmplte(@solr_uniquefound) {
            $slr_template =0;
            if($tmplte=~/URL/) {
                $slr_template = $tmplte;
            }
        }


        # Get multiple template object

        #my %filter = ('host' => \@foundTemplates);
        my %filter = ('host' => \@uniquefound);
        my @templateobj;
        my @templateobj_tmp = get_templateobj($zabbix,\%filter);

        ## Code to exclude Product specific template here as it will be added later
        foreach my $templateobj ( @templateobj_tmp ) {
            if( $templateobj->{host} =~/_Linux$|_Windows$|_solaris$/i ) {
                next;
            }
            push @templateobj, $templateobj;
        }


        # Get templateid from template objects

        my @templateid = get_templateobj_val(\@templateobj,"templateid");


        # code added on 5/8 sandeep

        my @addTemplates;
        my @removeTemplates;
        my @existinghostTemplates;

        # Get list of  existing templates for the host

        my $attached = get_host_templates($zabbix,$hostid[0]);

        if ( ref($attached) eq 'ARRAY' ) {
            my @attachedtemp =@{$attached};

            foreach my $href(@attachedtemp) {
                my %hash = %$href;
                push(@existinghostTemplates,$hash{'host'});
            }
        }
        else{
            push(@existinghostTemplates,$attached->{'host'});
        }

        addtoLogfile("Existing Templates for Host - @existinghostTemplates","");

        # generate list for templates to be added

        foreach my $t (@uniquefound){
            if ( ! (my @add = grep { $_ eq $t } @existinghostTemplates) ){
                push(@addTemplates,$t);
#               print "inside add list gen for";
            }
        }

        my @uniqueaddTemplates = uniq(@addTemplates);

        #addtoLogfile("New Templates to be linked - @uniqueaddTemplates","");

        #  generate list of templates to be unlinked


        foreach my $t (@existinghostTemplates){
            if ( ! (my @remove = grep { $_ eq $t } @uniquefound) ){
                push (@removeTemplates,$t);
            }
        }


        my @uniqueremoveTemplates = uniq(@removeTemplates);


        if (@uniqueremoveTemplates) {
            #addtoLogfile("No existing templates to be removed","");

            my %filter2 = ('host' => \@uniqueremoveTemplates);
            my @templateobj2 = get_templateobj($zabbix,\%filter2);

            # Get templateid from template objects

#               print Dumper(@templateobj2);

            my @uniqueremoveTemplateids = get_templateobj_val(\@templateobj2,"templateid");


            my @removeresponse = host_remove_template($zabbix,\@hostid,\@uniqueremoveTemplateids);

            if ( $removeresponse[0] eq 'success' ) {
                addtoLogfile("Removed Templates successfully - @uniqueremoveTemplates","");
            }
            else {
                addtoLogfile("ERROR Removing Templates failed - @uniqueremoveTemplates","");
            }

            @uniqueremoveTemplateids = ();
            @removeresponse = ();
        }
        else {
            addtoLogfile("No existing templates to be removed","");
        }


        if (@uniqueaddTemplates) {
            addtoLogfile("New Templates to be linked - @uniqueaddTemplates","");

#=pod
            my %filter1 = ('host' => \@uniqueaddTemplates);
            my @templateobj1 = get_templateobj($zabbix,\%filter1);

            # Get templateid from template objects

            my @uniqueaddTemplateids = get_templateobj_val(\@templateobj1,"templateid");

            #my @addresponse = host_add_template($zabbix,\@hostid,\@uniqueaddTemplateids);

#=cut
             my @results = host_update($zabbix,\@hostid,"templates","templateid",\@uniqueaddTemplateids);
             addtoLogfile("Result: @results");
#            #my @results = host_update($zabbix,\@hostid,"templates","templateid",\@templateid);

            foreach my $res (@results){
                if (!defined $res){
                    addtoLogfile("ERROR: Templates Not Added ","");
                }
            }

=pod
#            if ( $addresponse[0] eq '0' )
#            {
#                addtoLogfile("New Templates linked successfully - @uniqueaddTemplates","");#
#
#            }
#            else
#            {
#                addtoLogfile("ERROR -  Templates linking failed for - @uniqueaddTemplates","");
#
#            }
=cut
                        #@uniqueaddTemplateids = ();
        }
        else {
            addtoLogfile("No new templates to be added","");
        }


         addtoLogfile("End of Autoregistration","");
         addtoLogfile("--------------------------","");

         if ( exists $args{disable} ) {
             SFSF::Host::changestatus($zabbix, $h, 1); ##disable host by default
#             unmanageSolarwindsMonitor($h) if( ! $slrFailed ); ##execute if solarwinds script executed succesfully
         }
         elsif ( exists $args{addmaintenance} ) {
             add_into_maintenance($zabbix,$hostid[0])
         }

         ###create groups like pc_LMS_A_setA or setB and add this host
         system("/usr/local/etc/zbxAdm/2.2/scripts/createSetGrps.pl -hostName $h");

         #if( grep {/$product/} @products ) {
         #    print"Calling AddProductOSTemplate.pl with host $h and product $product\n";
         #    system("/usr/local/etc/zbxAdm/2.2/scripts/AddProductOSTemplate.pl -hostName $h -product $product");
         #}
    }
}
#=cut

################### To Update Host Visible Name ####################

if( exists $args{update_visible_name} ) {

    my $value1 = $args{update_visible_name};
    my @value = split('\|',$value1);


    if("$value[0]"&&"$value[1]" ne "" ) {
        #print "$value[0] and $value[1]\n";
### Get hostid

        my %hfilter = ('host' => $value[0]);
        my @hostobj = get_hostobj($zabbix,\%hfilter);
        #print Dumper(@hostobj);
        my @hostid = get_hostobj_val(\@hostobj,"hostid");
#####update visible name

        my @updated_name = update_host_visible_name($zabbix,$hostid[0],$value[1]);
        #print Dumper(@updated_name);
        addtoLogfile("=====================================================",$value[0]);
        addtoLogfile("Starting Visible Name Updation Process Of DC17 Server ",$value[0]);
        addtoLogfile("Hostname      - $value[0] ",$value[0]);
        addtoLogfile("Visible Name  - $value[1] ",$value[0]);
        addtoLogfile("Visible Name Updated Successfully!!\n",$value[0]);
        #print "Updated Visible Name Of Server $value[0]\n";

    }
    else{
        addtoLogfile("=====================================================",$value[0]);
        addtoLogfile("Visible Name Is Not Updated!!",$value[0]);
        addtoLogfile("$value[0]: Hostname or Visible Name Is Not provided\n",$value[0]);
        #print "$value[0]:  Hostname or Visible Name Is Not provided\n";
    }

}


sub checkDupRegex {
    my ( $hostName, $config ) = @_;
    
    my @hostmapper = get_config_mapping($config);
#    my @hostmapper = SFSF::Host::get_config_mapping();
    my %uniqHGs;
    my @hostGrpsAll;
    my $duplicate = 0;
    foreach (@hostmapper){
        our @line_array = split(':', $_);
        my ($regex, $HG, $template) = @line_array[0, 1, 2];
        if ( $hostName =~ qr/$regex/i ) {
            push @hostGrpsAll, $HG;
            ##in some cases there may be multiple host groups present for same regex. This scenario is not duplicate.
            ##Below code making sure that the host groups are not same
            $duplicate = 1 if ( exists $uniqHGs{$HG} );
            $uniqHGs{$HG} = 1;
        }
    }


    return ( $duplicate, @hostGrpsAll );

}

sub unmanageSolarwindsMonitor {
    my ( $hostName ) = @_;

    my ($monitorName, $dc) = getDCName($hostName);
    print ("Started Unmanaging Solarwinds monitoring - $monitorName\n","");
    addtoLogfile("Started Unmanaging Solarwinds monitoring - $monitorName\n","");

    if( ! -f "$solarwinds_home/recordings/$monitorName.recording" ) {
        print "No Recording found for monitor $monitorName. Skipping solarwinds Unmanage. \n";
        addtoLogfile("No Recording found for monitor $monitorName. Skipping solarwinds Unmanage. \n","");
        return ;
    }

    my $solarwindsScript = $solarwinds_home . "scripts/solarwinds.sh";
    my $unmanageMonitCmd;
    if( $dc ) {
        $unmanageMonitCmd = qq~ $solarwindsScript UnmanageMonitor $monitorName Duration 180 DataCenter $dc ~;  ##Hardcoding for 6 months to disable
    }
    else{
        $unmanageMonitCmd = qq~ $solarwindsScript UnmanageMonitor $monitorName Duration 180~;
    }
    my $result = qx($unmanageMonitCmd);
    if( $result =~ /Monitor is disabled/i ){
        print "Solarwinds monitor is disabled/unmanaged for $monitorName for 180 days\n";
        addtoLogfile("Solarwinds monitor is disabled/unmanaged for $monitorName for 180 days\n","");
    }
    else{
        print "Unable to disable/unmanage monitor $monitorName \n";
        addtoLogfile("Unable to disable/unmanage monitor $monitorName \n","");
    }

    return;
}

sub getDCName {
    my ( $hostName ) = @_;

    my ($monitorName, @domains) = split /\./, $hostName;

    my $domain = join '\.', @domains;

    open FH, "<", "/usr/local/etc/zbxAdm/2.2/scripts/solarwinds_api/conf/players.conf" or die "Can not open players.conf file\n";

    while(my $line=<FH>) {
        chomp($line);
        my @fields = split '\|', $line;
        my $dc = $fields[0];
        my $domainStr = $fields[1];
        if ( $domainStr =~ /$domain/i ) {
            return ($monitorName,$dc);
        }
    }

    close(FH);
    return ($monitorName,undef);
}

sub add_into_maintenance {
    my ( $zabbix, $hostId ) = @_;

    my $maintenance_host_groupid = get_hostgrp_id($zabbix, 'All-NotLive-Hosts-Maintenance');
    my $options = {'groups' => [ { 'groupid' => $maintenance_host_groupid } ], 'hosts' => [ { 'hostid' => $hostId } ] };
    my $result = $zabbix->raw('hostgroup','massadd',$options);
    if ( ref $result eq 'HASH' && exists $result->{groupids} ) {
        print "Host is added into Maintenance \n";
    }

}

sub delete_from_maintenance {
    my ( $zabbix, $hostId ) = @_;

    my $maintenance_host_groupid = get_hostgrp_id($zabbix, 'All-NotLive-Hosts-Maintenance');
    my $options = {'groupids' => [ $maintenance_host_groupid ], 'hostids' => [ $hostId ] };
    my $result = $zabbix->raw('hostgroup','massremove',$options);
    if ( ref $result eq 'HASH' && exists $result->{groupids} ) {
        print "Host is removed from Maintenance \n";
    }
}

sub get_hostgrp_id {
    my ($zabbix, $hostgrp) = @_;

    my $options = {'output' => 'groupid', 'filter' => { 'name' => [ $hostgrp ] } };
    my $result = $zabbix->raw('hostgroup','get',$options);

    if ( ref $result eq 'HASH' ) {
        return $result->{groupid};
    }
     #'All-Hosts-Maintenance')
}

sub check_valid_host {
    my ($zabbix, $host_name, $config) = @_;

    my $rc = 0;
    if( ! SFSF::Host::get_hostid($zabbix, $host_name) ) {
        $rc = 1;
        return ( $rc, "Host is not valid" );
    }
#    my ($duplicatePtrn, @hostGrps) = checkDupRegex($host_name) ;
     my ($duplicatePtrn, @hostGrps) = checkDupRegex($host_name, $config) ;
    if  ( $duplicatePtrn ) {
        $rc = 1;
        return ($rc, "Duplicate regex ");
    }

    if ( ! valid_regex_found($host_name, $config) ) {
        $rc = 1;
        return ($rc, "Regex not found" );
    }


    return ( $rc, "No error");
}

sub valid_regex_found {
    my ( $host_name, $config ) = @_;

    my $valid = 0;
#    my @hostmapper = SFSF::Host::get_config_mapping();
    my @hostmapper = get_config_mapping($config);
    foreach (@hostmapper){
        our @line_array = split(':', $_);
        my ($regex, $HG, $template) = @line_array[0, 1, 2];
        if ( $host_name =~ qr/$regex/i ) {
            $valid = 1;
            last;
        }
    }


    return $valid;

}

sub is_already_in_maintenance {
    my ( $zabbix, $hostId ) = @_;

    my $options = {'output' => 'extend', 'hostids' => [ $hostId ] };
    my $result = $zabbix->raw('host','get',$options);

    return $result->{'maintenance_status'};
}

sub addHostInAnsibleAgentRun {
    my ( $host_name ) = @_;
    open(my $fh, '+>>', '/etc/ansible/agent/inventory/hosts_agentansiblerun.txt');
    print $fh "$host_name\n";
    close $fh;    
}

sub get_config_mapping {
  my ( $config ) = @_;
  my @file_array;
  if ($config->{'sap'}){
    while ( (my $key,my $value) = each %{$config->{'sap'}} ) {
      if ( $key =~ /hostcfg/ ) {
        open (my $fh, "< $value");
        while (my $line = <$fh>) {
          chomp $line;
          if ($line ne "" and $line !~ m/^#/ ){
            push @file_array, $line;
          }
        }
      }
    }
  }
  return @file_array;
}
