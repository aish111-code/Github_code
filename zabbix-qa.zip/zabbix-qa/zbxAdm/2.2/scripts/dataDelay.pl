#!/usr/bin/perl
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

# Local variable declaration

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use SFSF::Host qw(get_hostid);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLDs qw(pfail);
use SFSF::Log qw(addtoLogfile);

my $hostName = $ARGV[0];

if( scalar @ARGV < 1 ) {
    die "$0 <hostname> [ <dc_override> ]
Example: $0 dc4sfjh01 [ DC23 ] \n";
}

my $dc_override = '';
if ( $ARGV[1] ) {
    $dc_override = $ARGV[1];
}
# Detect running env and set the connection variables

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

# Load API properites file
if ( uc $dc_override eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( uc $dc_override eq 'DC8' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC8.conf';
}
elsif ( uc $dc_override eq 'DC10' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC10.conf';
}
elsif ( uc $dc_override eq 'DC41' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC41.conf';
}
elsif ( uc $dc_override eq 'DC55' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC55.conf';
}
elsif ( uc $dc_override eq 'DC50' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC50.conf';
}
elsif ( uc $dc_override eq 'DC52' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC52.conf';
}
elsif ( uc $dc_override eq 'DC57' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC57.conf';
}
elsif ( uc $dc_override eq 'DC60' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC60.conf';
}
elsif ( uc $dc_override eq 'DC62' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC62.conf';
}
elsif ( uc $dc_override eq 'DC64' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC64.conf';
}
elsif ( uc $dc_override eq 'DC66' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC66.conf';
}
elsif ( uc $dc_override eq 'DC68' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC68.conf';
}
elsif ( uc $dc_override eq 'DC30' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC30.conf';
}
elsif ( uc $dc_override eq 'DC33' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC33.conf';
}
elsif ( uc $dc_override eq 'DC70' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC70.conf';
}
elsif ( uc $dc_override eq 'DC32' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC32.conf';
}
elsif ( uc $dc_override eq 'DC67' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC67.conf';
}
elsif ( uc $dc_override eq 'DC61' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC61.conf';
}
elsif ( uc $dc_override eq 'DC34' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC34.conf';
}
elsif ( uc $dc_override eq 'DC56' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC56.conf';
}
elsif ( uc $dc_override eq 'DC58' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC58.conf';
}
elsif ( uc $dc_override eq 'DC65' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC65.conf';
}
elsif ( uc $dc_override eq 'DC69' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC69.conf';
}
elsif ( uc $dc_override eq 'DC71' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC71.conf';
}
elsif ( uc $dc_override eq 'DC75' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC75.conf';
}
elsif ( uc $dc_override eq 'DC51' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC51.conf';
}
my $config = get_rsm_config($configFile);

pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};
my $count = 0;
my $zabbix;
eval { 
    $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});
};
if ( $@ ) {
    print "Can not connect to Zabbix. Exiting......\n";
    exit;
}

my $hostId = _getHostIdByName($zabbix,$hostName);
my $lastTimeStamp = _itemGetByKey($zabbix,$hostId,'system.cpu.load[,avg5]');

my $currentTimeStamp = `date +%s`;
chomp($currentTimeStamp);

my $diff = $currentTimeStamp - $lastTimeStamp;

#my $mails = q~ pradip.kumar.k@sap.com~;
#my $mails = q~ s.renuka@sap.com, pradip.kumar.k@sap.com, natalia.pyalling@sap.com, nandhini.chander@sap.com, rakhesh.ms@sap.com, sreekanth.kp@sap.com~;
#my $mails = q~ ayush.jain@sap.com,v.mohan@sap.com,s.renuka@sap.com,vivek.sivakumar@sap.com,jibin.sunny@sap.com,sindhu.madicherla@sap.com,nagapavan.kalgur@sap.com,durga.prasad.korrapati@sap.com,vidya.nandjha@sap.com,jose.ortiz@sap.com ~;

my $mails = q~ jibin.sunny@sap.com,DL_62D50CAEB98ABB02996051B9@global.corp.sap,sindhu.madicherla@sap.com,vidya.nandjha@sap.com,anusha.mandadi@sap.com,nagapavan.kalgur@sap.com ~;


if ( $diff >= 300 ) {
    my $mailCmd = qq~ echo "Last data was collected more than 5 mins ago. Exactly $diff secs ago" | mailx -r "sapsfplatformmonitoring\@sapsf.com" -s "Data collection delay on $hostName" $mails ~;
#    print "Last data was collected more than 5 mins ago. Exactly $diff secs ago \n";
    system($mailCmd);
}
#else{
#    print "Last data was collected $diff secs ago \n";
#}

sub _itemGetByKey {
    my( $zabbix, $hostId, $keyName ) = @_;

    return {} if ( ! defined $zabbix || ! $hostId || ! $keyName );

    my $options = {'output' =>'extend','hostids' => $hostId, 'search' => { 'key_' => $keyName } };
    my $myresult = $zabbix->raw('item', 'get', $options);
    if ( ref($myresult) eq 'ARRAY' ){
        foreach my $res ( @$myresult ) {
            if (lc $res->{'key_'} eq lc $keyName ) {
                 return $res->{lastclock};
            }
        }
    }
    else{
        if ( lc $myresult->{'key_'} eq lc $keyName ) {
            return $myresult->{lastclock};
        }
    }


    return undef;
}

sub _getHostIdByName {
    my ( $zabbix, $hostName ) = @_;

    return SFSF::Host::get_hostid($zabbix,$hostName);
}

