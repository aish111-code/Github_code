#!/usr/bin/perl 

##################################################################################
#
#Script  : boomi_xml.pl
#Author  : Surekha Pattnaik (C5188034)
#Reviewer: Sandeep M.R (C5182416)
#Date    : 5th Aug 2013
#Purpose : To create incident for BOOMI(http://trust.boomi.com/statuses.rss) to SPC
#Changes : v1.0 Initial Code 28th May 2013
#Changes : Added 'Information Message' Alert with severity 2
#Changes : Adapted libraries to use local perl setup
#####################################################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use CGI;
use XML::Simple;
use LWP::Simple;
use LWP;
use HTTP::Request;
use MIME::Base64;
use Net::SMTP;
use Switch;
use Time::Local;

use POSIX qw(strftime); my $yest_dt=strftime("%a, %d %h %Y",localtime(time-86400)); print $yest_dt;
my $todays_dt=`date "+%a, %d %h %Y"`;
print $todays_dt;
##################################################################################
require ("/usr/local/etc/zbxAdm/2.2/scripts/BOOMI_SPC/BOOMI_TRUST_RSS/SFSF.config");
##################################################################################

##################################################################################
# SPC Variables
my $my_hostname = `hostname`;
my $subject = '';
my $subject1 = '';
my $priority = '';
my $fileencode = ' ';
my $desc = ' ';
my $hcurl = ' ';
my $createxml = '';
my $hccontext = '';
my $encoded = '';
my $incidentid = '11111111';
my $eventkey = '';
my $status = '';

our $spcurl;
our $spcusr;
our $spcpwd;
my $r_all;
our $url;
our $usr;
our $pwd;
my $logfile = '';
my $responseno = '';
my $r_message = '';
my $r_code = '';
my $r_content = '';
my $incfile = '';
my $emailContent = '';

##############################################################

our $title = 'BOOMI  new entry added';
#our $to_list = "surekha.pattnaik\@sap.com, s.renuka\@sap.com";
#our $to_list = "surekha.pattnaik\@sap.com, s.renuka\@sap.coms.chakkenchath\@sap.com sutha.piriyan\@sap.com";
our $to_list = "surekha.pattnaik\@sap.com";
our $from = 'BOOMI';
our $subject = '';
#our $subject = 'Please find details of New Incident created';
our $filename_check = '';
my $line = '';
my $parser = new XML::Simple;
#my $LOGFILE = "/root/BOOMI/BOOMI_TRUST_RSS/Boomi_Logfile" ;
my $LOGFILE = "/var/log/zabbix/BOOMI/RSS/Boomi_Logfile" ;
#open (OUT, ">","check");
#my $DUMP = "/root/BOOMI/BOOMI_TRUST_RSS/DUMP_FILE" ;
my $DUMP = "/var/log/zabbix/BOOMI/RSS/DUMP_FILE" ;
open (DU, "> $DUMP");
#my $COMB = "/root/BOOMI/BOOMI_TRUST_RSS/COMBINED";
my $COMB = '/var/log/zabbix/BOOMI/RSS/COMBINED';
open (CO, "> $COMB");

my $tenant_id = "000000000740093744";
my $year = `date +%Y`;
my $month = `date +%m`;
my $day = `date +%d`;
my $hour = `date +%H`;
my $min = `date +%M`;
my $time = `date`;
#my $log_detail = "/root/BOOMI/BOOMI_TRUST_RSS/logs/BOOMI_LOG_".$year.$month.$day.$hour.$min;
my $log_detail = "/var/log/zabbix/BOOMI/RSS/logs/BOOMI_LOG_".$year.$month.$day.$hour.$min;
$log_detail =~ s/[\n]//g;
print $log_detail;
open (LD, ">> $log_detail");

print LD "Start Script Execution @ $time\n";

$url = 'http://trust.boomi.com/statuses.rss' ;
my $content = get $url or die "Unable to get $url\n";
my $data = $parser->XMLin($content);
#print Dumper($data);    # to print the complete tree structure
print DU Dumper($data) ;
#close (DU);
my $New_Entry_Dt = "$data->{channel}{item}[0]{pubDate}". "\n";  # to print only the 1st occurrence of the specified element i.e. title here
print LD "pubDate is: $New_Entry_Dt";
my $New_link = "$data->{channel}{item}[0]{link}". "\n";
print LD "link is: $New_link";
my $New_guid = "$data->{channel}{item}[0]{guid}". "\n";
print LD "guid is: $New_guid";
my $New_title = "$data->{channel}{item}[0]{title}". "\n";
print LD "title is: $New_title";
my $New_description = "$data->{channel}{item}[0]{description}". "\n";
print LD "description is: $New_description";


my $todays_dt=`date "+%a, %d %h %Y"`;
#print OUT "printing today's date $todays_dt";
print LD "printing today's date $todays_dt";

#open(FD, "< $LOGFILE");
foreach my $result (@{$data->{channel}{item}})
{
#        print $result->{"pubDate"} . "\n";  #to print all occurrences of one element i.e. pubDate here
open (FD, ">> $LOGFILE");
print FD "$result->{pubDate}$result->{title} \n";

my $pubDate_pubDate = "$result->{pubDate}";
my $title_title = "$result->{title}";
my $description_description = "$result->{description}";

my $something = "$result->{pubDate}|$result->{title}\n";
print CO "$something \n";
#print "pubDate and title combination is written to COMBINED file\n";

chomp($something);
chomp($todays_dt);
#$todays_dt='Tue, 20 Jan 2015';
#print "$todays_dt \n";
if($something =~ /$todays_dt/ && $something =~ /Atom Cloud - Performance Issues/ || $something =~ /$todays_dt/ && $something =~ /Atom Cloud - Service Disruption/ || $something =~ /$yest_dt/ && $something =~ /Atom Cloud - Informational Message/ || $something =~ /$todays_dt/ && $something =~ /AtomSphere Platform - Performance Issues/ || $something =~ /$todays_dt/ && $something =~ /AtomSphere Platform - Service Disruption/ || $something =~ /$yest_dt/ && $something =~ /AtomSphere Platform - Informational Message/ || $something =~ /$todays_dt/ && $description_description =~ /emergency maintenance/)
#if($something =~ /$todays_dt/ && $something =~ /Atom Cloud - Performance Issues/ || $something =~ /$todays_dt/ && $something =~ /Atom Cloud - Service Disruption/ || $something =~ /$todays_dt/ && $something =~ /AtomSphere Platform - Performance Issues/ || $something =~ /$todays_dt/ && $something =~ /AtomSphere Platform - Service Disruption/ || $something =~ /$todays_dt/ && $description_description =~ /emergency maintenance/)
#if($pubDate_pubDate eq 'Thu, 07 Nov 2013' && $title_title eq 'Atom Cloud - Performance Issues' || $pubDate_pubDate eq 'Thu, 07 Nov 2013' && $title_title eq 'Atom Cloud - Service Disruption' || $pubDate_pubDate eq 'Thu, 07 Nov 2013' && $title_title eq 'AtomSphere Platform - Performance Issues' || $pubDate_pubDate eq 'Thu, 07 Nov 2013' && $title_title eq 'AtomSphere Platform - Service Disruption')
#if($something eq $todays_dt && $something ne 'Atom Cloud - Operating Normally' || $something eq $todays_dt && $something ne 'Atom Cloud - Informational Message' || $something eq $todays_dt && $something ne 'AtomSphere Platform - Operating Normally' || $something eq $todays_dt && $something ne 'AtomSphere Platform - Informational Message' || $something eq $todays_dt && $something ne 'MDM Cloud - Operating Normally' || $something eq $todays_dt && $description_description =~ /emergency maintenance/)
{
#print "$something combined\n";
#print " Log file name is :  $something.log\n";
#print LD " Log file name is :  $something.log\n";
#$filename_check = "$something.log";
#my $dir = "/root/BOOMI/BOOMI_TRUST_RSS";
my $dirlog = "/var/log/zabbix/BOOMI/RSS/logs";
if (-e "$dirlog/$something.log") {
print LD "File Exists and is Non-Empty file!\n";
print LD "no alert\n";
 }
else {
print LD "no file exists\n";
print "$something combined\n";
print " Log file name is :  $something.log\n";
print LD " Log file name is :  $something.log\n";
$filename_check = "$something.log";
print LD "alert needs to be sent\n";
print LD "the filename is $filename_check\n";
$emailContent = "The  new entry is $result->{pubDate}|$result->{title}|$result->{guid}|$result->{description}";
#print OUT "$emailContent";
print LD "$emailContent";

do_sendmail($from, $to_list, "New TRUST RSS  BOOMI entry found", $emailContent );

#open(FQ, ">> /root/BOOMI/BOOMI_TRUST_RSS/$something.log");
open(FQ, ">> /var/log/zabbix/BOOMI/RSS/logs/$something.log");
print FQ "values are $result->{pubDate}|$result->{title}|$result->{guid}|$result->{description}";
print LD "values are $result->{pubDate}|$result->{title}|$result->{guid}|$result->{description}";
#$filename_check = "$something.log";
print LD "$filename_check \n";
close(FQ);

######################### Priority Check ######################################################
#if ($title_title =~ /Operating Normally/ )
if ($something  =~ /$todays_dt/ && $something =~ /Service Disruption/ )
                        {

                                $subject = "DC4 BOOMI TRUST ALERT Boomi Service Disruption ".$pubDate_pubDate;
                                print LD "\n Incident subject is $subject \n";
                                $priority = "1";
                                print LD "\n Incident priority is $priority \n";

                        }
                        elsif ($something  =~ /$todays_dt/ && $description_description =~ /emergency maintenance/ )
                        {
                                $subject = "DC4 BOOMI TRUST ALERT - emergency maintenance".$pubDate_pubDate;
                                print LD "\n Incident subject is $subject \n";
                                $priority = "1";
                                print LD "\n Incident priority is $priority \n";
                        }
                        elsif ($title_title eq 'Performance Issues' )
                        {
                                $subject = "DC4 BOOMI TRUST ALERT Boomi Performance Issues".$pubDate_pubDate;
                                print LD "\n Incident subject is $subject \n";
                                $priority = "2";
                                print LD "\n Incident priority is $priority \n";
                        }
                        elsif ($title_title eq 'Informational Message' )
                        {
                                $subject = "DC4 BOOMI TRUST ALERT Boomi Informational Message".$pubDate_pubDate;
                                print LD "\n Incident subject is $subject \n";
                                $priority = "2";
                                print LD "\n Incident priority is $priority \n";
                        }
                        else
                        {
                                $priority = "3";
                                print LD "\n Incident priority is $priority \n";

                        }
###########################  Priority Check Done  ###############################################

###########################  Incident Creation Part Added #######################################
                        my $desc = <<EODESC;
***** Boomi Alert Details *****
******* trust.boomi.com *******
Monitoring Tool - Custom Script
pubDate - ${pubDate_pubDate}
title - ${title_title}
description - ${description_description}
Integration Program Source - ${my_hostname}
EODESC

                        print LD "\n Incident detail is $desc \n";
                        $hcurl = "SMD_BOOMI_00001";
                        print LD "\n DEBUG: HC URL is $hcurl\n";
                        my $checkgroup = "SMD_BOOMI";
                        print LD "\n DEBUG: Check group is $checkgroup\n";

my $hccontext = <<EOHCC;
        <spr:ContentCollection xmlns:spr="http://www.sap.com/spr"><spr:Content xmlns:spr="http://www.sap.com/spr" ContextId="IncidentCreator" Sanity="" Size="3732">
        <HealthCheckContext>
        <CheckGroup></CheckGroup>
        <CheckID></CheckID>
        <EventID></EventID>
        <EventType/><CreationTimeUTC></CreationTimeUTC><LastUpdateTimeUTC></LastUpdateTimeUTC><SessionNumber></SessionNumber><KeyField1></KeyField1><KeyField2></KeyField2>
        <DiagnosticInformation>
        <Item><Name></Name><Value></Value></Item>
        <Item><Name></Name><Value></Value></Item><Item><Name></Name><Value/></Item>
        <Item><Name></Name><Value></Value></Item>
        </DiagnosticInformation>
        <Description><OptionalURL>/$hcurl/DE_01.xml</OptionalURL>
        </Description>
        <RecommendedAction><OptionalURL>/$hcurl/DE_01.xml</OptionalURL></RecommendedAction>
        <ErrorInformation>
        <Item><Name></Name><Value></Value></Item></ErrorInformation>
        <ErrorInformation/>
        <ContextInformation>
        <Item><Name></Name><Value></Value></Item></ContextInformation>
        <BusinessInformation><SoftwareEntity><SoftwareEntityCode></SoftwareEntityCode><ID></ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>IncidentCategory</SoftwareEntityCode><ID>0000030001</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationComponent</SoftwareEntityCode><ID>LOD-CI</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>BusinessObject</SoftwareEntityCode><ID>ApplicationManagementTaskMonitorEnhancedController</ID><NameSpace>http://sap.com/xi/A1S</NameSpace><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationArea</SoftwareEntityCode><ID>1004</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity></BusinessInformation></HealthCheckContext></spr:Content></spr:ContentCollection>
EOHCC

        #Encode HC Context to Base64
        $encoded = encode_base64($hccontext);
        $fileencode = ' ';
        $eventkey = $checkgroup."0000101";

                                my $createxml = <<EOXML;
                        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                           <soap:Header/>
                           <soap:Body>
                                  <urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                                         <IT_CONTEXT_PROVIDER>
                                                <item>
                                                   <PROVIDER_ID>/SAP/ABAP/HealthCheck/CheckContextProvider</PROVIDER_ID>
                                                   <CONTEXT_TYPE>5</CONTEXT_TYPE>
                                                   <CONTENT>$encoded</CONTENT>
                                                </item>
                                                <item>
                                                   <PROVIDER_ID>/SAP/BYDMS/River/SplunkAttachment</PROVIDER_ID>
                                                   <CONTEXT_TYPE>1</CONTEXT_TYPE>
                                                   <CONTENT>$fileencode</CONTENT>
                                                </item>
                                         </IT_CONTEXT_PROVIDER>
                                         <IV_CHECK_GROUP>$checkgroup</IV_CHECK_GROUP>
                                         <IV_CHECK_ID>00001</IV_CHECK_ID>
                                         <IV_EVENT_KEY>$eventkey</IV_EVENT_KEY>
                                         <IV_DESCRIPTION>$desc</IV_DESCRIPTION>
                                         <IV_DETAIL_LINK></IV_DETAIL_LINK>
                                         <IV_INCIDENT_PROCESS>SYSTEM INCIDENT</IV_INCIDENT_PROCESS>
                                         <IV_ISSUE_CATEGORY>30107</IV_ISSUE_CATEGORY>
                                         <IV_PRIORITY>$priority</IV_PRIORITY>
                                         <IV_PROCESS>32</IV_PROCESS>
                                         <IV_PROFILE></IV_PROFILE>
                                         <IV_REFERENCE_ID></IV_REFERENCE_ID>
                                         <IV_SUBJECT>$title_title</IV_SUBJECT>
                                         <IV_SYSTEM_ID></IV_SYSTEM_ID>
                                         <IV_TENANT_ID>$tenant_id</IV_TENANT_ID>
                                </urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                           </soap:Body>
                        </soap:Envelope>
EOXML
                                print LD "\n No $filename_check exists, creating new SPC incident\n";


                        if (sendCreate("new", $createxml, $spcurl, $usr, $pwd) eq 1)
                        {
                                print LD "\n DEBUG : Created a new Incident in SPC $incidentid\n";

                        }
                        else
                        {
                                print LD "\n DEBUG: Create Incident in SPC FAILED !!  \n";
                        }

               END:

################### Incident Creation Part Complete #####################################
}
}
}
####### check part end ##########
sub sendCreate
{
        my $createmode = $_[0];
        my $passedXml = $_[1];
        my $url = $_[2];
        my $usr = $_[3];
        my $pwd = $_[4];


        my $returnvalue;
        my $xmlParser = new XML::Simple();
        print LD "\n DEBUG : Calling do_webservice function";

        my $response = call_bldwebservice( $spcurl, $spcusr, $spcpwd, $passedXml );
#       my $response = call_webservice( $spcurl, $spcusr, $spcpwd, $passedXml );

        print LD "\n DEBUG: Executed do_webservice function \n";
        print LD "\n DEBUG: Response from the webservice call is $response \n";

        $r_content = $response->content;
        $r_code = $response->code;
        $r_message = $response->message;

        print LD "\n DEBUG: Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";
        $r_all = <<EORESPONSE;
                HTTP Code: $r_code
                HTTP Message: $r_message
                HTTP Content: $r_content
EORESPONSE


        if ($r_code eq '200')
        {
                my $mess = $xmlParser->XMLin($r_content);
                print LD "\n DEBUG : Message is $mess", "\n";
                print LD "\n DEBUG : xmlParser is $xmlParser", "\n";
                print LD "\n DEBUG : Content is $r_content", "\n";

                $incidentid = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CREATIONResponse"}{"EV_INCIDENT_ID"};
                print LD "\n DEBUG : INCIDENT ID is $incidentid", "\n";

                return 1;

        }
        else
        {
        my $emailContent = "Webservice Error - $r_message";
        do_sendmail($from, $to_list, "Webservice Error", $emailContent );
        }

}

sub findit {
   while (<FD>) {
     my @pattern = $_;
     return($_) if index($_,$New_Entry_Dt) > -1;
   }
}

sub call_bldwebservice
{
   my ( $url, $usr, $pwd, $xml ) = @_;

   print  LD "\nXML: \n$xml\n";
   print  LD "\nURL: \n$url\n";
   $ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;
   my $ua = LWP::UserAgent->new();
   my $r = HTTP::Request->new( "POST", $url );
   $r->header( "Content-Type" => "application/soap+xml","charset=UTF-8","user-agent" => "Hyperic" );
   $r->authorization_basic( $usr, $pwd );
   $r->content($xml);
   my $response = $ua->request($r);
   print  LD "DEBUG: Response is $response \n";
   return $response;
}


sub do_sendmail
{
   my ($from,
       $to,
       $subject,
       $body) = @_;

   open (MAIL, "|/usr/lib/sendmail -f $from $to");
   print MAIL "From: $from\n",
              "To: $to\n",
              "Subject: $subject\n",
              "\n",
              "$body";
   close (MAIL);
}

print LD "End Script Execution @ $time\n";

