#!/usr/bin/perl -w

###################################################################
# Purppose : To purge log files older than 7 days
# Author   : Surekha Pattnaik ( C5188034)
# Date     : 1st Aug 2013
#######################################################################


my $file = '';

foreach my $file (</var/log/zabbix/BOOMI/RSS/logs/*>)
{

	if ( -M $file > 7 )
	{
	#print "$file\n";
	unlink $file;
	}
}
