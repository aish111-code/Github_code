#!/usr/bin/perl -w

###################################################################
# Purppose : To purge log files and eventid files older than 7 days
# Author   : Sandeep M.R ( C5182416)
# Date     : 1st Aug 2013
#######################################################################


my $file = '';

foreach my $file (</root/BOOMI/PROD/logs/*>)
{

	if ( -M $file > 7 )
	{
	print "$file\n";
	unlink $file;
	}
}
