#!/usr/bin/perl -w

###################################################################
# Purppose : To purge files older than 30 days
# Author   : Sandeep M.R ( C5182416)
# Date     : 13th  Aug 2013
#######################################################################


my $file = '';

foreach my $file (</var/log/zabbix/BOOMI/PLATFORM/INC/*>)
{

	if ( -M $file > 30 )
	{
	print "$file\n";
	unlink $file;
	}
}
