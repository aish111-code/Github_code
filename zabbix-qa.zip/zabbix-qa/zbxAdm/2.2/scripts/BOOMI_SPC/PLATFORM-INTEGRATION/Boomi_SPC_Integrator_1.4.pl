#!/usr/bin/perl -w


##########################################################################################################################
# Script : Boomi_SPC_Integrator.pl
# Author : Surekha Pattnaik & Sandeep M.R
# Date   : 24th July 2013
# Purpose : To create SPC incidents for Boomi Platform email alerts
# Changes :  
#          5th Aug 2013 - Sandeep - Added 'Boomi' in INC subject 
#	   12th Aug 2013 - Sandeep - Implemented additional requirements on processing events of type "process.execution"
#          3rd Sep 2013 - Sandeep - Fixed issue with duplicate incidents for same event id for process alerts 
#	   4th Oct 2013	- Sandeep - Fixed issues with incident status checking for process events
#	  14th Nov 2013 - Surekha - Fixed blank subject issue which was coming due to new line in error xml tag
#         9th March 2015 - Sandeep - Migrated code to new zabbix server
#         12th July 2015 - Sandeep - Adapted libraries for local set up
#         Nov 2nd 2016  - Sandeep - Blocked processing of DC15 Boomi atom offline alerts 
#############################################################################################################################


require ("/usr/local/etc/zbxAdm/2.2/scripts/BOOMI_SPC/PLATFORM-INTEGRATION/SFSF.config");

##################################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use HTTP::Request;
use MIME::Base64;
use XML::Simple;
use Net::SMTP;
use Switch;
use Time::Local;


##################################################################

our $bldvnsurl;
our $spcurl;
our $spcusr;
our $spcpwd;
our $execurl;
my $v_emailContent = '';
my $r_all;
our $url;
our $usr;
our $pwd;
our $bldurl;
my $tenant_id = '';
my $logfile = '';
my $responseno = '';
my $r_message = '';
my $r_code = '';
my $r_content = '';
our $from;
our $to_list;
my $incfile = '';
my $r_content1 = '';
my $emailContent = '';
my $return_bld = '';
my $status = '';
my $evstatusdescription = '';
my $responsetype = '';
my $responsemsg = '';
my $evstatuscode = '';



###############################################################
my $eid = '';
my $eventId = '';
my $error = ' ';
my $accountId = '';
my $atomId = '';
my $atomName = '';
my $eventLevel = '';
my $eventDate = '';
my $status = '';
my $eventType = '';
my $executionId = '';
my $updateDate = '';
my $startTime = '';
my $endTime = '';
my $errorDocumentCount = '';
my $inboundDocumentCount = '';
my $outboundDocumentCount = '';
my $processName = '';
my $recordDate = '';
my $error = ''; 
my $environment = '';
my $classification = '';
my $errorType = ' ';
my $erroredStepLabel = ' ';
my $erroredStepType = ' ';
my $executionId = '';
my $execxml = '';
my $exec_type = '';
my $scriptsource = '';

my $year = '';
my $month = '';
my $day = '';
my $hour = '';
my $min = '';
my $vdate1 = '';
my $vdate2 = '';
my $log = '';
my $time = '';

##############################################################
# SPC Variables

my $subject = '';
my $subject1 = '';
my $priority = '';
my $fileencode = ' ';
my $desc = ' ';
my $hcurl = ' ';
my $createxml = '';
my $hccontext = '';
my $hcurl = '';
my $encoded = '';
my $incidentid = '';
my $eventkey = '';
my $inc1 = '';
my $inc = '';

##############################################################

$year =`date +%Y`;
$month =`date +%m`;
$day =`date +%d`;
$hour =`date +%H`;
$min =`date +%M`;

$time =`date`;
$vdate1=$year."-".$month."-".$day."T00:00:00Z";
$vdate2=$year."-".$month."-".$day."T24:00:00Z";
$vdate1 =~ s/[\n]//g;
$vdate2 =~ s/[\n]//g;

$log="/var/log/zabbix/BOOMI/PLATFORM/boomi_".$year.$month.$day."_".$hour.$min;

$log =~ s/[\n]//g;

open (FD,"> $log");

$scriptsource = `hostname`;

print FD "Starting Checks @ $time";


my $xml = <<EOXML;
<QueryConfig xmlns="http://api.platform.boomi.com/">
  <QueryFilter>
<expression operator="and" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="GroupingExpression">
        <nestedExpression operator="BETWEEN" property="eventDate"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="SimpleExpression">
      <argument>$vdate1</argument>
      <argument>$vdate2</argument>
        </nestedExpression>
        <nestedExpression operator="EQUALS" property="eventLevel"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="SimpleExpression">
        <argument>ERROR</argument>
        </nestedExpression>
</expression>
  </QueryFilter>
</QueryConfig>
EOXML


	print FD "DEBUG : Value of xml is $xml", "\n";
	my $xmlParser = new XML::Simple();
        print FD "DEBUG : Calling webservice function";
#	$ENV{HTTPS_PROXY}= 'https://proxy-tco.wdf.sap.corp:8080';
	$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;
	
#	use constant PROXY=>"https://proxy-tco.wdf.sap.corp:8080";
#	my $proxy="https://proxy-tco.wdf.sap.corp:8080";

	my $response = call_webservice( $url, $usr, $pwd, $xml );

	$r_content = $response->content;
	$r_code = $response->code;
	$r_message = $response->message;

	print FD "DEBUG: BOOMI API Web service Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";

	 if ($r_code eq '200')		# Boomi API call successful
        {
                my $mess = $xmlParser->XMLin($r_content);

				#print Dumper($mess);
                #print "\n DEBUG : Message is Dumper($mess)\n";

				#my $Query_Token = $mess->{'bns:QueryResult'}[0]{"bns:queryToken"}, "\n";		
				#print $Query_Token, "\n";

				#print $mess->{'bns:result'}[0]{"bns:eventId"}, "\n";   #to print only 1st event id value
				#print $mess->{'bns:result'}[0]{"bns:atomId"}, "\n";    #to print only 1st atomid value

				foreach my $result (@{$mess->{"bns:result"}}) 
				{

						print FD "\n Event details \n";

						$eventId = $result->{"bns:eventId"};
						$accountId = $result->{"bns:accountId"};
                        $atomId = $result->{"bns:atomId"};
                        $atomName = $result->{"bns:atomName"};
                        $eventLevel = $result->{"bns:eventLevel"};
                        $eventDate = $result->{"bns:eventDate"};
                        $status = $result->{"bns:status"};
                        $eventType = $result->{"bns:eventType"};
                        $processName = $result->{"bns:processName"};
                        $error = $result->{"bns:error"};
#			$error = "error occurred  and created for testing 
#so dont worry delete it";
			$error =~ y/\n//d;
                        $environment = $result->{"bns:environment"};

						if ($eventType =~ m/process.execution/ )   # Logic for events of type process
						{
							$executionId = $result->{"bns:executionId"};
							print FD "\n Process Execution ID is $executionId";

							# Call boomi api to get execution record details	

							$exec_type = exec_record($executionId);
							print FD "\n Process execution type is $exec_type";
				
							if ( $exec_type =~ m/exec_manual/ )
							{
								print FD "\n Skipping processing of event due to manual execution process event";
								goto END;
							}
							elsif ( $exec_type eq 1 )
							{
								goto END;   # Skip processing if webservice call was failure
							}
							else
							{
								# Call procedure process_exec for further processing
								process_exec();     
							}
						}
					
							
						
						else       								# Logic for all other types of events
						{

							if ($status =~ m/DEAD/ )			# change incident subject for offline errors
								{	
					
					 if ( $atomName =~ m/DC15/ )
                                                        {
                                                                print FD "\n Skipping processing of event for DC15 atoms offline event";
                                                                goto END;
                                                        }


					$subject = "Boomi ".$atomName." is offline";
                                	print FD "\n Incident subject is $subject \n";
                                	$priority = "1";
                                	print FD "\n Incident priority is $priority \n";

								}
							else
							{
									$subject1 = substr($error,0,110);
									$subject = "Boomi ".$subject1; 
                                 	print FD "\n Incident subject is $subject \n";
                                 	$priority = "2";
                                 	print FD "\n Incident priority is $priority \n";
                        	}

			my $desc = <<EODESC;
***** Boomi Platform Alert Details *****

Monitoring Tool - Boomi Platform
event Id - ${eventId}
accountId - ${accountId}
atomId - ${atomId}
atomName - ${atomName}
eventLevel - ${eventLevel}
eventDate - ${eventDate}
status - ${status}
eventType - ${eventType}
processName - ${processName}
error - ${error}
environment - ${environment}

Integration program source - $scriptsource

EODESC

						print FD "\n Incident comment is $desc \n"; 
						my $hcurl = "SMD_BOOMI_00001";
						print FD "\n DEBUG: HC URL is $hcurl\n";
						my $checkgroup = "SMD_BOOMI";
						print FD "\n DEBUG: Check group is $checkgroup\n";

my $hccontext = <<EOHCC;
        <spr:ContentCollection xmlns:spr="http://www.sap.com/spr"><spr:Content xmlns:spr="http://www.sap.com/spr" ContextId="IncidentCreator" Sanity="" Size="3732">
        <HealthCheckContext>
        <CheckGroup></CheckGroup>
        <CheckID></CheckID>
        <EventID></EventID>
        <EventType/><CreationTimeUTC></CreationTimeUTC><LastUpdateTimeUTC></LastUpdateTimeUTC><SessionNumber></SessionNumber><KeyField1></KeyField1><KeyField2></KeyField2>
        <DiagnosticInformation>
        <Item><Name></Name><Value></Value></Item>
        <Item><Name></Name><Value></Value></Item><Item><Name></Name><Value/></Item>
        <Item><Name></Name><Value></Value></Item>
        </DiagnosticInformation>
        <Description><OptionalURL>/$hcurl/DE_01.xml</OptionalURL>
        </Description>
        <RecommendedAction><OptionalURL>/$hcurl/DE_01.xml</OptionalURL></RecommendedAction>
        <ErrorInformation>
        <Item><Name></Name><Value></Value></Item></ErrorInformation>
        <ErrorInformation/>
        <ContextInformation>
        <Item><Name></Name><Value></Value></Item></ContextInformation>
        <BusinessInformation><SoftwareEntity><SoftwareEntityCode></SoftwareEntityCode><ID></ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>IncidentCategory</SoftwareEntityCode><ID>0000030001</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationComponent</SoftwareEntityCode><ID>LOD-CI</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>BusinessObject</SoftwareEntityCode><ID>ApplicationManagementTaskMonitorEnhancedController</ID><NameSpace>http://sap.com/xi/A1S</NameSpace><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationArea</SoftwareEntityCode><ID>1004</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity></BusinessInformation></HealthCheckContext></spr:Content></spr:ContentCollection>
EOHCC

						#Encode HC Context to Base64
						$encoded = encode_base64($hccontext);
						$fileencode = ' ';
						$eventkey = $checkgroup."0000101";

						#print FD "Event Id - ${eventId} \n";
						#print FD "accountId - ${accountId} \n";
						#print FD "atomId - ${atomId} \n";
						#print FD "atomName - ${atomName} \n";
						#print FD "eventLevel - ${eventLevel} \n";
						#print FD "eventDate - ${eventDate} \n";
						#print FD "status - ${status} \n";
						#print FD "eventType - ${eventType} \n";
						#print FD "processName - ${processName} \n";
						#print FD "error - ${error} \n";
						#print FD "environment - ${environment} \n";

						$incfile = "/var/log/zabbix/BOOMI/PLATFORM/INC/".${eventId};
						print FD "Incident file = $incfile \n";

						if ( -e $incfile )
						{
							print FD "\n File $incfile exists, skipping processing of this event \n";
						}
						else
						{
							print FD "\n File $incfile doest not exist \n";
							# Call SPC BLD webservice by External ID

my $bldxml = <<EOXML;
       <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="http://sap.com/xi/SAPGlobal20/Global" xmlns:rfc="urn:sap-com:sap:rfc:functions">
       <soap:Header/>
       <soap:Body>
       <urn:WSQueryRequestMessage>
       <ExternalID>${atomId}</ExternalID>
       </urn:WSQueryRequestMessage>
       </soap:Body>
       </soap:Envelope>
EOXML

							$return_bld = getBLDstatus($bldxml, $bldurl, $spcusr, $spcpwd);
							if ( $return_bld eq 1)
							{
								print FD "\n DEBUG: BLD Web service called successfully , tenant id is $tenant_id \n";
							}
							elsif ( $return_bld eq 2 )
							{
								print FD "\n DEBUG: NO BLD entry for atomid, SPC Incident will not be created \n";
								goto END;
							}else
							{
								$tenant_id = "000000000740090103";
								print FD "\n DEBUG: BLD Web service failure, processing with default tenant id $tenant_id !! \n";
							}

my $createxml = <<EOXML;
                        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                           <soap:Header/>
                           <soap:Body>
                                  <urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                                         <IT_CONTEXT_PROVIDER>
                                                <item>
                                                   <PROVIDER_ID>/SAP/ABAP/HealthCheck/CheckContextProvider</PROVIDER_ID>
                                                   <CONTEXT_TYPE>5</CONTEXT_TYPE>
                                                   <CONTENT>$encoded</CONTENT>
                                                </item>
                                                <item>
                                                   <PROVIDER_ID>/SAP/BYDMS/River/SplunkAttachment</PROVIDER_ID>
                                                   <CONTEXT_TYPE>1</CONTEXT_TYPE>
                                                   <CONTENT>$fileencode</CONTENT>
                                                </item>
                                         </IT_CONTEXT_PROVIDER>
                                         <IV_CHECK_GROUP>$checkgroup</IV_CHECK_GROUP>
                                         <IV_CHECK_ID>00001</IV_CHECK_ID>
                                         <IV_EVENT_KEY>$eventkey</IV_EVENT_KEY>
                                         <IV_DESCRIPTION>$desc</IV_DESCRIPTION>
                                         <IV_DETAIL_LINK></IV_DETAIL_LINK>
                                         <IV_INCIDENT_PROCESS>SYSTEM INCIDENT</IV_INCIDENT_PROCESS>
                                         <IV_ISSUE_CATEGORY>30107</IV_ISSUE_CATEGORY>
                                         <IV_PRIORITY>$priority</IV_PRIORITY>
                                         <IV_PROCESS>32</IV_PROCESS>
                                         <IV_PROFILE></IV_PROFILE>
                                         <IV_REFERENCE_ID></IV_REFERENCE_ID>
                                         <IV_SUBJECT>$subject</IV_SUBJECT>
                                         <IV_SYSTEM_ID></IV_SYSTEM_ID>
                                         <IV_TENANT_ID>$tenant_id</IV_TENANT_ID>
                                </urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                           </soap:Body>
                        </soap:Envelope>
EOXML

					print FD "\n No $incfile exists, creating new SPC incident\n";

					if (sendCreate("new", $createxml, $spcurl, $usr, $pwd) eq 1)
                        {
                            print FD "\n DEBUG : Created a new Incident in SPC $incidentid\n";
							open (IF,"> $incfile");
                            print FD " $incfile created\n";
                            close (IF);
                        }
                        else
                        {
                            print FD "\n DEBUG: Create Incident in SPC FAILED !!  \n";
                        }
			}	

		END:

		}			  # End of procesing logic for normal events
		
				}     # End of Forloop
		
		}     # End of RC 200
	else
		{
	# API error from BOOMI
	$emailContent = "BOOMI API Error - $r_message";
	print "$r_message \n";
          print "$r_content \n"; 
		if ($r_code = "Forbidden") {
                print "$v_emailContent \n";

        sendmail($from, $to_list, "BOOMI API Error", $r_content );
}
	print FD "\n BOOMI API ERROR, Exit from program\n ";
}


	$time=`date`;
	print FD "\n End of Checks @ $time";
	close (FD);

	
################ Procedure for handling process events ###########################

	
sub process_exec 
{

	# Check for atomId-processName-error file existance

	my $incname1 = $atomId.$processName.$error;
	print FD "\n Incname before  editing is \n $incname1";
	
#	$incname1 =~ s/[\n!-,\[\]:;().=' ]//g ;
	$incname1 =~ s/[\n!-,\[\]:;().='\/ ]//g ;    # changed on 10th Feb to resolve duplicate issue
	print FD "\n Incname after editing is \n $incname1";
	
	my $len = length($incname1);
	print FD "\n Length of Incname = $len";

		if ( $len > 255 )
		{
			print FD "\n Incname length > 255, going to cut \n";
			$incname1 = substr($incname1,0,255);
			print FD "\n Incname Afer cutting to 255  : \n $incname1";
		}
		else
		{
			print FD "\n Incname length < 255 \n";
		}
		
	$incfile = "/var/log/zabbix/BOOMI/PLATFORM/INC/".$incname1;
	
	print FD "\n Generated value of Inc file is $incfile\n";
	
	# Check if INC file exist or not
	
		if ( -e $incfile )
		{
			print FD "\n INC File exists";
			
			# check if incident is closed or not
			open (FI, "< $incfile");
			$inc = <FI>;
			chop($inc);
			print FD "\n SPC Incident from INC File is $inc";
		        $eid = <FI>;
			print FD "\n event ID from INC File is $eid";

                        if ( $eid eq ${eventId} )
			{
			print FD "\n $eid event is already processed, skipping processing";
			}
			else
			{
			print FD "\n $eid event is not processed, continue";	
			  	
			
			# Obtain current status of SPC incident
			
			my $incstatus = getStatus($inc);
			
			print FD "\n Current status of SPC Incident is : $incstatus";
		
			close (FI);

			if ( $incstatus eq "1" )
			{
				print FD "\n Incident is closed, creating a new one";
				goto START;
			}
			else
			{
				print FD "\n Skipping processing of event since incident is open";
			} 
			}	
		}
		else
		{
			print FD "\n INC file does not exist, new alert\n";
			
			START:
			
			
			$subject1 = substr($error,0,110);
			$subject = "Boomi ".$subject1; 
            print FD "\n SPC Incident subject is $subject \n";
            $priority = "2";
            print FD "\n SPC Incident priority is $priority \n";

my $desc = <<EODESC;
***** Boomi Platform Alert Details *****

Monitoring Tool - Boomi Platform
event Id - ${eventId}
accountId - ${accountId}
atomId - ${atomId}
atomName - ${atomName}
eventLevel - ${eventLevel}
eventDate - ${eventDate}
status - ${status}
eventType - ${eventType}
processName - ${processName}
error - ${error}
environment - ${environment}

Integration Program source - $scriptsource
EODESC

			print FD "\n SPC Incident comment is $desc \n"; 
			my $hcurl = "SMD_BOOMI_00001";
			print FD "\n SPC HC URL is $hcurl\n";
			my $checkgroup = "SMD_BOOMI";
			print FD "\n SPC Check group is $checkgroup\n";

my $hccontext = <<EOHCC;
        <spr:ContentCollection xmlns:spr="http://www.sap.com/spr"><spr:Content xmlns:spr="http://www.sap.com/spr" ContextId="IncidentCreator" Sanity="" Size="3732">
        <HealthCheckContext>
        <CheckGroup></CheckGroup>
        <CheckID></CheckID>
        <EventID></EventID>
        <EventType/><CreationTimeUTC></CreationTimeUTC><LastUpdateTimeUTC></LastUpdateTimeUTC><SessionNumber></SessionNumber><KeyField1></KeyField1><KeyField2></KeyField2>
        <DiagnosticInformation>
        <Item><Name></Name><Value></Value></Item>
        <Item><Name></Name><Value></Value></Item><Item><Name></Name><Value/></Item>
        <Item><Name></Name><Value></Value></Item>
        </DiagnosticInformation>
        <Description><OptionalURL>/$hcurl/DE_01.xml</OptionalURL>
        </Description>
        <RecommendedAction><OptionalURL>/$hcurl/DE_01.xml</OptionalURL></RecommendedAction>
        <ErrorInformation>
        <Item><Name></Name><Value></Value></Item></ErrorInformation>
        <ErrorInformation/>
        <ContextInformation>
        <Item><Name></Name><Value></Value></Item></ContextInformation>
        <BusinessInformation><SoftwareEntity><SoftwareEntityCode></SoftwareEntityCode><ID></ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>IncidentCategory</SoftwareEntityCode><ID>0000030001</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationComponent</SoftwareEntityCode><ID>LOD-CI</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>BusinessObject</SoftwareEntityCode><ID>ApplicationManagementTaskMonitorEnhancedController</ID><NameSpace>http://sap.com/xi/A1S</NameSpace><AlternativeID/><Name/></SoftwareEntity><SoftwareEntity><SoftwareEntityCode>ApplicationArea</SoftwareEntityCode><ID>1004</ID><NameSpace/><AlternativeID/><Name/></SoftwareEntity></BusinessInformation></HealthCheckContext></spr:Content></spr:ContentCollection>
EOHCC

			#Encode HC Context to Base64
			$encoded = encode_base64($hccontext);
			$fileencode = ' ';
			$eventkey = $checkgroup."0000101";
						#print FD "Event Id - ${eventId} \n";
						#print FD "accountId - ${accountId} \n";
						#print FD "atomId - ${atomId} \n";
						#print FD "atomName - ${atomName} \n";
						#print FD "eventLevel - ${eventLevel} \n";
						#print FD "eventDate - ${eventDate} \n";
						#print FD "status - ${status} \n";
						#print FD "eventType - ${eventType} \n";
						#print FD "processName - ${processName} \n";
						#print FD "error - ${error} \n";
						#print FD "environment - ${environment} \n";
			# Call SPC BLD webservice by External ID

my $bldxml = <<EOXML;
       <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="http://sap.com/xi/SAPGlobal20/Global" xmlns:rfc="urn:sap-com:sap:rfc:functions">
       <soap:Header/>
       <soap:Body>
       <urn:WSQueryRequestMessage>
       <ExternalID>${atomId}</ExternalID>
       </urn:WSQueryRequestMessage>
       </soap:Body>
       </soap:Envelope>
EOXML

		$return_bld = getBLDstatus($bldxml, $bldurl, $spcusr, $spcpwd);
		
		if ( $return_bld eq 1)
		{
			print FD "\n BLD Web service called successfully , tenant id is $tenant_id \n";
		}
		elsif ( $return_bld eq 2 )
		{
			print FD "\n NO BLD entry for atomid, SPC Incident will not be created \n";
			goto END;
		}else
		{
			$tenant_id = "000000000740090103";
			print FD "\n BLD Web service failure, processing with default tenant id $tenant_id !! \n";
		}

my $createxml = <<EOXML;
                        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                           <soap:Header/>
                           <soap:Body>
                                  <urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                                         <IT_CONTEXT_PROVIDER>
                                                <item>
                                                   <PROVIDER_ID>/SAP/ABAP/HealthCheck/CheckContextProvider</PROVIDER_ID>
                                                   <CONTEXT_TYPE>5</CONTEXT_TYPE>
                                                   <CONTENT>$encoded</CONTENT>
                                                </item>
                                                <item>
                                                   <PROVIDER_ID>/SAP/BYDMS/River/SplunkAttachment</PROVIDER_ID>
                                                   <CONTEXT_TYPE>1</CONTEXT_TYPE>
                                                   <CONTENT>$fileencode</CONTENT>
                                                </item>
                                         </IT_CONTEXT_PROVIDER>
                                         <IV_CHECK_GROUP>$checkgroup</IV_CHECK_GROUP>
                                         <IV_CHECK_ID>00001</IV_CHECK_ID>
                                         <IV_EVENT_KEY>$eventkey</IV_EVENT_KEY>
                                         <IV_DESCRIPTION>$desc</IV_DESCRIPTION>
                                         <IV_DETAIL_LINK></IV_DETAIL_LINK>
                                         <IV_INCIDENT_PROCESS>SYSTEM INCIDENT</IV_INCIDENT_PROCESS>
                                         <IV_ISSUE_CATEGORY>30107</IV_ISSUE_CATEGORY>
                                         <IV_PRIORITY>$priority</IV_PRIORITY>
                                         <IV_PROCESS>32</IV_PROCESS>
                                         <IV_PROFILE></IV_PROFILE>
                                         <IV_REFERENCE_ID></IV_REFERENCE_ID>
                                         <IV_SUBJECT>$subject</IV_SUBJECT>
                                         <IV_SYSTEM_ID></IV_SYSTEM_ID>
                                         <IV_TENANT_ID>$tenant_id</IV_TENANT_ID>
                                </urn:_-A1SSPC_-SPC_INCIDENT_CREATION>
                           </soap:Body>
                        </soap:Envelope>
EOXML

					
		if (sendCreate("new", $createxml, $spcurl, $usr, $pwd) eq 1)
        {
            print FD "\n Created a new Incident in SPC -  $incidentid\n";
			open (IF,"> $incfile");
            print IF "$incidentid\n";
	    print IF ${eventId};
            close (IF);
        }
        else
        {
             print FD "\n Create Incident in SPC FAILED !!  \n";
                     
		}
				
		}  # end of processing if INC file does not exist

}    # end of process_exec procedure


#################  Temp procedure for obtaining SPC Incident status ##########################

sub getStatu1s
{

my $inc1 = $_[0];

my $returnvalue;

$inc1 =~ s/^\s+//;
$inc1 =~ s/\s+$//;
 my $updatexml = '';

				$updatexml = <<EOXML;
                                <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                                <soap:Header/>
                                <soap:Body>
                                <urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
                                        <IV_INCIDENT_ID>$inc1</IV_INCIDENT_ID>
                                        <IV_NEW_COMMENT></IV_NEW_COMMENT>
                                        <IV_PRIORITY></IV_PRIORITY>
                                </urn:_-A1SSPC_-SPC_INCIDENT_UPDATE>
                                </soap:Body>
                                </soap:Envelope>
EOXML


my $xmlParser = new XML::Simple();

        my $response = call_bldwebservice( $spcurl, $spcusr, $spcpwd, $updatexml );

        $r_content = $response->content;
        $r_code = $response->code;
        $r_message = $response->message;

        print FD "\n DEBUG: Message we got is ==> $r_message \n URL is $spcurl \n Content is $r_content \n";


  if ($r_code eq '200')
        {
                my $mess = $xmlParser->XMLin($r_content);

                # Check Response Content for Update Success Msg
                my $ok = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"EV_OK"};

                if ($ok =~ m/HASH/)
                {
                        $ok = '';
                }
                else
                {
                }

                if(($response->is_success) && ($ok eq "true" ))
                {
	        print FD "\n $inc1 is OPEN";	
                $returnvalue = 1;
                }
 		else
                {

                        $responsetype = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"ET_MESSAGES"}{"item"}{"TYPE"};
                        print FD "\n Response type: $responsetype \n";

                        if ($responsetype eq 'E')
                        {
                                $responseno = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"ET_MESSAGES"}{"item"}{"NUMBER"};
                                $responsemsg = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_UPDATEResponse"}{"ET_MESSAGES"}{"item"}{"MESSAGE"};
                                print FD "Response No: $responseno \n";
                                print FD "Response Message: $responsemsg \n";
                        }

                # System in Downtime should not be an issue in update WS API
                # 014 - System in Downtime
                # 015 - Incident already completed
                        if ($responseno eq '015' )
                        {
                        print FD "\n $inc1 is completed";
			}

                        $returnvalue = 0;
                }
        }

        return $returnvalue;
}

	
########### Procedure for obtaining SPC Incident status ####################

sub getStatus
{
        my $inc1 = $_[0];

        my $returnvalue;

        my $getxml = '';
        $getxml = <<EOXML;
                <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                <soap:Header/>
                <soap:Body>
                <urn:_-A1SSPC_-GET_INCIDENT_STATUS>
                        <IV_INCIDENT_ID>$inc1</IV_INCIDENT_ID>
                </urn:_-A1SSPC_-GET_INCIDENT_STATUS>
                </soap:Body>
                </soap:Envelope>
EOXML

        my $xmlParser = new XML::Simple();
        print FD "\n Calling do_webservice function";

        my $response = call_bldwebservice( $spcurl, $spcusr, $spcpwd, $getxml );

        print FD "\n Executed do_webservice function \n";
        print FD "\n Response from the webservice call is $response \n";

        $r_content = $response->content;
        $r_code = $response->code;
        $r_message = $response->message;
		print FD "\n SPC Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";

        $r_all = <<EORESPONSE;
                HTTP Code: $r_code
                HTTP Message: $r_message
                HTTP Content: $r_content
EORESPONSE

	if (($r_code eq '200'))
        {
                my $mess = $xmlParser->XMLin($r_content);

                $evstatuscode = $mess->{"env:Body"}{"n0:_-A1SSPC_-GET_INCIDENT_STATUSResponse"}{"EV_STATUS_CODE"};
                print FD "\n EV status code is $evstatuscode";

                $evstatusdescription = $mess->{"env:Body"}{"n0:_-A1SSPC_-GET_INCIDENT_STATUSResponse"}{"EV_STATUS_DESCRIPTION"};
                print  FD "\n EV status Description is $evstatusdescription";

                if ($evstatuscode =~ m/HASH/)
                {
                        $evstatuscode = '';
                }
                else
                {

                }

                  if($evstatuscode ne '')
                {

                        print FD "\n Incident status code is $evstatuscode : Status description is $evstatusdescription";

                        if (( $evstatuscode eq "07" ) || ( $evstatuscode eq "08" )|| ( $evstatuscode eq "10" ) || ( $evstatuscode eq "11" ) )
                        {
                           print FD "\n Incident is closed in SPC, returnvalue is 1";
                           $returnvalue = 1;
                        }
                        else
                        {
                                print FD "\n Incident is open in SPC, returnvalue is 0";
                                $returnvalue = 0;
                        }


                }
                else
                {
                         $responsetype = $mess->{"env:Body"}{"n0:_-A1SSPC_-GET_INCIDENT_STATUSResponse"}{"ET_MESSAGES"}{"item"}{"TYPE"};

                  #      print $responsetype;

                        if ($responsetype eq 'E')
                        {
                                $responseno = $mess->{"env:Body"}{"n0:_-A1SSPC_-GET_INCIDENT_STATUSResponse"}{"ET_MESSAGES"}{"item"}{"NUMBER"};
                                $responsemsg = $mess->{"env:Body"}{"n0:_-A1SSPC_-GET_INCIDENT_STATUSResponse"}{"ET_MESSAGES"}{"item"}{"MESSAGE"};

                                print  FD "\n Response No: $responseno \n";
                                print  FD "\n Response Message: $responsemsg \n";
                        }

                   $returnvalue = 1 ;

                }

	  }
	        else
        {
                        print FD "\n SPC Web service error";
                        $returnvalue = 0;
        }

return $returnvalue;

}


sub sendCreate
{
        my $createmode = $_[0];
        my $passedXml = $_[1];
        my $url = $_[2];
        my $usr = $_[3];
        my $pwd = $_[4];


        my $returnvalue;
        my $xmlParser = new XML::Simple();
        print FD "\n Calling do_webservice function";

        my $response = call_bldwebservice( $spcurl, $spcusr, $spcpwd, $passedXml );

        print FD "\n Executed do_webservice function \n";
        print FD "\n Response from the webservice call is $response \n";

        $r_content = $response->content;
        $r_code = $response->code;
        $r_message = $response->message;

        print FD "\n Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";
        $r_all = <<EORESPONSE;
                HTTP Code: $r_code
                HTTP Message: $r_message
                HTTP Content: $r_content
EORESPONSE


        if ($r_code eq '200')
        {
                my $mess = $xmlParser->XMLin($r_content);
                print FD "\n Message is $mess", "\n";
                print FD "\n xmlParser is $xmlParser", "\n";
                print FD "\n Content is $r_content", "\n";

                $incidentid = $mess->{"env:Body"}{"n0:_-A1SSPC_-SPC_INCIDENT_CREATIONResponse"}{"EV_INCIDENT_ID"};
                print FD "\n SPC INCIDENT ID is $incidentid", "\n";

                return 1;

        }
	else
	{
	my $emailContent = "Webservice Error - $r_message";
        sendmail($from, $to_list, "Webservice Error", $emailContent );
	}

}


sub call_webservice
{
   my ( $url, $usr, $pwd, $xml ) = @_;

#   open (FH1, ">> $logfile") || die "problem opening $logfile\n";

   print  FD "\nXML: \n$xml\n";
   print  FD "\nURL: \n$url\n";

   my $ua = LWP::UserAgent->new();
   my $r = HTTP::Request->new( "POST", $url );
   #$r->header( "Content-Type" => "text/xml","charset=UTF-8","SOAPAction" => "","user-agent" => "Hyperic" ); ADD THIS LINE FOR PRODUCTIO CODE
   $r->header( "Content-Type" => "text/xml","charset=UTF-8","user-agent" => "Hyperic" );
   $r->authorization_basic( $usr, $pwd );
   $r->content($xml);
   my $response = $ua->request($r);
   print  FD "DEBUG: Response is $response \n";
   return $response;
}


sub call_bldwebservice
{
   my ( $url, $usr, $pwd, $xml ) = @_;

#   open (FH1, ">> $logfile") || die "problem opening $logfile\n";
#	delete $ENV{HTTPS_PROXY};

   print  FD "\nXML: \n$xml\n";
   print  FD "\nURL: \n$url\n";
	$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;
	#$ENV{HTTPS_PROXY}= 'https://proxy-tco.wdf.sap.corp:8080';
   my $ua = LWP::UserAgent->new();
   my $r = HTTP::Request->new( "POST", $url );
   #$r->header( "Content-Type" => "text/xml","charset=UTF-8","SOAPAction" => "","user-agent" => "Hyperic" ); ADD THIS LINE FOR PRODUCTIO CODE
   $r->header( "Content-Type" => "application/soap+xml","charset=UTF-8","user-agent" => "Hyperic" );
   $r->authorization_basic( $usr, $pwd );
   $r->content($xml);
   my $response = $ua->request($r);
   print  FD "DEBUG: Response is $response \n";
   return $response;
}

############## Send e-mail function ####################

sub sendmail
{
   my ($from,
       $to,
       $subject,
       $body) = @_;

   print "DEBUG: do_sendmail $body";
   open (MAIL, "|/usr/lib/sendmail -f $from $to");
   print MAIL "From: $from\n",
              "To: $to\n",
              "Subject: $subject\n",
              "\n",
              "$body";
   close (MAIL);
}


sub getBLDstatus
{
        my $passedXml = $_[0];
        my $url = $_[1];
        my $usr = $_[2];
        my $pwd = $_[3];


        my $returnvalue;
        my $xmlParser = new XML::Simple();
        print FD "DEBUG : Calling do_webservice function \n";

        my $response = call_bldwebservice( $bldurl, $spcusr, $spcpwd, $passedXml );
        print FD "DEBUG: Executed do_webservice function from getBLDstatus\n";
        print FD "DEBUG: Response from the webservice call is $response \n";

        $r_content = $response->content;
        $r_code = $response->code;
        $r_message = $response->message;

#$r_content=$r_content1."etails><TenantExternalID/><TenantID/><TenantURL/><TenantType/><CustomerID/><CustomerName/></TenantDetails></SystemDetails><ReturnMessages/></nm:WSQueryResponseMessage></env:Body></env:Envelope>";

        print FD "DEBUG: Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";
        $r_all = <<EORESPONSE;
                HTTP Code: $r_code
                HTTP Message: $r_message
                HTTP Content: $r_content
EORESPONSE


         if ($r_code eq '200')
        {
                my $mess = $xmlParser->XMLin($r_content);
		#print Dumper($mess);
                print FD "Message is $mess", "\n";
                print FD "xmlParser is $xmlParser", "\n";
                print FD "Content is $r_content", "\n";

                 my $tenant_id1 = $mess->{"env:Body"} {"n0:WSQueryResponseMessage"} {"SystemDetails"} {"AdminTenantId"} || "NULL";

                if ($tenant_id1 eq "NULL")
                {

                        print FD "\nDEBUG: Unknown atom in BLD \n";
			$returnvalue = 2;
			#$emailContent = "ERROR : Unknown atomid ${atomId} in BLD. Update ExternalID field in BLD";
			#sendmail($from, $to_list, "Unknown atomid in BLD", $emailContent ); 



                }
		else
                {
                   $tenant_id = $tenant_id1;
		   $returnvalue = 1;
		   print FD "DEBUG: Atom ID present in BLD \n";			
                }


        }
        else
        {
                #r_code ne 200
                print FD  "BLD ERROR response code $r_code", "\n";
                print FD  "$r_all \n";
                $returnvalue = 0;
		 my $emailContent = "Webservice Error - $r_all";
                        sendmail($from, $to_list, "Webservice Error", $emailContent );
        }
        
		return $returnvalue;
}



sub exec_record
{
 my $eid = $_[0];
 my $etype = '';

 $execxml = <<EOXML;
<QueryConfig xmlns="http://api.platform.boomi.com/">
  <QueryFilter>
	    <expression operator="EQUALS" property="executionId"
	      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="SimpleExpression">
	      <argument>$eid</argument>
	    </expression>
	  </QueryFilter>
</QueryConfig> 
EOXML


        print FD "DEBUG : Value of xml is $xml", "\n";
        my $xmlParser = new XML::Simple();
        print FD "DEBUG : Calling webservice function";
        $ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;

        my $response = call_webservice( $execurl, $usr, $pwd, $execxml );

        $r_content = $response->content;
        $r_code = $response->code;
        $r_message = $response->message;

        print FD "DEBUG: Web service Response content is $r_content, Response Code is $r_code, Response Message is $r_message \n";


  	if ($r_code eq '200')
        {
                my $mess = $xmlParser->XMLin($r_content);

                #print Dumper($mess);
                #print FD "\n DEBUG : Message is Dumper($mess)\n";

                $etype = $mess->{'bns:result'}{"bns:executionType"};    

	}
	else
	{
 		print FD  "BOOMI API  ERROR response code $r_code", "\n";
                $etype = 1;
                 my $emailContent = "BOOMI API Error - $r_code";
                        sendmail($from, $to_list, "BOOMI API Error", $emailContent );
	}

return $etype;
}	

