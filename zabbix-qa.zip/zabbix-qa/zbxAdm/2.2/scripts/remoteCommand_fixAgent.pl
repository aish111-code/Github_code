#!/usr/bin/perl

##################################################################
# Author        : Vikky Omkar
# Purpose       : Zabbix 2.2 Agent Fix script
# Reviewer      : Sandeep M.R
# Version       : Sep 29th 2015 - Initial code
#
####################################################################


use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;

# Local variable declaration

my @hostname;

# Add Modules and functions into local scope

        use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
        use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
        use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
        use TLDs qw(pfail);
        use SFSF::Host  qw(changestatus updatefqdn gethostnames_fromHostgroup gettechnames_fromHostgroup get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val build_host_template_list host_update search_cfg_Templates get_host_ip host_create_macro host_create_jmxinterface host_check_jmxinterface getHostnames_fromHostgroup build_config_mapping get_host_os check_temp_exists update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata host_metadatamacro hostcreate);
        use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
        use SFSF::Item qw(getLocalItems deletelocalitems);
        use SFSF::Web qw(getlocalwebmonitoring deletelocalwebmonitoring);
        use SFSF::Discovery qw(getlocaldiscoveryrule deletelocaldiscoveryrule);
        use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
        use SFSF::Log qw(addtoLogfile);
        use SFSF::Trigger qw(getlocaltriggers deletelocaltriggers get_triggerobj gettriggerobj_val);


# Detect running env and set the connection variables

        open(my $fh,'< /etc/hosts');
        my $env;

        while (my $line = <$fh>)
        {
                chomp $line;
                if ($line ne "" and $line =~ m/lab/ )
                {
                        $env = 'qa';
                }
                else { $env = 'prod' ; }
        }

# Load API properites file

        my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
        pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
        pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
        pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


#=pod
my %args;
my @alertname;

        GetOptions(\%args,
                        "UpdateFqdnName",
			"ChngHostStat"
                )
                or die "Invalid arguments ! Required Param: $0 -UpdateFqdnName <Present_Name> \n";
die "Missing options -
		-ChngHostStat <hostname>  <'1'-Disable,'0'-Enable>
                -UpdateFqdnName <Present_Name> \n" unless %args;

        my @key = keys (%args);
# Connect to Zabbix API and write authid to /tmp/hostname.tmp

        my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

        switch ($key[0]){
	
	 case "ChngHostStat" {
                                chomp(my $host = $ARGV[0]);
                                chomp(my $status = $ARGV[1]);
                                my $currentstatus = changestatus($zabbix,$host,$status);

                             }

        case "UpdateFqdnName" {
                                chomp(my $Present_Name = $ARGV[0]);
                                chomp(my $date=`date`);
                                my $logfile = "/var/log/zabbix/UpdateFqdn.txt";
                                my $fqdnname = `nslookup $Present_Name`;

                                if($fqdnname=~/$Present_Name/)
                                        {
                                          if($fqdnname=~/Name:\s*(.*?)\s/)
                                                {
                                                my $fqdnresult = updatefqdn($zabbix,$Present_Name,$1);
#print Dumper($fqdnresult);
                                                if($fqdnresult->{'hostids'})
                                                 {
                                                open (Handle,">>$logfile") or die " couldn't open $logfile to write!!";

                                                print Handle "$date :  $1 FQDN hostname updated\n\n";
                                                }

                                                }
                                        }

				}

			}


