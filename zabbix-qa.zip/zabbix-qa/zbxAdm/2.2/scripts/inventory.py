
##################################################################
# Author        : Sreekanth K P
# Purpose       : Zabbix inventory script
# Version       : 1.0
##################################################################
import json
import requests
import sys
import getpass
print "Enter your zabbix user name and password"
user = raw_input("User: ")
password = getpass.getpass()

mapping={'0': 'ENABLED', '1': 'DISABLED'}
url = "http://10.4.196.101/zabbix/api_jsonrpc.php"
headers = {"Content-Type": "application/json"}
login_data=json.dumps({
    "jsonrpc": "2.0",
    "method": "user.login",
    "params": {
        "user": user,
        "password": password
    },
    "id": 1
})
out = requests.post(url, data=login_data, headers=headers )


template_data=json.dumps(
{
    "jsonrpc": "2.0",
    "method": "host.get",
    "params": {
        "output": [ "host", "name", "status" ],
        "selectParentTemplates": [ "name" ],
        "selectGroups": [ "name" ],
        "selectInterfaces": [ "ip" ]
    },
    "id": 1,
    "auth": out.json()['result'].rstrip('\n')
})

template = requests.post(url, data=template_data, headers=headers )
template_out=json.loads(template.content)
print "HOSTNAME|VISIBLENAME|STATUS|IPADDRESS|TEMPLATES|GROUPS"
for t in template_out['result']:
        sys.stdout.write(t['host'])
        sys.stdout.write('|')
        sys.stdout.write(t['name'])
        sys.stdout.write('|')
        stat=t['status']
#       VALUE=mapping[stat]
        sys.stdout.write(mapping[stat])
        sys.stdout.write('|')
        count=len(t['interfaces'])
        new_count=0
        for t3 in t['interfaces']:
                sys.stdout.write(t3['ip'].rstrip('\n'))
                new_count=new_count+1
                if  new_count < count :
                        sys.stdout.write(',')
        sys.stdout.write('|')
        count=len(t['parentTemplates'])
        new_count=0
        for t1 in t['parentTemplates']:
                sys.stdout.write(t1['name'].rstrip('\n'))
                new_count=new_count+1
                if  new_count < count :
                        sys.stdout.write(',')
        sys.stdout.write('|')
        count=len(t['groups'])
        new_count=0
        for t2 in t['groups']:
                sys.stdout.write(t2['name'].rstrip('\n'))
                new_count=new_count+1
                if  new_count < count :
                        sys.stdout.write(',')
        sys.stdout.write('\n')



