#!/bin/bash

##################################################################
# Author: Sandeep M.R, Platform Services
# Purpose: Wrapper script to generate host inventory from zabbix
# Date   : July 13th 2015
##################################################################

/usr/local/etc/zbxAdm/2.2/scripts/report.pl -hostinventory > /var/log/zabbix/zbxInventory.txt
