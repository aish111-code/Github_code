#!/usr/bin/perl

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;
use File::Basename;

# Local variable declaration

# Add Modules and functions into local scope
my %args;

GetOptions(\%args,"templatefile=s", "option=s");

die "Missing options:
           -templatefile <template file>,
           -option <import|export> " unless %args ;


my $tem_file = $args{templatefile};
my $option = $args{option};
open(FH, "<", $tem_file ) or die "Can not open file\n";

while (my $template_filename=<FH>) {
    chomp($template_filename);
    $template_filename = basename($template_filename);
    $template_filename =~ s/\.xml//;
    

    my $new_file = "/usr/local/etc/zbxAdm/2.2/scripts/templates_to_import/batch11/" . $template_filename . ".xml";
    $new_file =~ s/\s/_/g;

    if ( $option eq 'export' ) {
        my $cmd = "/usr/local/etc/zbxAdm/2.2/scripts/templateImportExport.pl -template '$template_filename' -option export -destination $new_file -format xml";
        system($cmd);
        print($cmd);
        print("\n");
    }
    elsif ( $option eq 'import' ) {
        my $cmd = "/usr/local/etc/zbxAdm/2.2/scripts/templateImportExport.py --template '$template_filename' --option import --source $new_file --frmat xml";
        system($cmd);
        print($cmd);
        print("\n");
    }
}

close(FH);

