#!/bin/bash

###################################################
# Author : Sandeep M.R
# Purpose : Wrapper script to generate PLT reports
####################################################


su - zabbix -c '/usr/local/etc/zbxAdm/2.2/scripts/generatePLTreport.sh'
