#!/usr/bin/perl

##################################################################
# Author        : Sandeep M.R
# Purpose       : Zabbix 2.2 reporting script
# Reviewer      : Patrick Presto
# Version       : Jan 20th 2015 - Initial code
#               : Jan 26th 2015 - Added report.pm,-hostinventory option
#               : May 6th 2015 - Added -item_status function (Vikky Omkar)
#		: Sep 11th 2015 - Added TriggerReport function (Vikky Omkar)
####################################################################

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

# Local variable declaration

my @hostname;

# Add Modules and functions into local scope

	use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
	use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
	use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
	use TLDs qw(pfail);

	use SFSF::Host qw(gettechnames_fromHostgroup get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os);
	use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
	use SFSF::Log qw(addtoLogfile);
	use SFSF::Trigger qw(get_triggerobj gettriggerobj_val);
	use SFSF::Report qw(getTrigger gethostInventory  getgroupsInventory getHistory get_Item_Last_Value get_host_name getAging getevents);

# Detect running env and set the connection variables

	open(my $fh,'< /etc/hosts');
	my $env;

	while (my $line = <$fh>)
	{
   		chomp $line;
   		if ($line ne "" and $line =~ m/lab/ )
        	{	
        		$env = 'qa';
        	}
    		else { $env = 'prod' ; }
	}	

# Load API properites file

	my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
  	pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
  	pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
  	pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};


#=pod

# Connect to Zabbix API and write authid to /tmp/hostname.tmp
	
	my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});

my %args;
GetOptions(\%args, "dataCenter=s", "all" ) or die "Invalid arguments \n";
if ( ! %args  || ! ( $args{dataCenter} || $args{all} ) ) { ###if nothing passed or something other than accepted parameters
    die "Missing options -
         $0
                -all
                   OR
                -dataCenter < DC Number e.g. DC2 > 
         Example: $0 -all 
               OR
                  $0 -dataCenter DC2 \n";

}
                         # Get Hostgroup object

my %proxyIdToDCMap = ( 
                         10126 => 'DC2',
                         10182 => 'DC4',
                         10144 => 'DC5',
                         12475 => 'DC8',
                         11144 => 'DC8',
                         17291 => 'DC10',
                         13310 => 'DC12',
                         15913 => 'DC15',
                         17732 => 'DC16',
                         20749 => 'DC17',
                         23471 => 'DC18',
                         30877 => 'DC19',
                     );
                         

###used for this script purpose
my $invDumpFile = "/tmp/zbxDumpFile.csv";
##used to copy to web host to view from url https://zabbix-hcm.ondemand.com/zabbix/cops/zbxInventory.txt
##Both files almost same except the 1 or 2 columns
my $inventoryFile = "/tmp/zbxInventory.txt";
get_hosts( $zabbix );

sub get_hosts {
    my ( $zabbix ) = @_;

    if( exists $args{dataCenter} ) {
        $invDumpFile = "/tmp/zbxDumpFile_" . uc($args{dataCenter}) . ".csv";
    }
    open FH, ">", $invDumpFile or die "Can not open to write $invDumpFile:$! \n";
    print FH "Hostname,Host,IP,Host Status,DC,Groups\n";
    open ZBXFH, ">", $inventoryFile or die "Can not open to write $inventoryFile:$! \n";
    #print FH "#Hostname, IP, OS,Group 1, Group 2....Group n\n";
    #my %tfilter = ( 'output' => 'extend', 'filter' => { 'proxy_hostid' => [ 15534 ] }  );
    my %tfilter = ( 'output' => [ 'hostid', 'host', 'name','status', 'proxy_hostid' ], 'selectInterfaces' => [ 'ip', 'port' ], 'selectGroups' => [ 'name' ] );

    my $params = {%tfilter};
    my $api_result = $zabbix->raw('host','get', $params);

    foreach my $result ( @$api_result ) {
        my $hostId   = $result->{hostid};
        my $name = $result->{name};
        my $host = $result->{host};
        my $tmpstatus = $result->{status};
        my $status = $tmpstatus ? 'Disabled' : 'Enabled'; ##if status 0=enabled, 1=disabled
        my $proxy_hostid = $result->{proxy_hostid};   
        my @groups;
        my $grpString;
        my @ips;
        my %groupHash;
        foreach my $grpObj ( @{$result->{groups}} ) {
            push @groups, $grpObj->{name} if ( ! exists $groupHash{$grpObj->{name}} );
            $groupHash{$grpObj->{name}} = 1;
        }
        $grpString = join ",", @groups;
        my %ipHash;
        foreach my $ipObj ( @{$result->{interfaces}} ) {
            next if ( $ipObj->{ip} eq '0.0.0.0' );
            next if ( $ipObj->{port} != 10050 );  ##consider ips only of port 10050. Not jmx or other ips
            push @ips, $ipObj->{ip} if ( ! exists $ipHash{$ipObj->{ip}} );
            $ipHash{$ipObj->{ip}} = 1;
        }
       
        my $hostOS = _getOS($zabbix, $hostId, $name);

        my $dataCenter = _findDataCenter($proxy_hostid, $name, \@groups );
        if( exists $args{dataCenter} ) { 
            next if ( $dataCenter !~ /\b$args{dataCenter}\b/i );
        }
        print FH "$name, $host, @ips, $status, $dataCenter, @groups\n";
        print ZBXFH "$name, @ips, $hostOS, $grpString\n";
    }
    close(FH);
    close(ZBXFH);


}

sub _findDataCenter {
 
    my ($proxy_hostid, $hostName, $groupsRef) = @_;
  
    my %proxyIdToDCMapRev = reverse %proxyIdToDCMap;
    my $dc = 'unknown';
    my $grpStr = join " ", @$groupsRef;
    if( $grpStr =~ /(dc|pc|ps|sc|pf|pd)(\d{1,2})/i ) {
        my $num = $2;
        if( $num =~ /0(\d)/ ) {
            $num = $1;
        }
        $dc = 'DC' . $num;
        if ( ! exists $proxyIdToDCMapRev{$dc} ) {
            $dc = 'unknown';
        }
    }

    #yet DC is not discovered
    if ( $dc eq 'unknown' && $hostName =~ /(dc|pc|ps|sc|pf|pd)(\d{1,2})/i ) {
        my $num = $2;
        if( $num =~ /0(\d)/ ) {
            $num = $1;
        }
        $dc = 'DC' . $num;
        if ( ! exists $proxyIdToDCMapRev{$dc} ) {
            $dc = 'unknown';
        }
    }
    if ( $dc eq 'unknown' && exists $proxyIdToDCMap{$proxy_hostid} ) {
        $dc = $proxyIdToDCMap{$proxy_hostid};
    }



    $dc = $dc;
    return $dc;
 
}

sub _getOS {

    my ( $zabbix, $hostId, $hostName ) = @_;    
    my $hostOS = 'No OS Data';
    my $result = SFSF::Host::get_host_os($zabbix,$hostId);
    if ( $result =~ /Linux/i ){
        $hostOS = 'Linux';
    }
    elsif ( $result =~ /Windows/i ){
        $hostOS = 'Windows';
    }
    elsif ( $result =~ /Sun/i ){
        $hostOS = 'Sun';
    }
    
    return $hostOS;
}


my $lines = `wc -l $inventoryFile`;
chomp($lines);
$lines = (split /\s+/, $lines)[0];
my $mails = 's.renuka@sap.com,pradip.kumar.k@sap.com';
my $mailCmd;
if ( $lines > 6000 ) {
    $mailCmd = qq~ echo "SFSF Zabbix Inventory Generation Succesful - No of Hosts $lines"  | mailx -r "sapsfplatformmonitoring\@sap.com" -s "Zabbix Inventory Generation Successful" $mails ~;
}
else{

    $mailCmd = qq~ echo "SFSF Zabbix Inventory Generation Failed - No of hosts found $lines"   | mailx -r "sapsfplatformmonitoring\@sap.com" -s "Zabbix Inventory Generation Failed" $mails ~;
}
system($mailCmd);
