#!/usr/bin/perl

use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';

use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;
use Switch;
use Date::Parse;

# Local variable declaration

# Add Modules and functions into local scope

use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLDs qw(pfail);
use SFSF::Log qw(addtoLogfile);

my $tempalteRules = "/usr/local/etc/zbxAdm/2.2/conf/templateImportRules.conf";
open my $tconfFH, $tempalteRules or die "No configuration file $tempalteRules to read import rules :$! \n";


my %importRule;
while (my $line = <$tconfFH>) {
    chomp($line);
    my @rules = split /\|/, $line;
    my $category = $rules[0];
    chomp($category);
    my $actions = $rules[1];
    chomp($actions);
    foreach my $action ( split ",", $actions ) {
        $importRule{$category}{$action} = "true";
    }
}
close($tconfFH);


my %args;
GetOptions(\%args,"template=s","option=s","destination=s","source=s", "format=s"); 

die "Missing options:    
           -template <template name>
           -option <import|export>
           -source <source file to import from ( valid for import only ) >
           -destination <file to export to ( valid for export only ) >
           -format <xml|json> : default xml
           -dc [ optional datacenter argument if running from different Datacenter : DC23 or DC42 ] \n" unless %args ;
           
# Detect running env and set the connection variables

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

if ( exists $args{dc} && $args{dc} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{dc} && uc $args{dc} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}

my $config = get_rsm_config($configFile);
pfail("Zabbix API URL is not specified. Please check configuration file") unless defined $config->{$env}->{'url'};
pfail("Username for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'user'};
pfail("Password for Zabbix API is not specified. Please check configuration file") unless defined $config->{$env}->{'password'};
my $count = 0;
my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


my $format = $args{format} || 'xml';
my $templateName = $args{template};
my @templatesToExport = split ",", $templateName;
my $sourceFile = $args{source};
my $destinationFile = $args{destination} || "/tmp/$templateName" . $format;
my $option = $args{option};


if( $option eq 'import' ) {
    importTemplate( $zabbix, $templateName, $sourceFile, $format );
}
elsif( $option eq 'export' ) {
    exportTemplate( $zabbix, \@templatesToExport, $destinationFile, $format );
}
else{
    print "Unknown option : option \n";
    exit 1;
}

sub importTemplate {
    my ( $zabbix, $templateName, $sourceFile, $format ) = @_;

    my $template_id = get_templateid ($zabbix, $templateName);
    pfail("No such template or cannot return template id") unless defined $template_id;
    
    open my $fg, "<", $sourceFile or die "Can not open $sourceFile, please check if the file exists:$! \n";
    local $/=undef;
    my $data = <$fg>;
    my %tfilter = ( 'format' => $format, 'rules' => { %importRule }  , 'source' => $data );
    #my %tfilter = ( 'format' => $format, 'rules' => { 'templates' => { "createMissing" => "true", "updateExisting" => "true" }, 'items' => { "createMissing" => "true", "updateExisting" => "true" }, 'triggers' => { "createMissing" => "true", "updateExisting" => "true" }, 'templateScreens' => { "createMissing" => "true", "updateExisting" => "true" }, 'discoveryRules' => { "createMissing" => "true", "updateExisting" => "true" }, 'graphs' => { "createMissing" => "true", "updateExisting" => "true" }, 'templateLinkage' => { "createMissing" => "true" }, 'applications' => { "createMissing" => "true" }, 'groups' => { "createMissing" => "true", "updateExisting" => "true" }}  , 'source' => $data );
    my $params = {%tfilter};
    $zabbix->raw('configuration','import', $params);
    close($fg);

    return;

}
sub exportTemplate {
    my ( $zabbix, $templatesToExportRef, $destinationFile, $format ) = @_ ;

    my @templateIds;
    foreach my $templateName ( @$templatesToExportRef ) {
        my $template_id = get_templateid ($zabbix, $templateName);
        pfail("No such template or cannot return template id") unless defined $template_id;
        push @templateIds ,$template_id;
    }
    
    open my $efh, ">", $destinationFile or die "Can not open file $destinationFile to write :$! \n";
    my %tfilter = ( 'options' => { "templates" => [ @templateIds ] }, "format" => $format );
    my $params = {%tfilter};
    my $api_result = $zabbix->raw('configuration','export', $params);
    #print Dumper $api_result;

    print $efh $api_result;

    close($efh);
    return;
}
sub get_templateid {
    my ($zabbix,$template_name)  = @_;
    my $options = {'output' => ['templateid'], 'filter' => {'host' => $template_name}};
    my $result = $zabbix->get('template', $options);
    return if ( ! defined $result );
    my $template_id = $result->{templateid};
    return $template_id;

}

