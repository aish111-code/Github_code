#!/usr/bin/perl -w

###########################################################
# Author  : Pradip
# Purpose : Zabbix Auto Registration API Framework
# Date    : Jan 2018
############################################################


use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/site_perl/5.10.0';

use strict;
use warnings;

# Build @INC to point to relative ./lib for modules

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(abs_path $0) . '/../lib';
use lib dirname(abs_path $0) . '/../lib/perl5';


use Getopt::Long;
use JSON::RPC::Client;
use JSON;
use Encode;
use Carp;
use LWP::UserAgent;
use LWP::Protocol::https;
use Data::Dumper;

# Local variable declaration


use Zabbix qw(new ua get remove update event_ack create exist massadd massremove create_interface);
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file
use TLD_constants qw(:general :templates :value_types :ec :rsm :slv :config :api);
use TLDs qw(pfail);

use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata);
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);
use SFSF::Template qw(get_templateobj get_templateobj_val get_template);
use SFSF::Log qw(addtoLogfile);

# Detect running env and set the connection variables


my %args;

GetOptions(\%args,
                        "datacenter=s",
                        "pattern=s",
           );


if( ! scalar keys %args ) {
    usage();
}

    #-metricName < metric name >			        - options: system.cpu.load or system.cpu.load[,avg5] or vm.memory.size[pavailable] or jmx[\"java.lang:type=Memory\",HeapMemoryUsage.used] or jmx[\"java.lang:type=Memory\",HeapMemoryUsage.max]
sub usage {

    printf("%s 
    -datacenter < DCx>  	                        - Datacenter 
    -pattern< pattern >                                 - host pattern (full) to add

    Example: %s -datacenter DC2 -pattern '(dc2wfahanadb)+:pc2_WFA_HanaDB,All-DB-HANA:T_WFA_HANA' \n", $0, $0 ) ;

    exit 1;
}

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

# Load API properites file
if ( exists $args{datacenter}  && $args{datacenter} eq 'DC23' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
}
elsif ( exists $args{datacenter} && $args{datacenter} eq 'DC42' ) {
    $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC42.conf';
}

my $config = get_rsm_config($configFile);

# Connect to Zabbix API and write authid to /tmp/hostname.tmp

my $zabbix = Zabbix->new({'url' => $config->{$env}->{'url'}, user => $config->{$env}->{'user'}, password => $config->{$env}->{'password'}});


##Zabbix web host is in Eastern time......so convert all time time EDT
my $dc = $args{'datacenter'};
my $pattern = $args{'pattern'};
addPattern($zabbix, $dc, $pattern);


sub addPattern {
    my ( $zabbix, $dc, $pattern ) = @_;

    if( ! defined $zabbix ) {
        print "Some input parameters are not provided :" .  usage() . "\n";
        exit 1;
    }
 
    my $cfgFile = "/usr/local/etc/zbxAdm/2.2/conf/${dc}.hostMapping.cfg";
    system("echo $pattern >> $cfgFile");
    if ($? == 0) {
        print("Added successfully\n");
        exit 0;
    }
    else {
        print("Failed \n");
        exit 1;
    }
}
