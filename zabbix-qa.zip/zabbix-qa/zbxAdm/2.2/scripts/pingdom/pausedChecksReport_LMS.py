#This script provides list of LMS paused checks and send to subodh.kushwaha@sap.com
#Crontab entry create for this script on 10.4.196.100
#30 22 * * 0 /opt/python27/bin/python2.7 /home/roaming/C5263443/pingdom/pausedChecksReport_LMS.py >/dev/null 2>&1
import requests
import json
import re
import datetime
import csv
import sys
import os
from datetime import date

filename = 'LMS_PingdomPausedChecks_{}.csv'.format(date.today())
reload(sys)
sys.setdefaultencoding('utf8')
search_string = 'LMS'
pingdomApiUrl = 'https://api.pingdom.com/api/2.0/checks'
auth = ('cloudops.imc@sap.com', 'cloud123')
headers = {'App-Key': 'e369zksyxc0mys9ms579u5ag3yg3bfzj','Account-Email':'hosting_mgr@plateau.com'}

response = requests.get(pingdomApiUrl, auth=auth, headers=headers)
checks_parsed = json.loads(response.text)
chk_data = checks_parsed['checks']
pauseChk = [x for x in chk_data if ((not x['name'].startswith('[IGNORE]')) and (x['status'] == 'paused') and (x['name'].find(search_string)) > 0)]
	
for x in pauseChk:
		x.pop('acktimeout', None)
		x.pop('ipv6', None)
		x.pop('lastresponsetime', None)
		x.pop('resolution', None)
		x.pop('use_legacy_notifications', None)
		x.pop('autoresolve', None)
		try:
			product = re.search(':(.*?)\]', x['name']).group(1)
			DC = re.search('\[(.*?):', x['name']).group(1)
		except AttributeError:
			product = "N/A"
			DC = "N/A"
		x['Product'] = product
		x['DC'] = DC
		x['created'] = datetime.datetime.fromtimestamp(x['created']).strftime('%Y-%m-%d %H:%M:%S')
		try:
			x['lasttesttime'] = datetime.datetime.fromtimestamp(x['lasttesttime']).strftime('%Y-%m-%d %H:%M:%S')
		except KeyError:
			x['lasttesttime'] = "N/A"
			
		try:
			x['lasterrortime'] = datetime.datetime.fromtimestamp(x['lasterrortime']).strftime('%Y-%m-%d %H:%M:%S')
		except KeyError:
			x['lasterrortime'] = "N/A"
			
	
# open a file for writing

with open('/tmp/pingdom/%s' % filename, 'w') as f:

    dict_writer = csv.DictWriter(f, fieldnames=['id', 'created', 'lasttesttime', 'name', 'hostname', 'type', 'status', 'DC', 'Product', 'alert_policy_name', 'lasterrortime', 'alert_policy'])
    dict_writer.writeheader()
    dict_writer.writerows(pauseChk)
	
f.close()
os.system("mailx -a /tmp/pingdom/" + filename + "  -s \"Pingdom LMS Paused checks\" -r no-reply@sap.com subodh.kushwaha@sap.com vnr.sridhar.manepalli@sap.com < /dev/null")
