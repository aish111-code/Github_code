import requests
import json
import re
import datetime
import csv
import sys
import os

reload(sys)
#sys.setdefaultencoding('utf8')

pingdomApiUrl = 'https://api.pingdom.com/api/2.1/checks'
auth = ('Bikramjit.Sengupta@sap.com', 'Succ3$$F@ct0r$')
headers = {'App-Key': 'e369zksyxc0mys9ms579u5ag3yg3bfzj','Account-Email':'hosting_mgr@plateau.com'}

response = requests.get(pingdomApiUrl, auth=auth, headers=headers)
checks_parsed = json.loads(response.text)
chk_data = checks_parsed['checks']
pauseChk = [x for x in chk_data if ((not x['name'].startswith('[IGNORE]')) and x['status'] == 'paused' and ((('lasttesttime' in x)) and  ((((datetime.datetime.today() - datetime.timedelta(hours=24)) < datetime.datetime.fromtimestamp(x['lasttesttime']) and (datetime.datetime.today() - datetime.timedelta(hours=8)) > datetime.datetime.fromtimestamp(x['lasttesttime']))))))]

count = 0	
for x in pauseChk:
		count += 1
		x.pop('acktimeout', None)
		x.pop('ipv6', None)
		x.pop('lastresponsetime', None)
		x.pop('resolution', None)
		x.pop('use_legacy_notifications', None)
		x.pop('autoresolve', None)
		x.pop('verify_certificate', None)
		try:
			product = re.search(':(.*?)\]', x['name']).group(1)
			DC = re.search('\[(.*?):', x['name']).group(1)
		except AttributeError:
			product = "N/A"
			DC = "N/A"
		x['Product'] = product
		x['DC'] = DC
		x['created'] = datetime.datetime.fromtimestamp(x['created']).strftime('%Y-%m-%d %H:%M:%S')
		try:
			x['lasttesttime'] = datetime.datetime.fromtimestamp(x['lasttesttime']).strftime('%Y-%m-%d %H:%M:%S')
		except KeyError:
			x['lasttesttime'] = "N/A"
			
		try:
			x['lasterrortime'] = datetime.datetime.fromtimestamp(x['lasterrortime']).strftime('%Y-%m-%d %H:%M:%S')
		except KeyError:
			x['lasterrortime'] = "N/A"
			
	
if count > 0:
# open a file for writing
	#print(pauseChk)

	with open('/home/roamingold/I863215/scripts/PingdomRecentPausedChecks.csv', 'w') as f:

		dict_writer = csv.DictWriter(f, fieldnames=['id', 'created', 'lasttesttime', 'name', 'hostname', 'type', 'status', 'DC', 'Product', 'alert_policy_name', 'lasterrortime', 'alert_policy'])
		dict_writer.writeheader()
		dict_writer.writerows(pauseChk)
	
		f.close()

		#os.system("mailx -a /home/roamingold/I863215/scripts/PingdomRecentPausedChecks.csv  -s \"Action Required - Pingdom checks lying paused for more than 8 hours\" -r sapsfsdotoolsandutils@sap.com bikramjit.sengupta@sap.com < /dev/null")
		os.system("mailx -a /home/roamingold/I863215/scripts/PingdomRecentPausedChecks.csv  -s \"Action Required - Pingdom checks lying paused for more than 8 hours\" -r sapsfsdotoolsandutils@sap.com vidhya.k@sap.com devadas.kv@sap.com rajashree.g@sap.com ganesan.karuppasamy@sap.com sutha.piriyan.unni.krishnan@sap.com jibin.sunny@sap.com rakhesh.ms@sap.com prajwal.arunachala@sap.com sainadh.vadlamudi@sap.com bikramjit.sengupta@sap.com vnr.sridhar.manepalli@sap.com prajwal.arunachala@sap.com nandhini.chander@sap.com rajashree.g@sap.com pradip.kumar.k@sap.com sreekanth.kp@sap.com vnr.sridhar.manepalli@sap.com vishwas.mohan@sap.com rakhesh.ms@sap.com d.raj@sap.com s.renuka@sap.com bikramjit.sengupta@sap.com jibin.sunny@sap.com sainadh.vadlamudi@sap.com adrian.arduini@sap.com keith.burke@sap.com edit.csontos@sap.com zoltan.laszlo.dory@sap.com balint.hollosy@sap.com gabor.kaszonyi@sap.com arun.kumar.r.p@sap.com bineet.kumar@sap.com tarun.kumar.pachipulsu@sap.com anthony.sanchez@sap.com saravanan.segar@sap.com yim.wang@sap.com sapsfrtomonitoring@sap.com < /dev/null")

