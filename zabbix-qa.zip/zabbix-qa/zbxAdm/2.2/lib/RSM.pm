package RSM;

use strict;
use warnings;

#use lib '/usr/local/etc/zbxAdm/2.2/lib/myCorelib/lib/perl5' ;

#use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/lib';
#use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0/x86_64-linux-thread-multi';
#use lib '/usr/local/etc/zbxAdm/2.2/lib/perl5/5.10.0';

# Build @INC to point to relative ./lib for modules

#use File::Basename qw(dirname);
#use Cwd  qw(abs_path);
#use lib dirname(abs_path $0) . '/../lib';
#use lib dirname(abs_path $0) . '/../lib/perl5';



use Config::Tiny;
use base 'Exporter';

our @EXPORT = qw(get_rsm_config);

#my $config_file = '/usr/local/etc/zbxAdmin/2.2.4/current/scripts/zbx.conf';
#my $config_file = '/opt/zabbix/scripts/rsm.conf';

sub get_rsm_config
{
    my $config_file = shift;
    my $config = Config::Tiny->new;

    $config = Config::Tiny->read($config_file);

    unless (defined($config))
    {
	print STDERR (Config::Tiny->errstr(), "\n");
	exit(-1);
    }

    return $config;
}

sub find_env_details {
    my ( $inp ) = @_;

    open(my $fh,'< /etc/hosts');
    my $env;
    my $configFile;
          
    if( $inp eq 'env' ) {
        while (my $line = <$fh>) {
            chomp $line;
            if ($line ne "" and $line =~ m/lab/ ) {
                $env = 'qa';
            }
            else { 
                $env = 'prod' ; 
            }
        }
        return $env;
    }
    elsif ( $inp eq 'config' ) {
        while (my $line = <$fh>) {
            chomp $line;
            if( $line =~ /mg4zbxserver01/ ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';
            }
           elsif( $line =~ /(ss01zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC1.conf';
            } 	    
            elsif( $line =~ /(pc23)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC23.conf';
            }
            elsif( $line =~ /(pc22)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC22.conf';
            }
	    elsif( $line =~ /(ss25zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC25.conf';
            }	    
            elsif( $line =~ /(ss30zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC30.conf';
            }
	   elsif( $line =~ /(ss32zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC32.conf';
            }	    
           elsif( $line =~ /(ss33zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC33.conf';
            }	    
           elsif( $line =~ /(ss34zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC34.conf';
            }	
	    elsif( $line =~ /(ss47)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC47.conf';
            }
	    elsif( $line =~ /(ss41zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC41.conf';
	   
            }
            elsif( $line =~ /(ss43zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC43.conf';
            }	
            elsif( $line =~ /(ss50zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC50.conf';
            }
            elsif( $line =~ /(ss51zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC51.conf';
            }
             elsif( $line =~ /(ss52zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC52.conf';
            }
	    elsif( $line =~ /(ss55zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC55.conf';
            }	    
	    elsif( $line =~ /(ss56zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC56.conf';
            }
            elsif( $line =~ /(ss57zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC57.conf';
            }
            elsif( $line =~ /(ss58zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC58.conf';
            }
	    elsif( $line =~ /(ss60zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC60.conf';
            }
	    elsif( $line =~ /(ss61zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC61.conf';
            }	    
	     elsif( $line =~ /(ss62zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC62.conf';
            }
             elsif( $line =~ /(ss64zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC64.conf';
            }
             elsif( $line =~ /(ss65zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC65.conf';
            }
            elsif( $line =~ /(ss66zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC66.conf';
            }
	    elsif( $line =~ /(ss67zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC67.conf';
            }
           elsif( $line =~ /(ss68zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC68.conf';
            }
           elsif( $line =~ /(ss69zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC69.conf';
            }
           elsif( $line =~ /(ss70zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC70.conf';
            }
           elsif( $line =~ /(ss71zbx)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC71.conf';
            }
           elsif( $line =~ /(ss74)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC74.conf';
            }	    
           elsif( $line =~ /(ss75)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC75.conf';
            }
           elsif( $line =~ /(ss80)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC80.conf';
            }	
	   elsif( $line =~ /(ss82)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC82.conf';
            }
           elsif( $line =~ /(ss81)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC81.conf';
            }
	    elsif( $line =~ /(ss83)/i ) {
                $configFile = '/usr/local/etc/zbxAdm/2.2/conf/zbxDC83.conf';
            }
	    
        }
        return $configFile;
    }
}



1;
