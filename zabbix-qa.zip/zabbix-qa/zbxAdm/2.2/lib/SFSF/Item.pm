#!/usr/bin/perl

package SFSF::Item;


use Exporter qw(import);
our @EXPORT_OK = qw(getLocalItems deletelocalitems getLocalItemsByHostId);


use strict;
use warnings;
use JSON::RPC::Client;
use JSON;
use Data::Dumper;
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID uniq);
use RSM qw(get_rsm_config);
use SFSF::Log qw(addtoLogfile);


#my $config = get_rsm_config('./conf/zbx.conf');
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

my $config = get_rsm_config($configFile);

sub getLocalItems {
                my  $zabbix = $_[0];
                my $host = $_[1];
                my $options = {'output' =>'extend','host' =>$host,'inherited' => '0','filter' =>{'flags' => '0'}};#'filter' =>{'templated' => '1'}};
                my $myresult = $zabbix->raw('item','get',$options);

                }

sub deletelocalitems {
                        my $zabbix = $_[0];
                        my @itemid =@{$_[1]};
                        my $myresult = $zabbix->raw('item','delete',\@itemid);

                        return $myresult->{'itemids'};

                        }

sub getLocalItemsByHostId {
    my $zabbix = $_[0];
    my $hostId = $_[1];
    my $options = {'output' =>'extend','hostids' => $hostId, 'inherited' => '0','filter' =>{'flags' => '0'}};#'filter' =>{'templated' => '1'}};
    my $myresult = $zabbix->raw('item','get',$options);

    return $myresult;
}

1;
