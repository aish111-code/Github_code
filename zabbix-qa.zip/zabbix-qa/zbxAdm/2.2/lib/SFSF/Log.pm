#!/usr/bin/perl

package SFSF::Log;


use Exporter qw(import);
our @EXPORT_OK = qw(addtoLogfile addtodc17logfile);

#use 5.010;
use strict;
use warnings;
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file using relative path to zabbix.pl
#my $config = get_rsm_config('./conf/zbx.conf');
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

my $config = get_rsm_config($configFile);

sub addtoLogfile {
   my $log;
   my $log1;
	if($_[1] eq "")
	  {
		$log = $config->{'sap'}->{'logfile'};
	  }	
	else
	  {
		$log1 = $config->{'sap'}->{'hostupdatelogfile'};
		$log = $log1.'_'.$_[1].'.'.'txt'; 
	  }


  my $message = $_[0];
  my $timestamp = localtime(time);

  open my $fh, '>>', $log ;
  print $fh "\n$timestamp : $message";
  close $fh;

}


1;
