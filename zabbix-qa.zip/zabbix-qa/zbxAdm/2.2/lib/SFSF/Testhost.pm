#!/usr/bin/perl

package SFSF::Testhost;


use Exporter qw(import);
our @EXPORT_OK = qw(update_host_visible_name  edit_host_monitoring  check_host_exists get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val build_host_template_list host_update search_cfg_Templates get_host_ip host_create_macro host_create_jmxinterface host_check_jmxinterface getHostnames_fromHostgroup build_config_mapping get_host_os check_temp_exists);

#use 5.010;
use strict;
use warnings;
use JSON::RPC::Client;
use JSON;
use Data::Dumper;
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID uniq);
use RSM qw(get_rsm_config);
use SFSF::Log qw(addtoLogfile);

my @hostlist;
my $hostID;
#my $config = get_rsm_config('./conf/zbx.conf');
my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');

# Requires zabbix class as first input to use host.get for all parameters
# Optional second parameter that takes filter ex:  %filter = ('host' => 'DC13BIZX2CFAPP02');
sub get_hostobj($;$) {
  my %output = ('output' => 'extend');
  my $zabbix = $_[0];
  my $params;
  if ($_[1]) {
    my %tfilter = ('filter' => $_[1]);
    $params = {%output, %tfilter};
    my $api_result = $zabbix->raw('host','get', $params);
=pod    if ( ref($api_result) eq 'ARRAY' ){
      return @$api_result;
    }
    return $api_result;

  } else {
    $params = {%output};
    my $api_result = $zabbix->raw('host','get', $params);
    return @$api_result;
  }
=cut
	   return $api_result;
}

}


# Iterate through all host.get objects returned from get_all_hostobj.  Return array of all objects matching regex 
sub get_hostobj_val {
  my @hostObj = @{$_[0]};
  my $re = qr/^$_[1]$/;
  my @hostObjVal;
  foreach (@hostObj){
    my $key;
    my $value;
    while (($key,$value) = each %{$_}) {
      push @hostObjVal,$value if $key =~ $re;
    }
  }
  return @hostObjVal;
}



sub get_host_ip {
  my $zabbix = $_[0];
  my $HOSTID = $_[1];
  my $HOSTIP ;

  #foreach (@HOSTID) {
    #my $options = {'output' => 'extend', 'filter' => {'hostid' => $_, 'type' => '1' } };
    #my $options = {'output' => 'extend', 'filter' => {'hostid' => $_[1], 'type' => '1' } };
    my $options = {'output' => 'extend', 'filter' => {'hostid' => $HOSTID, 'type' => '1' } };
    my $myresult = $zabbix->raw('hostinterface','get', $options);
   #   push @HOSTIP,$myresult->{'ip'};

	#print Dumper($myresult);

   #foreach my $host (@{$myresult})
#	{
      $HOSTIP = $myresult->{'ip'};
#	print "$HOSTIP\n";
 
#	}
  #return @HOSTIP;
  return $HOSTIP;
}



sub check_temp_exists {

 my $zabbix = $_[0];
  my $tempname = $_[1];

    my $options = {'host' => $tempname,'nodeids' => '1' };

    my $myresult = $zabbix->raw('template','exists', $options);

	print Dumper($myresult);


}


sub getHostnames_fromHostgroup {

my $zabbix = $_[0];
my @HG_ID = $_[1];
my @HNAMES;

my $options = {'output' => 'extend', 'groupids' => @HG_ID };
my $myresult = $zabbix->raw('host','get',$options);
if ( ref($myresult) eq 'ARRAY' ){
  foreach my $h (@{$myresult}){
    push @HNAMES,$h->{'name'};
  }
} else{
  push @HNAMES, $myresult->{'name'};
}
return @HNAMES;
}








sub check_host_exists {

	 my $zabbix = $_[0];
	 my $hostname = $_[1];
	 my $options = {'host' => $hostname,'nodeids' => "1" };
	 my @myresult = $zabbix->raw('host','exists', $options);
	 return @myresult;
 #       print Dumper($myresult);

}

sub edit_host_monitoring {

	 my $zabbix = $_[0];
	 my $id = $_[1];
	 my $ch = $_[2];
	 my $options = {'hostid' => $id,'status' => $ch };
	 my $myresult = $zabbix->raw('host','update', $options);

#        print Dumper($myresult);
	 return $myresult;

}

sub update_host_visible_name {

	 my $zabbix = $_[0];
	 my $id = $_[1];
	 my $visiblename = $_[2];
	 my $options  = {'hostid' => $id,'name' => $visiblename};
	 my $myresult = $zabbix->raw('host','update', $options);
	 return $myresult;
}



1;
