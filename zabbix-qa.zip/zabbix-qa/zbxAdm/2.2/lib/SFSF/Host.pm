#!/usr/bin/perl

package SFSF::Host;


use Exporter qw(import);
our @EXPORT_OK = qw(host_maintenance changestatus updatefqdn gethostnames_fromHostgroup gettechnames_fromHostgroup get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val build_host_template_list host_update search_cfg_Templates get_host_ip host_create_macro host_create_jmxinterface host_check_jmxinterface getHostnames_fromHostgroup build_config_mapping get_host_os check_temp_exists update_host_visible_name get_host_templates host_add_template host_remove_template host_checkmetadata host_metadatamacro hostcreate);

#use 5.010;
use strict;
use warnings;
use JSON::RPC::Client;
use JSON;
use Data::Dumper;
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID uniq);
use RSM qw(get_rsm_config);
use SFSF::Log qw(addtoLogfile);


my @hostlist;
my $hostID;
#my $config = get_rsm_config('./conf/zbx.conf');
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

my $config = get_rsm_config($configFile);

# Requires zabbix class as first input to use host.get for all parameters
# Optional second parameter that takes filter ex:  %filter = ('host' => 'DC13BIZX2CFAPP02');
sub get_hostobj($;$) {
  my %output = ('output' => 'extend');
  my $zabbix = $_[0];
  my $params;
  if ($_[1]) {
    my %tfilter = ('filter' => $_[1]);
    $params = {%output, %tfilter};
    my $api_result = $zabbix->raw('host','get', $params);
    if ( ref($api_result) eq 'ARRAY' ){
      return @$api_result;
    }
    return $api_result;

  } else {
    $params = {%output};
    my $api_result = $zabbix->raw('host','get', $params);
    return @$api_result;
  }
}

#sub get_hostobj2($;$$) {
sub get_hostobj2 {
  my $zabbix = $_[0];
  my $params;
  my %output2;
  if ($_[1]) {
    %output2 = @{$_[1]};
  }
  if ($_[2]) {
    my %tfilter = ('filter' => $_[2]);
    $params = {%output2, %tfilter};
    my $api_result = $zabbix->raw('host','get', $params);
    if ( ref($api_result) eq 'ARRAY' ){
      return @$api_result;
    }
    return $api_result;

  } else {
    $params = {%output2};
    my $api_result = $zabbix->raw('host','get', $params);
    return @$api_result;
  }
}

# Iterate through all host.get objects returned from get_all_hostobj.  Return array of all objects matching regex
sub get_hostobj_val {
  my @hostObj = @{$_[0]};
  my $re = qr/^$_[1]$/;
  my @hostObjVal;
  foreach (@hostObj){
    my $key;
    my $value;
    while (($key,$value) = each %{$_}) {
      push @hostObjVal,$value if $key =~ $re;
    }
  }
  return @hostObjVal;
}

sub get_host_dns {
  my $zabbix = $_[0];
  my @HOSTID = @{$_[1]};
  my @HOSTDNS ;

  foreach (@HOSTID) {
    my $options = {'output' => 'extend', 'filter' => {'hostid' => $_ } };
    my $myresult = $zabbix->raw('hostinterface','get', $options);
    # Adding Support for multiple Interfaces (ex: JMX)
    if (ref($myresult) eq 'ARRAY'){
      foreach (@$myresult){
        if ($_->{'dns'} ne "") {
          push @HOSTDNS, $_->{'dns'};
        }
      }
    } else {
      push @HOSTDNS,$myresult->{'dns'};
    }
  }
  return @HOSTDNS;
}




sub host_checkmetadata {

my $host = $_[0];
my $driver = "mysql";
my $database = "zabbix";
my $dsn = "DBI:$driver:database=$database:host=dc4zabbixdb02.phx.sf.priv";
my $userid = "";
my $password = "";

my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;

my $sth = $dbh->prepare('select host,host_metadata
                        from autoreg_host
                        where host=?');
$sth->execute($host) or die $DBI::errstr;

my $rowcount=0;
my $metadata='';
my $host_name;

while (my @row = $sth->fetchrow_array()) {

                if ( $rowcount <= '1' )
                {

                  ($host_name, $metadata) = @row;
                     $rowcount++;
                }

        }

        $sth->finish();

        if ( $metadata eq '' )
        {
          addtoLogfile("No host metadata found","");
          return 'no';
        }
        else
        {
          addtoLogfile("Host metadata - $metadata","");
          return $metadata;
        }


}



sub get_host_ip {
  my $zabbix = $_[0];
  my $HOSTID = $_[1];
  my $HOSTIP = 'NO IP';
  #foreach (@HOSTID) {
    #my $options = {'output' => 'extend', 'filter' => {'hostid' => $HOSTID, 'type' => '1' } }; till 5/18
    my $options = {'output' => 'extend', 'hostids' => $HOSTID, 'filter' => {'type' => '1','main' => '1'}};
    my $myresult = $zabbix->raw('hostinterface','get', $options);
   #   push @HOSTIP,$myresult->{'ip'};

        #print Dumper($myresult);

   #foreach my $host (@{$myresult})
#       {
      if (defined $myresult->{'ip'} )
        {
      $HOSTIP = $myresult->{'ip'};
#       print "$HOSTIP\n";
        }
        else
        {
    $options = {'output' => 'extend', 'hostids' => $HOSTID, 'filter' => {'type' => '2','main' => '1'}};
    my $myresult = $zabbix->raw('hostinterface','get', $options);

      $HOSTIP = $myresult->{'ip'};


        }
#       }
  #return @HOSTIP;
  return $HOSTIP;
}

sub host_add_template
    {
         my $zabbix = $_[0];
         my @hid = @{$_[1]};
         my @tempid = @{$_[2]};
         my $flag=0;
        #my $options  = {'hosts'=>{'hostid' => $hid},'templates' => {'templateid' => \@tempid}};

         #my $options  = {'hosts'=>{'hostid' => $hid},'templates' => {'templateid' => @tempid}};
         my $options  = {'hostid' => $hid[0],'templates' => {'templateid' => @tempid}};
         my $myresult = $zabbix->raw('host','update', $options);

        print Dumper($myresult);
        if ( !((ref($myresult) eq 'ARRAY') || (ref($myresult) eq 'HASH') ))
        {
        $flag++;
        }
         return $flag;
    }

=pod

sub host_add_template
    {
         my $zabbix = $_[0];
         my $hid = $_[1];
         my @tempid = @{$_[2]};
         my $flag=0;
         #my $options  = {'hosts'=>{'hostid' => $hid},'templates' => {'templateid' => $tempid}};
        #my $options  = {'hosts'=>{'hostid' => $hid},'templates' => {'templateid' => \@tempid}};

         #my $options  = {'hosts'=>{'hostid' => $hid},'templates' => {'templateid' => @tempid}};
         my $options  = {'templates' => {'templateid' => @tempid},'hosts'=>{'hostid' => $hid}};
         my $myresult = $zabbix->raw('template','massadd', $options);

        print Dumper($myresult);
        if ( !((ref($myresult) eq 'ARRAY') || (ref($myresult) eq 'HASH') ))
        {
        $flag++;
        }
         return $flag;
    }
=cut

sub hostcreate
  {

        my $zabbix = $_[0];
        my $host = $_[1];
        my $ip = $_[2];

         my $options  = {'host'=> $host,'templates' => {'templateid' => '19020'},'groups' => {'groupid' => '5'},'interfaces' => {'type' => '1','main' => '1','useip' => '1','ip' => $ip,'dns' => '','port' => '10050'},'macros' => '{$META_HOSTNAME}'};

         my $myresult = $zabbix->raw('host','create', $options);



  }








sub host_remove_template
    {
         my $zabbix = $_[0];
         my @hid = @{$_[1]};
         my @tempid = @{$_[2]};



#       my $options  = {'hostids' => "$hid[0]",'templateids_clear' => "$tempid[0]"};
#         my $myresult = $zabbix->raw('host','massremove', $options);
        my $options  = {'hostid' => $hid[0],'templates_clear' =>  {'templateid' => @tempid}};
         my $myresult = $zabbix->raw('host','update', $options);
#               print Dumper($myresult);



        if ( (ref($myresult) eq 'ARRAY') || (ref($myresult) eq 'HASH') )
        {
        return "success";
        }
        else
        {
        return "error";
        }
         #return $myresult;
    }


#To get host id

sub get_hostid {

                my $zabbix = $_[0];
                my $hostname = $_[1];

                my $options = {'output'=>'hostid','filter' =>{'name' => $hostname}};
                my $result = $zabbix->raw('host','get',$options);
                my $hostid = $result->{'hostid'};

                if($hostid)
                        {
                                return $hostid;
                        }
                }

sub host_maintenance {

                         my $zabbix = $_[0];
                         my $hostid = $_[1];
                         my $status = $_[2];
# Groupid of Zabbix_Maintenance is 2983

                         if($status eq 'add')
                                        {

                        # To push host into maintenance
                                        my $options = {'hosts' => [{'hostid' => $hostid}],'groups'=> [{'groupid' => 2983}]};
                                        my $result = $zabbix->raw('host','massadd',$options);
                                        print Dumper($result);

                                        }
                         elsif($status eq 'remove')
                                        {
                        #To take host outoff maintenance
                                        my $options = {'hostids' => [$hostid],'groupids'=> [2983]};
                                         my $result1 = $zabbix->raw('host','massremove',$options);
                                        print Dumper($result1);

                                        }

                        }

sub get_host_os {
  my $zabbix = $_[0];
  my $HOSTID = $_[1];
  my $OS;

  #foreach (@HOSTID) {
    #my $options = {'output' => 'extend', 'filter' => {'hostid' => $_, 'key_' => 'system.uname' } };
    my $options = {'output' => 'extend', 'filter' => {'hostid' => $HOSTID, 'key_' => 'system.uname' } };
    my $myresult = $zabbix->raw('item','get', $options);
   #   push @HOSTIP,$myresult->{'ip'};

        if ( defined $myresult->{'lastvalue'} )
        {
      $OS = $myresult->{'lastvalue'};
        }
        else
        {
        $OS = "No";
        }
  #return @HOSTIP;
  return $OS;
}

sub check_temp_exists {

 my $zabbix = $_[0];
  my $tempname = $_[1];

    my $options = {'host' => $tempname,'nodeids' => '1' };

    my $myresult = $zabbix->raw('template','exists', $options);

        #print Dumper($myresult);


}


sub getHostnames_fromHostgroup {

my $zabbix = $_[0];
my @HG_ID = $_[1];
my @HNAMES;

my $options = {'output' => 'extend', 'groupids' => @HG_ID };
my $myresult = $zabbix->raw('host','get',$options);
if ( ref($myresult) eq 'ARRAY' ){
  foreach my $h (@{$myresult}){
    push @HNAMES,$h->{'name'};
  }
} else{
  push @HNAMES, $myresult->{'host'};
}
return @HNAMES;
}


sub gettechnames_fromHostgroup {
my $zabbix = $_[0];
my @HG_ID = $_[1];
my @HNAMES;

my $options = {'output' => 'extend', 'groupids' => @HG_ID,'filter' => {'status' => '0'} };
my $myresult = $zabbix->raw('host','get',$options);
if ( ref($myresult) eq 'ARRAY' ){
  foreach my $h (@{$myresult}){
    push @HNAMES,$h->{'host'};
  }
} else{
  push @HNAMES, $myresult->{'host'};
}
return @HNAMES;
}

sub gethostnames_fromHostgroup {

my $zabbix = $_[0];
my @HG_ID = $_[1];
my @HNAMES;

my $options = {'output' => 'extend', 'groupids' => @HG_ID ,'filter' => {'status' => '0'}};
my $myresult = $zabbix->raw('host','get',$options);
if ( ref($myresult) eq 'ARRAY' ){
  foreach my $h (@{$myresult}){
    push @HNAMES,$h->{'name'};
  }
} else{
  push @HNAMES, $myresult->{'name'};
}
return @HNAMES;
}



sub host_check_jmxinterface {
    my $zabbix = $_[0];
    my $HOSTID = $_[1];
    my $HOSTIP = $_[2];
    my $jmxport = $_[3];
    my $jmx = "false";
    my @options = ('output' => 'extend','selectInterfaces' => 'extend');
    my %filter = ('hostid' => $HOSTID, 'type' => 1);
    my @myresult = get_hostobj2($zabbix,\@options,\%filter);
        #print Dumper(@myresult);
    foreach (@myresult){
      while ( my ($key,$value) = each (%$_)) {
        if ($key eq 'interfaces'){
          foreach my $interface (@$value){
            if ( $interface->{'type'} eq 4 ){
                $jmx = $interface->{'ip'};
                addtoLogfile("JMX Interface Found : $interface->{'ip'} : $interface->{'port'}","");
            }
          }
        }
      }
    }
    return $jmx;
}

sub host_create_jmxinterface {
    my $zabbix = $_[0];
    my $HOSTID = $_[2];
    my $HOSTIP = $_[3];
    my $jmxport = $_[4];

    # Define parameters for the JMX interface
    my %params = (
        'hostid' => $HOSTID,
        'dns'    => "",
        'ip'     => $HOSTIP,
        'main'   => 1,
        'port'   => $jmxport,
        'type'   => 4,  # Type 4 corresponds to JMX interface
        'useip'  => 1
    );
    # Call the hostinterface.create method
    my $myresult = $zabbix->raw('hostinterface','create', \%params);
    # Log the result
    if ($myresult) {
        addtoLogfile("JMX Interface Created: " . $HOSTIP . ":" . $jmxport, "");
    } else {
        addtoLogfile("Failed to create JMX Interface for: " . $HOSTIP . ":" . $jmxport, "");
    }
}


sub updateHost {

my $zabbix = $_[0];
my @hid = @{$_[1]};
my @gid = @{$_[2]};

#print @gid;
#my @groups = map { { groupid => $_ } } @gid;

my @groups;     # this array will hold records of hash ie array of hash records

foreach my $id (@gid)
{
push (@groups,{groupid => $id});
# construct array of hash records of groupids
}

#print @groups;

foreach (@hid) {
my $options = {'hostid' => $_ ,'groups' => \@groups };
#my $myresult = $zabbix->raw('host','update', $options);
my $myresult = $zabbix->update('host',$options);

#push @HOSTDNS,$myresult->{'dns'};
#print Dumper($myresult);

}
}

sub host_create_macro {
my $zabbix = $_[0];
my @hid = @{$_[1]};
my @ip = $_[2];
my $macroname = $_[3];

foreach (@hid)  {
my $options = {'hostid' => $_ ,'macro' => "$macroname", 'value' => "@ip" };
my $myresult = $zabbix->create('usermacro',$options);
}


}

sub hostinterface_create {
  my $zabbix = $_[0];
  my $options = $_[1];
  my @results;
  my $result = $zabbix->create('hostinterface',$options);
  return @results;
}

sub host_update {
  my $zabbix = $_[0];
  my @hostids = @{$_[1]};
  my $object_param =$_[2];
  my $object_prop =$_[3];
  my @object_values = @{$_[4]};
  my @objects;
  my @results;
  foreach my $obj (@object_values) {
    push (@objects,{$object_prop => $obj});
  }
  foreach (@hostids) {
    my $options = {'hostid' => $_, $object_param => \@objects };
    #my $options = {'hostid' => $_, 'templates' => [{'templateid' => '10249'},{'templateid' => '10248'}]};
    #print Dumper($options);
    my $result = $zabbix->update('host',$options);
    #print Dumper($result);

    push @results, $result;
  }
  return @results;
}
sub get_config_mapping {
  my @file_array;
  if ($config->{'sap'}){
    while ( (my $key,my $value) = each %{$config->{'sap'}} ) {
      if ( $key =~ /hostcfg/ ) {
        open (my $fh, "< $value");
        while (my $line = <$fh>) {
          chomp $line;
          if ($line ne "" and $line !~ m/^#/ ){
            push @file_array, $line;
          }
        }
      }
    }
  }
  return @file_array;
}

sub searchHostCfg {
        my $hst = $_[0];
        my $hostid = $_[1];
        my $DNS_name = $_[2];
        my $match = "false";
        my @hostmapper = get_config_mapping;
        my @file_array;
        foreach (@hostmapper){
          our @line_array = split(':', $_);
          my ($regex, $HG, $template) = @line_array[0, 1, 2];
          if ( $hst =~ qr/$regex/i ) {
            $match = "true";
            our @tmp = split(',', $HG);
            push @file_array, @tmp;
          }
        }
        if ($match eq "false"){
          push @file_array, 'NOMATCH';
        }
        return @file_array;
}


sub build_host_template_list {
        my $hst = $_[0];
        my $match = "false";
        my @templatelist;
        # Use hostgroup names from Cfg File to find standard app templates
        my @cgroups = searchHostCfg($hst);

        if ($cgroups[0] eq "NOMATCH") { goto END; }

        my @groupList = buildParentHostgroups(@cgroups);
        foreach my $group (@groupList) {
          if ( $group =~ m/.*?_.*/ ) {
                push @templatelist, "T_".$group;
            if ( $group =~ m/.*?_(.*)/) {
                push @templatelist, "T_".$1;
            }
          }
        }

        # code added for generating all dc specific template combinations


        my $childtemplate='T_'.$cgroups[0];

        my @groupList1 = buildParentHostgroups($childtemplate);
         foreach my $group (@groupList1) {
          if ( $group =~ m/.*?_.*/ ) {
                push @templatelist, "T_".$group;
            if ( $group =~ m/.*?_(.*)/) {
                push @templatelist, "T_".$1;
            }
          }
        }


        my @hostmapper = get_config_mapping;
        foreach (@hostmapper){
          our @line_array = split(':', $_);
          my ($regex, $HG, $template) = @line_array[0, 1, 2];
          if ( $hst =~ m/$regex/i ) {
            $match = "true";
            #addtoLogfile("Template matched : $template","");
                if ( defined $template )
                {

            our @tmp = split(',', $template);
            push @templatelist, @tmp;
                }
          }
        }
        if ($match eq "false"){
          #addtoLogfile("ERROR: No Template matched.  Using Default : T_OS_Linux ","");
          #@templatelist = ('T_OS_Linux');
          addtoLogfile("ERROR: No Template matched.","");
        }
        #print @templatelist;
        END:
        return uniq(@templatelist);
}


sub changestatus {
                my $zabbix = $_[0];
                my $hostname = $_[1];
                my $newstatus = $_[2];
                my $options = {'output'=>'hostid','filter' =>{'name' => $hostname}};
                my $result = $zabbix->raw('host','get',$options);
                my $hostid=$result->{'hostid'};

                if($hostid)
                        {
                        my $options  = {'hostid' => $hostid,'status' => $newstatus};
                        my $result = $zabbix->raw('host','update', $options);
                        return $result;

                        }

                }


sub updatefqdn {
                my $zabbix = $_[0];
                my $oldname =  $_[1];
                my $newname = $_[2];
                my $options = {'output'=>'hostid','filter' =>{'name' => $oldname}};
                my $result = $zabbix->raw('host','get',$options);
                my $hostid=$result->{'hostid'};

                if($hostid)
                        {

                         my $options  = {'hostid' => $hostid,'host' => $newname};
                         my $result1  = $zabbix->raw('host','update', $options);
                        return $result1;

                        }
                }


sub update_host_visible_name
    {
         my $zabbix = $_[0];
         my $id = $_[1];
         my $visiblename = $_[2];
         my $options  = {'hostid' => $id,'name' => $visiblename};
         my $myresult = $zabbix->raw('host','update', $options);
         return $myresult;
    }

sub get_host_templates {

                         my $zabbix = $_[0];
                        my $hostids = $_[1];
                        my $options ={'output'=>{'name','host'},'hostids' => $hostids};
                        my $api_result = $zabbix->raw('template','get',$options);
                        return $api_result;

}


=pod
sub build_host_template_list {
       #my $zabbix = $_[0];
       my $hst = $_[0];
        my $match = "false";
        my @templatelist;
        # Use hostgroup names from Cfg File to find standard app templates
        my @cgroups = searchHostCfg($hst);

        if ($cgroups[0] eq "NOMATCH") { goto END; }

       my @childgroup = split ('_',$cgroups[0]);

        my $first = shift @childgroup;
        unshift @childgroup, 'T';
        my $childtemplate = join('_',@childgroup);

        push @templatelist, $childtemplate;

        # add dc wise template

        my $dctemplate = 'T_'.$cgroups[0];


        #print "$dctemplate\n";

        push @templatelist,$dctemplate;

        my @hostmapper = get_config_mapping;
        foreach (@hostmapper){
          our @line_array = split(':', $_);
          my ($regex, $HG, $template) = @line_array[0, 1, 2];
          if ( $hst =~ qr/$regex/i ) {
            $match = "true";
            #addtoLogfile("Template matched : $template","");

           if ( defined $template )
                {
                        our @tmp = split(',', $template);
                        push @templatelist, @tmp;
                }
                }
        }
        if ($match eq "false"){
          #addtoLogfile("ERROR: No Template matched.  Using Default : T_OS_Linux ","");
          #@templatelist = ('T_OS_Linux');
          addtoLogfile("ERROR: No Template matched.","");
        }
        END:
        print @templatelist;
        return uniq(@templatelist);
}
=cut


1;
