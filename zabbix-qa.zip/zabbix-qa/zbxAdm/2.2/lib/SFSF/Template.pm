#!/usr/bin/perl

package SFSF::Template;


use Exporter qw(import);
our @EXPORT_OK = qw(get_templateobj get_templateobj_val get_template );

#use 5.010;
use strict;
use warnings;
use JSON::RPC::Client;
use JSON;
use Data::Dumper;
use SFSF::Log qw(addtoLogfile);

# Requires zabbix class as first input to use host.get for all parameters
# Optional second parameter that takes filter ex:  %filter = ('host' => 'DC13BIZX2CFAPP02');
sub get_templateobj($;$) {
  my %output = ('output' => 'extend');
  my $zabbix = $_[0];
  my $params;
  if ($_[1]) {
    my %tfilter = ('filter' => $_[1]);
    $params = {%output, %tfilter};
    my $api_result = $zabbix->raw('template','get', $params);
    if ( ref($api_result) eq 'ARRAY' ){
      return @$api_result;
    }
    return $api_result;

  } else {
    $params = {%output};
    my $api_result = $zabbix->raw('template','get', $params);
    return @$api_result;
  }
}

sub get_template($$$$) {
    my $zabbix = shift;
    my $template_name = shift;
    my $selectMacros = shift;
    my $selectHosts = shift;

    my $options = {'output' => ['templateid', 'host'], 'filter' => {'host' => $template_name}};

    $options->{'selectMacros'} = 'extend' if (defined($selectMacros) and $selectMacros eq 'true');

    $options->{'selectHosts'} = ['hostid', 'host'] if (defined($selectHosts) and $selectHosts eq 'true');

    my $result = $zabbix->get('template', $options);

    return $result;
}

# Iterate through all template.get objects returned from get_templateobj.  Return array of all objects matching regex 
sub get_templateobj_val {
  my @templateObj = @{$_[0]};
  my $re = qr/^$_[1]$/;
  my @templateObjVal;
  foreach (@templateObj){
    my $key;
    my $value;
    while (($key,$value) = each %{$_}) {
      push @templateObjVal,$value if $key =~ $re;
    }
  }
  return @templateObjVal;
}

sub discoverHostTemplates {
  my @file = @_;
  my $cgroup = "";
  my @groupList;
  foreach my $line (@file) {
    my @groups = split('_', $line);
    foreach my $val (@groups) {
      #chomp $val;
      if ($cgroup eq ""){
        $cgroup = $val;
        push @groupList, $cgroup;
      }
      else {
        $cgroup = "$cgroup"."_"."$val";
        push @groupList, $cgroup;
      }
    }
    $cgroup = "";
  }
  return uniq(@groupList);
}

1;
