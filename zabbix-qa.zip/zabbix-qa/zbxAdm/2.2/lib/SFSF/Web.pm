#!/usr/bin/perl

package SFSF::Web;


use Exporter qw(import);
our @EXPORT_OK = qw(getlocalwebmonitoring deletelocalwebmonitoring getLocalWebScenarioByHostId);


use strict;
use warnings;
use JSON::RPC::Client;
use JSON;
use Data::Dumper;
use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID uniq);
use RSM qw(get_rsm_config);
use SFSF::Log qw(addtoLogfile);


#my $config = get_rsm_config('./conf/zbx.conf');
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';
my $config = get_rsm_config($configFile);


sub getlocalwebmonitoring {
                my  $zabbix = $_[0];
                my $host = $_[1];
                my $optn = {'output' => 'hostid','filter' => {'host' => $host}};
                my $hid = $zabbix->raw('host','get',$optn);
                my $options = {'output' =>'extend','hostids' =>$hid,'inherited' => '0'};
                my $myresult = $zabbix->raw('httptest','get',$options);
                        }

sub deletelocalwebmonitoring {

                                my $zabbix = $_[0];
                        my @itemid = @{$_[1]};
                        my $myresult = $zabbix->raw('httptest','delete', \@itemid);
                        return $myresult->{'httptestids'};

                                }


sub getLocalWebScenarioByHostId {
    my  $zabbix = $_[0];
    my $hostid = $_[1];
    my $options = {'output' =>'extend','hostids' =>$hostid,'inherited' => '0'};
    my $myresult = $zabbix->raw('httptest','get',$options);

    return $myresult;
}


1;

