#!/usr/bin/perl

package SFSF::TestReport;


use Exporter qw(import);
our @EXPORT_OK = qw(get_host_name getTrigger gethostInventory  getgroupsInventory getHistory get_Item_Last_Value);

use Data::Dumper;
use Time::Local;



#use 5.010;
use strict;
use warnings;
use RSM qw(get_rsm_config); # Using Config::Tiny to read properties file using relative path to zabbix.pl
#my $config = get_rsm_config('./conf/zbx.conf');
my $config = get_rsm_config('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf');
use SFSF::Host qw(get_hostid get_host_dns searchHostCfg updateHost get_hostobj get_hostobj_val search_cfg_Templates build_host_template_list get_host_ip host_create_macro host_create_jmxinterface host_update host_check_jmxinterface getHostnames_fromHostgroup get_host_os);

use SFSF::Hostgroups qw(buildParentHostgroups checkHostgroupExistance createHostgroup getHostgroupID get_hostgroup_obj getHostgroupID uniq check_JMX get_hostgroup_objval);

my @hostname;

sub getHistory {

my $zabbix = $_[0];
my $h_group = $_[1];
my $h_key = $_[2];
my $h_timefrom = $_[3];
my $h_timetill = $_[4];

my @hgroup = get_hostgroup_obj($zabbix,{'name' => $h_group});
die "No Hostgroups Found Matching $h_group" unless %{ $hgroup[0] };

my @hgroup_id = get_hostgroup_objval(\@hgroup, 'groupid');

#print Dumper(@hgroup_id);
my $gid;

foreach my $trigger (@hgroup_id)
{

$gid=$trigger->{'groupid'};

}

my $options = {'output' => 'extend','filter' => { 'status' => '0' }, 'groupids' => $gid };

my $hosts = $zabbix->raw('host','get', $options);

#print Dumper($hosts);

my @HID;  # arrary of hids which are part of the usergroup

foreach my $h (@${hosts})
{

push @HID, $h->{'hostid'};

}

#print @HID;

# convert input from, till time to unix timestamp format

my $sec = "1";
my $min = "00";
my $hours = "00";

my @fdate = split (/\//,$h_timefrom);
my $year = $fdate[0];
my $month = $fdate[1];
my $day = $fdate[2];

#print "\n Year $year Month $month Day $day";

my $h_fromunixtime = timelocal($sec,$min,$hours,$day,$month-1,$year); 

my @tdate = split(/\//,$h_timetill);
my $tyear = $tdate[0];
my $tmonth = $tdate[1];
my $tday = $tdate[2];

my $h_tillunixtime = timelocal($sec,$min,$hours,$tday,$tmonth-1,$tyear); 

#print "Unixtime is $h_tillunixtime";

# get all itemids for corresponding keys

my @itemid;

foreach my $hid (@HID)
{

#print "\n$hid";


my $ioptions = {'output' => 'extend','hostids' => $hid,'search' => {'key_' => $h_key}};

my $items = $zabbix->raw('item','get', $ioptions);

#print Dumper($items);

#print "$items->{'itemid'}\n";
push @itemid,$items->{'itemid'};

}

my $hoptions = {'output' => 'extend','itemids' => \@itemid,'timefrom' => $h_fromunixtime, 'timetill' => $h_tillunixtime};
my $h = $zabbix->raw('history','get', $hoptions);

print Dumper($h);

}




sub getgroupsInventory {

my $zabbix = $_[0];
my $options = {'output' => 'extend','sortfield' => 'name'};
my $groups = $zabbix->raw('hostgroup','get', $options);

#print Dumper($groups);

foreach my $g (@${groups})
{
print "$g->{'name'}\n"; 
}
}

sub gethostInventory {

my $zabbix = $_[0]; 

my $options = {'output' => 'extend','filter' => { 'status' => '0' }};

my $hosts = $zabbix->raw('host','get', $options);

#print Dumper($hosts);

foreach my $h (@{$hosts} )
{

print "\n$h->{'name'},";

#my $ip = get_host_ip($zabbix,$h->{'hostid'});

#print "$ip,";


my $hostgroupoption = {'output' => 'hostid','selectGroups' => 'extend','filter' => { 'name' => $h->{'name'}}};

my $groups = $zabbix->raw('host','get',$hostgroupoption);

#print Dumper($groups);

foreach my $g (@{$groups->{'groups'}})
{

print "$g->{'name'},"
}



}


}



sub getTrigger {

my $zabbix = $_[0];
my $triggername = $_[1];

# get triggerids

#my $options = {'output' => {'triggerid','lastchange'},'nodeids' => '0','filter' => { 'value' => '1' },'monitored' => '1','skipDependent' => '1','sortfield' => 'lastchange','sortorder' => 'DESC','search' => {'description' => 'mount point' }};

my $options = {'output' => {'triggerid','lastchange'},'nodeids' => '0','filter' => { 'value' => '1' },'monitored' => '1','skipDependent' => '1','sortfield' => 'lastchange','sortorder' => 'DESC','search' => {'description' => $triggername }};

my $triggers = $zabbix->raw('trigger','get', $options);
#print Dumper($triggers);


#my $trig_count = keys %{$triggers};
my $trig_count = @{$triggers};

#print "$trig_count\n";


my @triggerid;

if ($trig_count == 2 )
{
	# only one problem alert
	push @triggerid,$triggers->{'triggerid'};

}
elsif ($trig_count > 2)
{
	# more than 1 problem alerts

	foreach my $trigger (@{$triggers} )
	{

	push @triggerid,$trigger->{'triggerid'};

	}	

}
else
{
exit 1;
}

#print @triggerid;

# for all PROBLEM triggerids, read details of last event, to read hostname and timestamp
my %lastAlerttime;

foreach my $t (@{triggerid})
{


#my $options1={'nodeids' => '0','triggerids' => $t,'output' => 'extend','selectHosts' => {'0' => 'itemid','1' => 'hostid','2' => 'key_','3' => 'name'},'selectDependencies' => 'extend','selectLastEvent' => '1','expandDescription' => '1','preservekeys' => '1'};
my $options1={'nodeids' => '0','triggerids' => $t,'output' => 'extend','selectHosts' => {'0' => 'itemid','1' => 'hostid','2' => 'key_','3' => 'host'},'selectDependencies' => 'extend','selectLastEvent' => '1','expandDescription' => '1','preservekeys' => '1','filter' => { 'value' => '1' } };

my $triggers1 = $zabbix->raw('trigger','get', $options1);

#print Dumper($triggers1);


foreach my $k (keys %$triggers1) {
    #print "key=$k";
    foreach my $h (@{$triggers1->{$k}{hosts}}) {
        #my @cgroups = searchHostCfg($h->{name},'','');
        #print " $h->{name}\n" // 'not defined';
        #print Dumper($h);
        push @hostname,$h->{host};
    }
	#print $triggers1->{$k}{lastchange};
	$lastAlerttime{$hostname[$#hostname]}=$triggers1->{$k}{lastchange};
}
}

#print @hostname;

#my @hh = keys %lastAlerttime;
#print @hh;

my @uniqhostname;

foreach my $var ( @hostname ){
  if ( ! grep( /$var/, @uniqhostname ) ){
     push( @uniqhostname, $var );
  }
}


foreach my $h (@uniqhostname)
{

# Read group names for all hosts

my $options2={'selectGroups' => 'extend','filter' => {'host' => $h }};

my $g1 = $zabbix->raw('host','get', $options2);

#print Dumper($g1);

my $t = localtime($lastAlerttime{$h});


print "\n$triggername|$h|$t|";

foreach my $group (@{$g1->{'groups'}})
{
print "$group->{'name'}|";
}

}



}



sub get_Item_Last_Value {

			my $zabbix = $_[0];
			my @hosts = @{$_[1]};
			my $item = $_[2];
			my @hname;
			foreach my $h (@hosts)
			{
			push (@hname,$h);
			}
			my $options ={'output'=>{'name','lastvalue'},'name' =>$item ,'host' => \@hname};
			my $api_result = $zabbix->raw('item','getobjects',$options);
			return $api_result;
		   	
		    }

sub get_host_name {

                        my $zabbix = $_[0];
                        my @hostids = @{$_[1]};
                        my @hids;
                        #my @api_result;
                        foreach my $h (@hostids)
                        {
                        push (@hids,$h);
                        #print "@hids";
                        }
                        my $options ={'output'=>{'name','host'},'hostids' => \@hids};
                        my $api_result = $zabbix->raw('host','get',$options);
                        return $api_result;

                    }












1;
