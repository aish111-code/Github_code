#!/usr/bin/perl

package SFSF::Hostgroups;

use Exporter qw(import);
our @EXPORT_OK = qw(buildParentHostgroups checkHostgroupExistance get_hostgroup_obj getHostgroupID createHostgroup uniq check_JMX get_hostgroup_objval);

#use 5.010;
use strict;
use warnings;
use JSON::RPC::Client;
use Data::Dumper;
use Switch;
use RSM qw(get_rsm_config);
use SFSF::Log qw(addtoLogfile);

my $json;
our $api_url;
our $user;
our $password;
our $jsonrpc;
our $method;
our $client = new JSON::RPC::Client;
our $authID;
our $response;
our $hst;

#require("/usr/local/etc/zbxAdmin/2.2/API_CONNECT.config");

#$api_url = "http://dc13zbxw01.lab.od.sap.biz:1080/zabbix/api_jsonrpc.php";
#$jsonrpc = "2.0";
#$method = "user.login";
#$user = "";
#$password = "";

# code to detect running env and set the connection variables

my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';

my $config = get_rsm_config($configFile);

our $api_url1 = "$config->{$env}->{'url'}/api_jsonrpc.php";
our $jsonrpc1 = "2.0";
our  $method1 = "user.login";
our $user1 = $config->{$env}->{'user'};
our $password1 = $config->{$env}->{'password'};
our $authID1 = '';


sub apiConnect {


  my $json = {
  jsonrpc => "$jsonrpc1",
  method => "$method1",
  params => {
    user => "$user1",
    password => "$password1"
  },
  id => 1
  };
  print Dumper($json);
  $response = $client->call($api_url1, $json);
  print Dumper($api_url1);
  print Dumper($response);
  print Dumper('debugging............');
  #die "Authentication failed\n" unless $response->{content}->{'result'};
  print Dumper($response->{'content'});
  if ($response->{'content'}->{'result'}){
    $authID1 = $response->{'content'}->{'result'};
  }
  else {
    $authID1 = undef;
  }
  return $authID1;
}

sub uniq {
    my %seen;
    grep !$seen{$_}++, @_;
}

sub buildParentHostgroups {
  my @file = @_;
  my $cgroup = ""; 
  my @groupList; 
  foreach my $line (@file) {
    my @groups = split('_', $line);
    foreach my $val (@groups) {
      #chomp $val;
      if ($cgroup eq ""){
        $cgroup = $val;
        push @groupList, $cgroup; 
      }
      else {
        $cgroup = "$cgroup"."_"."$val";
        push @groupList, $cgroup; 
      }
    }
    $cgroup = "";
  }
  return uniq(@groupList);
}

sub checkHostgroupExistance($;$) {

  my $zabbix = $_[0];
  my $params;
  $params = {'output' => 'extend','filter' =>{'name' => "$_[1]"}};
  my $api_result = $zabbix->raw('hostgroup','get', $params);
  my @api_result = $zabbix->raw('hostgroup','get', $params);
  #print Dumper($api_result);
  foreach my $result ( @api_result ) {
            if( $result->{name} ) {
                return 1;
            }
            
        }
  return 0;
}

sub getHostgroupID($;$) {
  my @gids;
  my $zabbix = $_[0];
  my @gnames = @{$_[1]};
  my $params;

  foreach my $gname(@gnames){

  $params = {'output' => 'extend','filter' =>{'name' => "$gname"}};
  my $api_result = $zabbix->raw('hostgroup','get', $params); 
  my @api_result = $zabbix->raw('hostgroup','get', $params);
  foreach my $GID (@api_result) {
    push @gids, $GID->{groupid};
  }
  }
  return @gids;
}

sub createHostgroup {
  my $zabbix = $_[0];
  my $hgroupname = $_[1];
  my $params;
  $params = {'name' => "$hgroupname"};
  my @api_result = $zabbix->raw('hostgroup','create', $params);

# print Dumper(@api_result);
}

sub check_JMX {
my @hostgroups = @{$_[0]};
my $jmxcfgfile = $_[1];
my $jmxport = "false";

       
	foreach my $hstgroup (@hostgroups) { 
        open (my $fh, "< $jmxcfgfile");
	while (my $line = <$fh>) {
                chomp $line;
                if ($line ne "" and $line !~ m/^#/ ){
                  our @line_array = split(':', $line);
                  my ($regex, $port) = @line_array[0, 1];
                  if ( $hstgroup =~ m/$regex/ ) {
                        #print "Matched :$HG\n";
                        $jmxport = $port;
                  }
                }
        }
	close ($fh);
	}
return $jmxport;
}

sub get_hostgroup_obj($;$) {
  my %output = ('output' => 'extend');
  my $zabbix = $_[0];
  my $params;
  if ($_[1]) {
    my %tfilter = ('filter' => $_[1]);
    $params = {%output, %tfilter};
    my $api_result = $zabbix->raw('hostgroup','get', $params);
    if ( ref($api_result) eq 'ARRAY' ){
      return @$api_result;
    }
    return $api_result;

  } else {
    $params = {%output};
    my $api_result = $zabbix->raw('hostgroup','get', $params);
    if ( ref($api_result) eq 'ARRAY' ){
      return @$api_result;
    }
    return $api_result;
    #return @$api_result;
  }
}

sub get_hostgroup_objval {
  my @hostObj = @{$_[0]};
  my $re = qr/^$_[1]$/;
  my @hostObjVal;
  foreach (@hostObj){
    my $hash;
    my $key;
    my $value;
    while (($key,$value) = each %{$_}) {
      $hash->{$key} = $value if $key =~ $re;
    }
    push @hostObjVal,$hash if $hash;
  }
  return @hostObjVal;
}








1;
