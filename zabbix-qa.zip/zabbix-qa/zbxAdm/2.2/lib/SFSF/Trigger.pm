#!/usr/bin/perl

package SFSF::Trigger;


use Exporter qw(import);
our @EXPORT_OK = qw(getlocaltriggers deletelocaltriggers get_triggerobj gettriggerobj_val);

#use 5.010;
use strict;
use warnings;
use JSON::RPC::Client;
use JSON;
use Data::Dumper;
use RSM qw(get_rsm_config);
use SFSF::Log qw(addtoLogfile);

#my $config = get_rsm_config('./conf/zbx.conf');
my $env = RSM::find_env_details('env');
my $configFile = RSM::find_env_details('config') || '/usr/local/etc/zbxAdm/2.2/conf/zbx.conf';
my $config = get_rsm_config($configFile);


# Requires zabbix class as first input to use host.get for all parameters
# Optional second parameter that takes filter ex:  %filter = ('host' => 'DC13BIZX2CFAPP02');
sub get_triggerobj($;$) {
  my %output = ('output' => 'extend');
  my $zabbix = $_[0];
  my $params;
  if ($_[1]) {
    my %tfilter = ('filter' => $_[1]);
    $params = {%output, %tfilter};
    my $api_result = $zabbix->raw('trigger','get', $params);
    if ( ref($api_result) eq 'ARRAY' ){
      return @$api_result;
    }
    return $api_result;

  } else {
    $params = {%output};
    my $api_result = $zabbix->raw('trigger','get', $params);
    return @$api_result;
  }
}


# Iterate through all trigger.get objects returned from get_all_hostobj.  Return array of all objects matching regex 

sub get_triggerobj_val {
  my @trigObj = @{$_[0]};
  my $re = qr/^$_[1]$/;
  my @trigObjVal;
  foreach (@trigObj){
    my $key;
    my $value;
    while (($key,$value) = each %{$_}) {
      push @trigObjVal,$value if $key =~ $re;
    }
  }
  return @trigObjVal;
}

sub getlocaltriggers {

                my  $zabbix = $_[0];
                my $host = $_[1];
                my %hash_status = ('0' => 'Enabled','1'=>'Disabled');
                my %hash_temp = ('0' => 'LocalTrigger','1'=>'TemplateItem');
                my $options = {'output' =>'extend','host' =>$host};
                my $myresult = $zabbix->raw('trigger','getobjects',$options);
                my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                         if ( $item_count > 1 ){
                                        foreach my  $h (@{$myresult}){
                                                if($h->{'templateid'} eq '0' && $h->{'flags'} eq '0'){
                                                print "$host\t$hash_temp{$h->{'templateid'}}\t$hash_status{$h->{'status'}}\t\t$h->{'triggerid'}\t$h->{'description'}\n";
                                                }
                                                                        }
                            #                    print "*******************************************\n";
                                                } # print "*******************************************\n";
                                                else { if($myresult->{'templateid'}){
                                                                if($myresult->{'templateid'} eq '0' && $myresult->{'flags'} eq '0'){
                                                                print "$host\t$hash_temp{$myresult->{'templateid'}}\t$hash_status{$myresult->{'status'}}\t\t$myresult->{'triggerid'}\t$myresult->{'description'}\n";
                                                                 print "********************************************\n";
					                                                               				}
                                                        }                          }
                        }



sub deletelocaltriggers {
			
			my  $zabbix = $_[0];
                	my $host = $_[1];
			my @triggerids;
               	        my $options = {'output' =>'extend','host' =>$host};
               		 my $myresult = $zabbix->raw('trigger','getobjects',$options);
                	my $item_count = ref $myresult eq 'HASH' || scalar @$myresult;
                         if ( $item_count > 1 ){
                                        foreach my  $h (@{$myresult}){
                                                if($h->{'templateid'} eq '0' && $h->{'flags'} eq '0'){
                                               push(@triggerids,$h->{'triggerid'});
 						addtoLogfile("$host : Deleted Trigger Id - $h->{'triggerid'}  Trigger Name - $h->{'description'}","Audit");
                                                }
                                                                        }
                                                
                                                }
                                                else {
                                                                if($myresult->{'templateid'} eq '0' && $myresult->{'flags'} eq '0'){
                                                                push(@triggerids,$myresult->{'triggerid'});
								addtoLogfile("$host : Deleted Trigger Id - $myresult->{'triggerid'}  Trigger Name - $myresult->{'description'}","Audit");
                                                                 
                                                                                                                                }
                                                        }
			my $result = $zabbix->raw('trigger','delete',\@triggerids);
                        #return $myresult->{'triggerid'};	
                        }


1;
