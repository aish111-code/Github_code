from zabbix_api import ZabbixAPI
from RSM import parseConfig
import re
from pprint import pprint


config = parseConfig('/usr/local/etc/zbxAdm/2.2/conf/zbx.conf')

def main():

	fh = open('/etc/hosts','r')
        env = ''

        for line in fh.readline():
            if line != "" and re.match('lab', line):
                env = 'qa'
                break
        else :
                env = 'prod'

      
        url    = config.get(env,'url')
        user   = config.get(env,'user')
        passwd = config.get(env,'password')

	zabbix = ZabbixAPI(server=url + "/api_jsonrpc.php")
        zabbix.login(user,passwd)

	#getHostObj(zabbix,'pcappp01c01.syd.sf.priv')
	#getHostObj(zabbix)
	"""
	hostDNS = getHostDNS(zabbix,[12918,18650])
 	print hostDNS

 	hostIp = getHostIP(zabbix, 18650)
	print hostIp

   	hostId = getHostId(zabbix,'pcappp01c01.syd.sf.priv')
	print hostId

   	hostOS = getHostOS(zabbix,18650)
	print hostOS

 	hostNames = getHostNamesFromHostGrpId(zabbix,[2689])
  	print hostNames

 	hostNames = getTechNamesFromHostGrpId(zabbix,[2689])
  	print hostNames
        templates = getTemplatesByHostId(zabbix,12918)
	print templates
	"""
def get_config_mapping():
	file_array = list()
	options = config.options('sap')
	if options:
		for option in options:
			try:
				if re.match('hostcfg',option):
					file = config.get('sap',option)
					print(file)
					with open(file,'r') as inp:
						for line in inp:
							if line != '' and not re.match('^#',line):
								file_array.append(line)
			except:
				pass

	return file_array

def getHostObj(zabbix,host=None):
	api_result = None
	if host:
		params = { 'output' : 'extend', 'filter' : { 'host' : ( host ) } }
		api_result = zabbix.host.get(params)
	else:
		api_result = zabbix.host.get({'output' : 'extend'})
				      
	print api_result
	return api_result

def getHostDNS(zabbix,hostIdList):
	hostDNS = list()
	for hostId in hostIdList:
		options = { 'output' : 'extend', 'filter' : {'hostid' : hostId} }
		result = zabbix.hostinterface.get(options)
		if type(result) == list:
			for eachRes in result:
				if eachRes['dns'] != "":
					hostDNS.append(eachRes['dns'])
		else:
			hostDNS.append(result['dns'])

	return hostDNS

def getHostIP(zabbix,hostID):
	hostIp = None
	options = { 'output' : 'extend', 'hostids' : hostID, 'filter' : {'type' : '1','main' : '1'} }
	result = zabbix.hostinterface.get(options)
	try:
		hostIp = result[0]['ip']
	except:
		options = { 'output' : 'extend', 'hostids' : hostID, 'filter' : {'type' : '2','main' : '1'} }
		result = zabbix.hostinterface.get(options)
		if result:
			hostIp = result[0]['ip']

	return hostIp

def getHostId(zabbix,hostName):
	options = { 'output' : 'hostid', 'filter' : { 'name' : hostName } }
	result = zabbix.host.get(options)
	if result:
		return result[0]['hostid']
	
def getHostOS(zabbix,hostId):
	options = { 'output' : 'extend', 'filter' : { 'hostid' : hostId, 'key_' : 'system.uname' } }
	result = zabbix.item.get(options)
	if result:
		return result[0]['lastvalue']
	else:
		return "No"

def getHostNamesFromHostGrpId(zabbix,hostGrpIdsList=[]):
	hostNames = list()
	options = { 'output':'extend', 'groupids':hostGrpIdsList }
	result = zabbix.host.get(options)
	if type(result) == list:
		for hostRec in result:
			hostNames.append(hostRec['name'])
	else:
		hostNames.append(result['host'])

	return hostNames

def getTechNamesFromHostGrpId(zabbix,hostGrpIdsList=[]):
        hostNames = list()
        options = { 'output':'extend', 'groupids':hostGrpIdsList, 'filter':{'status':0} }
        result = zabbix.host.get(options)
        if type(result) == list:
                for hostRec in result:
                        hostNames.append(hostRec['host'])
        else:
                hostNames.append(result['host'])

        return hostNames

def getHostNamesByHostGrpId(zabbix,hostGrpIdsList=[]):

	hostNames = list()

	options = {'output':'extend', 'groupids':hostGrpIdsList, 'filter' : {'status':0}}
  	result = zabbix.host.get(options)
	if type(result) == list:
                for hostRec in result:
                        hostNames.append(hostRec['name'])
        else:
                hostNames.append(result['name'])

        return hostNames

def updateHostStatus(zabbix,hostName,newStatus):
	options = {'output':'hostid','filter':{'name':hostName}}
	result = zabbix.host.get(options)
	hostid = result['hostid']
        if hostid:
 		options  = {'hostid' : hostid,'status' : newStatus}
                result = zabbix.host.update(options)
                return result

	return

def updateFQDN(zabbix,oldHost,newHost):
	options = {'output':'hostid','filter':{'name':oldHost}}
        result = zabbix.host.get(options)
        hostid = result['hostid']
        if hostid:
                options  = {'hostid' : hostid,'host' : newHost}
                result = zabbix.host.update(options)
                return result

        return

def updateVissibleName(zabbix,oldHost,newHost):
	options = {'output':'hostid','filter':{'name':oldHost}}
        result = zabbix.host.get(options)
        hostid = result['hostid']
        if hostid:
                options  = {'hostid' : hostid,'name' : newHost}
                result = zabbix.host.update(options)
                return result

        return

def getTemplatesByHostId(zabbix,hostId):
	templates=[]
	options = {'output':['name','host'],'hostids' : hostId}
        result = zabbix.template.get(options)
 	if result:
		for eachRes in result:
			templates.append(eachRes['host'])
        return templates

if __name__ == '__main__':
	main()
