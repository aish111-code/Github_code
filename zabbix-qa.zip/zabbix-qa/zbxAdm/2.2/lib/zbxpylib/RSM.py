#from ConfigParser import SafeConfigParser
from configparser import ConfigParser as SafeConfigParser
def parseConfig(configFile):
	config = SafeConfigParser()
	config.read(configFile)
	return config
