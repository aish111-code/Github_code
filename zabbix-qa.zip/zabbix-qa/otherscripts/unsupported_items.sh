


Dir="/root/mysql_unsupported"

python ${Dir}/mysql_unsupported_items.py -dc DC10 >$Dir/zabbix_apac_unsupported.html
echo "Completed"
python ${Dir}/mysql_unsupported_items.py -dc DC8 >$Dir/zabbix_america_unsupported.html
echo "Completed"
python ${Dir}/mysql_unsupported_items.py -dc DC41 >$Dir/zabbix_america-primary_unsupported.html
echo "Completed"
python ${Dir}/mysql_unsupported_items.py -dc DC23 >$Dir/zabbix_EMEA_unsupported.html
echo "Completed"
python ${Dir}/mysql_unsupported_items.py -dc DC25 >$Dir/zabbix_QA_unsupported.html

FROM="saasopsps@successfactors.com"
MAILTO="dl_hcm_mysql_db_support@sap.com,sajeev.george@sap.com,v.gandrakota@sap.com,brijesh.patel03@sap.com,ayush.jain@sap.com,s.renuka@sap.com,jibin.sunny@sap.com,sindhu.madicherla@sap.com,v.manepalli@sap.com"
#MAILTO="ayush.jain@sap.com"
SUBJECT="MYSQL Unsupported Data Collection Zabbix Report"
boundary="ZZ_/afg6432dfgkl.94531q"
export file1=$Dir/zabbix_apac_unsupported.html
export file2=$Dir/zabbix_america_unsupported.html
export file3=$Dir/zabbix_america-primary_unsupported.html
export file5=$Dir/zabbix_EMEA_unsupported.html
export file6=$Dir/zabbix_QA_unsupported.html
(
printf '%s\n' "From: $FROM
To: $MAILTO
Subject: $SUBJECT
Mime-Version: 1.0
Content-Type: multipart/mixed; boundary=\"$boundary\"

--${boundary}
Content-Type: text/html
Content-Disposition: inline
<br>
<br>
<center><h3 style='font-family:Arial'>MYSQL Unsupported Data Collection Zabbix Report </h3></center>
<h5 style='font-family:Arial'>Regards,</h5>
<h5 style='font-family:Arial'>CO-Tools</h5>
"

 printf '%s\n' "--${boundary}
Content-Type: text/html
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename=\"$(basename $file1)\"
"
base64 "$file1"



 printf '%s\n' "--${boundary}
Content-Type: text/html
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename=\"$(basename $file2)\"
"
base64 "$file2"

 printf '%s\n' "--${boundary}
Content-Type: text/html
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename=\"$(basename $file3)\"
"
base64 "$file3"


 printf '%s\n' "--${boundary}
Content-Type: text/html
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename=\"$(basename $file5)\"
"
base64 "$file5"

 printf '%s\n' "--${boundary}
Content-Type: text/html
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename=\"$(basename $file6)\"
"
base64 "$file6"


 printf '%s\n' "--${boundary}--"

) | /usr/sbin/sendmail -f $FROM $MAILTO

