#!/bin/bash
#python /opt/inventory.py|grep -Eiv "pc16|sc16|pc18|sc18|dc16|dc18|pc2|pd2|ps2|sc2|dc2|pc02|sc02|pc17|sc17|ps17|dc17|dc19|pc19|sc19|ps19|pc4|pc04|sc4|sc04|dc4|ps4|pd4|pc8|pc08|sc8|sc08|ps8|ps08|pd8|ps40|dc8|pc10|sc10|ps10|pc15|sc15|ps15" > /opt/nginx/html/zabbix/cops/Inventory_temp.txt
python /opt/inventory.py|grep -Ei "HOSTNAME" > /opt/nginx/html/zabbix/cops/Inventory_temp.txt


#DC13 inventory
python /opt/inventory_dc13.py >/opt/nginx/html/zabbix/cops/inventory_dc13_temp.txt
grep -v HOSTNAME /opt/nginx/html/zabbix/cops/inventory_dc13_temp.txt >> /opt/nginx/html/zabbix/cops/Inventory_temp.txt

##Added by jibin##
##This part pulls dc23 inventory and combine it with dc4 inventory#
cd /opt/nginx/html/zabbix/cops/
sftp  toolsandutil@sftp4.successfactors.com <<EOF
get inventory_dc23_temp.txt
exit
EOF
grep -viE 'HOSTNAME|pd11|pc11|sc11|ps11|ss11' /opt/nginx/html/zabbix/cops/inventory_dc23_temp.txt >> /opt/nginx/html/zabbix/cops/Inventory_temp.txt
##

##This part pulls dc42 inventory and combine it with dc4 inventory#
#cd /opt/nginx/html/zabbix/cops/
#sftp  toolsandutil@sftp4.successfactors.com <<EOF
#get inventory_dc42_temp.txt
#exit
#EOF
#grep -vE 'HOSTNAME|sc44|pc44|ss44|dc44|PC44|SC44|SS44' /opt/nginx/html/zabbix/cops/inventory_dc42_temp.txt >> /opt/nginx/html/zabbix/cops/Inventory_temp.txt
##

##This part pulls dc8 (Americas Cluster ) inventory and combine it with dc4 inventory#
cd /opt/nginx/html/zabbix/cops/
sftp  toolsandutil@sftp4.successfactors.com <<EOF
get inventory_dc8_temp.txt
exit
EOF
grep -v HOSTNAME /opt/nginx/html/zabbix/cops/inventory_dc8_temp.txt >> /opt/nginx/html/zabbix/cops/Inventory_temp.txt

##This part pulls dc10 (APAC Cluster ) inventory and combine it with dc4 inventory#
cd /opt/nginx/html/zabbix/cops/
sftp  toolsandutil@sftp4.successfactors.com <<EOF
get inventory_dc10_temp.txt
exit
EOF
grep -v HOSTNAME /opt/nginx/html/zabbix/cops/inventory_dc10_temp.txt >> /opt/nginx/html/zabbix/cops/Inventory_temp.txt

##This part pulls dc41 (Promary America Cluster ) inventory and combines it with dc4 inventory#
cd /opt/nginx/html/zabbix/cops/
sftp  toolsandutil@sftp4.successfactors.com <<EOF
get inventory_dc41_temp.txt
exit
EOF
grep -v HOSTNAME /opt/nginx/html/zabbix/cops/inventory_dc41_temp.txt >> /opt/nginx/html/zabbix/cops/Inventory_temp.txt

##This part pulls dc41 (Promary America Cluster ) inventory and combines it with dc4 inventory#
cd /opt/nginx/html/zabbix/cops/
sftp  toolsandutil@sftp4.successfactors.com <<EOF
get inventory_dc25_temp.txt
exit
EOF
grep -v HOSTNAME /opt/nginx/html/zabbix/cops/inventory_dc25_temp.txt >> /opt/nginx/html/zabbix/cops/Inventory_temp.txt


count=`cat /opt/nginx/html/zabbix/cops/Inventory_temp.txt|grep -vi decommission|wc -l`

msg="

Total number of hosts: $count
Invetory URL: https://zabbix-hcm.ondemand.com/zabbix/cops/Inventory.txt
"

#email="jibin.sunny@sap.com"
email="ayush.jain@sap.com,s.renuka@sap.com,jibin.sunny@sap.com,sindhu.madicherla@sap.com"


if [ $count -gt 20000 ]
then
#echo "$msg" | mailx -r "ZBX@sap.com" -s "Zabbix Inventory Generation Successful" $email
rm -f /opt/nginx/html/zabbix/cops/Inventory.txt
mv /opt/nginx/html/zabbix/cops/Inventory_temp.txt /opt/nginx/html/zabbix/cops/Inventory.txt
else
#echo $count
echo "$msg" | mailx -r "ZBX@sap.com" -s "Zabbix Inventory Generation Failed" $email
fi
