#!/bin/bash

########################################
# Author: Sandeep
# Purpose: Zabbix CAM User Admin Script
# Date Dec 25th 2020
#########################################

# Script Configurations #
#url=http://10.10.198.22/api_jsonrpc.php
#url=https://zabbix-apac.ondemand.com/api_jsonrpc.php
#url=(https://zabbix-apac.ondemand.com/api_jsonrpc.php https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php)

declare -A myzabbix
myzabbix=(["https://zabbix-dc01.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-qa.cld.ondemand.com/api_jsonrpc.php"]=36 ["https://zabbix-dc52.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc30.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php"]=57 ["https://zabbix-dc66.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc60.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc68.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc64.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc70.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-americas-primary.cld.ondemand.com/api_jsonrpc.php"]=40 ["https://zabbix-dc74.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc33.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc55.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc57.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc62.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc50.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc32.cld.ondemand.com/api_jsonrpc.php"]=57 ["https://zabbix-dc67.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc61.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc34.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc56.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc58.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc65.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc69.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc71.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc75.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc51.cld.ondemand.com/api_jsonrpc.php"]=38 ["https://zabbix-dc43.cld.ondemand.com/api_jsonrpc.php"]=38)

user=zbxapicam
password=<passvault>
ldapurl=ldaps://dc64-ad01.sf.priv:636
#usergroupid=40
emaillist="s.renuka@sap.com,ayush.jain@sap.com,jibin.sunny@sap.com,sindhu.madicherla@sap.com,jose.ortiz@sap.com"
logfile="/opt/zabbix"

cd /opt/zabbix


cam()
{

zbxurl=$1
echo -e "\n Starting Execution in Zabbix URL $zbxurl \n" >> $logfile/camlogfile.txt
ugid=$2

# 1. get authorization token
auth=$(curl -s -X POST \
-H 'Content-Type: application/json-rpc' \
-d " \
{
 \"jsonrpc\": \"2.0\",
 \"method\": \"user.login\",
 \"params\": {
  \"user\": \"$user\",
  \"password\": \"$password\"
 },
 \"id\": 1,
 \"auth\": null
}
" $zbxurl | \
jq -r '.result'
)

# 2. Get User list from Zabbix AD User Group

if [ -f /opt/zabbix/zabbixcurrentuserlist.txt ]
then
    rm /opt/zabbix/zabbixcurrentuserlist.txt
fi


$(curl -s -X POST \
-H 'Content-Type: application/json-rpc' \
-d " \
{
 \"jsonrpc\": \"2.0\",
    \"method\": \"user.get\",
    \"params\": {
        \"output\": \"extend\",
        \"usrgrpids\": \"$ugid\"
        },
    \"auth\": \"$auth\",
    \"id\": 1
}
" $zbxurl | \
jq -r '.result[] | [.username,.userid] | join(",")' >> /opt/zabbix/zabbixcurrentuserlist.txt )

zabbixusercount=`cat /opt/zabbix/zabbixcurrentuserlist.txt | wc -l`
echo "Current Total Zabbix Users $zabbixusercount " >> $logfile/camlogfile.txt

#3. Get AD Group User List & Generate List of New Users to be Added to Zabbix

if [ -f /opt/zabbix/addnewuserlist.txt ]
then
rm /opt/zabbix/addnewuserlist.txt
fi

(ldapsearch -x -H "$ldapurl" -D CN=SVC_DC25_ADO,OU=Service,OU=Accounts,OU=SF_SAP,DC=sf,DC=priv -w '<passvault>' -b ou=accounts,ou=SF_SAP,dc=sf,dc=priv "(&(objectClass=user)(memberOf=CN=SAPSF_A-Zabbix_Operator,OU=Roles,OU=SF_SAP,DC=sf,DC=priv))" | grep -Ei "sAMAccountName") > /opt/zabbix/aduserlist.txt

adusercount=`wc -l /opt/zabbix/aduserlist.txt | cut -f1 -d" "`

echo "Current Total AD Users $adusercount" >> $logfile/camlogfile.txt

if [ $adusercount -gt 0 ]
then
sed -i 's/sAMAccountName: //g' /opt/zabbix/aduserlist.txt

#4. Generate list of users to be added to Zabbix

   for aduser in `cat /opt/zabbix/aduserlist.txt`
   do
     grep -iw $aduser /opt/zabbix/zabbixcurrentuserlist.txt > temp.txt
     if [ $? -eq 1 ]
     then
        echo "Found New User to be added - $aduser" >> $logfile/camlogfile.txt
        echo $aduser >> /opt/zabbix/addnewuserlist.txt
     fi
   done

#5. Generate list of users to be removed from Zabbix

   if [ -f /opt/zabbix/removeuserlist.txt ]
   then
        rm /opt/zabbix/removeuserlist.txt
   fi

   if [ $zabbixusercount -ne 0 ]
   then
        for zuser in `cat /opt/zabbix/zabbixcurrentuserlist.txt`
        do
                zusername=`echo $zuser | cut -d',' -f1`
                grep -iw $zusername /opt/zabbix/aduserlist.txt > temp.txt
                if [ $? -eq 1 ]
                then
                        echo "Found Existing User to be removed - $zusername" >> $logfile/camlogfile.txt
                        echo $zuser >> /opt/zabbix/removeuserlist.txt
                fi

        done
   fi

fi

#6. Get count of users to be added/removed
addcount=0
removecount=0
if [ -f /opt/zabbix/addnewuserlist.txt ]
then
        addcount=`wc -l /opt/zabbix/addnewuserlist.txt | cut -d' ' -f1`
fi
if [ -f /opt/zabbix/removeuserlist.txt ]
then
removecount=`wc -l /opt/zabbix/removeuserlist.txt | cut -d' '  -f1`
fi

if [ $addcount -eq 0 ] && [ $removecount -eq 0 ]
then
        echo "No new users found for adding/removing in Zabbix" >> $logfile/camlogfile.txt
else
        echo "Found $addcount users to be added & $removecount users to be removed" >> $logfile/camlogfile.txt
fi

#7. Add new users to Zabbix

if [ $addcount -gt 0 ]
then
        for newuser in `cat /opt/zabbix/addnewuserlist.txt`
        do

        curl -s -X POST \
-H 'Content-Type: application/json-rpc' \
-d " \
{
 \"jsonrpc\": \"2.0\",
    \"method\": \"user.create\",
    \"params\": {
        \"username\": \"$newuser\",
        \"refresh\": \"60s\",
        \"rows_per_page\": \"100\",
        \"roleid\": \"2\",
        \"url\": \"/zabbix.php?action=problem.view\",
        \"usrgrps\": [
           {
            \"usrgrpid\": \"$ugid\"
           }
          ]
    },
    \"auth\": \"$auth\",
    \"id\": 1
}
" $zbxurl > newuserlog.txt

 grep -iw error /opt/zabbix/newuserlog.txt
 if [ $? -eq 0 ]
 then
    echo "Error while creating user $newuser" >> $logfile/camlogfile.txt
 else
   echo "Created new user $newuser successfully" >> $logfile/camlogfile.txt
 fi

        done
fi

#8. Delete user from zabbix

if [ $removecount -gt 0 ]
then
        for removeuser in `cat /opt/zabbix/removeuserlist.txt`
        do
        uid=`echo $removeuser | cut -d',' -f2`

       curl -s -X POST \
-H 'Content-Type: application/json-rpc' \
-d " \
{
 \"jsonrpc\": \"2.0\",
    \"method\": \"user.delete\",
    \"params\": [
           \"$uid\"
                ],
    \"auth\": \"$auth\",
    \"id\": 1
}
" $zbxurl > removeuserlog.txt

grep -iw error /opt/zabbix/removeuserlog.txt
 if [ $? -eq 0 ]
 then
    echo "Error while removing user $removeuser" >> $logfile/camlogfile.txt
 else
   echo "Removed $removeuser successfully" >> $logfile/camlogfile.txt
 fi

        done
fi


#8. logout user
curl -s -X POST \
-H 'Content-Type: application/json-rpc' \
-d " \
{
    \"jsonrpc\": \"2.0\",
    \"method\": \"user.logout\",
    \"params\": [],
    \"id\": 1,
    \"auth\": \"$auth\"
}
" $zbxurl > temp

echo -e "\nEnd of Execution in Zabbix URL $zbxurl" >> $logfile/camlogfile.txt

}


## Main Program ##

rm /opt/zabbix/camlogfile.txt
echo -e "\nJob Running on VM: `hostname`" > /opt/zabbix/camlogfile.txt

for u in "${!myzabbix[@]}"
do
        cam $u ${myzabbix[$u]}
done

noemailcount=`grep "No new users found for adding/removing in Zabbix" /opt/zabbix/camlogfile.txt | wc -l`

if [ $noemailcount -lt 8 ]
then
d=`date +%d/%m/%Y`
#cat /opt/zabbix/camlogfile.txt | mailx -r "sapsfsdotoolsandutils@sapsf.com" -s "Zabbix CAM Integration Job Execution Summary ${d} " $emaillist

fi
