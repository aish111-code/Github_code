
#/bin/bash
zbx_agent_file="zabbix-agent-5.0.19-2.sap.el12.x86_64.rpm"
zbx_agent="zabbix-agent-5.0.19-2.sap.el12.x86_64"
yum_url="http://yum.dc080.sf.priv"
for host in `cat list_zbx.txt`; do
echo "### STARTED CHANGE FOR: $host ####"
ssh -q -o "StrictHostKeyChecking=no" deployer@$host sudo su - << 'EOF'
hostname
if sudo zypper locks | grep -i zabbix
then
  sudo zypper rl 'zabbix-agent'
  sudo zypper rl '*zabbix-agent*'
  sudo zypper rl *zabbix*
fi
if ! sudo rpm -qa | grep zabbix-agent | grep -i $zbx_agent
then
  sudo cp /etc/zabbix/zabbix_agentd.conf /etc/zabbix/zabbix_agentd.conf.bak
  sudo systemctl stop zabbix-agentd.service
  sudo systemctl stop zabbix_agentd.service
  sudo zypper --non-interactive --no-gpg-checks rm zabbix-agent
  curl -o /tmp/$zbx_agent_file $yum_url/hcm/platform/zabbix/$zbx_agent_file
  sudo zypper --non-interactive --no-gpg-checks in /tmp/$zbx_agent_file
  sudo systemctl restart zabbix-agent.service
fi
echo "===============Start Validation====================================="
echo "Hostname:" && hostname
echo "New_version"
sudo rpm -qa | grep zabbix
echo "CONF_file"
sudo tail -10 /etc/zabbix/zabbix_agentd.conf
echo "Custom_scripts_count"
sudo ls /etc/zabbix/zabbix_agentd_custom_scripts|wc -l
echo "Agent_status"
sudo systemctl status zabbix-agent.service|grep Active:
echo "Cron_entry"
sudo crontab -l | grep /usr/sbin/updatezbx
echo "===============End Validation======================================="

if ! sudo rpm -qa | grep zabbix-agent | grep -i 5.0.19-2
then
  sudo zypper --non-interactive --no-gpg-checks in zabbix-agent
  sudo systemctl start zabbix-agentd.service
  sudo systemctl start zabbix_agentd.service
fi

if sudo zypper locks | grep -i zabbix
then
  sudo zypper al 'zabbix-agent'
  sudo zypper al '*zabbix-agent*'
  sudo zypper al '*zabbix*'
fi
echo "deleting downloaded rpm"
rm /tmp/$zbx_agent_file
EOF
  echo "#### COMPLETED CHANGE FOR: $host ####"
done

