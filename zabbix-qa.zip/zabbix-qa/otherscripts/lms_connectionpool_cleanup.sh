date
python /root/trigger_cleanup/lms_connectionpool_cleanup.py -dc DC8
python /root/trigger_cleanup/lms_connectionpool_cleanup.py -dc DC23
python /root/trigger_cleanup/lms_connectionpool_cleanup.py -dc DC41
python /root/trigger_cleanup/lms_connectionpool_cleanup.py -dc DC10
