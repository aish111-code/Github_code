#!/bin/sh
# Check if an IP address is listed on one of the following blacklists
# The format is chosen to make it easy to add or delete
# The shell will strip multiple whitespace

BLISTS="
elitist.rfc-clueless.org
escalations.dnsbl.sorbs.net
ex.dnsbl.org
feb.spamlab.com
fnrbl.fast.net
forbidden.icm.edu.pl
free.v4bl.org
fresh.spameatingmonkey.net
fresh10.spameatingmonkey.net
fresh15.spameatingmonkey.net
fulldom.rfc-clueless.org
gl.suomispam.net
grey.uribl.com
hil.habeas.com
http.dnsbl.sorbs.net
images.rbl.msrbl.net
in.dnsbl.org
ipbl.zeustracker.abuse.ch
ips.backscatterer.org
ix.dnsbl.manitu.net
korea.services.net
l1.bbfh.ext.sorbs.net
l2.bbfh.ext.sorbs.net
l3.bbfh.ext.sorbs.net
l4.bbfh.ext.sorbs.net
"
# -- Sanity check on parameters
[ $# -ne 1 ] && ERROR 'Please specify a single IP address'

# -- if the address consists of 4 groups of minimal 1, maximal digits, separated by '.'
# -- reverse the order
# -- if the address does not match these criteria the variable 'reverse will be empty'

reverse=$(echo $1 |
  sed -ne "s~^\([0-9]\{1,3\}\)\.\([0-9]\{1,3\}\)\.\([0-9]\{1,3\}\)\.\([0-9]\{1,3\}\)$~\4.\3.\2.\1~p")

if [ "x${reverse}" = "x" ] ; then
      ERROR  "IMHO '$1' doesn't look like a valid IP address"
      exit 1
fi

# Assuming an IP address of 11.22.33.44 as parameter or argument

# If the IP address in $0 passes our crude regular expression check,
# the variable  ${reverse} will contain 44.33.22.11
# In this case the test will be:
#   [ "x44.33.22.11" = "x" ]
# This test will fail and the program will continue

# An empty '${reverse}' means that shell argument $1 doesn't pass our simple IP address check
# In that case the test will be:
#   [ "x" = "x" ]
# This evaluates to true, so the script will call the ERROR function and quit

# -- do a reverse ( address -> name) DNS lookup
REVERSE_DNS=$(dig +short -x $1)

count=0
# -- cycle through all the blacklists
for BL in ${BLISTS} ; do
    # show the reversed IP and append the name of the blacklist

    # use dig to lookup the name in the blacklist
    #echo "$(dig +short -t a ${reverse}.${BL}. |  tr '\n' ' ')"
    LISTED="$(dig +short -t a ${reverse}.${BL}.)"
    if [ ! -z $LISTED ];then
        ((count=count+1))
    fi
done

echo $count

