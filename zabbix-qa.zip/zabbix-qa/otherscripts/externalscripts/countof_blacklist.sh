#!/bin/sh
# Check if an IP address is listed on one of the following blacklists
# The format is chosen to make it easy to add or delete
# The shell will strip multiple whitespace

BLISTS="
0spam-killlist.fusionzero.com
0spam.fusionzero.com
0spamurl.fusionzero.com
abuse.rfc-clueless.org
access.redhawk.org
all.rbl.jp
all.spamrats.com
aspews.ext.sorbs.net
b.barracudacentral.org
babl.rbl.webiron.net
backscatter.spameatingmonkey.net
badconf.rhsbl.sorbs.net
badnets.spameatingmonkey.net
bb.barracudacentral.org
bl.blocklist.de
bl.drmx.org
bl.fmb.la
bl.konstant.no
bl.mailspike.net
bl.mav.com.br
bl.nszones.com
bl.scientificspam.net
bl.spamcop.net
bl.spameatingmonkey.net
bl.suomispam.net
black.uribl.com
blacklist.sci.kun.nl
blacklist.woody.ch
block.ascams.com
block.dnsbl.sorbs.net
bogons.cymru.com
bogusmx.rfc-clueless.org
bsb.empty.us
bsb.spamlookup.net
cbl.abuseat.org
cbl.anti-spam.org.cn
cblless.anti-spam.org.cn
cblplus.anti-spam.org.cn
cdl.anti-spam.org.cn
cidr.bl.mcafee.com
combined.rbl.msrbl.net
communicado.fmb.la
crawler.rbl.webiron.net
db.wpbl.info
dbl.suomispam.net
dnsbl-0.uceprotect.net
dnsbl-1.uceprotect.net
dnsbl-2.uceprotect.net
dnsbl-3.uceprotect.net
dnsbl.anticaptcha.net
dnsbl.beetjevreemd.nl
dnsbl.calivent.com.pe
dnsbl.cobion.com
dnsbl.dronebl.org
dnsbl.inps.de
dnsbl.justspam.org
dnsbl.kempt.net
dnsbl.madavi.de
dnsbl.net.ua
dnsbl.rv-soft.info
dnsbl.rymsho.ru
dnsbl.sorbs.net
dnsbl.tornevall.org
dnsbl.zapbl.net
dnsblchile.org
dnsrbl.org
dnsrbl.swinog.ch
dob.sibl.support-intelligence.net
dsn.rfc-clueless.org
dul.dnsbl.sorbs.net
dul.pacifier.net
dyn.nszones.com
dyna.spamrats.com
dyndns.rbl.jp
dynip.rothen.com
elitist.rfc-clueless.org
escalations.dnsbl.sorbs.net
ex.dnsbl.org
feb.spamlab.com
fnrbl.fast.net
forbidden.icm.edu.pl
free.v4bl.org
fresh.spameatingmonkey.net
fresh10.spameatingmonkey.net
fresh15.spameatingmonkey.net
fulldom.rfc-clueless.org
gl.suomispam.net
grey.uribl.com
hil.habeas.com
http.dnsbl.sorbs.net
images.rbl.msrbl.net
in.dnsbl.org
ipbl.zeustracker.abuse.ch
ips.backscatterer.org
ix.dnsbl.manitu.net
korea.services.net
l1.bbfh.ext.sorbs.net
l2.bbfh.ext.sorbs.net
l3.bbfh.ext.sorbs.net
l4.bbfh.ext.sorbs.net
list.bbfh.org
list.blogspambl.com
mail-abuse.blacklist.jippg.org
mailsl.dnsbl.rjek.com
misc.dnsbl.sorbs.net
multi.surbl.org
multi.uribl.com
netbl.spameatingmonkey.net
netscan.rbl.blockedservers.com
new.spam.dnsbl.sorbs.net
nomail.rhsbl.sorbs.net
noptr.spamrats.com
nsbl.fmb.la
old.spam.dnsbl.sorbs.net
orvedb.aupads.org
pbl.spamhaus.org
phishing.rbl.msrbl.net
pofon.foobar.hu
postmaster.rfc-clueless.org
problems.dnsbl.sorbs.net
proxies.dnsbl.sorbs.net
psbl.surriel.com
public.sarbl.org
rbl.abuse.ro
rbl.blockedservers.com
rbl.dns-servicios.com
rbl.efnet.org
rbl.efnetrbl.org
rbl.fasthosts.co.uk
rbl.interserver.net
rbl.iprange.net
rbl.lugh.ch
rbl.rbldns.ru
rbl.realtimeblacklist.com
rbl.schulte.org
rbl.spamlab.com
rbl.talkactive.net
rbl2.triumf.ca
recent.spam.dnsbl.sorbs.net
red.uribl.com
relays.bl.kundenserver.de
relays.dnsbl.sorbs.net
relays.nether.net
rhsbl.rymsho.ru
rhsbl.scientificspam.net
rhsbl.sorbs.net
rhsbl.zapbl.net
rsbl.aupads.org
safe.dnsbl.sorbs.net
sbl-xbl.spamhaus.org
sbl.nszones.com
sbl.spamhaus.org
short.fmb.la
short.rbl.jp
singular.ttk.pte.hu
smtp.dnsbl.sorbs.net
socks.dnsbl.sorbs.net
spam.dnsbl.anonmails.de
spam.dnsbl.sorbs.net
spam.pedantic.org
spam.rbl.blockedservers.com
spam.rbl.msrbl.net
spam.spamrats.com
spamguard.leadmon.net
spamlist.or.kr
spamrbl.imp.ch
spamsources.fabel.dk
st.technovision.dk
stabl.rbl.webiron.net
tor.efnet.org
torexit.dan.me.uk
truncate.gbudb.net
ubl.nszones.com
ubl.unsubscore.com
unsure.nether.net
uri.blacklist.woody.ch
uribl.abuse.ro
uribl.pofon.foobar.hu
uribl.spameatingmonkey.net
uribl.swinog.ch
uribl.zeustracker.abuse.ch
urired.spameatingmonkey.net
url.rbl.jp
urlsl.dnsbl.rjek.com
v4.fullbogons.cymru.com
virus.rbl.jp
virus.rbl.msrbl.net
vote.drbl.caravan.ru
vote.drbl.gremlin.ru
web.dnsbl.sorbs.net
web.rbl.msrbl.net
work.drbl.caravan.ru
work.drbl.gremlin.ru
wormrbl.imp.ch
xbl.spamhaus.org
z.mailspike.net
zen.spamhaus.org
zombie.dnsbl.sorbs.net
"

# -- Sanity check on parameters
[ $# -ne 1 ] && ERROR 'Please specify a single IP address'

# -- if the address consists of 4 groups of minimal 1, maximal digits, separated by '.'
# -- reverse the order
# -- if the address does not match these criteria the variable 'reverse will be empty'

reverse=$(echo $1 |
  sed -ne "s~^\([0-9]\{1,3\}\)\.\([0-9]\{1,3\}\)\.\([0-9]\{1,3\}\)\.\([0-9]\{1,3\}\)$~\4.\3.\2.\1~p")

if [ "x${reverse}" = "x" ] ; then
      ERROR  "IMHO '$1' doesn't look like a valid IP address"
      exit 1
fi

# Assuming an IP address of 11.22.33.44 as parameter or argument

# If the IP address in $0 passes our crude regular expression check,
# the variable  ${reverse} will contain 44.33.22.11
# In this case the test will be:
#   [ "x44.33.22.11" = "x" ]
# This test will fail and the program will continue

# An empty '${reverse}' means that shell argument $1 doesn't pass our simple IP address check
# In that case the test will be:
#   [ "x" = "x" ]
# This evaluates to true, so the script will call the ERROR function and quit

# -- do a reverse ( address -> name) DNS lookup
REVERSE_DNS=$(dig +short -x $1)

count=0
# -- cycle through all the blacklists
for BL in ${BLISTS} ; do
    # show the reversed IP and append the name of the blacklist

    # use dig to lookup the name in the blacklist
    #echo "$(dig +short -t a ${reverse}.${BL}. |  tr '\n' ' ')"
    LISTED="$(dig +short -t a ${reverse}.${BL}.)"
    if [ ! -z $LISTED ];then
	((count=count+1))
    fi
done

echo $count
