import json
import requests
import sys
import re
import getpass
import argparse
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

parser = argparse.ArgumentParser()
parser.add_argument('-dc', help="data center")

args = parser.parse_args()
dcno = args.dc


if dcno == "DC8":
        url="https://zabbix-americas.ondemand.com/api_jsonrpc.php"
elif dcno == "DC10":
        url="https://zabbix-apac.ondemand.com/api_jsonrpc.php"
elif dcno == "DC23":
        url="https://zabbix-cc.sapsf.com/api_jsonrpc.php"
elif dcno == "DC42":
        url="https://zabbix-azure.sapsf.com/api_jsonrpc.php"
elif dcno == "DC41":
        url="https://zabbix-americas-primary.ondemand.com/api_jsonrpc.php"
elif dcno == "DC25":
        url="https://zabbix-qa.cld.ondemand.com/api_jsonrpc.php"
else:
        print "Please choose one of the DCs : DC8 , DC10, DC23, DC41, DC42, DC25"

headers = {"Content-Type": "application/json"}
login_data=json.dumps({
    "jsonrpc": "2.0",
    "method": "user.login",
    "params": {
        "user": "ZABBIX_SFSF_API",
        "password": <passvault>
    },
    "id": 1
})
out = requests.post(url, data=login_data, headers=headers )

data_dump=json.dumps(
{
    "jsonrpc": "2.0",
    "method": "problem.get",
    "params":{"output": ["eventid","name","objectid"],"acknowledged":"0","suppressed":"0","filter": {"severity": ["3","4"]},"search":{"name":"ConnectionPool Usage is"} },

    "id": 1,
    "auth": out.json()['result'].rstrip('\n')
})



output = requests.post(url, data=data_dump, headers=headers )
problemdata=output.json()['result']

for i in range(0, len(problemdata)):
        eventid=problemdata[i]['eventid']
        triggerid=problemdata[i]['objectid']
        name=problemdata[i]['name']
	
	print str(eventid)+"    "+str(name)
	substring="ConnectionPool Usage is"

        if substring in name:

                data_dump=json.dumps({"jsonrpc": "2.0","method": "trigger.get","params":{"output": "extend","triggerids": triggerid,"selectFunctions": "extend","filter": {"description": "{HOST.NAME} - ConnectionPool Usage is > 60 % (active={ITEM.VALUE1},max={ITEM.VALUE2})","state": "1"}},"id": 1,"auth": out.json()['result'].rstrip('\n')})

                output1 = requests.post(url, data=data_dump, headers=headers )
                triggerdata=output1.json()['result']

                if str(len(triggerdata)) ==  "1" :
                        data_dump=json.dumps({"jsonrpc": "2.0","method": "event.acknowledge","params":{"output": "extend","eventids": eventid,"action": "1","message": "Problem State is Unknown"},"id": 1,"auth": out.json()['result'].rstrip('\n')})
                        output2 = requests.post(url, data=data_dump, headers=headers )
                        print output2.json()
                        print "Closed Event"
                        continue

                data_dump=json.dumps({"jsonrpc": "2.0","method": "trigger.get","params":{"output": "extend","triggerids": triggerid,"selectFunctions": "extend","filter": {"description": "{HOST.NAME} - ConnectionPool Usage is > 90 % (active={ITEM.VALUE1},max={ITEM.VALUE2})","state": "1"}},"id": 1,"auth": out.json()['result'].rstrip('\n')})

                output1 = requests.post(url, data=data_dump, headers=headers )
                triggerdata=output1.json()['result']

                if str(len(triggerdata)) ==  "1" :
                        data_dump=json.dumps({"jsonrpc": "2.0","method": "event.acknowledge","params":{"output": "extend","eventids": eventid,"action": "1","message": "Problem State is Unknown"},"id": 1,"auth": out.json()['result'].rstrip('\n')})
                        output2 = requests.post(url, data=data_dump, headers=headers )
                        print output2.json()
                        print "Closed Event"
                        continue
