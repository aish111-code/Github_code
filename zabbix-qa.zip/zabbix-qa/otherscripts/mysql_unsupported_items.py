import json
import requests
import sys
import re
import getpass
import argparse
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

parser = argparse.ArgumentParser()
parser.add_argument('-dc', help="data center")

args = parser.parse_args()
dcno = args.dc

if dcno == "DC8":
	url="https://zabbix-americas.ondemand.com/api_jsonrpc.php"
elif dcno == "DC10":
	url="https://zabbix-apac.ondemand.com/api_jsonrpc.php"
elif dcno == "DC23":
        url="https://zabbix-cc.sapsf.com/api_jsonrpc.php"
elif dcno == "DC42":
        url="https://zabbix-azure.sapsf.com/api_jsonrpc.php"
elif dcno == "DC41":
        url="https://zabbix-americas-primary.ondemand.com/api_jsonrpc.php"
elif dcno == "DC25":
        url="https://zabbix-qa.cld.ondemand.com/api_jsonrpc.php"
else:
	print "Please choose one of the DCs : DC8 , DC10, DC23, DC41, DC42, DC25"

headers = {"Content-Type": "application/json"}
login_data=json.dumps({
    "jsonrpc": "2.0",
    "method": "user.login",
    "params": {
        "user": "ZABBIX_SFSF_API",
        "password": <passvault>
    },
    "id": 1
})
out = requests.post(url, data=login_data, headers=headers )

data_dump=json.dumps(
{
    "jsonrpc": "2.0",
    "method": "hostgroup.get",
    "params":{"output": "extend","filter": {"name": "All-DB-MYSQL"}},
    "id": 1,
    "auth": out.json()['result'].rstrip('\n')
})


output = requests.post(url, data=data_dump, headers=headers )
hstgroupid= output.json()["result"][0]["groupid"]


data_dump=json.dumps(
{
    "jsonrpc": "2.0",
    "method": "host.get",
    "params":{"output": "extend","groupids":hstgroupid,"filter": {"status": "0","maintenance_status": "0"}},
    "id": 1,
    "auth": out.json()['result'].rstrip('\n')
})

output1 = requests.post(url, data=data_dump, headers=headers )
hostdata = output1.json()['result']
html_data="<html><body><br><br><table border=2 BORDERCOLOR=BLACK style='font-family:Arial'>"
html_data=html_data+"<tr><th>HOSTNAME</th> <th><table border=2 BORDERCOLOR=BLACK><th colspan=4><th></th></table></th></tr>"
for v in range(len(hostdata)):
        hstnme=hostdata[v]["name"]
        hstid=hostdata[v]["hostid"]
        data_dump=json.dumps({"jsonrpc": "2.0","method": "item.get","params":{"hostids":hstid,"filter": {"state": "1"},"monitored": "true"},"id": 1,"auth": out.json()['result'].rstrip('\n')})
        output2 = requests.post(url, data=data_dump, headers=headers )
        item_data = output2.json()['result']
        if str(len(item_data)) !=  "0" :
                html_data=html_data+"<tr><td>"+str(hstnme)+"</td><td><table border=2 BORDERCOLOR=BLACK>"
                for u in range(len(item_data)):
                        temp=""
                        temp=temp+"<tr><td bgcolor=#ffd1b3 colspan=4>"+str(item_data[u]["name"])+"</td>"
                        temp=temp+"<td colspan=4>"+str(item_data[u]["key_"])+"</td>"
                        temp=temp+"<td bgcolor=#ffd1b3 colspan=4>"+str(item_data[u]["error"])+"</td></tr>"
                        html_data=html_data+temp
                html_data=html_data+"</table><td></tr>"
html_data=html_data+"</table></body></html>"
print html_data

