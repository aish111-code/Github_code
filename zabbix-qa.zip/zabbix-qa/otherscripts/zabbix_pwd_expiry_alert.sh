#!/bin/bash

###### change DIR value where script is present
DIR="/root/pass_reset_alert"
currenttimestamp=`date +'%s'`

####pass the 1st argument as DB IP
if [ "$#" -ne 1 ]; then
    echo "Please pass the DB IP as arument to the script
                './<scriptname> <DB IP>'"
        exit
else
dbhost=$1
fi
### Add the user in array which needs to be monitored
users=("testuser" "zbxutility" "ZABBIX_SFSF_API" "zbxsuperadmin" "grafana_zabbix")
##update mail ids who needs to get the alert(s)
mailid="ayush.jain@sap.com"

#####function to gather user details for 1st execution only
gather_user_detail()
{
if [ ! -f "${DIR}/zabbix_user_detail.txt" ];then
        echo "Username Password Timestamp">$DIR/zabbix_user_detail.txt
        for j in "${users[@]}"
        do
                temp_MD5pass=`mysql -h $1 -uzabbixproddb -p<passvault> -e "use zabbix; select passwd from users where alias=\"$j\";"|sed 's/ /\n/g'| grep -Ev 'passwd'`
                if [ -z $temp_MD5pass ];then
                        echo "Not able to fetch password for $i"
                        continue
                fi

                echo "$j $temp_MD5pass $currenttimestamp" >>$DIR/zabbix_user_detail.txt

        done
        echo -e "zabbix_user_detail.txt file updated on `hostname`  \n\n `cat $DIR/zabbix_user_detail.txt`"|mailx -r "saasopsps@successfactors.com" -s "zabbix_user_detail.txt file updated on `hostname`" "$mailid"
fi
}


###function checking pass expiry and modification
pwd_expiry_check()
{

for i in "${users[@]}"
do
        n_MD5pass=`mysql -h $1 -uzabbixproddb -p'' -e "use zabbix; select passwd from users where alias=\"$i\";"|sed 's/ /\n/g'| grep -Ev 'passwd'`

        if [ -z $n_MD5pass ];then
                echo "Not able to fetch password for $i"
                continue
        fi
        ac_md5pass=`cat $DIR/zabbix_user_detail.txt|grep -i $i|awk '{print $2}'`
        ac_timestamp=`cat $DIR/zabbix_user_detail.txt|grep -i $i|awk '{print $3}'`

        if [ "$ac_md5pass" == "$n_MD5pass" ];then
                ((clock=$currenttimestamp - $ac_timestamp ))
                if [ $clock -gt 15552000 ];then
                        echo -e "Password for $i is not changed from last 6 months on `hostname`  \n\n Please update the password \n\n last pass change timestamp= `date -d @$ac_timestamp` \n\n Current timestamp: `date -d @$currenttimestamp` "|mailx -r "saasopsps@successfactors.com" -s "Password expired for $i on `hostname`" "$mailid"
                fi
        else
                sed -i "/$i/d" $DIR/zabbix_user_detail.txt
                echo "$i $n_MD5pass $currenttimestamp" >>$DIR/zabbix_user_detail.txt
                echo -e "Password for $i updated on `hostname`  \n\n  last pass change timestamp= `date -d @$ac_timestamp` \n\n New pass change timestamp: `date -d @$currenttimestamp` \n\n "|mailx -r "saasopsps@successfactors.com" -s "Password updated for $i on `hostname`" "$mailid"
        fi

done

}


gather_user_detail $dbhost

sleep 5
pwd_expiry_check $dbhost
