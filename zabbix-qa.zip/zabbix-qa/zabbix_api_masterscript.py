import requests
import json
import re
#import csv
import sys
import smtplib
import getpass
import getopt
import pandas as pd
#from openpyxl import Workbook
import numpy as np
import datetime


# Defining basic usage
def usage ():
	print('The input format for each of the existing methods is given below: \n * --method add_template/delete_template --hosts/groups <comma seperated list of hosts or groups --templates <templatename> \n * --method get_unsupported_items --applications/groups <comma seperated list of applications or groups> \n * --method get_hosts_from_template --templates <comma seperated list of templates> \n * --method get_hosts_from_groups --groups <comma seperated list of groups> \n * --method get_hosts_from_proxy --proxy <comma seperated list of proxies> \n * --method decommission_hosts --hosts hosts.txt \n * --method compare_hostlist --proxy <proxy> --compare "<environment_1>,<environment_2>" ed list of groups> \n * --method get_hosts_from_proxy --proxy <comma seperated list of proxies> \n * --method decommission_hosts --hosts <comma seperated list of hosts>" \n * --method migrate_hosts --hosts hosts.txt --migrate "<environment_1>,<environment_2>" \n * --method disable_trigger --hosts hosts.txt \n * --method get_item_data \n * Environment list for compare_hostlist method : legacy,emea,azure,apac,america \n * Environment has to be added for emea,Azure,APAC as --env emea/azure/apac \n * While giving input with a space in it\'s name, use quotes. Ex: "Pacemaker status"')

# Block 1: Making sure that the user enters input in proper format
#Changed extra method
methods=['add_template','delete_template','get_unsupported_items','get_latest_data','get_hosts_from_template','get_hosts_from_groups','get_hosts_from_proxy','compare_hostlist','decommission_hosts','migrate_hosts','disable_trigger','get_item_data','add_item']

argv=sys.argv[1:]
if argv==[]:
	usage()
	sys.exit()
opts,args=getopt.getopt(argv,"h:g:m:t:e:a:p:c:i:n:",["hosts=","groups=","method=","templates=","env=","applications=","proxy=","compare=","migrate=","item"])
opts=dict(opts)

keys = opts.keys()
values = opts.values()
method=opts['--method']
envmatrix = {'legacy':'https://zabbix-hcm.ondemand.com/zabbix/api_jsonrpc.php','emea':'https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php','azure':'https://zabbix-azure.sapsf.com/api_jsonrpc.php','apac':'https://zabbix-apac.ondemand.com/api_jsonrpc.php','america':'https://zabbix-americas.ondemand.com/api_jsonrpc.php','americas_primary':'https://zabbix-americas-primary.ondemand.com/api_jsonrpc.php'}
envlist = envmatrix.keys()
if '--env' in keys :
	env = opts['--env']

	api = envmatrix[env]

elif '--compare' in keys or '--migrate' in keys:
	
	try:
		[env1,env2] = opts['--compare'].split(',')
	except:
		try :
			[env1,env2] = opts['--migrate'].split(',')
		except :
			usage()
			exit()

	if env1 not in envlist or env2 not in envlist :
		print 'Enter a valid environment name \n'
		usage()
		exit()
	api1 = envmatrix[env1]
	api2 = envmatrix[env2]
	
else :
	api = 'https://zabbix-hcm.ondemand.com/zabbix/api_jsonrpc.php'

if (opts==[] or '--method'not in keys or
	method not in methods or 
	method in ['add_template','delete_template'] and len(opts)<3 or
	method not in ['add_template','delete_template'] and len(opts)>3
	):	
	usage()
	sys.exit()

# Getting auth token
def gettoken():
	user = raw_input("User id :")
	password = getpass.getpass('Password :')
	data='{"jsonrpc":"2.0","method":"user.login","params":{"user":"%s","password":"%s"},"id":1,"auth":null}' %(user,password)

	if method not in  ['compare_hostlist','migrate_hosts']:
		
		r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
		r=r.json()
		print r 
		if 'result' not in r :
			print('Invalid Credentials')
			exit()
		token = r["result"]

		return token

	else :
		
		r= requests.post(api1, data=data, headers={'Content-Type': 'application/json'})
		r=r.json()
		if 'result' not in r :
			print('Invalid Credentials')
			exit()
		token1 = r["result"]	

		r= requests.post(api2, data=data, headers={'Content-Type': 'application/json'})
		r=r.json()
		if 'result' not in r :
			print('Invalid Credentials')
			exit()
		token2 = r["result"]	
		return token1,token2

# Defining methods
# Block 2 :
def genparameters(opts,method,token):
	# Check if syntax is correct
	if ('--groups' not in keys and '--hosts' not in keys) or '--templates' not in keys :
		usage()
		sys.exit()
	else :
		if '--groups' in keys:
			update='--groups'
		else :
			update ='--hosts'
	
		updatevalue = opts[update].split(',')
		newtemplates = opts['--templates'].split(',')
	
	if update=='--groups':
		# Getting groupid of the group name
		for group in updatevalue:
			data='{"jsonrpc":"2.0","method":"hostgroup.get","params":{"filter": {"name": "%s"} },"id":2,"auth": "%s"}' %(str(group),token)
			r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
			
			if 'result' in r.json():
				if r.json()['result']==[]:
					print "The group name " + str(group)+" is invalid"
					continue
				else :
					gid=r.json()['result'][0]['groupid']
				# Getting the hosts from the group id
				data='{"jsonrpc":"2.0","method":"host.get","params":{"groupids":"%s" },"id":2,"auth": "%s"}' %(gid,token)
				r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
				hosts=r.json()['result']

				# Updating for every host :
				if method=='add_template':
					for host in hosts :
						hid = host['hostid']
						hostname=host['host']
						addtemplate(hid,token,newtemplates,hostname)
				elif method=='delete_template':
					for host in hosts :
						hid = host['hostid']
						hostname=host['host']
						deltemplate(hid,token,newtemplates,hostname)
			else :
				print "Invalid Group name" + str(r.json()['error'])
				continue
			
		# Write the method
	elif update == '--hosts':
		for host in updatevalue :
			data={"jsonrpc":"2.0","method":"host.get","params":{"filter":{"host":str(host)} },"id":1, "auth":token }
			r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'}) 
			if 'result' in r.json():
				if r.json()['result']==[]:
					data = {"jsonrpc":"2.0","method":"host.get","params":{"filter":{"name":str(host)} },"id":1, "auth":token }
					tempr= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
					
					if 'result' in tempr.json():
						if tempr.json()['result'] == []:
							print "The host name "+ str(host) +" is invalid"
						else :
							h = tempr.json()['result'][0]
					else :
						print "Invalid Host name" + str(tempr.json()['error'])

				else :
					h = r.json()['result'][0]

				# Updating for the host 
				if method == 'add_template':
					hid = h['hostid']
					hostname = h['host']
					addtemplate(hid,token,newtemplates,hostname)
				elif method == 'delete_template':
					hid = h['hostid']
					hostname = h['host']
					deltemplate(hid,token,newtemplates,hostname)


			else :
				print "Invalid Host name" + str(r.json()['error'])
		
	
def addtemplate(hid,token,newtemplates,hostname):
	tl,templist,newtempid=get_temp_ids(hid,token,newtemplate)
	newtemp = {"templateid": str(newtempid)}
	templist.append(newtemp)
	tl.append(newtempid)

	# Updating the host
	if len(tl)==len(set(tl)) :
		data={"jsonrpc":"2.0","method":"host.update","params":{"hostid":hid,"templates":templist},"id":1, "auth":token }
		r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r=r.json()	
		if 'result' not in r :
			print str(hostname) + ' Template not added \n Error : '+'  ' + str(r['error']['data'])
		else:
			print str(hostname) + ' Added Template'
			# else:
			# 	print str(host['name']) + ' ' + 'Added Template'

	else : 
			print str(hostname)+ ' Template already added' 

def deltemplate(hid,token,newtemplates,hostname):
	tl,templist,newtempid=get_temp_ids(hid,token,newtemplates)
	
	# Removing the template
	if newtempid in tl :
			data={"jsonrpc":"2.0","method":"host.update","params":{"hostid":hid,"templates_clear":newtempid},"id":1, "auth":token }
			r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
			r=r.json()
			print str(hostname)+ ' ' + 'Removed the template'

	else :
			print str(hostname)+ ' ' + 'The template is not attached'

def get_temp_ids(hid,token,newtemplates):
	data='{"jsonrpc":"2.0","method":"template.get","params":{"hostids":[%s]},"id":2,"auth": "%s"}' %(hid,token)
	r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
	r=r.json()
	results=r['result']
	templist = []
	tl = []
		# Getting the template list of already existing templates
	for result in results:
		temp = {"templateid": str(result['templateid'])}
		templist.append(temp)
		tl.append(result['templateid'])
	if newtemplates == 'null':
		return tl 
	else :
		for newtemplate in newtemplates :
			data='{"jsonrpc":"2.0","method":"template.get","params":{"filter":{"host":"%s"} },"id":3,"auth": "%s"}' %(newtemplate,token)
			r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
			r=r.json()
			if 'result' in r:
				if r['result']==[]:
					print 'The template is invalid'
					exit()
				else:
					newtempid=r['result'][0]['templateid']
			
				
			else :
				print 'Failed to identify template :' + ' '+ str(r['error'])
		return tl,templist,newtempid

def disable_trigger(tid):
		data={"jsonrpc":"2.0","method":"trigger.update","params":{"triggerid":tid,"status":1},"id":1, "auth":token }
		r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r = r.json()
		print r

if method in ['add_template','delete_template']:
	token=gettoken()
	genparameters(opts,method,token)
		
if method == 'get_unsupported_items' :
	if ('--applications' not in keys and '--groups' not in keys):
		usage()
		exit()
	token = gettoken()
	if '--applications' in keys :
		app_list= opts['--applications'].split(',')
		l=[]
		for app in app_list:
			data='{"jsonrpc":"2.0","method":"item.get","params":{"filter": {"state": "1"}, "application":"%s","monitored": "true","selectHosts":["host","name"]},"id":2,"auth": "%s"}'%(app,token)
			r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
			
			if 'result' not in r.json():
				print 'The application name ' + str(app) + ' is invalid' + str(r.json['error'])
				
			else:
				if r.json()['result'] == []:
					print 'The application name ' + str(app) + ' is invalid'
					continue 
				else :
					results = r.json()["result"]
					for result in results:
						
						dic = dict([("Application",app),("Error",result["error"]),("Item Name",result["name"]),("Host Name",result['hosts'][0]["host"]),('Key',result["key_"])])
						l.append(dic)
		df =pd.DataFrame(l)
		df.to_csv('api_output.txt',header=True, index=False,sep=',')
		print 'Success - Check the file api_output.txt for any output'
		
	 
	if '--groups' in keys :
		grouplist= opts['--groups'].split(',')
		l=[]
		for group in grouplist :
			data='{"jsonrpc":"2.0","method":"item.get","params":{"selectApplications":["name"],"monitored": "true","selectHosts":["host","name"],"group":"%s","filter": {"state": "1"} },"id":2,"auth": "%s"}'%(group,token)
			r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
			
			if 'result' not in r.json():
				print 'The group name ' + str(group) + ' is invalid' + str(r.json['error'])
			else:
				if r.json()['result'] == []:
					print 'The group name ' + str(group) + ' is invalid or has no unsupportd items'
					continue 
				else :
					results = r.json()["result"]					
					for result in results:
						if result['applications']==[]:
							dic = dict([ ('Hostname', result["hosts"][0]['name']),('Error',result["error"]),('Item name',result["name"]),('Key',result["key_"]),('Application', 'No Application'),('Group',group)])
							l.append(dic)
						else :
							dic = dict([ ('Hostname', result["hosts"][0]['name']),('Error',result["error"]),('Item name',result["name"]),('Key',result["key_"]),('Application',result["applications"][0]['name']),('Group',group)])
							l.append(dic)
						
		df =pd.DataFrame(l)
		df=df.drop_duplicates(subset=['Hostname'], keep='first', inplace=False)
		df.to_csv('api_output.txt',header=True, index=False,sep=',')
		print 'Success - Check the file api_output.txt for any output'
				



		
if method=='get_hosts_from_template' :
	if '--templates' not in keys :
		usage()
		exit()

	token=gettoken()
	template_list=opts['--templates'].split(',')
	l=[]
	for temp in template_list :
		
		data='{"jsonrpc":"2.0","method":"template.get","params":{"selectHosts":["host","key_","name"],"filter": {"host": "%s"} },"id":2,"auth": "%s"}' %(str(temp),token)
		r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
		r=r.json()

		if 'result' in r :
			if r['result'] == []:
				print 'The template name ' + str(temp) + ' is invalid'
				continue
			else :
				results = r["result"]
				dic = {}
				hosts= results[0]['hosts']
				if hosts ==[]:
					print 'No hosts in ' + str(temp) + ' template or it is a linked template'
				else :
					ls = []
					for h in hosts:
						ls.append(str(h['hostid']))

					data={"jsonrpc":"2.0","method":"hostinterface.get","params":{"hostids":ls,"selectHosts":"extend"},"id":1, "auth":token }
					tempr= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
					results=tempr.json()['result']
					for result in results :
						if str(result['hosts'][0]['status'])== '0' :
							status = 'Enabled'
						else :
							status = 'Disabled'
						dic = dict([("Template Name",temp),("Host Name",result['hosts'][0]['host']),("IP",result["ip"]),('Status',status)])
						l.append(dic)


	df =pd.DataFrame(l)
	df=df.drop_duplicates(subset=['Host Name'], keep='first', inplace=False)
	df.to_csv('api_output.txt',header=True, index=False,sep=',')

	print 'Success - Check the file api_output.txt for any output'
				

	
if method == 'get_hosts_from_groups':
	if '--groups' not in keys :
		usage()
		exit()
	
	token = gettoken()
	grouplist = opts['--groups'].split(',')
	# Getting host id's of groups 
	
	data={"jsonrpc":"2.0","method":"hostgroup.get","params":{"output":"extend","filter":{"name":grouplist},"selectHosts":"extend"},"id":1, "auth":token }
	r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
	r=r.json()
	if 'result' not in r :
		print 'Failed to identify group :' + ' '+ str(r['error'])
		exit()
	else :
		if r['result']==[]:
			print 'One of the group names is invalid'
			
		else :
			l = []
			for re in r['result'] :
				ls = []
				hosts=re['hosts']
				group= re['name']
				
				for host in hosts :
					ls.append(str(host['hostid']))

				 
				data={"jsonrpc":"2.0","method":"hostinterface.get","params":{"hostids":ls,"selectHosts":"extend"},"id":1, "auth":token }
				tempr= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
				results=tempr.json()['result']
				for result in results :
					if str(result['hosts'][0]['status'])== '0' :
						status = 'Enabled'
					else :
						status = 'Disabled'
					dic = dict([("Group",group),("Host Name",result['hosts'][0]['host']),("Host Name 2",result['hosts'][0]['name']),("IP",result["ip"]),("Status",status)])
					l.append(dic)
			
			df =pd.DataFrame(l)
			df=df.drop_duplicates(subset=['Host Name'], keep='first', inplace=False)
			df.to_csv('api_output.txt',header=True, index=False,sep=',')
			print 'Success - Check the file api_output.txt for any output'
if method == 'get_hosts_from_proxy':
	if '--proxy' not in keys :
		usage()
		exit()
	token = gettoken()
	proxylist = opts['--proxy'].split(',')
	l = []
	for proxy in proxylist :
		data={"jsonrpc":"2.0","method":"host.get","params":{"filter":{"name":str(proxy)} },"id":1, "auth":token }
		r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r=r.json()
		if 'result' not in r :
			print 'Failed to identify proxy :' + ' '+ str(r['error'])
			exit()
		else :
			if r['result']==[]:
				print 'The proxy '+ str(proxy)+ ' is invalid'
				continue
			else :
				proxy_id = str(r['result'][0]['proxy_hostid'])
				proxy = r['result'][0]['host']
				data={"jsonrpc":"2.0","method":"proxy.get","params":{"proxyids":proxy_id, "selectHosts":"extend"},"id":1, "auth":token }
				r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
				r=r.json()
				hosts = r['result'][0]['hosts']
				ls = []
				for host in hosts:
					ls.append(str(host['hostid']))
					# hostid = str(host['hostid'])
					
					# # Host Group 
					# data={"jsonrpc":"2.0","method":"host.get","params":{"hostids":hostid,"selectGroups":"extend"},"id":1, "auth":token }
					# r=requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
					# result = r.json()['result']
					# groups = result[0]['groups']
					# groupname = ""
					# for group in groups :
					# 	groupname = groupname+","+str(group['name'])


					# # Host IP, Status
					# data={"jsonrpc":"2.0","method":"hostinterface.get","params":{"hostids":hostid,"selectHosts":"extend"},"id":1, "auth":token }
					# r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
					# result=r.json()['result'][0]
					# if result['hosts'][0]['status']=='0':
					# 	status = 'Enabled'
					# else :
					# 	status = 'Disabled'
					# dic = dict([("Proxy",proxy),("Host Name",result['hosts'][0]['host']),("Host Name 2",result['hosts'][0]['name']),("IP",result["ip"]),('Status',status),('Groupnames',groupname)])
					# print result['hosts'][0]['name']
					# l.append(dic)


				data={"jsonrpc":"2.0","method":"hostinterface.get","params":{"hostids":ls,"selectHosts":"extend"},"id":1, "auth":token }
				r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
				results=r.json()['result']
				for result in results :			
					if str(result['hosts'][0]['status'])== '0' :
						status = 'Enabled'
					else :
						status = 'Disabled'		
					dic = dict([("Proxy",proxy),("Host Name",result['hosts'][0]['host']),("Host Name 2",result['hosts'][0]['name']),("IP",result["ip"]),('Status',status)])
					l.append(dic)
	
	df =pd.DataFrame(l)
	df=df.drop_duplicates(subset=['Host Name'], keep='first', inplace=False)
	df.to_csv('api_output.txt',header=True, index=False,sep=',')
	print 'Success - Check the file api_output.txt for any output'


if method == 'compare_hostlist' :
	if '--compare' not in keys or '--proxy' not in keys :
		usage()
		exit()
	token1,token2 = gettoken()
	proxylist = opts['--proxy'].split(',')
	l1 = []
	l2= []
	l3=[]
	
	for proxy in proxylist :
		ls1=[]
		ls2=[]

		data={"jsonrpc":"2.0","method":"host.get","params":{"filter":{"name":str(proxy)} },"id":1, "auth":token1 }
		r= requests.post(api1, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r=r.json()
		if 'result' not in r :
			print 'Failed to identify proxy :' + ' '+ str(r['error'])
			exit()
		else :
			if r['result']==[]:
				print 'The proxy '+ str(proxy)+ ' is invalid for '+str(env1) + ' environment'
				continue
			else :
				proxy_id = str(r['result'][0]['proxy_hostid'])
				#proxy = r['result'][0]['host']
				data={"jsonrpc":"2.0","method":"proxy.get","params":{"proxyids":proxy_id, "selectHosts":"extend"},"id":1, "auth":token1 }
				r= requests.post(api1, data=json.dumps(data), headers={'Content-Type':'application/json'})
				r=r.json()
				hosts = r['result'][0]['hosts']
				ls1 = []
				for host in hosts :
					ls1.append(str(host['host']))


		data={"jsonrpc":"2.0","method":"host.get","params":{"filter":{"name":str(proxy)} },"id":1, "auth":token2 }
		r= requests.post(api2, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r=r.json()
		
		if 'result' not in r :
			print 'Failed to identify proxy :' + ' '+ str(r['error'])
			exit()
		else :
			if r['result']==[]:
				print 'The proxy '+ str(proxy)+ ' is invalid for ' + str(env2)+ ' environment'
				continue
			else :
				proxy_id = str(r['result'][0]['proxy_hostid'])
				proxy = r['result'][0]['host']
				data={"jsonrpc":"2.0","method":"proxy.get","params":{"proxyids":proxy_id, "selectHosts":"extend"},"id":1, "auth":token2 }
				r= requests.post(api2, data=json.dumps(data), headers={'Content-Type':'application/json'})
				r=r.json()
				hosts = r['result'][0]['hosts']
				ls2 = []
				for host in hosts :
					ls2.append(str(host['host']))

		ls3 = set(ls1)-set(ls2)
		ls3.update(set(ls2)-set(ls1))
		ls3= list(ls3)
		ls1 = list(set(ls1))
		ls2 = list(set(ls2))
		l1.extend(ls1)
		l2.extend(ls2)
		l3.extend(ls3)
	
	data = {str(env1):l1}
	l2 = pd.Series(l2)
	l3 = pd.Series(l3)
	df = pd.DataFrame(data)
	df[env2] = l2
	df['Hosts not registered'] = l3
	df.to_csv('api_output.txt',header=True, index=False,sep=',')
	print 'Success - Check the file api_output.txt for any output'
				
if method == 'decommission_hosts' :
	if '--hosts' not in keys:
		usage()
		exit()
	token = gettoken()

	hostlist = open('hosts.txt').read().splitlines()

	#Getting template ID 
	data='{"jsonrpc":"2.0","method":"template.get","params":{"filter":{"host":"T_Host_Decommission"} },"id":3,"auth": "%s"}' %(token)
	r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
	r=r.json()
	newtempid=r['result'][0]['templateid']
	decomtemp = {"templateid": str(newtempid)}

	#Getting group id 
	data={"jsonrpc":"2.0","method":"hostgroup.get","params":{"output":"extend","filter":{"name":"hosts-decommissioned"}},"id":1, "auth":token }
	r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
	r=r.json()
	groupid = r['result'][0]['groupid']
	decomgroup = {"groupid": str(groupid)}


	for host in hostlist :
		data={"jsonrpc":"2.0","method":"host.get","params":{"filter":{"host":str(host)} },"id":1, "auth":token }
		r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'}) 
		if 'result' in r.json():
			if r.json()['result']==[]:
				data = {"jsonrpc":"2.0","method":"host.get","params":{"filter":{"name":str(host)} },"id":1, "auth":token }
				tempr= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
			
				if 'result' in tempr.json():
					if tempr.json()['result'] == []:
						print "The host name "+ str(host) +" is invalid"
					else :
						h = tempr.json()['result'][0]
				else :
					print "Invalid Host name" + str(tempr.json()['error'])
					continue

			else :
				h = r.json()['result'][0]

			# Updating for the host 
			#print r.json()
			hid = h['hostid']
			hostname = h['host']

			#Add Template :
			tl = get_temp_ids(hid,token,'null')
			data={"jsonrpc":"2.0","method":"host.massremove","params":{"templateids_clear":tl,"hostids":[str(hid)]},"id":1, "auth":token }
			r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
			r=r.json()
			print r

			data={"jsonrpc":"2.0","method":"host.update","params":{"hostid":hid,"templates":decomtemp,"groups":decomgroup,"status": 1},"id":1, "auth":token }
			r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
			r=r.json()	
			if 'result' not in r :
				print str(hostname) + ' Template not added \n Error : '+'  ' + str(r['error']['data'])
			else:
				print str(hostname) + ' Done Decommissioning'
		else :
			print "Invalid Host name" + str(r.json()['error'])


if method == 'migrate_hosts' :
	if '--hosts' not in keys :
		usage()
		exit()

	token1,token2 = gettoken()
	hosts = open('hosts.txt').read().splitlines()

	for host in hosts :
		print host
		data={"jsonrpc":"2.0","method":"host.get","params":{"filter":{"host":str(host)} },"id":1, "auth":token1 }
		r= requests.post(api1, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r=r.json()
		if 'result' not in r :
			print 'Failed to identify host :' + ' '+ str(r['error'])
			exit()
		else :
			if r['result']==[]:
				print 'The host '+ str(host)+ ' is invalid for '+str(env1) + ' environment'
				continue
			else :
				host_id = str(r['result'][0]['hostid'])

		data={"jsonrpc":"2.0","method":"configuration.export","params":{"options":{"hosts":[str(host_id)]},"format": "xml" },"id":1, "auth":token1 }
		r= requests.post(api1, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r = r.json()
		source = str(r['result'])
		true = bool("yes")
		data={"jsonrpc":"2.0","method":"configuration.import","params":{"format":"xml","rules":{"hosts":{"updateExisting":true,"createMissing":true},"groups":{"createMissing":true},"items":{"updateExisting":true,"createMissing":true},"templateLinkage":{"createMissing":true},"applications":{"createMissing":true},"discoveryRules":{"updateExisting":true,"createMissing":true},"triggers":{"updateExisting":true,"createMissing":true},"graphs":{"updateExisting":true,"createMissing":true},"httptests":{"updateExisting":true,"createMissing":true},"valueMaps":{"createMissing":true} },"source":source},"id":1, "auth":token2}
		

		r= requests.post(api2, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r=r.json()

		if 'result' in r:
			f = open('api_output.txt', 'a')
			f.write(host+","+str(r['result']))
			data={"jsonrpc":"2.0","method":"host.get","params":{"filter":{"host":str(host)} },"id":1, "auth":token2 }
			r= requests.post(api2, data=json.dumps(data), headers={'Content-Type':'application/json'})
			r=r.json()
			host_id = str(r['result'][0]['hostid'])
			data={"jsonrpc":"2.0","method":"hostgroup.massadd","params":{"groups":[{"groupid":"282"}],"hosts":[{"hostid":host_id}]},"id":1, "auth":token2 }
			r= requests.post(api2, data=json.dumps(data), headers={'Content-Type':'application/json'})
			r=r.json()
			if 'result' not in r:
				f.write(",Could not add to maintenance")
			f.write("\n")
			f.close()
		else :
			f = open('api_output.txt', 'a')
			f.write(host+","+str(r['error']['data']))
			f.write("\n")
			f.close()


		
if method == 'disable_trigger':
	if '--hosts' not in keys :
		usage()
		exit()

	token = gettoken()
	hosts_raw = open('hosts.txt').read().splitlines()
	hosts = [x for i, x in enumerate(hosts_raw) if i%3 !=0]
	for host in hosts :
		print host
		data={"jsonrpc":"2.0","method":"trigger.get","params":{"host":host},"id":1, "auth":token }
		r= requests.post(api, data=json.dumps(data), headers={'Content-Type':'application/json'})
		r = r.json()
		if 'result' not in r :
			print "Recheck the host name  "+ str(host)
		else :
			triggers  = r['result']
			for trigger in triggers :
				desc = trigger['description']
				trigger_id = trigger['triggerid']
				if 'Overseer' in desc :
					disable_trigger(trigger_id)
				elif 'ALL cores' in desc :
					disable_trigger(trigger_id)
				elif 'SOLR Corrupt Cores' in desc :
					disable_trigger(trigger_id)
				elif 'missing replicas' in desc :
					disable_trigger(trigger_id)


## Changes
if method == 'get_item_data' :
	# if ('--applications' not in keys and '--groups' not in keys):
	# 	usage()
	# 	exit()
	token = gettoken()
	
	#app_list= ['NTP','Filesystem']
	app_list = ['NTP']
	l=[]
	for app in app_list:
		data='{"jsonrpc":"2.0","method":"item.get","params":{"output": "extend","application":"%s","monitored":"true","selectHosts":["host","name"]},"id":2,"auth": "%s"}'%(app,token)
		r= requests.post(api, data=data, headers={'Content-Type': 'application/json'})
		#print r.text
		try:
			req = r.json()
			#print r.json()
		except:
			continue
		if 'result' not in r.json():
			print 'The application name ' + str(app) + ' is invalid' + str(r.json['error'])
			
		else:
			if r.json()['result'] == []:
				print 'The application name ' + str(app) + ' is invalid'
				continue 
			else :
				results = r.json()["result"]
				# if app=='NTP':
				# 	find = 'system.localtime[local]'
				# else:
				# 	find = 'system.localtime'
				# now = datetime.datetime.utcnow()
				for result in results :
					#print result
					#print result['key_']
					if result["key_"] == 'system.localtime[local]':
						#print result
						# print result['lastvalue']						
	# 					epoch = float(result['lastvalue'])
	# 					d = datetime.datetime.utcfromtimestamp(epoch)
	# 					print d
	# 					if d>now :
	# 						diff = ((d-now).seconds)/1800
	# 					else :
	# 						diff = ((now-d).seconds)/1800
	# 				    # print result
						dic = dict([("Host Name",result['hosts'][0]["host"]),("Value",result['lastvalue']),("Item Name",result["name"])])
						l.append(dic)
	df =pd.DataFrame(l)
	df.to_csv('api_output.txt',header=True, index=False,sep=',')
	print 'Success - Check the file api_output.txt for any output'


if method=="add_item" :
	token = gettoken()
	i=0
	templates = ["T_APIGEE_Linux", "T_BizX_Linux", "T_BizX_Linux_NonProd", "T_BOOMI_Linux", "T_ELK_Linux", "T_GeoIP_Linux", "T_HANA_Linux", "T_J2W_Linux", "T_JAM_Linux", "T_LMS_Linux", "T_LMS_Linux_NonProd", "T_LMS_W_iContent-Linux_URL", "T_MOB_Linux", "T_OHM_Linux", "T_OPTIER_Linux", "T_OS_Linux", "T_SPLUNK_Linux", "T_UA_Linux", "T_WFA_Linux", "T_ZABBIX_Linux"]
	data={"jsonrpc":"2.0","method":"template.get","params":{"output": "extend","filter":{"host":templates},"selectApplications":["applications","name","applicationid"] },"id":2,"auth":token}	
	r= requests.post(api, data=json.dumps(data), headers={'Content-Type': 'application/json'})
	# print r.json()	
	#sids = r.json()['result'][0]['templateid']
	results = r.json()['result']
	for result in results :
		for app in result['applications']:
			if app['name'] == 'Filesystem':
				appid = app['applicationid']
				break
		id = result['templateid']
		data={"jsonrpc":"2.0","method":"item.create","params":{"name": "NTP time check","key_":"system.localtime[local]","hostid":id,"type":7,"value_type":4,"delay":"1h","applications":[appid] },"id":2,"auth":token}
		r= requests.post(api, data=json.dumps(data), headers={'Content-Type': 'application/json'})
		# print r.json()
		print templates[i]
		print r.json()
		i=i+1
