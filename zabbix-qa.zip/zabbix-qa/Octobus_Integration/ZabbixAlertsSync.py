#!/usr/bin/python -W ignore::DeprecationWarning
# -*- coding: utf-8 -*-
#
import traceback
import re
import sys
from shutil import copyfile
from time import time
from requests.packages import urllib3
from common import Process, Logger, mail_notification,Zabbix, http_session,Cache, Octobus, CONFIG_FILE, CURRENT_EVENTS_PATH,CLUSTER
import ast
import json

CURRENT_TIME=int(time())
CLEANUP_NAME = 'ZabbixAlertCleanup'
CLEANUP_LIMIT = 20
CLEANUP_DELAY_SECONDS=18
ENABLE_LOG_IN_FILE = True
VERBOSE=True

def old_octobus_alerts():
        alerts = {}
        for line in open(CURRENT_EVENTS_PATH+'Current_Events').readlines():
                try:
                        oid = line.split(',')[3].strip("\n")
                except :
                        oid = ''
                        print(line)
                alerts[str(line.split(',')[0])] = {'status':line.split(',')[1],'host':line.split(',')[2].strip("\n"),'_id':oid}
        return alerts

def new_octobus_alerts(octobus) :
        days = 7
        docs = []
        for i in range(days)[::-1]:
                if i==0:
                        lte = "now"
                        gte = "now-24h"
                else :
                        lte = "now-"+str(24*(i))+"h"
                        gte = "now-"+str(24*(i+1))+"h"

                params = {
                                "size":10000,
                                "sort": [{"@timestamp":{"order":"asc"}}],
                                "query" : {
                                        "bool":{
                                                "filter": [
                                                        { "term":  { "Cluster.keyword": str(CLUSTER)}},
                                                        { "range": {
                                                                "@timestamp": {
                                                                        "time_zone": "+05:30",
                                                                        "gte": gte,
                                                                        "lt": lte
                                                        }
                                                }
                                        }
                                ]
                        }
                        }
                }

                print(params)
                r = octobus.request(params)
                docs.extend(r)
                total = len(docs)
                print(total)
        return docs

def update_octobus_alerts(docs):
        for doc in docs :
                newEvents[str(doc['_source']['Problem ID'])] = {'status':str(doc['_source']['Status']),'host':str(doc['_source']['Host']),'_id':str(doc['_id'])}


def write_current_events(currEvents):
        with open(CURRENT_EVENTS_PATH+'Current_Events', 'w') as outFile:
                for event in currEvents.keys() :
                        outFile.write(str(event)+','+str(currEvents[event]['status'])+','+str(currEvents[event]['host'])+','+str(currEvents[event]['_id'])+'\n')

def get_zabbix_alerts(zabbix):
        # problems = zabbix.request({'method': 'problem.get', 'id': 3, 'params': {'output': "extend",'objectids': triggerIds }})

        problems = zabbix.request({'method': 'trigger.get', 'id': 3, 'params': {
                                                                                                                                                            'monitored':True ,
                                                                                                                                                            'skipDependent':False ,
                                                                                                                                                            'expandDescription': True,
                                                                                                                                                            'maintenance' : False,
                                                                                                                                                            'sortfield' : 'lastchange',
                                                                                                                                                            'sortorder' : 'DESC',
                                                                                                                                                            'selectLastEvent' : ['eventids','clock'],
                                                                                                                                                            'selectHosts':['name','hostid','host','maintenance_status'],
                                                                                                                                                            'selectGroups':['name','groupid'],
                                                                                                                                                            'output': ['triggerid', 'priority', 'description', 'value', 'lastchange'],
                                                                                                                                                            'filter':{'value':1, 'priority':[2,3,4,5],'status':0}
                                                                                                                                                            }})


        zabbixProblems = {}
        for problem in problems :
                zabbixProblems[str(problem['triggerid'])] = problem
        print "Current Problems Count is"
        print len(zabbixProblems.keys())

        return zabbixProblems

def compare_alerts(currEvents, zabbixProblems,octobus):

        severity_map = {'Zabbix_Severity':'Octobus_Severity',
                                        '1':'5',
                                        '2':'4',
                                        '3':'3',
                                        '4':'2',
                                        '5':'1'
                                        }


        missingAlertIds = list(set(zabbixProblems.keys())-set(currEvents.keys()))
        extraOctobusIds = list(set(currEvents.keys()) - set(zabbixProblems.keys()))
        commonIds = list(set(zabbixProblems) & set(currEvents))
        octobusFeed = {}
        inactiveIds = []
        print "Missing Alert Ids are"
        print(missingAlertIds)
        print "Extra Octobus Ids are"
        #print(extraOctobusIds)
        print len(extraOctobusIds)
        for alertid in missingAlertIds + commonIds:

                if alertid in commonIds :
                        if  str(severity_map[zabbixProblems[alertid]['priority']]) == str(currEvents[alertid]['status']):
                                continue
                problem = zabbixProblems[alertid]
                groupnames = ','.join([str(group['name']) for group in problem['groups']])

                postEvent(problem=str(problem['description']),
                          host = str(problem['hosts'][0]['host']),
                          severity = str(severity_map[zabbixProblems[alertid]['priority']]),
                          groups = groupnames,
                          problemId = str(problem['triggerid']),
                          status = str(severity_map[zabbixProblems[alertid]['priority']]),
                          eventId = str(problem['lastEvent']['eventid']),
                          eventTime = str(problem['lastEvent']['clock']),
                          octobus=octobus)

        if len(extraOctobusIds) != 0 :
                for alertid in extraOctobusIds:
                        inactiveIds.append(currEvents[alertid]['_id'])
                params = {
                                "size":1000,
                                "query": {
                                                "ids" :{
                                                        "values":inactiveIds
                                                        }
                                        }
                        }
                docs = octobus.request(params)
                for doc in docs:
                        postEvent(problem=str(doc['_source']['Problem Name'].encode('ascii', 'ignore')),
                                  host = str(doc['_source']['Host']),
                                severity = '0',
                                groups = str(doc['_source']['Group Names']),
                                problemId = str(doc['_source']['Problem ID']),
                                status = '0',
                                eventId = str(doc['_source']['Event ID']),
                                eventTime = str(doc['_source']['Event Time']),
                                octobus=octobus)




def postEvent(problem,host,severity,groups,problemId,status,eventId,eventTime,octobus):
        problemfeed = {
                "Problem Name": problem,
                "Host": host,
                "Severity" : severity,
                "Group Names": groups ,
                "Problem ID" : problemId,
                "Status":status,
                "Event ID": eventId,
                "Event Time" : eventTime,
                "Trigger State": "Update event from " + CLUSTER + " Zabbix Server",
                "Cluster" : CLUSTER
              }
        print problem
        res = octobus.request(problemfeed,post=True)
        print res


def main() :
        process = Process(CLEANUP_NAME)
        process.start()
        urllib3.disable_warnings()
        with Cache(CLEANUP_NAME) as cacheData:
                cache = cacheData.get()
                if cache.get('timestamp', None) == None:
                        cache['timestamp'] = CURRENT_TIME
                        cleanup = True
                elif ((cache.get('status', False) == False) or ((CURRENT_TIME - cache['timestamp']) > CLEANUP_DELAY_SECONDS)):
                        cleanup = True
                else :
                        cleanup = False
                if cleanup :
                        logger = None
                        session = None
                        currEvents = {}
                        newEvents = {}
                        lastAuditStamp = int(cache.get('lastAuditStamp'))
                        try :
                                copyfile(CURRENT_EVENTS_PATH+'Current_Events', CURRENT_EVENTS_PATH+'Current_Events_Copy')
                                logger = Logger(name=CLEANUP_NAME, log_in_file=ENABLE_LOG_IN_FILE, verbose=VERBOSE)
                                logger.log('%s,class=ZabbixAlertCleanup,status="execution starts"'%(CURRENT_TIME))
                                session = http_session()
                                currEvents = old_octobus_alerts()
                                print(len(currEvents.keys()))

                                with Zabbix(session=session) as zabbix, Octobus(session=session) as octobus :
                                        docs = new_octobus_alerts(octobus)

                                ########## Process all new Octobus events ##########
                                        for doc in docs :
                                                newEvents[str(doc['_source']['Problem ID'])] = {'status':str(doc['_source']['Status']),'host':str(doc['_source']['Host']),'_id':str(doc['_id'])}

                                        print('Count of new events is')
                                        print(len(newEvents))
                                        for event in newEvents.keys():
                                                currEvent = currEvents[event] if event in currEvents.keys() else {}
                                                newEvent = newEvents[event]

                                                if str(newEvent['status'])=='0' :
                                                        if currEvent :
                                                                del currEvents[event]
                                                else :
                                                        currEvents[event] = newEvents[event]

                                        write_current_events(currEvents)
                                        zabbixProblems = get_zabbix_alerts(zabbix)
                                        compare_alerts(currEvents, zabbixProblems,octobus)


                        except Exception as e:
                                cache['status'] = False
                                errlog = traceback.format_exc()
                                mail_notification(CLEANUP_NAME, errlog)
                                if logger:
                                        logger.log('%s,class=ZabbixAlertCleanup,status="execution Ends"'%(CURRENT_TIME))
                                        logger.log(errlog)
                                else :
                                        print(errlog)

                        finally :
                                cacheData.set(cache)

                        if session != None:
                                session.close()

                process.close()

if __name__ == '__main__':
        main()
