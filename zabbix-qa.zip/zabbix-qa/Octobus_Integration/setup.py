#!/usr/bin/python -W ignore::DeprecationWarning
# -*- coding: utf-8 -*-
#
import traceback
import re
import sys
from shutil import copyfile
from time import time
from requests.packages import urllib3
from common import Process, Logger, mail_notification,Zabbix, http_session,Cache, Octobus, CONFIG_FILE, CURRENT_EVENTS_PATH,CLUSTER
import ast
import json

CURRENT_TIME=int(time())
CLEANUP_NAME = 'ZabbixAlertCleanup'
CLEANUP_LIMIT = 20
CLEANUP_DELAY_SECONDS=18
ENABLE_LOG_IN_FILE = True
VERBOSE=True


def main() :
	
# Create Inventory file
	session = http_session()
        with Zabbix(session=session) as zabbix, Octobus(session=session) as octobus :
# Create Current Events file
		newEvents = {}
                params = {
				"size":1000,
                                "sort": [{"@timestamp":{"order":"asc"}}
                                ],
                                "query": {
					"bool": {
							"filter": [
									{ "term":  { "Cluster.keyword": str(CLUSTER)}},
                                                                        { "range": {
											"@timestamp": {
													"time_zone": "+05:30",
                                                                                                        "gte": "now-1h",
                                                                                                         "lt": "now"
                                                                                                          }
                                                                                     }
                                                                         }
                                                                    ]
                                                    }                                                                           }
                          }

                docs = octobus.request(params)
                total = len(docs)
                print(total)
		for doc in docs :
			newEvents[str(doc['_source']['Problem ID'])] = {'status':str(doc['_source']['Status']),'host':str(doc['_source']['Host']),'_id':str(doc['_id'])}
	
                with open(CURRENT_EVENTS_PATH+'Current_Events', 'w') as outFile:
			for event in newEvents.keys() :
				if newEvents[event]['status']!= '0':
					outFile.write(str(event)+','+str(newEvents[event]['status'])+','+str(newEvents[event]['host'])+','+str(newEvents[event]['_id'])+'\n')

		outFile.close()
		print('Current events file has been generated at '+CURRENT_EVENTS_PATH)
	

# Create cache file
		with open(CURRENT_EVENTS_PATH+'ZabbixAlertCleanup.cache', 'w') as outFile:
			outFile.write('{"status": true, "timestamp":'+str(CURRENT_TIME)+', "lastAuditStamp": "'+str(CURRENT_TIME)+'"}')
			print(outFile)
		outFile.close()
		print('Created cache file')
if __name__ == '__main__':
         main()

