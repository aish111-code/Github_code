# -*- coding: utf-8 -*-
#
import json
import os
import re
import sys
import ssl
import errno
import tempfile
import traceback
import platform
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from time import sleep, strptime, mktime, strftime
from datetime import tzinfo, timedelta, datetime
from requests import Session
from requests.adapters import HTTPAdapter
from requests.packages import urllib3
from requests.auth import HTTPBasicAuth
from requests.packages.urllib3.contrib import pyopenssl
from requests.packages.urllib3.poolmanager import PoolManager
from requests.packages.urllib3.packages.six.moves.urllib.parse import urlencode
from itertools import islice

PROCFS_PATH='/proc'

#CUSTOMENTRY
CONFIG_FILE = '/etc/zabbix/Octobus_Integration/Config_File'
ZABBIX_JSONRPC_VERSION='2.0'

for line in open(CONFIG_FILE).readlines():
    if 'ZabbixApi' in line:
        ZABBIX_URL = line.split("=")[1].strip("\n")
    elif 'OctobusApi' in line:
        OCTOBUS_URL = line.split("=")[1].strip("\n")
    elif 'CurrentEventsLocation' in line :
        CURRENT_EVENTS_PATH = line.split("=")[1].strip("\n")
    elif 'ZabbixAuthToken' in line :
        ZABBIX_TOKEN = line.split("=")[1].strip("\n")
    elif 'OctobusAuthToken' in line :
        OCT_TOKEN = line.split("=")[1].strip("\n")
    elif 'Cluster' in line :
        CLUSTER = line.split("=")[1].strip("\n")
    elif 'OctobusPostURL' in line :
        OCTOBUS_POST_URL = line.split("=")[1].strip("\n")
# Http Settings
HTTP_MAX_RETRIES = 3
HTTP_RETRY_SECONDS=10

###########################################################
# Zabbix                                                 #
###########################################################

class Zabbix(object):
    def __init__(self, session=None):
        self.session = session
#        self._params = {'jsonrpc': ZABBIX_JSONRPC_VERSION}

    def __enter__(self):
        return self

    def request(self, params):
        if not self.session:
            self.session = http_session()
        if 'jsonrpc' not in params.keys():
            params['jsonrpc'] = ZABBIX_JSONRPC_VERSION
        if 'auth'not in params.keys():
            params['auth'] = ZABBIX_TOKEN
        result = None
        retry = True
        retryCount = 0
        response = None
        try:
            while retry:
                retry = False
                response = self.session.post(ZABBIX_URL, data=json.dumps(params), allow_redirects=True)
                if response.status_code == 200:
                    resultJson = response.json()
                    if 'result' in resultJson.keys():
                        result = resultJson['result']
                    else:
                        if resultJson.has_key('error') and resultJson['error'].has_key('data') and resultJson['error']['data'] == 'Session terminated, re-login, please.':
                            params['auth'] = ZABBIX_TOKEN
                            retry = True
                            retryCount += 1
                            sleep(HTTP_RETRY_SECONDS)
                        else:
                            raise CustomException('Zabbix: %s' % (json.dumps(resultJson['error'])))
                else:
                    if response.status_code >= 500 and retryCount < HTTP_MAX_RETRIES:
                        retry = True
                        retryCount += 1
                        sleep(HTTP_RETRY_SECONDS)
                    else:
                        raise CustomException('Zabbix: code - %s, message - %s' % (response.status_code, response.text))
        finally:
            if response != None:
                response.close()
        return result

    def __exit__(self, type, value, traceback):
        if self.session != None:
            self.session.close()
            self.session = None


###########################################################
# Octobus                                                 #
###########################################################

class Octobus(object):
    def __init__(self, session=None):
        self.session = session

    def __enter__(self):
        return self

    def request(self,params,post=False):
        if not self.session:
            self.session = http_session()
        result = None
        retry = True
        retryCount = 0
        response = None
        try:
            while retry:
                retry = False
                if post==False:
                        self.session = update_session(self.session,{'Authorization':'ApiKey '+OCT_TOKEN})
                        response = self.session.get(OCTOBUS_URL, data = json.dumps(params),verify=False,allow_redirects=True)
                        result = response.json()['hits']['hits']
                if post==True:
                        response = self.session.post(OCTOBUS_POST_URL, data=json.dumps(params), verify=False, allow_redirects=True)
                        if response.status_code == 200:
                             print(response)
                #     if resultJson.has_key('hits'):
                #         result = resultJson['hits']['hits']
                #     else:
                #         if resultJson.has_key('error') and resultJson['error'].has_key('data') and resultJson['error']['data'] == 'Session terminated, re-login, please.':
                #             params['auth'] = self._generateAuthToken(cache, True)
                #             retry = True
                #         else:
                #             raise CustomException('Zabbix: %s' % (json.dumps(resultJson['error'])))
                # else:
                #     if response.status_code >= 500 and retryCount < HTTP_MAX_RETRIES:
                #         retry = True
                #         retryCount += 1
                #         sleep(HTTP_RETRY_SECONDS)
                #     else:
                #         raise CustomException('Zabbix: code - %s, message - %s' % (response.status_code, response.text))
        finally:
            if response != None:
                response.close()
        return result

    def __exit__(self, type, value, traceback):
        if self.session != None:
            self.session.close()
            self.session = None


###########################################################
# Process                                                 #
###########################################################
class Process(object):
    def __init__(self, name):
        self.pidfile = '%s%s%s.pid' % (tempfile.gettempdir(), os.sep, name)

    def getPidFile(self):
        return self.pidfile

    def getPid(self):
        pid = read_file(self.pidfile)
        return int(pid) if pid != '' and pid.isdigit() else 0

    def __pids__(self):
        return [int(x) for x in os.listdir(PROCFS_PATH if sys.version_info[0] == 3 else PROCFS_PATH.encode('latin-1')) if x.isdigit()]

    def __pid_exists__(self, pid):
        try:
            os.kill(pid, 0)
        except OSError as err:
            if err.errno == errno.ESRCH:
                return False
            elif err.errno == errno.EPERM:
                return True
            else:
                raise err
        else:
            return True

    def start(self):
        pid = self.getPid()
        if pid != 0 and self.pid_exists(pid):
            print("Process %s already running (%s)" % (pid, self.pidfile))
            sys.exit()
        write_file(self.pidfile, str(os.getpid()))

    def close(self):
        if os.path.isfile(self.pidfile):
            os.unlink(self.pidfile)

    def pid_exists(self, pid):
        if not self.__pid_exists__(pid):
            return False
        else:
            try:
                path = "%s/%s/status" % (PROCFS_PATH, pid)
                with open(path, 'rb') as f:
                    for line in f:
                        if line.startswith(b"Tgid:"):
                            tgid = int(line.split()[1])
                            return tgid == pid
                    raise ValueError("'Tgid' line not found in %s" % path)
            except (EnvironmentError, ValueError):
                return pid in self.__pids__()


###########################################################
# Utils                                                   #
###########################################################

# File mode settings
READ_MODE='r'
WRITE_MODE='w'
APPEND_MODE = 'a+'

# Mail Notification settings
MAIL_FROM = 'SAP SF SDO Tools and Utils<sapsfsdotoolsandutils@sap.com>'
MAIL_TO = ['vishwas.mohan01@sap.com','jibin.sunny@sap.com','ankeeta.anand.shet@sap.com','DL_62D50CAEB98ABB02996051B9@global.corp.sap']
MAIL_SUBJECT = 'Problem in sending events from %s to Octobus'
INVALID_FORMAT_MAIL_SUBJECT='Problem in %s Events - Unexpected format'

# Logger
class Logger(object):
    def __init__(self, name=None, log_in_file=False, verbose=True):
        if name != None:
#            self.logfile = '%s%s%s%s.log' % (os.path.dirname(os.path.abspath(__file__)), os.sep, name, strftime('%Y-%m-%d'))
            self.logfile = '%s%s%s%s.log' % (os.path.normpath(os.path.dirname(os.path.abspath(__file__))+ os.sep + os.pardir), os.sep+'logs'+os.sep,name, strftime('%Y-%m-%d'))
        else:
            self.logfile = None
        self.verbose = verbose
        self.log_in_file = log_in_file

    def log(self, message):
        if self.verbose:
            print(message)
        if self.logfile and self.log_in_file:
            try:
                with open(self.logfile, APPEND_MODE) as outFile:
                    outFile.write('%s\n' % message)
            except IOError as ioe:
                print(str(ioe))

class Cache(object):
    def __init__(self, lamName, name=None, defaultValue={}):
#        self.cachename = '%s%s%s%s.cache' % (os.path.dirname(os.path.abspath(__file__)), os.sep, lamName, name if name else '')
        self.cachename = '%s%s%s%s.cache' % (os.path.normpath(os.path.dirname(os.path.abspath(__file__))),os.sep,lamName, name if name else '')
        self.defaultValue = defaultValue
        content = read_file(self.cachename)
        self.cacheContent = json.loads(content) if content else self.defaultValue

    def __enter__(self):
        return self

    def get(self):
        if self.cacheContent:
            return self.cacheContent
        return self.defaultValue

    def set(self, content):
        self.cacheContent = content

    def __exit__(self, type, value, traceback):
        if not self.cacheContent:
            self.cacheContent = self.defaultValue
        write_file(self.cachename, json.dumps(self.cacheContent))


# handle tls connection
class TlsAdapter(HTTPAdapter):
    """"Transport adapter that forces TLS"""
    def get_max_tls_protocol(self):
        protocols = ('PROTOCOL_TLSv1_2', 'PROTOCOL_TLSv1_1', 'PROTOCOL_TLSv1')
        for proto in protocols:
            if hasattr(ssl, proto):
                proto_id = getattr(ssl, proto)
                if proto_id in pyopenssl._openssl_versions:
                    return proto_id
        return None

    def init_poolmanager(self, *pool_args, **pool_kwargs):
        self.poolmanager = PoolManager(*pool_args, ssl_version=self.get_max_tls_protocol(), **pool_kwargs)

# Custom exception
class CustomException(Exception):
    def __init__(self, value):
        self.parameter = value
    def __str__(self):
        return repr(self.parameter)

# Create http session
def http_session(headers=None, retry=HTTP_MAX_RETRIES):
    session = Session()
    session.mount('http://', HTTPAdapter(max_retries=retry))
    session.mount('https://', TlsAdapter(max_retries=retry))
    session.headers.update(headers if headers else {'Content-Type': 'application/json'})
    return session

def update_session(session,headers) :
    session.headers.update(headers if headers else {'Content-Type': 'application/json'})
    return session


def mail_notification(lamName, body, subject=MAIL_SUBJECT, fromAddress=MAIL_FROM, toAddress=MAIL_TO, includeHostname=True):
    cluster = CLUSTER
    msg = MIMEMultipart()
    msg['From'] = fromAddress
    msg['To'] = ','.join(toAddress)
    msg['Subject'] = cluster + (subject % lamName)
    msg.attach(MIMEText(body, 'plain'))
    mailServer = None
    try:
        mailServer = SMTP('localhost')
        mailServer.sendmail(fromAddress, toAddress, msg.as_string())
    except Exception as e:
        print(str(e))
    finally:
        if mailServer != None:
            mailServer.quit()

def read_file(filename):
    data = ''
    try:
        with open(filename, READ_MODE) as read_file:
            data = read_file.read()
    except IOError as ioe:
        if ioe.errno <> errno.ENOENT:
            print(str(ioe))
    return data

def write_file(filename, content):
    try:
        with open(filename, WRITE_MODE) as outFile:
            outFile.write(content)
    except IOError as ioe:
        print(str(ioe))
