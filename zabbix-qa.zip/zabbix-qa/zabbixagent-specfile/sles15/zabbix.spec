Name:		zabbix
Version:	5.0.19
Release:	%{?alphatag:0.}1.sap.el15%{?alphatag}%{?dist}
Summary:	The Enterprise-class open source monitoring solution
Group:		Applications/Internet
License:	GPLv2+
URL:		http://www.zabbix.com/
Source0:	%{name}-%{version}%{?alphatag}.tar.gz
Source1:	zabbix-web22.conf
Source2:	zabbix-web24.conf
Source3:	zabbix-logrotate.in
Source4:	zabbix-java-gateway.init
Source5:	zabbix-agent.init
Source6:	zabbix-server.init
Source7:	zabbix-proxy.init
Source10:	zabbix-agent.service
Source11:	zabbix-server.service
Source12:	zabbix-proxy.service
Source13:	zabbix-java-gateway.service
Source14:	zabbix_java_gateway-sysd
Source15:	zabbix-tmpfiles.conf
Source16:	zabbix-php-fpm.conf
Source17:	zabbix-nginx.conf
Source18:	zabbix-agent2.service
#*** modified for sap :start ***#
Source19:	gen_config.sh
Source20:	updatezbx
#*** modified for sap :end ***#
Patch0:		frontend.patch
Patch1:		fping3-sourceip-option.patch
Patch2:		conf.patch


Buildroot:	%{_tmppath}/zabbix-%{version}-%{release}-root-%(%{__id_u} -n)

%{!?build_agent: %global build_agent 1}

%if 0%{?sles} >= 15
%ifarch x86_64
%{!?build_agent2: %global build_agent2 1}
%endif
%endif

%{!?build_proxy: %global build_proxy 1}
%{!?build_java_gateway: %global build_java_gateway 1}
%{!?build_server: %global build_server 1}
%{!?build_frontend: %global build_frontend 1}

%{!?build_with_mysql: %global build_with_mysql 1}
%{!?build_with_pgsql: %global build_with_pgsql 1}
%{!?build_with_sqlite: %global build_with_sqlite 1}

%if 0%{?build_with_mysql} == 0 && 0%{?build_with_pgsql} == 0
%global build_server 0
%if 0%{?build_with_sqlite} == 0
%global build_proxy 0
%endif
%endif

BuildRequires:	make
BuildRequires:	mysql-devel
BuildRequires:	postgresql-devel
BuildRequires:	net-snmp-devel
BuildRequires:	openldap2-devel
BuildRequires:	gnutls-devel
BuildRequires:	sqlite-devel
BuildRequires:	unixODBC-devel
BuildRequires:	curl-devel >= 7.13.1
BuildRequires:	OpenIPMI-devel >= 2
%if 0%{?sles} >= 15
BuildRequires:	libssh-devel
%else
BuildRequires:	libssh2-devel
%endif
BuildRequires:	java-devel >= 1.6.0
BuildRequires:	libxml2-devel
BuildRequires:	pcre-devel
BuildRequires:	libevent-devel
%if 0%{?sles} > 15
BuildRequires:	openssl-devel >= 1.1.0
%else
BuildRequires:	openssl-devel >= 1.0.1
%endif
BuildRequires:	systemd

%description
Zabbix is the ultimate enterprise-level software designed for
real-time monitoring of millions of metrics collected from tens of
thousands of servers, virtual machines and network devices.

%package agent
Summary:		Zabbix Agent
Group:			Applications/Internet
Requires:		logrotate
Requires(pre):		/usr/sbin/useradd
Requires(post):		systemd
Requires(preun):	systemd
Requires(preun):	systemd
Obsoletes:		zabbix

%if 0%{?build_agent2} != 1
%description agent
Zabbix agent to be installed on monitored systems.

%else
%description agent
Old implementation of zabbix agent.
To be installed on monitored systems.

%package agent2
Summary:		New Zabbix Agent
Group:			Applications/Internet
Requires:		logrotate
Requires(post):		systemd
Requires(preun):	systemd
Requires(preun):	systemd
Obsoletes:		zabbix

%description agent2
New implementation of zabbix agent.
To be installed on monitored systems.
%endif

%package get
Summary:		Zabbix Get
Group:			Applications/Internet

%description get
Zabbix get command line utility.

%package sender
Summary:		Zabbix Sender
Group:			Applications/Internet

%description sender
Zabbix sender command line utility.

%package js
Summary:		Zabbix JS
Group:			Applications/Internet

%description js
Zabbix js command line utility.

%package proxy-mysql
Summary:		Zabbix proxy for MySQL or MariaDB database
Group:			Applications/Internet
Requires:		fping
Requires(post):		systemd
Requires(preun):	systemd
Requires(postun):	systemd
Provides:		zabbix-proxy = %{version}-%{release}
Provides:		zabbix-proxy-implementation = %{version}-%{release}
Obsoletes:		zabbix
Obsoletes:		zabbix-proxy

%description proxy-mysql
Zabbix proxy with MySQL or MariaDB database support.

%package proxy-pgsql
Summary:		Zabbix proxy for PostgreSQL database
Group:			Applications/Internet
Requires:		fping
Requires(post):		systemd
Requires(preun):	systemd
Requires(postun):	systemd
Provides:		zabbix-proxy = %{version}-%{release}
Provides:		zabbix-proxy-implementation = %{version}-%{release}
Obsoletes:		zabbix
Obsoletes:		zabbix-proxy

%description proxy-pgsql
Zabbix proxy with PostgreSQL database support.

%package proxy-sqlite3
Summary:		Zabbix proxy for SQLite3 database
Group:			Applications/Internet
Requires:		fping
Requires(post):		systemd
Requires(preun):	systemd
Requires(postun):	systemd
Provides:		zabbix-proxy = %{version}-%{release}
Provides:		zabbix-proxy-implementation = %{version}-%{release}
Obsoletes:		zabbix
Obsoletes:		zabbix-proxy

%description proxy-sqlite3
Zabbix proxy with SQLite3 database support.

%package java-gateway
Summary:		Zabbix java gateway
Group:			Applications/Internet
Requires:		java >= 1.6.0
Requires(post):		systemd
Requires(preun):	systemd
Requires(postun):	systemd
Obsoletes:			zabbix

%description java-gateway
Zabbix java gateway

%if 0%{?build_server}
%package server-mysql
Summary:		Zabbix server for MySQL or MariaDB database
Group:			Applications/Internet
Requires:		fping
Requires(post):		systemd
Requires(preun):	systemd
Requires(postun):	systemd
Provides:		zabbix-server = %{version}-%{release}
Provides:		zabbix-server-implementation = %{version}-%{release}
Obsoletes:		zabbix
Obsoletes:		zabbix-server

%description server-mysql
Zabbix server with MySQL or MariaDB database support.

%package server-pgsql
Summary:		Zabbix server for PostgresSQL database
Group:			Applications/Internet
Requires:		fping
Requires(post):		systemd
Requires(preun):	systemd
Requires(postun):	systemd
Provides:		zabbix-server = %{version}-%{release}
Provides:		zabbix-server-implementation = %{version}-%{release}
Obsoletes:		zabbix
Obsoletes:		zabbix-server
%description server-pgsql
Zabbix server with PostgresSQL database support.

%package web
Summary:		Zabbix web frontend common package
Group:			Application/Internet
BuildArch:		noarch
Requires:		dejavu-fonts
Requires(post):		%{_sbindir}/update-alternatives
Requires(preun):	%{_sbindir}/update-alternatives
Suggests:		zabbix-web-deps
Suggests:		zabbix-apache-conf
Suggests:		zabbix-nginx-conf

%description web
Zabbix web frontend common package

%package web-deps
Summary:		PHP dependencies metapackage for frontend
Group:			Application/Internet
BuildArch:		noarch
%if 0%{?sles} >= 15
Requires:		php7-sockets
Requires:		php7-gettext
Requires:		php7-gd
Requires:		php7-bcmath
Requires:		php7-mbstring
Requires:		php7-ldap
Requires:		php7-zlib
%else
Requires:		php72-sockets
Requires:		php72-gettext
Requires:		php72-gd
Requires:		php72-bcmath
Requires:		php72-mbstring
Requires:		php72-ldap
Requires:		php72-zlib
%endif
Requires:		zabbix-web = %{version}-%{release}
Requires:		zabbix-web-database = %{version}-%{release}

%description web-deps
PHP dependencies metapackage for frontend

%package web-mysql
Summary:		Zabbix web frontend for MySQL
Group:			Applications/Internet
BuildArch:		noarch
Requires:		php-mysql
Requires:		zabbix-web = %{version}-%{release}
Requires:		zabbix-web-deps = %{version}-%{release}
Provides:		zabbix-web-database = %{version}-%{release}

%description web-mysql
Zabbix web frontend for MySQL

%package web-pgsql
Summary:		Zabbix web frontend for PostgreSQL
Group:			Applications/Internet
BuildArch:		noarch
Requires:		php-pgsql
Requires:		zabbix-web = %{version}-%{release}
Requires:		zabbix-web-deps = %{version}-%{release}
Provides:		zabbix-web-database = %{version}-%{release}

%description web-pgsql
Zabbix web frontend for PostgreSQL

%package apache-conf
Summary:		Automatic zabbix frontend configuration with apache
Group:			Applications/Internet
BuildArch:		noarch
Requires:		zabbix-web-deps = %{version}-%{release}
Requires:		apache2
%if 0%{?sles} >= 15
Requires:		apache2-mod_php7 >= 7.2
%else
Requires:		apache2-mod_php72
%endif

%description apache-conf
Automatic zabbix frontend configuration with apache

%package nginx-conf
Summary:		Automatic zabbix frontend configuration with nginx
Group:			Applications/Internet
BuildArch:		noarch
Requires:		zabbix-web-deps = %{version}-%{release}
Requires:		nginx
Requires:		php-fpm >= 7.2

%description nginx-conf
Automatic zabbix frontend configuration with nginx

%package web-japanese
Summary:		Japanese font settings for frontend
Group:			Applications/Internet
BuildArch:		noarch
Requires:		ipa-pgothic-fonts
Requires:		zabbix-web = %{version}-%{release}
Requires(post):		%{_sbindir}/update-alternatives
Requires(preun):	%{_sbindir}/update-alternatives

%description web-japanese
Japanese font configuration for Zabbix web frontend
%endif

%prep
%setup0 -q -n %{name}-%{version}%{?alphatag}

%if 0%{?build_frontend}
%patch0 -p1

## remove font file
rm -f ui/assets/fonts/DejaVuSans.ttf

# replace font in defines.inc.php
sed -i -r "s/(define\(.*_FONT_NAME.*)DejaVuSans/\1graphfont/" \
	ui/include/defines.inc.php

# remove .htaccess files
rm -f ui/app/.htaccess
rm -f ui/conf/.htaccess
rm -f ui/include/.htaccess
rm -f ui/local/.htaccess

# remove translation source files and scripts
find ui/locale -name '*.po' | xargs rm -f
find ui/locale -name '*.sh' | xargs rm -f
%endif

%if 0%{?build_server} || 0%{?build_proxy} || 0%{?build_agent} || 0%{?build_agent2}
%patch1 -p1
%endif

%if 0%{?build_server} || 0%{?build_proxy}
# traceroute command path for global script
sed -i -e 's|/usr/bin/traceroute|/bin/traceroute|' database/mysql/data.sql
sed -i -e 's|/usr/bin/traceroute|/bin/traceroute|' database/postgresql/data.sql
sed -i -e 's|/usr/bin/traceroute|/bin/traceroute|' database/sqlite3/data.sql
%endif

%if 0%{?build_server}
# copy sql files for servers
cat database/mysql/schema.sql > database/mysql/create.sql
cat database/mysql/images.sql >> database/mysql/create.sql
cat database/mysql/data.sql >> database/mysql/create.sql
gzip database/mysql/create.sql

cat database/postgresql/schema.sql > database/postgresql/create.sql
cat database/postgresql/images.sql >> database/postgresql/create.sql
cat database/postgresql/data.sql >> database/postgresql/create.sql
gzip database/postgresql/create.sql
gzip database/postgresql/timescaledb.sql
%endif

%if 0%{?build_proxy}
# sql files for proxyes
gzip database/mysql/schema.sql
gzip database/postgresql/schema.sql
gzip database/sqlite3/schema.sql
%endif

%if 0%{?build_java_gateway}
# change log directory for Java Gateway
sed -i -e 's|/tmp/zabbix_java.log|/var/log/zabbix/zabbix_java_gateway.log|g' src/zabbix_java/lib/logback.xml
%endif

# update config files
%patch2 -p1


# Build consists of 1-3 configure/make passes, one for each database.
# pass 1: is sqlite proxy, may be omitted.
# pass 2: is pqsql server/proxy, may be omitted.
# pass 3: If only one database is enabled, then it must occur with pass 3.

%build
build_conf_common="
	--enable-dependency-tracking
	--sysconfdir=/etc/zabbix
	--libdir=%{_libdir}/zabbix
	--enable-ipv6
	--with-net-snmp
	--with-ldap
	--with-libcurl
	--with-openipmi
	--with-unixodbc
%if 0%{?sles} >= 15
	--with-ssh
%else
	--with-ssh2
%endif
	--with-libxml2
	--with-libevent
	--with-libpcre
	--with-openssl
"

# setup pass 3
%if 0%{?build_with_mysql} && ( 0%{?build_server} || 0%{?build_proxy} )
build_conf_3="
%if 0%{?build_server}
	--enable-server
%endif
%if 0%{?build_proxy}
	--enable-proxy
%endif
	--with-mysql
"

build_db_3=mysql
%endif


# setup pass 2
%if 0%{?build_with_pgsql} && ( 0%{?build_server} || 0%{?build_proxy} )
build_conf_2="
%if 0%{?build_server}
	--enable-server
%endif
%if 0%{?build_proxy}
	--enable-proxy
%endif
	--with-postgresql
"

if [ -z "$build_conf_3" ]; then
	build_conf_3="$build_conf_2"
	build_conf_2=""
	build_db_3="pgsql"
fi
%endif


# setup pass 1
%if 0%{?build_with_sqlite} && 0%{?build_proxy}
build_conf_1="--enable-proxy --with-sqlite3"

if [ -z "$build_conf_3" ]; then
	build_conf_3="$build_conf_1"
	build_conf_1=""
	build_db_3=sqlite3
fi
%endif


# add agents and java-gateway to pass 3
build_conf_3="
%if 0%{?build_agent}
	--enable-agent
%endif
%if 0%{?build_agent2}
	--enable-agent2
%endif
%if 0%{?build_java_gateway}
	--enable-java
%endif
	$build_conf_3
"


# pass 1
if [ -n "$build_conf_1" ]; then
	%configure $build_conf_common $build_conf_1
	make $make_flags
	mv src/zabbix_proxy/zabbix_proxy src/zabbix_proxy/zabbix_proxy_sqlite3
fi


# pass 2
if [ -n "$build_conf_2" ]; then
	%configure $build_conf_common $build_conf_2
	make $make_flags
%if 0%{?build_server}
	mv src/zabbix_server/zabbix_server src/zabbix_server/zabbix_server_pgsql
%endif
%if 0%{?build_proxy}
	mv src/zabbix_proxy/zabbix_proxy src/zabbix_proxy/zabbix_proxy_pgsql
%endif
fi


# pass 3
if [ -n "$build_conf_3" ]; then
	%configure $build_conf_common $build_conf_3
	make $make_flags
%if 0%{?build_server}
	mv src/zabbix_server/zabbix_server "src/zabbix_server/zabbix_server_$build_db_3"
%endif
%if 0%{?build_proxy}
	mv src/zabbix_proxy/zabbix_proxy "src/zabbix_proxy/zabbix_proxy_$build_db_3"
%endif
fi


#
# install
#

%install

rm -rf $RPM_BUILD_ROOT
mkdir -p $RPM_BUILD_ROOT%{_localstatedir}/log/zabbix
mkdir -p $RPM_BUILD_ROOT%{_localstatedir}/run/zabbix
mkdir -p $RPM_BUILD_ROOT%{_sysconfdir}/logrotate.d

%if 0%{?sles} >= 15
make DESTDIR=$RPM_BUILD_ROOT GOBIN=$RPM_BUILD_ROOT%{_sbindir} install
%else
make DESTDIR=$RPM_BUILD_ROOT install
%endif


%if 0%{?build_agent}
mv $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_agentd.conf.d $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_agentd.d
install -dm 755 $RPM_BUILD_ROOT%{_docdir}/zabbix-agent-%{version}
cat %{SOURCE3} | sed \
	-e 's|COMPONENT|agentd|g' \
	> $RPM_BUILD_ROOT%{_sysconfdir}/logrotate.d/zabbix-agent
install -Dm 0644 -p %{SOURCE10} $RPM_BUILD_ROOT%{_unitdir}/zabbix-agent.service
install -Dm 0644 -p %{SOURCE15} $RPM_BUILD_ROOT%{_prefix}/lib/tmpfiles.d/zabbix-agent.conf
#*** modified for sap :start ***#
install -Dm 0755 -p %{SOURCE19} $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/gen_config.sh
install -Dm 0755 -p %{SOURCE20} $RPM_BUILD_ROOT%{_sbindir}/updatezbx
#*** modified for sap :end ***#
%endif


%if 0%{?build_agent2}
mkdir $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_agent2.d
cp man/zabbix_agent2.man $RPM_BUILD_ROOT%{_mandir}/man8/zabbix_agent2.8
cat %{SOURCE3} | sed \
	-e 's|COMPONENT|agent2|g' \
	> $RPM_BUILD_ROOT%{_sysconfdir}/logrotate.d/zabbix-agent2
install -Dm 0644 -p %{SOURCE18} $RPM_BUILD_ROOT%{_unitdir}/zabbix-agent2.service
install -Dm 0644 -p %{SOURCE15} $RPM_BUILD_ROOT%{_prefix}/lib/tmpfiles.d/zabbix_agent2.conf
%endif


%if 0%{?build_server} || 0%{?build_proxy}
mkdir -p $RPM_BUILD_ROOT/usr/lib/zabbix
mv $RPM_BUILD_ROOT%{_datadir}/zabbix/externalscripts $RPM_BUILD_ROOT/usr/lib/zabbix
%endif


%if 0%{?build_proxy}
install -m 0755 -p src/zabbix_proxy/zabbix_proxy_* $RPM_BUILD_ROOT%{_sbindir}/
rm $RPM_BUILD_ROOT%{_sbindir}/zabbix_proxy
mv $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_proxy.conf.d $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_proxy.d
cat %{SOURCE3} | sed \
	-e 's|COMPONENT|proxy|g' \
	> $RPM_BUILD_ROOT%{_sysconfdir}/logrotate.d/zabbix-proxy
install -Dm 0644 -p %{SOURCE12} $RPM_BUILD_ROOT%{_unitdir}/zabbix-proxy.service
install -Dm 0644 -p %{SOURCE15} $RPM_BUILD_ROOT%{_prefix}/lib/tmpfiles.d/zabbix-proxy.conf
%endif


%if 0%{?build_server}
install -m 0755 -p src/zabbix_server/zabbix_server_* $RPM_BUILD_ROOT%{_sbindir}/
rm $RPM_BUILD_ROOT%{_sbindir}/zabbix_server
mv $RPM_BUILD_ROOT%{_datadir}/zabbix/alertscripts $RPM_BUILD_ROOT/usr/lib/zabbix
mv $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_server.conf.d $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_server.d
cat %{SOURCE3} | sed \
	-e 's|COMPONENT|server|g' \
	> $RPM_BUILD_ROOT%{_sysconfdir}/logrotate.d/zabbix-server
install -Dm 0644 -p %{SOURCE11} $RPM_BUILD_ROOT%{_unitdir}/zabbix-server.service
install -Dm 0644 -p %{SOURCE15} $RPM_BUILD_ROOT%{_prefix}/lib/tmpfiles.d/zabbix-server.conf
%endif


%if 0%{?build_frontend}
# install frontend files
find ui -name '*.orig' | xargs rm -f
cp -a ui/* $RPM_BUILD_ROOT%{_datadir}/zabbix

# install frontend configuration files
mkdir -p $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/web
touch $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/web/zabbix.conf.php
mv $RPM_BUILD_ROOT%{_datadir}/zabbix/conf/maintenance.inc.php $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/web/

# drop config files in place
install -Dm 0644 -p %{SOURCE2} $RPM_BUILD_ROOT%{_sysconfdir}/apache2/conf.d/zabbix.conf
install -Dm 0644 -p %{SOURCE16} $RPM_BUILD_ROOT%{_sysconfdir}/php7/fpm/php-fpm.d/zabbix.conf
install -Dm 0644 -p %{SOURCE17} $RPM_BUILD_ROOT%{_sysconfdir}/nginx/conf.d/zabbix.conf
%endif


%if 0%{?build_java_gateway}
rm $RPM_BUILD_ROOT%{_sbindir}/zabbix_java/settings.sh
rm $RPM_BUILD_ROOT%{_sbindir}/zabbix_java/startup.sh
rm $RPM_BUILD_ROOT%{_sbindir}/zabbix_java/shutdown.sh
mkdir -p $RPM_BUILD_ROOT%{_sysconfdir}/zabbix
mv $RPM_BUILD_ROOT%{_sbindir}/zabbix_java/lib/logback.xml $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_java_gateway_logback.xml
rm $RPM_BUILD_ROOT%{_sbindir}/zabbix_java/lib/logback-console.xml
mkdir -p $RPM_BUILD_ROOT%{_datadir}
mv $RPM_BUILD_ROOT%{_sbindir}/zabbix_java $RPM_BUILD_ROOT%{_datadir}/zabbix-java-gateway
install -m 0755 -p %{SOURCE14} $RPM_BUILD_ROOT%{_sbindir}/zabbix_java_gateway
cat src/zabbix_java/settings.sh | sed \
	-e 's|^PID_FILE=.*|PID_FILE="/var/run/zabbix/zabbix_java.pid"|g' \
	> $RPM_BUILD_ROOT%{_sysconfdir}/zabbix/zabbix_java_gateway.conf
install -Dm 0644 -p %{SOURCE13} $RPM_BUILD_ROOT%{_unitdir}/zabbix-java-gateway.service
install -Dm 0644 -p %{SOURCE15} $RPM_BUILD_ROOT%{_prefix}/lib/tmpfiles.d/zabbix-java-gateway.conf
%endif


%clean
rm -rf $RPM_BUILD_ROOT


#
# files and scriptlets
#

%if 0%{?build_agent}
%files agent
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README conf/zabbix_agentd/userparameter_mysql.conf
%config(noreplace) %{_sysconfdir}/zabbix/zabbix_agentd.conf
%config(noreplace) %{_sysconfdir}/logrotate.d/zabbix-agent
%dir %{_sysconfdir}/zabbix/zabbix_agentd.d
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_sbindir}/zabbix_agentd
%{_mandir}/man8/zabbix_agentd.8*
%{_unitdir}/zabbix-agent.service
%{_prefix}/lib/tmpfiles.d/zabbix-agent.conf
#*** modified for sap :start ***#
%{_sbindir}/updatezbx
%{_sysconfdir}/zabbix/gen_config.sh
#*** modified for sap :end ***#
%files get
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%{_bindir}/zabbix_get
%{_mandir}/man1/zabbix_get.1*

%files sender
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%{_bindir}/zabbix_sender
%{_mandir}/man1/zabbix_sender.1*

%pre agent
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:
#*** modified for sap :start ***#
if [ -e /etc/zabbix/zabbix_agentd.conf.d ] ; then rm -rf /etc/zabbix/zabbix_agentd.conf.d ; fi
if [ -e /etc/zabbix/zabbix_agentd_custom_scripts ] ; then rm -rf /etc/zabbix/zabbix_agentd_custom_scripts ; fi

#stop previous agent and clean up pidfile
if [ `ps -ef|grep zabbix-agentd|wc -l` -gt 1 ]; then killall -9 zabbix-agentd;fi
if [ `ps -ef|grep zabbix_agentd|wc -l` -gt 1 ]; then killall -9 zabbix_agentd;fi
if [ -f /var/run/zabbix/zabbix-agentd.pid ]; then rm /var/run/zabbix/zabbix-agentd.pid;fi
if [ -f /var/run/zabbix/zabbix_agentd.pid ]; then rm /var/run/zabbix/zabbix_agentd.pid;fi
#*** modified for sap :end ***#

%post agent
%systemd_post zabbix-agent.service
:
#*** modified for sap :start ***#
/etc/zabbix/gen_config.sh
chown zabbix:zabbix /etc/zabbix/zabbix_agent*.conf
chmod 0640 /etc/zabbix/zabbix_agent*.conf
mkdir -p /etc/zabbix/zabbix_agentd_custom_scripts
mkdir -p /etc/zabbix/zabbix_agentd.conf.d
rmdir /etc/zabbix/zabbix_agentd.d
chown zabbix:zabbix /etc/zabbix
chown zabbix:zabbix /etc/zabbix/zabbix_agentd.conf.d
chown zabbix:zabbix /etc/zabbix/zabbix_agentd_custom_scripts
chmod 755 /etc/zabbix/zabbix_agentd.conf.d
chmod 755 /etc/zabbix/zabbix_agentd_custom_scripts
/usr/sbin/updatezbx

if [ `crontab -l 2>/dev/null |grep "/usr/sbin/updatezbx"|wc -l` -lt 1 ] ;
    then
        line="$(( ( RANDOM %% 50 ) + 1 )) 04 * * * /usr/sbin/updatezbx"
        (crontab -l; echo "$line" ) | crontab -
        else
    crontab -l|grep -v /usr/sbin/updatezbx | crontab -
    line="$(( ( RANDOM %% 50 ) + 1 )) 04 * * * /usr/sbin/updatezbx"
    (crontab -l; echo "$line" ) | crontab -
fi
systemctl enable zabbix-agent
systemctl restart zabbix-agent
#*** modified for sap :end ***#

%preun agent
if [ "$1" = 0 ]; then
%systemd_preun zabbix-agent.service
fi
:

%postun agent
%systemd_postun_with_restart zabbix-agent.service
:

%posttrans agent
# preserve old userparameter_mysql.conf file during upgrade
if [ -f %{_sysconfdir}/zabbix/zabbix_agentd.d/userparameter_mysql.conf.rpmsave ] && [ ! -f %{_sysconfdir}/zabbix/zabbix_agentd.d/userparameter_mysql.conf ]; then
       cp -vn %{_sysconfdir}/zabbix/zabbix_agentd.d/userparameter_mysql.conf.rpmsave %{_sysconfdir}/zabbix/zabbix_agentd.d/userparameter_mysql.conf
fi
:
%endif


%if 0%{?build_agent2}
%files agent2
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%config(noreplace) %{_sysconfdir}/zabbix/zabbix_agent2.conf
%config(noreplace) %{_sysconfdir}/logrotate.d/zabbix-agent2
%dir %{_sysconfdir}/zabbix/zabbix_agent2.d
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_sbindir}/zabbix_agent2
%{_mandir}/man8/zabbix_agent2.8*
%{_unitdir}/zabbix-agent2.service
%{_prefix}/lib/tmpfiles.d/zabbix_agent2.conf

%pre agent2
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:

%post agent2
%systemd_post zabbix-agent2.service
# make sure that agent2 log file is create with proper attributes (ZBX-18243)
if [ $1 == 1 ] && [ ! -f %{_localstatedir}/log/zabbix/zabbix_agent2.log ]; then
	touch %{_localstatedir}/log/zabbix/zabbix_agent2.log
	chown zabbix:zabbix %{_localstatedir}/log/zabbix/zabbix_agent2.log
fi
:

%preun agent2
%systemd_preun zabbix-agent2.service
:

%postun agent2
%systemd_postun_with_restart zabbix-agent2.service
%endif


%if 0%{?build_server} || 0%{?build_proxy}
%files js
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%{_bindir}/zabbix_js
%endif


%if 0%{?build_proxy}
%if 0%{?build_with_mysql}
%files proxy-mysql
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%doc database/mysql/schema.sql.gz
%attr(0640,root,zabbix) %config(noreplace) %{_sysconfdir}/zabbix/zabbix_proxy.conf
%dir /usr/lib/zabbix/externalscripts
%config(noreplace) %{_sysconfdir}/logrotate.d/zabbix-proxy
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_mandir}/man8/zabbix_proxy.8*
%{_unitdir}/zabbix-proxy.service
%{_prefix}/lib/tmpfiles.d/zabbix-proxy.conf
%{_sbindir}/zabbix_proxy_mysql

%pre proxy-mysql
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:

%post proxy-mysql
%systemd_post zabbix-proxy.service
/usr/sbin/update-alternatives --install %{_sbindir}/zabbix_proxy \
	zabbix-proxy %{_sbindir}/zabbix_proxy_mysql 10
:

%preun proxy-mysql
if [ "$1" = 0 ]; then
%systemd_preun zabbix-proxy.service
/usr/sbin/update-alternatives --remove zabbix-proxy \
%{_sbindir}/zabbix_proxy_mysql
fi
:

%postun proxy-mysql
%systemd_postun_with_restart zabbix-proxy.service
:
%endif


%if 0%{?build_with_pgsql}
%files proxy-pgsql
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%doc database/postgresql/schema.sql.gz
%attr(0600,root,zabbix) %config(noreplace) %{_sysconfdir}/zabbix/zabbix_proxy.conf
%dir /usr/lib/zabbix/externalscripts
%config(noreplace) %{_sysconfdir}/logrotate.d/zabbix-proxy
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_mandir}/man8/zabbix_proxy.8*
%{_unitdir}/zabbix-proxy.service
%{_prefix}/lib/tmpfiles.d/zabbix-proxy.conf
%{_sbindir}/zabbix_proxy_pgsql

%pre proxy-pgsql
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:

%post proxy-pgsql
%systemd_post zabbix-proxy.service
/usr/sbin/update-alternatives --install %{_sbindir}/zabbix_proxy \
	zabbix-proxy %{_sbindir}/zabbix_proxy_pgsql 10
:

%preun proxy-pgsql
if [ "$1" = 0 ]; then
%systemd_preun zabbix-proxy.service
/usr/sbin/update-alternatives --remove zabbix-proxy \
	%{_sbindir}/zabbix_proxy_pgsql
fi
:

%postun proxy-pgsql
%systemd_postun_with_restart zabbix-proxy.service
:
%endif


%if 0%{?build_with_sqlite}
%files proxy-sqlite3
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%doc database/sqlite3/schema.sql.gz
%attr(0600,root,zabbix) %config(noreplace) %{_sysconfdir}/zabbix/zabbix_proxy.conf
%dir /usr/lib/zabbix/externalscripts
%config(noreplace) %{_sysconfdir}/logrotate.d/zabbix-proxy
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_mandir}/man8/zabbix_proxy.8*
%{_unitdir}/zabbix-proxy.service
%{_prefix}/lib/tmpfiles.d/zabbix-proxy.conf
%{_sbindir}/zabbix_proxy_sqlite3

%pre proxy-sqlite3
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:

%post proxy-sqlite3
%systemd_post zabbix-proxy.service
/usr/sbin/update-alternatives --install %{_sbindir}/zabbix_proxy \
	zabbix-proxy %{_sbindir}/zabbix_proxy_sqlite3 10
:

%preun proxy-sqlite3
if [ "$1" = 0 ]; then
%systemd_preun zabbix-proxy.service
/usr/sbin/update-alternatives --remove zabbix-proxy \
	%{_sbindir}/zabbix_proxy_sqlite3
fi
:

%postun proxy-sqlite3
%systemd_postun_with_restart zabbix-proxy.service
:
%endif
%endif


%if 0%{?build_server}
%if 0%{?build_with_mysql}
%files server-mysql
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%doc database/mysql/create.sql.gz
%doc database/mysql/double.sql
%attr(0600,root,zabbix) %config(noreplace) %{_sysconfdir}/zabbix/zabbix_server.conf
%dir /usr/lib/zabbix/alertscripts
%dir /usr/lib/zabbix/externalscripts
%config(noreplace) %{_sysconfdir}/logrotate.d/zabbix-server
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_mandir}/man8/zabbix_server.8*
%{_unitdir}/zabbix-server.service
%{_prefix}/lib/tmpfiles.d/zabbix-server.conf
%{_sbindir}/zabbix_server_mysql

%pre server-mysql
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:

%post server-mysql
%systemd_post zabbix-server.service
/usr/sbin/update-alternatives --install %{_sbindir}/zabbix_server \
	zabbix-server %{_sbindir}/zabbix_server_mysql 10
:

%preun server-mysql
if [ "$1" = 0 ]; then
%systemd_preun zabbix-server.service
/usr/sbin/update-alternatives --remove zabbix-server \
	%{_sbindir}/zabbix_server_mysql
fi
:

%postun server-mysql
%systemd_postun_with_restart zabbix-server.service
:
%endif


%if 0%{?build_with_pgsql}
%files server-pgsql
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%doc database/postgresql/create.sql.gz
%doc database/postgresql/double.sql
%doc database/postgresql/timescaledb.sql.gz
%attr(0600,root,zabbix) %config(noreplace) %{_sysconfdir}/zabbix/zabbix_server.conf
%dir /usr/lib/zabbix/alertscripts
%dir /usr/lib/zabbix/externalscripts
%config(noreplace) %{_sysconfdir}/logrotate.d/zabbix-server
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_mandir}/man8/zabbix_server.8*
%{_unitdir}/zabbix-server.service
%{_prefix}/lib/tmpfiles.d/zabbix-server.conf
%{_sbindir}/zabbix_server_pgsql

%pre server-pgsql
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:

%post server-pgsql
%systemd_post zabbix-server.service
/usr/sbin/update-alternatives --install %{_sbindir}/zabbix_server \
	zabbix-server %{_sbindir}/zabbix_server_pgsql 10
:

%preun server-pgsql
if [ "$1" = 0 ]; then
%systemd_preun zabbix-server.service
/usr/sbin/update-alternatives --remove zabbix-server \
	%{_sbindir}/zabbix_server_pgsql
fi
:

%postun server-pgsql
%systemd_postun_with_restart zabbix-server.service
:
%endif
%endif


%if 0%{?build_frontend}
%files web
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%dir %attr(0750,wwwrun,www) %{_sysconfdir}/zabbix/web
%ghost %attr(0644,wwwrun,www) %config(noreplace) %{_sysconfdir}/zabbix/web/zabbix.conf.php
%config(noreplace) %{_sysconfdir}/zabbix/web/maintenance.inc.php
%{_datadir}/zabbix

%files web-deps
%defattr(-,root,root,-)

%files web-mysql
%defattr(-,root,root,-)

%files web-pgsql
%defattr(-,root,root,-)

%files web-japanese
%defattr(-,root,root,-)

%files apache-conf
%doc AUTHORS ChangeLog COPYING NEWS README
%config(noreplace) %{_sysconfdir}/apache2/conf.d/zabbix.conf

%files nginx-conf
%doc AUTHORS ChangeLog COPYING NEWS README
%config(noreplace) %{_sysconfdir}/nginx/conf.d/zabbix.conf
%config(noreplace) %{_sysconfdir}/php7/fpm/php-fpm.d/zabbix.conf

%post web
# The fonts directory was moved into assets subdirectory at one point.
#
# This broke invocation of update-alternatives command below, because the target link for zabbix-web-font changed
# from zabbix/fonts/graphfont.ttf to zabbix/assets/fonts/graphfont.ttf
#
# We handle this movement by deleting /var/lib/alternatives/zabbix-web-font file if it contains the old target link.
# We also remove symlink at zabbix/fonts/graphfont.ttf to have the old fonts directory be deleted during update.
if [ -f /var/lib/alternatives/zabbix-web-font ] && \
	[ -z "$(grep %{_datadir}/zabbix/assets/fonts/graphfont.ttf /var/lib/alternatives/zabbix-web-font)" ]
then
	rm /var/lib/alternatives/zabbix-web-font
	if [ -h %{_datadir}/zabbix/fonts/graphfont.ttf ]; then
		rm %{_datadir}/zabbix/fonts/graphfont.ttf
	fi
fi
/usr/sbin/update-alternatives --install %{_datadir}/zabbix/assets/fonts/graphfont.ttf \
	zabbix-web-font %{_datadir}/fonts/truetype/DejaVuSans.ttf 10
:

%post web-japanese
/usr/sbin/update-alternatives --install %{_datadir}/zabbix/assets/fonts/graphfont.ttf \
	zabbix-web-font %{_datadir}/fonts/truetype/ipagp.ttf 20
:

%post apache-conf
if [ -d /etc/zabbix/web ]; then
	chown wwwrun:www /etc/zabbix/web
fi
if [ $1 == 1 ]; then
	a2enmod php7
fi
:

%post nginx-conf
if [ -d /etc/zabbix/web ]; then
	chown wwwrun:www /etc/zabbix/web
fi
:

%preun web
if [ "$1" = 0 ]; then
/usr/sbin/update-alternatives --remove zabbix-web-font \
	%{_datadir}/fonts/truetype/DejaVuSans.ttf
fi
:

%preun web-japanese
if [ "$1" = 0 ]; then
/usr/sbin/update-alternatives --remove zabbix-web-font \
	%{_datadir}/fonts/truetype/ipagp.ttf
fi
:
%endif


%if 0%{?build_java_gateway}
%files java-gateway
%defattr(-,root,root,-)
%doc AUTHORS ChangeLog COPYING NEWS README
%config(noreplace) %{_sysconfdir}/zabbix/zabbix_java_gateway.conf
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/log/zabbix
%attr(0755,zabbix,zabbix) %dir %{_localstatedir}/run/zabbix
%{_datadir}/zabbix-java-gateway
%{_sbindir}/zabbix_java_gateway
%{_unitdir}/zabbix-java-gateway.service
%{_prefix}/lib/tmpfiles.d/zabbix-java-gateway.conf
%config(noreplace) %{_sysconfdir}/zabbix/zabbix_java_gateway_logback.xml

%pre java-gateway
getent group zabbix > /dev/null || groupadd -r zabbix
getent passwd zabbix > /dev/null || \
	useradd -r -g zabbix -d %{_localstatedir}/lib/zabbix -s /sbin/nologin \
	-c "Zabbix Monitoring System" zabbix
:

%post java-gateway
%systemd_post zabbix-java-gateway.service
:

%preun java-gateway
if [ $1 -eq 0 ]; then
%systemd_preun zabbix-java-gateway.service
fi
:

%postun java-gateway
%systemd_postun_with_restart zabbix-java-gateway.service
:
%endif

%debug_package


#
# changelog
#

%changelog
* Thu Dec 23 2021 Zabbix Packager <info@zabbix.com> - 5.0.19-1
- update to 5.0.19

* Mon Nov 29 2021 Zabbix Packager <info@zabbix.com> - 5.0.18-1
- update to 5.0.18

* Mon Oct 18 2021 Zabbix Packager <info@zabbix.com> - 5.0.17-1
- update to 5.0.17

* Wed Sep 29 2021 Zabbix Packager <info@zabbix.com> - 5.0.16-1
- update to 5.0.16

* Mon Aug 30 2021 Zabbix Packager <info@zabbix.com> - 5.0.15-1
- update to 5.0.15

* Mon Jul 19 2021 Zabbix Packager <info@zabbix.com> - 5.0.14-1
- update to 5.0.14

* Mon Jun 28 2021 Zabbix Packager <info@zabbix.com> - 5.0.13-1
- update to 5.0.13
- denying web server access to vendor subdir in /usr/share/zabbix
- renamed config.patch to frontend.patch
- replaced conf file sed substitutions with patches

* Mon May 24 2021 Zabbix Packager <info@zabbix.com> - 5.0.12-1
- update to 5.0.12

* Mon Apr 26 2021 Zabbix Packager <info@zabbix.com> - 5.0.11-1
- update to 5.0.11

* Mon Mar 29 2021 Zabbix Packager <info@zabbix.com> - 5.0.10-1
- update to 5.0.10

* Mon Feb 22 2021 Zabbix Packager <info@zabbix.com> - 5.0.9-1
- update to 5.0.9

* Mon Jan 25 2021 Zabbix Packager <info@zabbix.com> - 5.0.8-1
- update to 5.0.8
- reworked spec file to allow selecting which packages are being built via macros (ZBX-18826)

* Mon Dec 21 2020 Zabbix Packager <info@zabbix.com> - 5.0.7-1
- update to 5.0.7

* Mon Nov 30 2020 Zabbix Packager <info@zabbix.com> - 5.0.6-1
- update to 5.0.6

* Mon Oct 26 2020 Zabbix Packager <info@zabbix.com> - 5.0.5-1
- update to 5.0.5
- replaced libssh2 with libssh on sles15

* Mon Sep 28 2020 Zabbix Packager <info@zabbix.com> - 5.0.4-1
- update to 5.0.4
- added separate zabbix-web-deps package
- creating empty log file for agent2 (ZBX-18243)

* Mon Aug 24 2020 Zabbix Packager <info@zabbix.com> - 5.0.3-1
- update to 5.0.3

* Mon Jul 13 2020 Zabbix Packager <info@zabbix.com> - 5.0.2-1
- update to 5.0.2
- removed ZBX-17801 patch
- updated php dependencies for zabbix-web and zabbix-apache-conf packages

* Thu May 28 2020 Zabbix Packager <info@zabbix.com> - 5.0.1-1
- update to 5.0.1
- added patch that fixes (ZBX-17801)

* Mon May 11 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-1
- update to 5.0.0

* Tue May 05 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.7rc1
- update to 5.0.0rc1
- moved frontends/php to ui directory

* Mon Apr 27 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.6beta2
- update to 5.0.0beta2

* Tue Apr 14 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.5beta1
- update to 5.0.0beta1

* Mon Mar 30 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.4alpha4
- update to 5.0.0alpha4

* Mon Mar 16 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.3alpha3
- update to 5.0.0alpha3

* Mon Feb 17 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.2alpha2
- update to 5.0.0alpha2

* Wed Feb 05 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.2alpha1
- added posttrans script that preserves /etc/zabbix/zabbix_agentd.d/userparameter_mysql.conf file

* Mon Jan 27 2020 Zabbix Packager <info@zabbix.com> - 5.0.0-0.1alpha1
- update to 5.0.0alpha1

* Thu Dec 19 2019  Zabbix Packager <info@zabbix.com> - 4.4.4-1
- update to 4.4.4
- added After=<database>.service directives to server and proxy service files

* Wed Nov 27 2019 Zabbix Packager <info@zabbix.com> - 4.4.3-1
- update to 4.4.3
- added User=zabbix and Group=zabbix directives to agent service file

* Mon Nov 25 2019 Zabbix Packager <info@zabbix.com> - 4.4.2-1
- update to 4.4.2

* Mon Oct 28 2019 Zabbix Packager <info@zabbix.com> - 4.4.1-1
- update to 4.4.1

* Mon Oct 07 2019 Zabbix Packager <info@zabbix.com> 4.4.0-1
- update to 4.4.0

* Thu Oct 03 2019 Zabbix Packager <info@zabbix.com> - 4.4.0-0.5rc1
- update to 4.4.0rc1

* Tue Sep 24 2019 Zabbix Packager <info@zabbix.com> - 4.4.0-0.4beta1
- update to 4.4.0beta1
- added zabbix-agent2 package

* Wed Sep 18 2019 Zabbix Packager <info@zabbix.com> - 4.4.0-0.3alpha3
- update to 4.4.0alpha3

* Thu Aug 15 2019 Zabbix Packager <info@zabbix.com> - 4.4.0-0.2alpha2
- update to 4.4.0alpha2

* Wed Jul 17 2019 Zabbix Packager <info@zabbix.com> - 4.4.0-0.1alpha1
- update to 4.4.0alpha1
- removed apache config from zabbix-web package
- added dedicated zabbix-apache-conf and zabbix-nginx-conf packages

* Fri Mar 29 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-1
- update to 4.2.0

* Tue Mar 26 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-0.6rc2
- update to 4.2.0rc2

* Mon Mar 18 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-0.5rc1
- update to 4.2.0rc1

* Mon Mar 04 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-0.4beta2
- update to 4.2.0beta2

* Mon Feb 18 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-0.1beta1
- update to 4.2.0beta1
- removed support for jabber and dependency on iksemel

* Mon Feb 04 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-0.3alpha3
- build of 4.2.0alpha3 with *.mo files

* Wed Jan 30 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-0.2alpha3
- added timescaledb.sql.gz to zabbix-server-pgsql package

* Mon Jan 28 2019 Zabbix Packager <info@zabbix.com> - 4.2.0-0.1alpha3
- update to 4.2.0alpha3

* Fri Dec 21 2018 Zabbix Packager <info@zabbix.com> - 4.2.0-0.2alpha2
- initial release of 4.2.0alpha2 (spec file copied and adjusted from Red Hat version)

