#!/bin/bash

# variable section

HOSTN=`/bin/hostname`
DOMN=`/bin/domainname -d`
####################


function strconta
{
string=$1
str=$2
if [ "${string}" != "${string/${str}/}" ]; then
   /bin/true
else
/bin/false
fi

}


sed -i 's/^[A-Z]/#&/g' /etc/zabbix/zabbix_agentd.conf
#command everithing else out



MNAME=""
VNAME=""
NEWHNAME=""
HANAVNAME=""

if  strconta ${HOSTN} ${DOMN}
then
NEWHNAME=${HOSTN}
else
NEWHNAME="${HOSTN}.${DOMN}"
fi

if [ -f /etc/mcollective/monsoonfacts.yaml ]
then
MNAME=`grep -w name /etc/mcollective/monsoonfacts.yaml| cut -d':' -f2 | sed 's/ //g'`
fi

if [ -f /etc/sysconfig/network/virtualip ]
then
VNAME=`cat /etc/sysconfig/network/virtualip|cut -f2 -d':'`
fi

if [ -f /usr/sap/sapservices ]
then
HANAVNAME=`cat /usr/sap/sapservices|awk -F 'pf=' '{print $2}'|awk -F '/' '{print $7}'|awk -F '_' '{print $3}'|awk '{print $1}'|tr -d [:space:]`
fi

function gencfg
{
echo "Hostname=${NEWHNAME}"

if [ "R${MNAME}R" != "RR" ]
then
HOSTMETA="${MNAME}.${DOMN}"
echo "HostMetadata=${HOSTMETA}"
fi

if [ "R${VNAME}R" != "RR" ]
then
HOSTMETA="${VNAME}.${DOMN}"
echo "HostMetadata=${HOSTMETA}"
fi

if [ "R${HANAVNAME}R" != "RR" ]
then
HOSTMETA="${HANAVNAME}.${DOMN}"
echo "HostMetadata=${HOSTMETA}"
fi
echo "Timeout=30"
echo "AllowKey=system.run[*]"
echo "Server=zbxproxy"
echo "ServerActive=zbxproxy"
echo "Include=/etc/zabbix/zabbix_agentd.conf.d/"
echo "LogFile=/var/log/zabbix/zabbix_agentd.log"
echo "PidFile=/run/zabbix/zabbix_agentd.pid"
}

#genetarate config items
gencfg >>/etc/zabbix/zabbix_agentd.conf

#adding zbxproxysales for dc40 nodes###
AGENTCONF="/etc/zabbix/zabbix_agentd.conf"

grep -iE 'Hostname=sc40|Hostname=pc40|Hostname=ss40|Hostname=ps40' $AGENTCONF
if [ $? -eq 0 ]
then
sed -i -e 's/^Server=zbxproxy$/Server=zbxproxysales/g' $AGENTCONF
sed -i -e 's/^ServerActive=zbxproxy$/ServerActive=zbxproxysales/g' $AGENTCONF
fi


grep -iE 'HostMetadata=sc40|HostMetadata=pc40|HostMetadata=ss40|HostMetadata=ps40' $AGENTCONF
if [ $? -eq 0 ]
then
sed -i -e 's/^Server=zbxproxy$/Server=zbxproxysales/g' $AGENTCONF
sed -i -e 's/^ServerActive=zbxproxy$/ServerActive=zbxproxysales/g' $AGENTCONF
fi
